-- MIKE TODO: This stored is not done yet.

create procedure dbo.internal_get_affected_objects_by_client_control
    @gobject_id  int
as
begin
    set nocount on

    create table #client_control_file_ids(
        file_id int
    )

    insert  #client_control_file_ids(file_id)
    (
        select  distinct p.file_id
        from    primitive_instance_file_table_link p
        where   p.gobject_id = @gobject_id
    )

    -- get files per primitive definition....
    select g.gobject_id gobject_id
    from   file_table f
    inner join #client_control_file_ids c on
            f.file_id = c.file_id
    inner join file_primitive_definition_link fpdl on 
              f.file_id = fpdl.file_id
    inner join primitive_definition pd on 
            fpdl.primitive_definition_id = pd.primitive_definition_id
    inner join template_definition td on 
            pd.template_definition_id = td.template_definition_id
    inner join gobject g on 
            g.template_definition_id = td.template_definition_id
    
    union
    
    -- get files per feature....
    select pifl.gobject_id gobject_id
    from file_table f
    inner join #client_control_file_ids c on
            f.file_id = c.file_id
    inner join feature_file_link ffl on
            f.file_id = ffl.file_id
    inner join feature fe on
            fe.feature_id = ffl.feature_id
    inner join primitive_instance_feature_link pifl on
            pifl.feature_id = fe.feature_id
      
    union
    -- get files per client control....
    
    select vev.gobject_id gobject_id
    from file_table f
    inner join #client_control_file_ids c on
            f.file_id = c.file_id
    inner join primitive_instance_file_table_link piftl on
            f.file_id = piftl.file_id
    inner join visual_element_version vev on
            piftl.gobject_id = vev.gobject_id and
            piftl.package_id = vev.package_id and
            piftl.mx_primitive_id = vev.mx_primitive_id
end


go

