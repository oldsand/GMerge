/**************************************************/
/*Object Name :  internal_get_manifest_template_instances		*/
/*Object Type :  Stored Proc.						*/
/*Purpose :    Procedure to get the instances of the Template*/
/*Used By :    CDI											*/
/**************************************************/
create proc dbo.internal_get_manifest_template_instances
(
@varviselemIdsOrFileOfIds nvarchar(4000)
)
as
begin    
	--CR L00114664 , edited the Query to retrieve instances of hierarchical object along with template instances

	create table  #viselem_table (viselem_id int)
	insert #viselem_table(viselem_id)
	exec internal_select_ids @varviselemIdsOrFileOfIds

	select distinct vw.visual_element_id,vw.visual_element_type from #viselem_table vids
		inner join visual_element_version vev 
		on vids.viselem_id = vev.visual_element_id
		inner join internal_visual_element_description_view vw
		on vw.inherited_from_visual_element_id = vev.inherited_from_visual_element_id
		where vw.tag_name not like '$%'

	drop table #viselem_table
end
go

