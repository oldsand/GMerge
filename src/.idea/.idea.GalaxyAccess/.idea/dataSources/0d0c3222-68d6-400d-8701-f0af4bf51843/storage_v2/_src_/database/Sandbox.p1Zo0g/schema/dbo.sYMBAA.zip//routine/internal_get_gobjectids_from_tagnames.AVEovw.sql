/*********************************************************************/
/*Object Name :  internal_get_gobjectids_from_tagnames              */
/*Object Type :  Stored Proc.                                       */
/*Purpose :    Used by GetGobjectIdsFromName to retrieve GobjectIDs */
/*Used By :    CDI                                                  */
/*******************************************************************/
CREATE  PROCEDURE [dbo].[internal_get_gobjectids_from_tagnames]

@FileNameOfNames nvarchar (265),
@NamespaceId int
 AS
begin
set nocount on


SET QUOTED_IDENTIFIER OFF

CREATE TABLE  #tagnames_table ( tag_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS not null)
CREATE TABLE  #results_table ( tag_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS not null, gobject_id int not null)
DECLARE @SQL nvarchar(2000)

SET @SQL = 'BULK INSERT #tagnames_table  FROM ''' + @FileNameOfNames + ''' WITH(TABLOCK, DATAFILETYPE=''widechar'')'

EXEC (@SQL)
begin tran
insert into #results_table(tag_name, gobject_id) 
            select tt.tag_name, 0 from #tagnames_table tt

update rt set rt.gobject_id = g.gobject_id  from #results_table rt inner join gobject g on rt.tag_name = g.tag_name and g.namespace_id = @NamespaceId
      
select gobject_id from #results_table

drop table #results_table
commit tran



end
go

