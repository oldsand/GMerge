CREATE proc dbo.internal_get_attributes_from_gobject_ids	
	@XMLDoc ntext,	@m_UserId int
	AS
begin

set rowcount 10000
set nocount on

DECLARE @iDoc int
EXECUTE sp_xml_preparedocument @iDoc OUTPUT, @XMLDoc	

DECLARE @idstable table( gobjectid int)

insert into @idstable(gobjectid)
	( select * from OpenXML(@iDoc, '/ROOT/GObject',1) WITH (gobjectid int) )



declare @packageids table(gobjectid int, packageid int) 

insert into @packageids( gobjectid, packageid ) 
( 
	select gobject_id , 
		case when checked_out_by_user_guid = user_guid then 
				2 
			else 
				1
			end as packageid 
	from gobject 
	inner join user_profile 
		on user_profile_id = @m_UserId
) 

declare @attributes table
(
	template_definition_id int, 
	primitive_definition_id int, 
	attribute_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS , 
	mx_attribute_id smallint, 
	mx_data_type int, 
	security_classification int, 
	mx_attribute_category int, 
	is_frequently_accessed bit,  
	is_array bit
)

insert into @attributes 
select primitive_definition.template_definition_id, primitive_definition.primitive_definition_id, 
		attribute_definition.attribute_name, 
		attribute_definition.mx_attribute_id, 
		attribute_definition.mx_data_type, 
		attribute_definition.security_classification, 
		attribute_definition.mx_attribute_category, 
		attribute_definition.is_frequently_accessed,
		attribute_definition.is_array 
from  primitive_definition primitive_definition  
 inner join attribute_definition attribute_definition  
 on attribute_definition.primitive_definition_id = primitive_definition.primitive_definition_id  

declare @resultstable table
(  
	tag_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS, 
	attribute_name nvarchar(361) COLLATE SQL_Latin1_General_CP1_CI_AS , 
	mx_data_type int, 
	area_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS , 
	original_template_tag_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS, 
	mx_attribute_category int, 
	derived_template_tag_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS, 
	is_frequently_accessed bit, 
	hierarchical_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
	security_classification int, 
	is_array bit
) 

insert into @resultstable 
	select gobject.tag_name,
	case when Len( primitive_instance.primitive_name ) > 0 then
	primitive_instance.primitive_name + '.' + attribute_definition.attribute_name else 
		attribute_definition.attribute_name 
	end as attribute_name, 
	case when template_attribute.mx_data_type is not null then 
			template_attribute.mx_data_type 
		else attribute_definition.mx_data_type 
	end	as  mx_data_type, 
	case when area.gobject_id is  null then '' 
		else area.tag_name 
	end as  area,
	template_definition.original_template_tagname, 
	attribute_definition.mx_attribute_category, 
	derived_from.tag_name, 
	attribute_definition.is_frequently_accessed, 
	gobject.hierarchical_name,
	case when template_attribute.security_classification is not null then
		template_attribute.security_classification 
	else attribute_definition.security_classification 
	end as security_classification,
	attribute_definition.is_array
		
	from gobject 
	left join gobject area 
	on area.gobject_id = gobject.area_gobject_id and gobject.gobject_id IN	( select gobjectid from @idstable)
	inner join template_definition template_definition 
	on template_definition.template_definition_id = gobject.template_definition_id 
	inner join gobject derived_from 
			on derived_from.gobject_id = gobject.derived_from_gobject_id and gobject.gobject_id IN	( select gobjectid from @idstable)
	inner join @attributes attribute_definition 
			on attribute_definition.template_definition_id = gobject.template_definition_id 
	inner join @packageids packageids 
			on packageids.gobjectid = gobject.gobject_id and gobject.gobject_id IN	( select gobjectid from @idstable)
	inner join primitive_instance 
			on primitive_instance.package_id = packageids.packageid  
			and primitive_instance.gobject_id  = packageids.gobjectid
			and primitive_instance.primitive_definition_id = attribute_definition.primitive_definition_id 
	inner join package templatepackage 
			on templatepackage.package_id = derived_from.checked_in_package_id 
	left join primitive_instance template_primitive 
			on template_primitive.gobject_id = derived_from.gobject_id
			and template_primitive.package_id = templatepackage.package_id  -- checked in package 
			and template_primitive.mx_primitive_id = primitive_instance.mx_primitive_id 
	left join template_attribute template_attribute 
			on template_attribute.gobject_id = derived_from.gobject_id 
			and template_attribute.package_id = templatepackage.package_id  -- checked in package
	and template_attribute.mx_attribute_id = attribute_definition.mx_attribute_id 
	where	attribute_name not like '[_]%' 
	and mx_attribute_category not in ( 0, 1, 17 ) 
	and  gobject.is_template < 1 

insert into @resultstable 
	select gobject.tag_name,  case when Len( primitive_instance.primitive_name ) > 0 then
		primitive_instance.primitive_name + '.' + dynamic_attribute.attribute_name else 
		dynamic_attribute.attribute_name 
	end as attribute_name, dynamic_attribute.mx_data_type, 
	case when area.gobject_id is  null then  '' 
	else area.tag_name 
	end as  area,
	template_definition.original_template_tagname,
	dynamic_attribute.mx_attribute_category, 
	derived_from.tag_name, 
	1,  
	gobject.hierarchical_name,
	dynamic_attribute.security_classification,
	dynamic_attribute.is_array
	 	
	from gobject 
	left join gobject area 
			on area.gobject_id = gobject.area_gobject_id and gobject.gobject_id IN	( select gobjectid from @idstable)
	inner join template_definition template_definition 
			on template_definition.template_definition_id = gobject.template_definition_id 
	inner join gobject derived_from 
			on derived_from.gobject_id = gobject.derived_from_gobject_id 
	inner join @packageids packageids 
			on packageids.gobjectid = gobject.gobject_id 
	inner join primitive_instance 
			on primitive_instance.gobject_id  = packageids.gobjectid	
			and primitive_instance.package_id = packageids.packageid  
	inner join dynamic_attribute dynamic_attribute 
			on dynamic_attribute.gobject_id = packageids.gobjectid
			and dynamic_attribute.package_id = packageids.packageid
	where gobject.gobject_id IN	( select gobjectid from @idstable) and
			attribute_name not like '[_]%' 
		and mx_attribute_category not in ( 0, 1, 17 ) 
		and  gobject.is_template < 1 
	order by gobject.tag_name
 
 
set rowcount 0 
 
select DISTINCT * from @resultstable order by tag_name, attribute_name 

EXECUTE sp_xml_removedocument @iDoc

end
go

