create procedure dbo.internal_package_upgrade_needed_gobject_list    
	-- comma separated list of visual element ids or file of ids
    @FileNameOfIds nvarchar(4000)
AS
SET NOCOUNT ON
begin

	declare @package_files table( file_id int )
	
	CREATE TABLE #Temp_files ( file_id int )
	
	insert #Temp_files(file_id)
    	exec internal_select_ids @FileNameOfIds


	insert into @package_files(file_id) 
		( SELECT distinct * FROM #Temp_files)

	DROP TABLE #Temp_files
	
        declare @gobjectids table 
        (
            gobject_id  int
        )

        insert  @gobjectids(gobject_id)
        (
            SELECT DISTINCT gobject.gobject_id
            FROM   file_primitive_definition_link 
            INNER JOIN primitive_definition ON 
	--file_primitive_definition_link.handler_clsid = primitive_definition.package_handler_clsid 
		   primitive_definition.primitive_definition_id
                   = file_primitive_definition_link.primitive_definition_id 
            INNER JOIN gobject ON 
                   primitive_definition.template_definition_id = gobject.template_definition_id
            WHERE (gobject.derived_from_gobject_id <> 0) AND --(primitive_definition.package_handler_clsid <> '{00000000-0000-0000-0000-000000000000}') AND
	    (
                file_primitive_definition_link.file_id IN 
	        (select * from @package_files ) and file_primitive_definition_link.is_needed_for_package = 1
            )
        )    

        insert  @gobjectids(gobject_id)
        (
            select  distinct pf.gobject_id
            from    primitive_instance_file_table_link pf inner join 
                    @package_files pa on pa.file_id = pf.file_id
        )

        select  distinct gobject_id 
        from    @gobjectids
end

go

