create proc dbo.internal_migrate_set_remoteplatformobjects_softwareupgraderequired
@FileNameOfIds nvarchar (265)
As
begin 

if exists(select id from sysobjects where name = 'migration_is_going_on')
    drop table migration_is_going_on

exec internal_bind_visual_element_references

--used by import
if ( LEN(@FileNameOfIds) > 0)
begin
	CREATE TABLE  #results_table ( gobject_id int)
	DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
	EXEC (@SQL)
	
	update gobject
	set     gobject.software_upgrade_needed = 1,
			gobject.deployed_package_id = gobject.checked_in_package_id,
			gobject.last_deployed_package_id = gobject.checked_in_package_id
	from   
	gobject inner join #results_table rt
	on gobject.gobject_id = rt.gobject_id
	
	
	drop table #results_table
end
else if exists(select '*' from deployed_objects) -- used by Upgrade 
begin
	update gobject
	set     gobject.software_upgrade_needed = 1,
			gobject.deployed_package_id = gobject.checked_in_package_id,
			gobject.last_deployed_package_id = gobject.checked_in_package_id
	from    
	gobject inner join deployed_objects
	on
	gobject.tag_name = deployed_objects.tag_name
	and 
	gobject.namespace_id = deployed_objects.namespace_id
end
			
declare @count int
set @count = 0
select  @count = count(*) from sysobjects where name = 'deployed_objects'
if (@count = 1)
begin
	drop table deployed_objects
end


end
go

