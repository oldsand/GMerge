-- this view becomes an indexed view and is used to increase
-- the performance of internal_mark_view_app_for_redeploy
--
-- contains gobject_ids of all view apps
CREATE  view dbo.internal_all_view_app_view with schemabinding as    
    select TOP 100 PERCENT 
            gobject_id,
            td.category_id
    from dbo.gobject g
    inner join dbo.template_definition td on
        g.template_definition_id = td.template_definition_id and        
        (  (td.category_id = 17 and g.is_template = 0)
        or (td.category_id = 26 and g.is_template = 1) )
        and g.derived_from_gobject_id <> 0
        order by td.category_id desc

go

