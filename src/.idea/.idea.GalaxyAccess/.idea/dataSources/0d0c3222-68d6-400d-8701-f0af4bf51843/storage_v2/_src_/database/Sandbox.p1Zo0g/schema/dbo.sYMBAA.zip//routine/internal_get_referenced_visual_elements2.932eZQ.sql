-- Returns the all visual elements referenced by
-- the set of visual elements in the input table 
-- The caller should have created the table
-- ALTER   table #visual_element_ids_for_referenced_elements(visual_element_id int)
-- Example:
--
--    exec internal_get_referenced_visual_elements 0, '7F0312F4-0D1E-4D8D-84E2-1DEA26A65237'
--
create proc dbo.internal_get_referenced_visual_elements2
(
    -- set to 0 to find direct references
    -- set to 1 to find direct and indirect references
    @recursive as bit,
 
    -- user making request, will affect results returned
    @user_guid uniqueidentifier
)
as begin

    create table  #final_selection 
    (
        visual_element_id int,
        gobject_id int,
        package_id int
    )

    create index final_selection_index on #final_selection (visual_element_id, gobject_id, package_id)

    declare @next_selection  table
    (
        visual_element_id int,
        gobject_id int,
        package_id int
    )
 
    while( 1 = 1 )
    begin   
        
        insert into @next_selection   

            select 
                bound_vev.visual_element_id, 
                vev.gobject_id, 
                vev.package_id
            from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id and
                bver.package_id = vev.package_id and
                bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
            where bound_vev.visual_element_id not in 
            (select visual_element_id from #final_selection)
        union
            select 
                bound_vev.visual_element_id, 
                vev.gobject_id, 
                vev.package_id
            from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id and
                bver.package_id = vev.package_id and
                bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
            where bound_vev.visual_element_id not in 
            (select visual_element_id from #final_selection)

        

        delete from @next_selection where dbo.is_package_visible_to_user( gobject_id, package_id, @user_guid ) = 0		
	    truncate table #visual_element_ids_for_referenced_elements 		

        insert into #visual_element_ids_for_referenced_elements
	        select visual_element_id from @next_selection 

	    insert into #final_selection
	         select * from @next_selection 

         delete from @next_selection
 
        
    if( (@@ROWCOUNT = 0) or (@recursive = 0) )
      break
    end

   insert into #visual_element_ids_for_required_file(visual_element_id) 
   select visual_element_id from #final_selection

   drop table #final_selection

 
end

go

