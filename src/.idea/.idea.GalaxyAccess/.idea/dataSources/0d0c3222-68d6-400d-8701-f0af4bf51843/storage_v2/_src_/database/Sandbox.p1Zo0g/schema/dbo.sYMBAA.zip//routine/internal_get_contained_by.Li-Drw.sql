/**************************************************/
/*Object Name :  internal_get_contained_by				*/
/*Object Type :  Stored Proc.										*/
/*Purpose :    Procedure to find out the conatined_by_gobject_id and its tagname*/
/*Used By :    CDI													*/
/**************************************************/
create proc dbo.internal_get_contained_by
@tagname nvarchar(329),
@containedbygobject_id int out,
@containedbytagname    nvarchar(329) out
as
begin
set @containedbytagname = ''
set @containedbygobject_id = (select contained_by_gobject_id from gobject where tag_name = @tagname and namespace_id = 1)
if ( @containedbygobject_id > 0 )
  exec internal_get_tag_name @containedbygobject_id,@containedbytagname out

end
go

