
/*
This procedure will verify that input gobject_id = is_partner_deployed or not
usage:
declare @P1 int
exec internal_is_my_partner_deployed
     gobject_id = 23, @P1
*/
CREATE  PROCEDURE dbo.internal_is_my_partner_deployed
@gobject_id  int,
@is_partner_deployed int  OUTPUT
 AS
begin
SET NOCOUNT ON
	set @is_partner_deployed = dbo.is_partner_deployed(@gobject_id)

end
go

