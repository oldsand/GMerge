-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*Object Name :  internal_remove_control_class_link						      */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To update the link table entries for a client control*/
/*Used By	  :  internal_delete_fsobject											  */
/**********************************************************************/

create PROCEDURE dbo.internal_remove_control_class_link
(
    @gobject_id int    
)
as
begin
set nocount  on

delete from 
	client_control_class_link
where 
	gobject_id = @gobject_id


end
go

