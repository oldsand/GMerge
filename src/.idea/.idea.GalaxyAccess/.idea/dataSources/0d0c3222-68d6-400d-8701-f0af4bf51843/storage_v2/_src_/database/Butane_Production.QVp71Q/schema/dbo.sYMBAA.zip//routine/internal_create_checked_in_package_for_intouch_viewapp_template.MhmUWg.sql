
--Client must first ALTER  #template_ids_table table ( id int) before calling this stored procedure
--Client stored procs : internal_mark_view_app_for_redeploy
create       proc dbo.internal_create_checked_in_package_for_intouch_viewapp_template
as
begin
begin tran


	insert into package
	(
		gobject_id,
		status_id,
		reference_status_id,
		operation_status,
		security_group,
		derived_from_package_id,
		    deployable_configuration_version,
		    package_type,
		    package_version
	)
	select
		idtable.id,
		p.status_id,
		p.reference_status_id,
		1,
		p.security_group,
		p.derived_from_package_id,
		    p.deployable_configuration_version + 1,
		    'I',
		    p.package_version + 1
	from
			#template_ids_table idtable
			inner join package p
				on p.gobject_id = idtable.id
			inner join gobject g
				on g.gobject_id = idtable.id
				and g.checked_in_package_id = p.package_id



-- Update the gobject row temporary
		update	gobject
		set		gobject.deployed_package_id = package.package_id
		from	gobject gobject
		inner join #template_ids_table idTable
		on	gobject.gobject_id = idTable.id
		inner join package
		on package.gobject_id = gobject.gobject_id
		where package.operation_status = 1
	
    declare @new_timestamp bigint
    exec internal_get_next_timestamp @new_timestamp out

	-- Now make a copy of the primitive instance
	insert into primitive_instance
	(
		gobject_id,
		package_id,
		mx_primitive_id,
		primitive_definition_id,
		primitive_name,
		parent_mx_primitive_id,
		execution_group,
		execution_order,
		owned_by_gobject_id,
		extension_type,
		is_object_extension,
		checked_in_primitive_version,
		checked_out_primitive_version,
        timestamp_of_last_change,
        max_child_timestamp,
		entity_change_type,
		operation_on_primitive_mask,
		created_by_parent,
		status_id,
		ref_status_id,
		primitive_attributes,
		mx_value_errors,
		mx_value_warnings,
		mx_value_reference_warnings				
	)
	select
		gobject.gobject_id,
		gobject.deployed_package_id,
		mx_primitive_id,
		primitive_definition_id,
		primitive_name,
		parent_mx_primitive_id,
		execution_group,
		execution_order,
		owned_by_gobject_id,
		extension_type,
		is_object_extension,
		checked_in_primitive_version,
		checked_out_primitive_version,
        @new_timestamp,
        max_child_timestamp,
		1,
		0,
        created_by_parent,
		status_id,
		ref_status_id,
		primitive_attributes,
		mx_value_errors,
		mx_value_warnings,
		mx_value_reference_warnings		
		
	from
			gobject
			inner join #template_ids_table idTable
			on idTable.id = gobject.gobject_id
			inner join	primitive_instance primitive_instance
			on primitive_instance.package_id = gobject.checked_in_package_id
		


		-- make a copy of the attribute_reference
		insert into attribute_reference
		(
		  gobject_id,
		  package_id,
		  referring_mx_primitive_id,
		  referring_mx_attribute_id,
		  element_index,
		  resolved_gobject_id,
		  reference_string,
		  context_string,
		  object_signature,
		  resolved_mx_primitive_id,
		  resolved_mx_attribute_id,
		  resolved_mx_property_id,
		  attribute_signature,
		  lock_type,
		  is_valid,
		  attr_res_status,
		  attribute_index	
		)
		select 
  		  gobject.gobject_id,
		  gobject.deployed_package_id,
		  referring_mx_primitive_id,
		  referring_mx_attribute_id,
		  element_index,
		  resolved_gobject_id,
		  reference_string,
		  context_string,
		  object_signature,
		  resolved_mx_primitive_id,
		  resolved_mx_attribute_id,
		  resolved_mx_property_id,
		  attribute_signature,
		  lock_type,
		  is_valid,attr_res_status,
		  attribute_index		
		from
			gobject
			inner join #template_ids_table idTable
				on idTable.id = gobject.gobject_id
            inner join attribute_reference ar
			    on ar.gobject_id = gobject.gobject_id 
				and ar.package_id = gobject.checked_in_package_id


		-- Template attribute
		insert into template_attribute
		(
			gobject_id,
			package_id,
			mx_primitive_id,
			mx_attribute_id,
			security_classification,
			mx_data_type,
			mx_value,
			lock_type,
			original_lock_type
		)
		select 
			gobject.gobject_id,
			gobject.deployed_package_id, 	
			ta.mx_primitive_id,
			ta.mx_attribute_id,       				-- mx_attribute_id
			ta.security_classification, 			-- security_classification
			ta.mx_data_type, 						-- mx_data_type
			ta.mx_value, 							-- mx_value
			ta.lock_type,              				-- lock_type
			ta.lock_type							-- original_lock_type
		from 
		    gobject inner join #template_ids_table idTable on idTable.id = gobject.gobject_id
			        inner join template_attribute ta 
					on ta.package_id = gobject.checked_in_package_id and 	
					   ta.gobject_id = gobject.gobject_id
		
		-- Now make a copy of dynamic attributes
		insert into dynamic_attribute
		(
			gobject_id,
			package_id,
			mx_primitive_id,
			mx_attribute_id,
			attribute_name,
			mx_data_type,
			is_array,
			security_classification,
			mx_attribute_category,
			lock_type,
			mx_value,
			owned_by_gobject_id,
			original_lock_type,
			dynamic_attribute_type,
			bitvalues

		)
		select 
			gobject.gobject_id,
			gobject.deployed_package_id,
			da.mx_primitive_id,
			da.mx_attribute_id,       
			da.attribute_name,
			da.mx_data_type,
			da.is_array,
			da.security_classification,
			da.mx_attribute_category,
			da.lock_type,
			da.mx_value,
			da.owned_by_gobject_id,
			da.lock_type,
			da.dynamic_attribute_type,
			da.bitvalues        
        
		
		from 	
			gobject inner join #template_ids_table idTable on idTable.id = gobject.gobject_id
					inner join dynamic_attribute da 
					on da.package_id = gobject.checked_in_package_id and 
					   da.gobject_id = gobject.gobject_id
		

		-- Now make a copy of features
		insert into primitive_instance_feature_link
		(
			gobject_id,
			package_id,
			mx_primitive_id,
			feature_id,
			feature_name,
			feature_type
		)
		select
		    	gobject.gobject_id,
			gobject.deployed_package_id,
			f.mx_primitive_id,
			f.feature_id,
			f.feature_name,
			f.feature_type
		from
			gobject inner join #template_ids_table idTable on idTable.id = gobject.gobject_id
					inner join primitive_instance_feature_link f
					on f.package_id = gobject.checked_in_package_id and
					   f.gobject_id = gobject.gobject_id
		
        
        -- now, make a copy of the visual elements
        insert into visual_element_version
           (gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_id,    
            inherited_from_gobject_id,
            inherited_from_package_id,
            inherited_from_mx_primitive_id ,
            inherited_from_visual_element_id)
        select distinct
            vev.gobject_id,            
            g.deployed_package_id,
            vev.mx_primitive_id,
            vev.visual_element_id,
            vev.inherited_from_gobject_id,
			case when vev.inherited_from_package_id = vev.package_id then
					g.checked_in_package_id
			else
				vev.inherited_from_package_id 
			end,				
            vev.inherited_from_mx_primitive_id,
            vev.inherited_from_visual_element_id
        
		from gobject g 
		inner join #template_ids_table idTable
		        on idTable.id = g.gobject_id
        inner join visual_element_version vev on vev.package_id = g.checked_in_package_id
		


	insert into owned_visual_element
           (gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_id,
            thumbnail,
            description,
            visual_element_definition,
            is_thumbnail_dirty)
        select 
            o.gobject_id,
            g.checked_in_package_id,
            o.mx_primitive_id,
            o.visual_element_id,
            o.thumbnail,
            o.description,
            o.visual_element_definition,
	    o.is_thumbnail_dirty
        from gobject g 
		inner join #template_ids_table idTable
		        on idTable.id = g.gobject_id
        inner join owned_visual_element o
                on g.checked_in_package_id = o.package_id
		

-- add visual_element_references...
        insert into visual_element_reference
        (   gobject_id ,
            package_id ,
            mx_primitive_id ,    
            visual_element_reference_index ,
            --visual_element_bind_status ,-- now a calculated column..
            is_relative_reference ,
            -- bound section...
            checked_in_bound_visual_element_gobject_id ,
            checked_in_bound_visual_element_package_id ,
            checked_in_bound_visual_element_mx_primitive_id ,
            checked_out_bound_visual_element_gobject_id ,
            checked_out_bound_visual_element_package_id ,
            checked_out_bound_visual_element_mx_primitive_id ,
            -- unbound section
            checked_in_unbound_visual_element_name ,
            checked_in_unbound_visual_element_type ,
            checked_in_unbound_tag_name  ,
            checked_in_unbound_primitive_name ,
            checked_in_unbound_relative_object_name ,
            checked_in_unbound_visual_element_id ,
            checked_out_unbound_visual_element_name ,
            checked_out_unbound_visual_element_type ,
            checked_out_unbound_tag_name ,
            checked_out_unbound_primitive_name ,
            checked_out_unbound_relative_object_name ,
            checked_out_unbound_visual_element_id ,
            checked_out_visual_element_package_id ,
            checked_out_to_user_guid)

        select
            v.gobject_id ,
            g.deployed_package_id ,
            v.mx_primitive_id ,    
            v.visual_element_reference_index ,
            --v.visual_element_bind_status ,-- now a calculated column..
            v.is_relative_reference ,
            -- bound section...
            v.checked_in_bound_visual_element_gobject_id ,
            v.checked_in_bound_visual_element_package_id ,
            v.checked_in_bound_visual_element_mx_primitive_id ,
            v.checked_out_bound_visual_element_gobject_id ,
            v.checked_out_bound_visual_element_package_id ,
            v.checked_out_bound_visual_element_mx_primitive_id ,
            -- unbound section
            v.checked_in_unbound_visual_element_name ,
            v.checked_in_unbound_visual_element_type ,
            v.checked_in_unbound_tag_name  ,
            v.checked_in_unbound_primitive_name ,
            v.checked_in_unbound_relative_object_name ,
            v.checked_in_unbound_visual_element_id ,
            v.checked_out_unbound_visual_element_name ,
            v.checked_out_unbound_visual_element_type ,
            v.checked_out_unbound_tag_name ,
            v.checked_out_unbound_primitive_name ,
            v.checked_out_unbound_relative_object_name ,
            v.checked_out_unbound_visual_element_id ,
            v.checked_out_visual_element_package_id ,
            v.checked_out_to_user_guid
		from gobject g 
		inner join #template_ids_table idTable
		        on idTable.id = g.gobject_id
        inner join visual_element_reference v on v.package_id = g.checked_in_package_id
        
		
        insert into primitive_instance_file_table_link
            (gobject_id,
            package_id,
            mx_primitive_id,
            file_id,
            is_needed_for_package,
            is_needed_for_runtime,
            is_needed_for_editor)        
        select 
        p.gobject_id,
        g.deployed_package_id,
        p.mx_primitive_id,
        p.file_id,
        p.is_needed_for_package,
        p.is_needed_for_runtime,
        p.is_needed_for_editor

		from gobject g 
        inner join #template_ids_table idTable
                on idTable.id = g.gobject_id
        inner join primitive_instance_file_table_link p 
                on p.package_id = g.checked_in_package_id

-- Update the gobject row
		update	gobject
		set		gobject.checked_in_package_id = gobject.deployed_package_id,
				gobject.configuration_version =  gobject.configuration_version + 1,
				gobject.deployed_package_id = 0
		from	gobject gobject
		inner join #template_ids_table idTable
		on	gobject.gobject_id = idTable.id
		inner join package
		on package.gobject_id = gobject.gobject_id
		where package.operation_status = 1



--update package status
		update	package
		set		package.operation_status = 0
		from #template_ids_table idTable
		inner join gobject
			on	gobject.gobject_id = idTable.id
		inner join package
			on	gobject.checked_in_package_id = package.package_id
        
commit tran
end
go

