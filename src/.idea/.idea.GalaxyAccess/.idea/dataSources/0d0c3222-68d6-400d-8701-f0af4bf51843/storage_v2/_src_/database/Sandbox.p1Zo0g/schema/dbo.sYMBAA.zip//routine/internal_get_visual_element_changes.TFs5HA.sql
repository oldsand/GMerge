create procedure dbo.internal_get_visual_element_changes
@last_known_timestamp bigint,
@user_guid uniqueidentifier,
@latestDBTS bigint out
as

begin tran

declare @filtered_visual_element_changes table(
	visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	visual_element_id int,
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
	change_type int,
	timestamp_of_last_change bigint)

declare @filtered_renamed_visual_element table(
	visual_element_id int,
	old_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	new_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
	timestamp_of_rename bigint)

declare @filtered_deleted_visual_element table(
	visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
	timestamp_of_delete bigint,
	visual_element_id int)



-- return empty datasets if there are no changes...
select 
	@latestDBTS = max_visual_element_timestamp
from galaxy with(nolock) 

if(@last_known_timestamp = @latestDBTS)
begin
	select *
	from @filtered_visual_element_changes
	where 1=0

	select *
	from @filtered_renamed_visual_element
	where 1=0

	select *
	from @filtered_deleted_visual_element
	where 1=0

	commit
	return
end


declare @raw_visual_element_changes table(
	visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	visual_element_id int,
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
	change_type int,
	timestamp_of_last_change bigint)

-- Handle changed visual elements...
insert into @raw_visual_element_changes	
select 
	v.visual_element_name,
	v.visual_element_id,
	v.visual_element_type,
	vet.change_type,
	vet.timestamp_of_last_change
from internal_visual_element_timestamp_per_user_view vet with(nolock)
inner join internal_visual_element_description_per_user_view v with(nolock)  on
	vet.visual_element_id = v.visual_element_id and
	v.user_guid = @user_guid
where 
	vet.timestamp_of_last_change > @last_known_timestamp and
	vet.user_guid = @user_guid and 
	vet.change_type <> 0

-- Handle inherited visual elements...
insert into @raw_visual_element_changes	
select 
	v.visual_element_name,
	v.visual_element_id,
	v.visual_element_type,
	vec.change_type,
	vec.timestamp_of_last_change
from @raw_visual_element_changes vec
inner join internal_visual_element_description_per_user_view v with(nolock) on
	v.inherited_from_visual_element_id = vec.visual_element_id
	

-- Handle visual elements affected by "undo check out."
insert into @raw_visual_element_changes	
select 
	v.visual_element_name,
	v.visual_element_id,
	v.visual_element_type,
	v.change_type,
	v.timestamp_of_last_change
from visual_element_affected_by_undo_check_out v with(nolock) 
where 
	v.timestamp_of_last_change > @last_known_timestamp and
	v.check_out_undone_by_user_guid = @user_guid


-- now, filter these results:
-- 1) No duplicate change types per visual_element



	declare @visual_element_name nvarchar(329)
	declare @visual_element_id int
	declare @visual_element_type nvarchar(32)
	declare @change_type int
	declare @timestamp_of_last_change bigint

select top(1)
	@visual_element_name = visual_element_name,
	@visual_element_id = visual_element_id,
	@visual_element_type = visual_element_type,
	@change_type = change_type,
	@timestamp_of_last_change = timestamp_of_last_change
from @raw_visual_element_changes

while (@@rowcount > 0)
begin

insert into @filtered_visual_element_changes(	
	visual_element_name ,
	visual_element_id ,
	visual_element_type ,
	change_type ,
	timestamp_of_last_change )
select
	@visual_element_name ,
	@visual_element_id ,
	@visual_element_type ,
	@change_type ,
	@timestamp_of_last_change
where not exists
	(select '*'
	from @filtered_visual_element_changes
	where
		visual_element_name = @visual_element_name and
		visual_element_id = @visual_element_id and
		change_type = @change_type)

delete
from @raw_visual_element_changes
where 
	@visual_element_name = visual_element_name and
	@visual_element_id = visual_element_id and
	@visual_element_type = visual_element_type and
	@change_type = change_type and
	@timestamp_of_last_change = timestamp_of_last_change


select top(1)
	@visual_element_name = visual_element_name,
	@visual_element_id = visual_element_id,
	@visual_element_type = visual_element_type,
	@change_type = change_type,
	@timestamp_of_last_change = timestamp_of_last_change 
from @raw_visual_element_changes

end

-- renamed visual element section
declare @raw_renamed_visual_element table(
	visual_element_id int,
	old_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	new_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
	timestamp_of_rename bigint
)

insert into @raw_renamed_visual_element
select 
	rve.visual_element_id,
	rve.old_visual_element_name,
	rve.new_visual_element_name,
	rve.visual_element_type,
	rve.timestamp_of_rename
from renamed_visual_element rve with(nolock) 
inner join gobject g_checked_out with(nolock) on
	 g_checked_out.gobject_id = rve.gobject_id and
	 g_checked_out.checked_out_package_id = rve.package_id and
	 g_checked_out.checked_out_by_user_guid = @user_guid
where rve.timestamp_of_rename > @last_known_timestamp
union
select 
	rve.visual_element_id,
	rve.old_visual_element_name,
	rve.new_visual_element_name,
	rve.visual_element_type,
	rve.timestamp_of_rename
from renamed_visual_element rve with(nolock) 
where rve.timestamp_of_rename > @last_known_timestamp and
	rve.package_id not in 
	(
		select checked_out_package_id 
		from gobject with(nolock) 
		where checked_out_package_id  > 0
	)

-- Apply filter:
-- 1) No duplicate visual_element_id, visual_element_names and type

declare	@old_visual_element_name nvarchar(329)
declare	@new_visual_element_name nvarchar(329)
declare @timestamp_of_rename bigint

select top(1)
	@visual_element_id = visual_element_id,
	@old_visual_element_name = old_visual_element_name,
	@new_visual_element_name = new_visual_element_name,
	@visual_element_type = visual_element_type,
	@timestamp_of_rename = timestamp_of_rename
from @raw_renamed_visual_element

while(@@rowcount > 0)
begin
	insert into @filtered_renamed_visual_element(
		visual_element_id ,
		old_visual_element_name ,
		new_visual_element_name ,
		visual_element_type,
		timestamp_of_rename)
	select
		@visual_element_id ,
		@old_visual_element_name ,
		@new_visual_element_name ,
		@visual_element_type,
		@timestamp_of_rename
	where not exists(
		select '*'
		from @filtered_renamed_visual_element
		where
			visual_element_id = @visual_element_id and
			old_visual_element_name = @old_visual_element_name and
			new_visual_element_name = @new_visual_element_name and
			visual_element_type = @visual_element_type)
	
	delete
	from @raw_renamed_visual_element
	where
		visual_element_id = @visual_element_id and
		old_visual_element_name = @old_visual_element_name and
		new_visual_element_name = @new_visual_element_name and
		visual_element_type = @visual_element_type and
		timestamp_of_rename = @timestamp_of_rename

	select top(1)
		@visual_element_id = visual_element_id,
		@old_visual_element_name = old_visual_element_name,
		@new_visual_element_name = new_visual_element_name,
		@visual_element_type = visual_element_type,
		@timestamp_of_rename = timestamp_of_rename
	from @raw_renamed_visual_element
		

end


-- Return dataset #1 to caller: changed visual elements
select 
	visual_element_name ,
	visual_element_id ,
	visual_element_type ,
	change_type ,
	timestamp_of_last_change
from @filtered_visual_element_changes
order by timestamp_of_last_change

-- Return dataset #2 to caller: renamed visual elements
select 
	visual_element_id ,
	old_visual_element_name ,
	new_visual_element_name ,
	visual_element_type ,
	timestamp_of_rename 
from @filtered_renamed_visual_element
order by timestamp_of_rename


--deleted visual elements
declare @raw_deleted_visual_element table(
	visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
	timestamp_of_delete bigint,
	visual_element_id int)

insert into @raw_deleted_visual_element
select 
	dvev.visual_element_name,
	dvev.visual_element_type,
	dvev.timestamp_of_delete,
	dvev.visual_element_id
from deleted_visual_element_version dvev with(nolock)
inner join gobject g_checked_out with(nolock) on
	 g_checked_out.gobject_id = dvev.gobject_id and
	 g_checked_out.checked_out_package_id = dvev.package_id and
	 g_checked_out.checked_out_by_user_guid = @user_guid
where timestamp_of_delete > @last_known_timestamp
union
select 
	dvev.visual_element_name,
	dvev.visual_element_type,
	dvev.timestamp_of_delete,
	dvev.visual_element_id
from deleted_visual_element_version dvev with(nolock)
where timestamp_of_delete > @last_known_timestamp and
	dvev.package_id not in 
	(
		select checked_out_package_id 
		from gobject
		where checked_out_package_id  > 0
	)


declare @timestamp_of_delete bigint

select top(1)
	@visual_element_name = visual_element_name,
	@visual_element_type = visual_element_type,
	@timestamp_of_delete = timestamp_of_delete,
	@visual_element_id = visual_element_id
from @raw_deleted_visual_element

while(@@rowcount > 0)
begin
	insert into @filtered_deleted_visual_element(
		visual_element_name,
		visual_element_type,
		timestamp_of_delete,
		visual_element_id)
	select
		@visual_element_name,
		@visual_element_type,
		@timestamp_of_delete,
		@visual_element_id
	where not exists(
		select '*'
		from @filtered_deleted_visual_element
		where 
			@visual_element_name = visual_element_name and
			@visual_element_type = visual_element_type)
	
	delete 
	from @raw_deleted_visual_element
	where 
		@visual_element_name = visual_element_name and
		@visual_element_type = visual_element_type and
		@timestamp_of_delete = timestamp_of_delete 

	select top(1)
		@visual_element_name = visual_element_name,
		@visual_element_type = visual_element_type,
		@timestamp_of_delete = timestamp_of_delete,
		@visual_element_id = visual_element_id
	from @raw_deleted_visual_element
	
end

select 
		visual_element_name,
		visual_element_type,
		timestamp_of_delete,
		visual_element_id
from @filtered_deleted_visual_element
order by timestamp_of_delete


commit

go

