/**************************************************/
/*Object Name :  internal_get_all_visible_templates				*/
/*Object Type :  Stored Proc.						*/
/*Purpose	  :  stored procedure to get the visible templates */
/*Used By	  :  package server net								*/
/*Return Values: */
/**************************************************/
create procedure [dbo].[internal_get_all_visible_templates]
	@bIsDepthZeroSpecified bit = 0
As
begin 
	set nocount on

	if @bIsDepthZeroSpecified = 0
		begin
			select fg.gobject_id 
			from folder_gobject_link fg 
			inner join folder fd on fg.folder_id = fd.folder_id
	inner join gobject gobj
			on gobj.gobject_id = fg.gobject_id
	and gobj.is_template = 1
			order by  fd.folder_id
		end
	else
		begin
			select fg.gobject_id 
			from folder_gobject_link fg 
			inner join folder fd on fg.folder_id = fd.folder_id
			inner join gobject gobj on gobj.gobject_id = fg.gobject_id
			and gobj.is_template = 1
			and gobj.contained_by_gobject_id = 0
			order by  fd.folder_id
		end

	
end
go

