/*
** Returns: ---This will return all Top level UDO templates which has FA in itself or it's child. And non of them are checkedout, deployed or protected.
** Algorithm: 
** 
*/
--exec internal_get_convertible_fa_list
create procedure dbo.internal_get_convertible_fa_list
as
begin

	set nocount on

	declare @ResultSet table( 
					TopTemplateId int, IsConvertable int, protected int, FA_CNT smallint);

	declare @NotCnvertableFinalSet table( 
					TopTemplateId int, NotConvertable smallint);

	declare @HasFAFinalSet table( 
					TopTemplateId int, hasFA_CNT smallint);

	WITH DirectReports (TopTemplateId, derived_from_gobject_id, gobject_id, IsConvertable, Level)
	AS
	(
	-- Anchor member definition
		SELECT e.gobject_id, NULL, e.gobject_id, case when ( e.checked_out_package_id = 0 and e.deployed_package_id = 0) then 1 else 0 end IsConvertable,
			1 AS Level
		FROM dbo.gobject AS e		
		WHERE derived_from_gobject_id = (select gobject_id from gobject where tag_name = '$UserDefined')
		UNION ALL
	-- Recursive member definition
		SELECT d.TopTemplateId, d.gobject_id, e.gobject_id, case when  ( e.checked_out_package_id = 0 and e.deployed_package_id = 0) then 1 else 0 end IsConvertable,
			Level + 1
		FROM dbo.gobject AS e    
		INNER JOIN DirectReports AS d
			ON d.gobject_id = e.derived_from_gobject_id

	)

	insert @ResultSet
	SELECT distinct d.TopTemplateId, d.IsConvertable, gp.gobject_id as protected, FA_Primitives.FA_CNT
	FROM DirectReports d
	inner join gobject g
	on g.gobject_id = d.gobject_id
	left outer join gobject_protected gp
	on gp.gobject_id = d.gobject_id
	CROSS APPLY (select      cast(COUNT(*) as smallint) as FA_CNT from primitive_instance sg_pi
									  inner join primitive_definition pd
													on pd.primitive_definition_id = sg_pi.primitive_definition_id 												
											   where sg_pi.gobject_id = g.gobject_id
													and sg_pi.package_id = g.checked_in_package_id
													and template_definition_id in (select template_definition_id from gobject where tag_name = '$UserDefined')												
													and pd.primitive_name in (N'AnalogUtilities', N'BooleanUtilities')
						 ) FA_Primitives

				  
	insert @HasFAFinalSet
	select distinct TopTemplateId, HAS_FA.CNT from @ResultSet rt
	CROSS APPLY (select      cast(COUNT(*) as smallint) as CNT from @ResultSet res 
								where res.TopTemplateId = rt.TopTemplateId                                 												                                           
								and (res.FA_CNT > 0)
						 ) HAS_FA

	delete from @ResultSet where TopTemplateId not in (select TopTemplateId from @HasFAFinalSet h where h.hasFA_CNT > 0)
	--Now @ResultSet has all Top template which has FA

	--select f.*, g.tag_name from @ResultSet f
	--inner join gobject g
	--on g.gobject_id = f.TopTemplateId
	
	insert @NotCnvertableFinalSet
	select distinct TopTemplateId, NOT_CONVERT.CNT from @ResultSet rt
	CROSS APPLY (select      cast(COUNT(*) as smallint) as CNT from @ResultSet res 
								where res.TopTemplateId = rt.TopTemplateId                                 												                                           
								and (res.protected is not null or res.IsConvertable != 1)
						 ) NOT_CONVERT

	select f.TopTemplateId,
	case when ( f.NotConvertable = 0 ) then 1 else 0 end IsConvertable,
	g.tag_name
	  from @NotCnvertableFinalSet f
	  inner join gobject g
	 on g.gobject_id = f.TopTemplateId

 end

go

