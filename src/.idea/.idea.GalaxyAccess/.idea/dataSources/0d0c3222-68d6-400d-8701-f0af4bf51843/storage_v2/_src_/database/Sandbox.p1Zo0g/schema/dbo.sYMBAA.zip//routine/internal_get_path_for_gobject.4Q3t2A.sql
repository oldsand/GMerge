create proc dbo.internal_get_path_for_gobject
	@gobjectId int,
    @folder_type smallint,
    @path nvarchar(650) out
As
set nocount on
    declare @folderId int
    
	select @folderId = folder_id from folder_gobject_link
    where gobject_id = @gobjectId and folder_type = @folder_type

    exec internal_get_path @folderId,@path out

set nocount off

go

