/*
** Procedure [internal_ab_get_autobound_reference]
** This is expected to be invoked by the IDE (via FSObject) to retrieve and display an autobound reference.
** For this reason, this query doesn't care about the validity of the UDA on behalf of which this query is executed.
*/
CREATE PROCEDURE dbo.internal_ab_get_autobound_reference
    @attr_name nvarchar(329) -- Attribute reference being sought (e.g.: uda1.InputSource)
  , @gobject_id  int = 0
as
begin
  set nocount on
  declare @attr_ref nvarchar(329) = NULL
  declare @qual_ref nvarchar(329) = NULL
  declare @dio_name nvarchar(329)
  declare @sg_name  nvarchar(329)
  declare @dio_id int = 0
  declare @sg_mx_primitive_id smallint = 0
  declare @ao_name  nvarchar(329)
  declare @uda_name nvarchar(329)
  declare @io_attr  nvarchar(329)  -- 'InputSource'|'OutputDest'

  -- Split the passed @attr_name into its components
  SELECT @io_attr  = io_attr_ref
       , @uda_name = ao_attr
       , @ao_name  = ao_tag_name 
    FROM itvfabSplitAttrRef (@attr_name)

  if @gobject_id = -1 
  begin
    -- Deployment functionality typically invokes this sproc with a @gobject_id of -1
    -- If @gobject_id == -1, @attr_name will contain the following information: "gobject_id.uda_primitive_id.uda_attribute_id"
    -- The call to itvfabSplitAttrRef will have split @attr_name into the three IDs
    declare @prim_id int
    declare @attr_id int

    -- The conversion of char to int in the following assignments is implicit
    set @gobject_id = @ao_name
    set @prim_id    = @uda_name
    set @attr_id    = @io_attr

    SELECT @ao_name                               = lo.tag_name
         , @uda_name                              = lo_pi.primitive_name
         , @io_attr                               = lo_attr_def.attribute_name
         , @dio_id                                = odl.dio_id
         , @sg_mx_primitive_id                    = odl.sg_mx_primitive_id
      FROM object_device_linkage odl
    INNER JOIN gobject lo
        ON lo.gobject_id                          = odl.gobject_id
    INNER JOIN attribute_reference lo_attr_ref
        ON lo_attr_ref.gobject_id                 = lo.gobject_id
       AND lo_attr_ref.package_id                 = lo.checked_in_package_id
       AND lo_attr_ref.referring_mx_primitive_id  = @prim_id
       AND lo_attr_ref.referring_mx_attribute_id  = @attr_id
       AND lo_attr_ref.element_index              = 0                                      -- No arrays for now.
       AND lo_attr_ref.reference_string           = N'---Auto---'
    INNER JOIN primitive_instance lo_pi
        ON lo_pi.package_id                       = lo_attr_ref.package_id
       AND lo_pi.gobject_id                       = lo_attr_ref.gobject_id
       AND lo_pi.mx_primitive_id                  = lo_attr_ref.referring_mx_primitive_id
    INNER JOIN attribute_definition lo_attr_def
        ON lo_attr_def.primitive_definition_id    = lo_pi.primitive_definition_id
       AND lo_attr_def.mx_attribute_id            = lo_attr_ref.referring_mx_attribute_id
     WHERE odl.gobject_id                         = @gobject_id
  end
  else if @uda_name IS NOT NULL AND ( @gobject_id <> 0 OR @ao_name IS NOT NULL )
  begin
    -- Typically invoked by the Simplified Attribute Editor, this is the more tolerant code-path
    -- @attr_name will contain the following information: "tag-name (or '*' if gobject_id <> 0).uda_name.uda_attribute_name"
    -- Examples: 'Pump1.Tank.Level.InputSource' or '*.Tank.Level.InputSource'
    -- Construct a default item reference (in the event that the object isn't linked to a device)
    -- Also retrieve liked device info, if available (i.e., via an outer join)
    SELECT @attr_ref             = g.hierarchical_name + N'.' + @uda_name
         , @dio_id               = ISNULL (dio_id, 0)
         , @sg_mx_primitive_id   = ISNULL (sg_mx_primitive_id, 0)
         , @dio_name             = dio.tag_name
         , @sg_name              = sg_pi.primitive_name
      FROM gobject g
     LEFT OUTER JOIN object_device_linkage odl
        ON odl.gobject_id        = g.gobject_id 
     LEFT OUTER JOIN gobject dio
        ON dio.gobject_id        = odl.dio_id
     LEFT OUTER JOIN primitive_instance sg_pi
        ON sg_pi.gobject_id      = dio.gobject_id
       AND sg_pi.package_id      = dio.checked_in_package_id
       AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
     WHERE g.gobject_id          = CASE WHEN @gobject_id <> 0 THEN @gobject_id ELSE g.gobject_id END
       AND g.tag_name            = ISNULL(@ao_name, g.tag_name) -- Sanity check: Validate tag-name if fully qualified attribute reference
  end

    if (@dio_id <> 0 AND @sg_mx_primitive_id <> 0)
    begin
      SELECT  @qual_ref = 
              CASE 
                WHEN xlate_rule_name IN (N'Radical_Override', N'Radical_Override_Default_SG', N'ASB_Reference')
                  THEN overridden_attr_reference 
                WHEN xlate_rule_name IN (N'Device_Override',  N'Device_and_SG_Override')
                  THEN overridden_attr_reference + N'.' + default_attr_reference
                ELSE
                    dio_tag_name + N'.'
                  + dio_scan_group_name + N'.'
                  + ISNULL (overridden_attr_reference, default_attr_reference) 
              END
        FROM  GetAutobindInfoForDIO (@dio_id, @sg_mx_primitive_id, @gobject_id, @uda_name, @io_attr) bind_info   --HF CR L00139227

    if @@ROWCOUNT = 0
    begin
      if @attr_ref IS NOT NULL -- New attribute: Construct default reference
        set @qual_ref = @dio_name + N'.' + @sg_name + N'.' + @attr_ref
      else
        set @qual_ref = N'---'
    end
    end
    else if @attr_ref IS NOT NULL
      set @attr_ref = N'<IODevice>.' + @attr_ref
  else
    set @qual_ref = N'---'

  SELECT ISNULL (@qual_ref, ISNULL (@attr_ref, N'<Invalid!>')) as ResolvedAttrRef

end
go

