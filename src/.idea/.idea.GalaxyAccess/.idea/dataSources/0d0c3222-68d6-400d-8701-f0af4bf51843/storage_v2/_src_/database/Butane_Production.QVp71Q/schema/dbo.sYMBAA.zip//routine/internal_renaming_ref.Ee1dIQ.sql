create proc dbo.internal_renaming_ref
      @catid  int,
      @packagestatus int,
      @srcgobjectid  int
as
begin
 -- Get the Instance ID
 
 declare @objectid table ( gobject_id int)
 declare @attr_ref table ( gobject_id int,package_id int,ref_prim_id int,ref_attr_id int,ref_element_index int )

if  @catid = 1 -- it is a platform
  begin

	  insert into @attr_ref select ar.gobject_id,ar.package_id,ar.referring_mx_primitive_id,ar.referring_mx_attribute_id,ar.element_index
	         from attribute_reference ar 
	         where ar.gobject_id <> @srcgobjectid 
		 and ar.resolved_gobject_id = @srcgobjectid 

  end
else if @catid < 10 -- it is a engine ( 2-9 )
  begin
	  insert into @attr_ref select ar.gobject_id,ar.package_id,ar.referring_mx_primitive_id,ar.referring_mx_attribute_id,ar.element_index
	         from attribute_reference ar 
	         where ar.gobject_id <> @srcgobjectid 
		 and ar.resolved_gobject_id = @srcgobjectid 

  end
else if @catid = 13 -- it is an area
  begin
      -- this can be an area or application category object
	  insert into @attr_ref select ar.gobject_id,ar.package_id,ar.referring_mx_primitive_id,ar.referring_mx_attribute_id,ar.element_index
	         from attribute_reference ar 
	         where ar.gobject_id <> @srcgobjectid 
		 and ar.resolved_gobject_id = @srcgobjectid 
      
  end
else  -- everything else
  begin

	  insert into @attr_ref select ar.gobject_id,ar.package_id,ar.referring_mx_primitive_id,ar.referring_mx_attribute_id,ar.element_index
	         from attribute_reference ar 
	         where ar.gobject_id <> @srcgobjectid 
		 and ar.resolved_gobject_id = @srcgobjectid 

  end

  insert into @objectid select distinct a.gobject_id from @attr_ref a 

  update package set reference_status_id = @packagestatus 
  from package 
  inner join gobject on package_id = gobject.checked_in_package_id
  inner join @objectid obj on obj.gobject_id = gobject.gobject_id

  update attribute_reference set is_valid = 1,resolved_mx_primitive_id=0 from attribute_reference ar , @attr_ref atr
  where  ar.gobject_id = atr.gobject_id and ar.package_id = atr.package_id 
	and ar.referring_mx_primitive_id = atr.ref_prim_id 
	and ar.referring_mx_attribute_id = atr.ref_attr_id
	and ar.element_index = atr.ref_element_index


end
go

