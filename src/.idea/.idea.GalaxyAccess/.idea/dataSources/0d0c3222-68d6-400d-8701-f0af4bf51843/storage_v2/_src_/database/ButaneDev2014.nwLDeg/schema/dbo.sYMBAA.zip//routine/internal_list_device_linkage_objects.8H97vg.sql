create proc dbo.internal_list_device_linkage_objects
AS
select  distinct g.gobject_id as 'entity_id', 
        g.tag_name as 'name', 
        'object' as type,
        '' as description,
        up.user_guid,
        CASE WHEN g.checked_out_by_user_guid = up.user_guid THEN 
            1
        ELSE 
            0 
        END 
        AS is_checkout, 
        cd.last_modified,
        g.contained_name,
        g.hierarchical_name, 
        g.area_gobject_id,
        g.is_template,
        g.is_hidden,
--      package.status_id as status, 
        CASE WHEN package.status_id = 0 THEN
            CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0) --ver_warning_view.has_warning = 1 
                THEN 2 
            ELSE 0 
            END
        ELSE package.status_id
        END as status,
        package.reference_status_id as refStatus,
        g.hosted_by_gobject_id,
        g.derived_from_gobject_id as derived_from_id,
        template_definition.base_gobject_id as base_type,  
        isnull((select user_profile_name from user_profile where user_guid = g.checked_out_by_user_guid),'') as checkoutbyname, 
        g.checked_out_by_user_guid as checkedout_by,
        folder_gobject_link.folder_id AS toolset_id, 
        g.checked_in_package_id,
        g.template_definition_id,       
        g.contained_by_gobject_id as container_id,  
        g.area_gobject_id as area_id, 
        CASE WHEN package_checked_out.status_id = 0 THEN
            CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
                THEN 2 
            ELSE 0 
            END
        ELSE package.status_id 
        END as checked_out_package_status,
        (g.is_template * 1) +
            (g.is_hidden * 2 ) +
            ((CASE WHEN g.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
            ((CASE WHEN g.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +
            ((CASE WHEN (g.deployed_package_id <> 0) and ((g.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
            THEN 1  ELSE 0  END) * 16 ) +
            ((CASE WHEN (g.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
            ((CASE WHEN (g.namespace_id = 1 and template_definition.category_id = 3 and g.is_template = 0 and dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1 ) THEN 1 ELSE 0 END) * 64) +
            ((CASE WHEN (g.namespace_id = 2 and template_definition.category_id = 3 and g.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
            ((CASE WHEN (dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) THEN 1 ELSE 0 END) * 256) + 
            ((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
                        ((g.deployed_package_id <> 0) and (dbo.is_partner_deployed(g.gobject_id) =  0))) then 1 else 0 end) * 512) +
            ((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
                        ((g.deployed_package_id = 0) and (dbo.is_partner_deployed(g.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
            case when exists(select gobject_id from gobject where derived_from_gobject_id = g.gobject_id) --Hasderived_obj
                 then 2048   else 0  end +
            case when exists(select gobject_id from gobject where hosted_by_gobject_id = g.gobject_id) --Hasassigned_obj
                 then 4096   else 0  end + 
            case when exists(select gobject_id from gobject where contained_by_gobject_id =g.gobject_id) --HasContained_obj
                 then 8192   else 0  end +
            case when exists(select gobject_id from gobject where area_gobject_id = g.gobject_id) --HasBelongTo_obj
                 then 16384  else 0  end +
            ( (CASE WHEN (g.is_template = 0 and template_definition.category_id = 1) then
                    dbo.is_gr_platform_id(g.gobject_id) 
                else 
                    cast(0 as bit) end) * 32768) +
                    CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = g.gobject_id )
                    then  131072 else 0 end                                                     
        as 'gObjectStatus',
        template_definition.category_id,
        CAST ( pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
        g.namespace_id,
        folder_gobject_link.folder_id 

        -- New device linkage stuff.
        -- TODO: Need to add {assigned_to_device int} to the gobject table.
        --       Need to ensure that the new autobind tables have been created.
        -- Note:
        -- Device linkage is done in two parts:
        -- 1. The automation object is linked with the device-integration Object through the new 'assigned_to_device' column in the gobject table.
        -- 2. Individual attributes of the linked automation object are assigned to specific scan-groups within the DIO via the 'autobound_attribute' table.
        -- This query only returns (1): If we need (2), we'll have to retrieve:
        -- distinct autobound_attribute.sg_mx_primitive_id 
        -- where  autobound_attribut.dio_id = g.assigned_to_device
        --   and  (autobound_attribute.{gobject_id, package_id, mx_primitive_id, mx_attribute_id} = attribute_reference{gobject_id, package_id, mx_primitive_id, mx_attribute_id})
        --   and  (attribute_reference.{gobject_id, package_id} = g.{gobject_id, g.checked_in_package})
        -- 
        -- Much better to create a view for this.
        --g.assigned_to_device as deviceLinkageRef

from gobject g 
join package 
    on g.gobject_id = package.gobject_id 
    and g.checked_in_package_id = package.package_id
join template_definition on
    g.template_definition_id = template_definition.template_definition_id 
    and template_definition.category_id in (11,12,24) and g.is_template = 0
inner join proxy_timestamp pt on
        g.gobject_id = pt.gobject_id
left join package package_checked_out 
    on g.gobject_id = package_checked_out.gobject_id 
    and g.checked_out_package_id = package_checked_out.package_id
    
left outer join visual_element_reference ver_warning_view on
        g.gobject_id = ver_warning_view.gobject_id and
        package.package_id = ver_warning_view.package_id and
        ver_warning_view.visual_element_bind_status = 0 and
        ver_warning_view.checked_in_unbound_visual_element_name <> '---'
        
left outer join visual_element_reference ver_warning_view_checked_out on
        package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
        package_checked_out.package_id = ver_warning_view_checked_out.package_id and
        ver_warning_view_checked_out.visual_element_bind_status = 0 and
        ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'    
        
--inner join internal_visual_element_reference_warning_status_view ver_warning_view on
--  g.gobject_id = ver_warning_view.gobject_id and
--  package.package_id = ver_warning_view.package_id
--left outer join internal_visual_element_reference_warning_status_view ver_warning_view_checked_out on
--  package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
--  package_checked_out.package_id = ver_warning_view_checked_out.package_id
    
left join folder_gobject_link on
    folder_gobject_link.gobject_id = g.gobject_id
left outer join package checked_in_package on 
    g.gobject_id = checked_in_package.gobject_id 
    --g.checked_in_package_id = checked_in_package.package_id
inner join dbo.user_profile up
    on g.checked_out_by_user_guid is null and checked_in_package.package_id = g.checked_in_package_id
    or (g.checked_out_by_user_guid  = up.user_guid and checked_in_package.package_type = 'O')
    or (g.checked_out_by_user_guid  <> up.user_guid and checked_in_package.package_id = g.checked_in_package_id)
left outer join package deployed_package on 
    g.gobject_id = deployed_package.gobject_id and
    g.deployed_package_id = deployed_package.package_id
LEFT OUTER JOIN

(SELECT [gobject_id], MAX([change_date]) as 'last_modified'  FROM [gobject_change_log] GROUP BY [gobject_id]) as cd on cd.gobject_id = g.gobject_id

--where 
--    g.area_gobject_id = @varwhere and 
--  g.is_hidden = 0 and g.is_template = 0 and 
--  g.contained_by_gobject_id  = 0 AND 
--    template_definition.category_id = 13 and
--  g.tag_name > @startingAfterTagname
go

