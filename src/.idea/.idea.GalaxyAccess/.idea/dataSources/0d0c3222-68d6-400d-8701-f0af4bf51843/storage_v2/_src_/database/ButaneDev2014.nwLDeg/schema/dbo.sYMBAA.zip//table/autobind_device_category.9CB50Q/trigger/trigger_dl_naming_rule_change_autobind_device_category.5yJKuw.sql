create  trigger trigger_dl_naming_rule_change_autobind_device_category 
ON  [autobind_device_category]
FOR INSERT, UPDATE
AS  
begin
	declare @category_id smallint
	select @category_id = category_id
	from inserted 
	
    EXECUTE internal_ab_refresh_attribute_aliases 0, 0, 0, 0, @category_id
end

go

