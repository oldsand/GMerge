/*
-- Function: evaluate_autobind_naming_rule
-- This function evaluates a DIO attribute reference string based on the passed naming rule (@rule_str)
-- The naming rule is a string in wich substitutable tokens may be embedded.
-- Supported substitutable tokens:
-- <DeviceName>: The tag-name of the DIO involved in the linkage
-- <TopicName>: The name of the scan-group of the DIO that is involved in the linkage
-- <TagName>: The tag-name of the application object that is linked to the DIO
-- <ContainedName>: The contained-name of the application object that is linked to the DIO
-- <HierarchicalName>: The hierarchical-name of the application object that is linked to the DIO
-- <AttributeName>: The name of the application object [I/O] attribute that maps to the DIO attribute 
-- <IOScope>: The I/O scope of the application object attribute: {Input, Output, InputOutput}
-- <IOType>: The I/O type of the attribute: {I, O} 
*/
CREATE function dbo.evaluate_autobind_naming_rule( 
        @rule_str           as nvarchar(329),
        @tag_name           as nvarchar(329),
        @hierarchical_name  as nvarchar(329),
        @contained_name     as nvarchar(329),
        @attribute_name     as nvarchar(329),
        @device_name        as nvarchar(329) = N'',
        @topic_name         as nvarchar(329) = N'',
        @pd_primitive_name  as nvarchar(329) = N'',
        @ad_attribute_name  as nvarchar(329) = N'')
returns nvarchar(329) -- new reference specification after applying the rule spec 
as
begin
    declare @DIO_attr_ref nvarchar(329)
    declare @separator int

    -- I/O Scope: This is essentially the primitive_definition.primitive_name of the I/O attribute.
    -- Need to strip out the trailing literal "Extension" that identifies extension primitives.
    set @separator = CHARINDEX (N'Extension', @pd_primitive_name)
    if @separator > 0
        set @pd_primitive_name = SUBSTRING (@pd_primitive_name, 1, @separator - 1)

    -- I/O Type: This is the value of attribute_definition.attribute_name for the I/O attribute {InputSource, OutputDest}
    -- We need just the first character {I,O}
    if LEN (@ad_attribute_name) > 1
        set @ad_attribute_name = SUBSTRING (@ad_attribute_name, 1, 1)

    -- Simply replace all known tokens embedded in the passed naming rule string
    set @DIO_attr_ref =
        REPLACE (
            REPLACE (
                REPLACE (
                    REPLACE (
                        REPLACE (
                            REPLACE (
                                REPLACE (
                                    REPLACE (@rule_str, N'<AttributeName>', @attribute_name),
                                    N'<TagName>', @tag_name),
                                N'<TopicName>', ISNULL (@topic_name, N'<Default>')),
                            N'<DeviceName>', @device_name),
                        N'<HierarchicalName>', @hierarchical_name), 
                    N'<ContainedName>', @contained_name), 
                N'<IOScope>', @pd_primitive_name), 
            N'<IOType>', @ad_attribute_name)


    return @DIO_attr_ref

end
go

