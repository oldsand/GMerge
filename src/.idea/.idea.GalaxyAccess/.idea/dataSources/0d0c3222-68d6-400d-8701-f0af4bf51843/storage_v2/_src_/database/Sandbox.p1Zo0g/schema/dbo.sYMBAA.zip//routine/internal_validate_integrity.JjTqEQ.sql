/*
tests for validity of the database as a whole

returns two rowsets:
  - A single string: 'Passed' or 'Failed'
  - a table with one row per test:  table ( passed bit, test_name nvarchar(100))

usage: 
    exec internal_validate_integrity

*/
create procedure [dbo].[internal_validate_integrity]
as
begin
	WAITFOR DELAY '00:00:01'
	set nocount on

    declare @test_name nvarchar(100)
    declare @passed bit
    declare @count int   
    declare @pass_fail table ( passed bit, test_name nvarchar(100))

DECLARE @t TABLE  
(
	[gobject_id] [int]  NULL,
	[package_id] [int]  NULL,
	[mx_primitive_id] [smallint]  NULL,
	[visual_element_reference_index] [int]  NULL
) 
    -------------------------------------------------------
    -- test that there are no blank tag_names
    -------------------------------------------------------
    set @test_name = 'no blank tag names'
    set @passed = 0
    select @count = count(1) from gobject where tag_name = ''
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    -------------------------------------------------------
    -- test that there are no unreferenced packages
    -------------------------------------------------------
    set @test_name = 'no unreferenced packages'
    set @passed = 0
    select @count = count(1) from package with(nolock)
    where (isnumeric(package_type) = 0 ) and 
        not exists
        (
        select * from gobject with(nolock) where
            package.package_id = gobject.checked_in_package_id
            or package.package_id = gobject.checked_out_package_id
            or package.package_id = gobject.deployed_package_id
			or package.package_id = gobject.last_deployed_package_id
        ) 
		and package_id not in
		(
			select package_id 
			from old_checked_in_packages with(nolock) 
		)
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    -------------------------------------------------------
    -- test that there are orphaned packages
    -------------------------------------------------------
    set @test_name = 'no orphaned checked_in_package_id'
    set @passed = 0
    select @count = count(1) from gobject
    where (checked_in_package_id not in ( 
        select  package_id
        from    package )
        ) 
    and  checked_in_package_id <> 0

    if @count = 0
        set @passed = 1
    insert into @pass_fail values ( @passed, @test_name )


    set @test_name = 'no orphaned checked_out_package_id'
    set @passed = 0
    select @count = count(1) from gobject
    where (checked_out_package_id not in ( 
        select  package_id
        from    package )
        ) 
    and  checked_out_package_id <> 0

    if @count = 0
        set @passed = 1
    insert into @pass_fail values ( @passed, @test_name )


    set @test_name = 'no orphaned deployed_package_id'
    set @passed = 0
    select @count = count(1) from gobject
    where (deployed_package_id not in ( 
        select  package_id
        from    package )
        ) 
    and  deployed_package_id <> 0
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    -----------------------------------------------------
    -- test that all object versions are increasing
    -----------------------------------------------------
    set @test_name = 'all object version numbers should be increasing'
    set @passed = 0

    select  @count = count('*') 
    from    gobject_change_log a 
    inner join gobject_change_log b
    on a.gobject_id = b.gobject_id 
    where   a.configuration_version > b.configuration_version
    and     a.change_date <= b.change_date

    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )
        

    ------------------------------------------------------------------
    ---- test that all gobject templates have a row in template table
    ------------------------------------------------------------------
    --set @test_name = 'all templates in template table'
    --set @passed = 0

    --select @count = count(1) from gobject where is_template = 1 and tag_name not in ('$Galaxy','$_AutoImport','$Symbol','$ClientControl') and not exists 
    --    ( select '*' from folder_gobject_link f where f.gobject_id = gobject.gobject_id )

    --if @count = 0
    --    set @passed = 1

    ---- record single test result
    --insert into @pass_fail values ( @passed, @test_name )
        
    ----------------------------------------------------------------
    -- test that all gobject templates have a row in template table
    ----------------------------------------------------------------
    set @test_name = 'all instances have checked-in packages'
    set @passed = 0

    select @count = count('*') from gobject where not exists 
		( select '*' from package where package_id = gobject.checked_in_package_id )

    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    ----------------------------------------------------------------
    -- test for bad template references in gobject
    ----------------------------------------------------------------
    set @test_name = 'validate template references in gobject'
    set @passed = 0

    select @count = count('*') 
	from gobject child 
	where derived_from_gobject_id <> 0 and not exists (
		select * 
			from gobject 
            where gobject_id = child.derived_from_gobject_id)
        
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    ---------------------------------------------------------------------------------------------
    -- test that checked-in visual_element_references are not corrupt
    ---------------------------------------------------------------------------------------------
    set @test_name = 'Checked-in bound VERs have checked-in unbound data'
    set @passed = 0
                select @count =  
                count(1)  
 from visual_element_reference
 where 
    ( 
        (checked_in_bound_visual_element_gobject_id <> null) or
        (checked_in_bound_visual_element_package_id <> null) or
        (checked_in_bound_visual_element_mx_primitive_id <> null)
    )
    and
    (
        (checked_in_unbound_visual_element_name <> null) or
        (checked_in_unbound_visual_element_type <> null) or
        (checked_in_unbound_tag_name <> null) or
        (checked_in_unbound_primitive_name <> null) or
        (checked_in_unbound_relative_object_name <> null)
    )



    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )


    ---------------------------------------------------------------------------------------------
    -- test that checked-out visual_element_references are not corrupt
    ---------------------------------------------------------------------------------------------
    set @test_name = 'Checked-out bound VERs have checked-out unbound data'
    set @passed = 0
                select @count =  
                count(1)  
 from visual_element_reference
 where 
    ( 
        (checked_out_bound_visual_element_gobject_id <> null) or
        (checked_out_bound_visual_element_package_id <> null) or
        (checked_out_bound_visual_element_mx_primitive_id <> null)
    )
    and
    (
        (checked_out_unbound_visual_element_name <> null) or
        (checked_out_unbound_visual_element_type <> null) or
        (checked_out_unbound_tag_name <> null) or
        (checked_out_unbound_primitive_name <> null) or
        (checked_out_unbound_relative_object_name <> null)
    )



    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )


    -----------------------------------------------------------------------------------------
    -- test that visual element reference view does not have any null reference strings...
    -----------------------------------------------------------------------------------------
    set @test_name = 'internal_visual_element_reference_per_user_view should not return null refernces'
    set @passed = 0
    select @count =   
        count(1)   
    from internal_visual_element_reference_per_user_view
    where reference_string is null
            
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )


    -----------------------------------------------------------------------------------------
    -- test that gobjects are not missing any inherited visual_element references
    -----------------------------------------------------------------------------------------
    set @test_name = 'gobjects should inherit visual element references'
    set @passed = 0
                select @count =   
                count(1)   
                from gobject i   
                inner join gobject t on   
                    i.derived_from_gobject_id = t.gobject_id   
                inner join visual_element_reference tref   
                on tref.gobject_id = t.gobject_id where not exists   
                        ( select 1 from visual_element_reference iref   
                            where iref.gobject_id = i.gobject_id   
                            and tref.mx_primitive_id = iref.mx_primitive_id   
                            and tref.visual_element_reference_index =   
                                iref.visual_element_reference_index)
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )


    -----------------------------------------------------------------------------------------
    -- test that gobjects have inherited their parents visual elements
    -----------------------------------------------------------------------------------------
    set @test_name = 'gobjects should have their parents visual elements'
    set @passed = 0
    select @count =   
    count(1)
    from
    (select g.gobject_id,
            derived_from_gobject_id,
            count(1)vecount
    from gobject g
    left outer join visual_element_version vev on 
        g.gobject_id = vev.gobject_id and
        vev.visual_element_id <> vev.inherited_from_visual_element_id and
        vev.package_id = g.checked_in_package_id
    group by g.gobject_id,derived_from_gobject_id)my 
inner join 
    (select vev.gobject_id, 
        count(1)vecount
    from visual_element_version vev
    inner join gobject g on
    vev.package_id = g.checked_in_package_id 
    group by vev.gobject_id)parent
    on my.derived_from_gobject_id = parent.gobject_id
where my.vecount <> parent.vecount

            
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    -----------------------------------------------------------------------------------------
    -- test that checked out visual element versions have corresponding CHECKEDOUT packages
    -----------------------------------------------------------------------------------------
	-- if this test fails, GetVisualElementData can have major issues with returning correct data...
    set @test_name = 'Checked out visual element versions have corresponding checkedout packages'
    set @passed = 0
    select @count = count(1) 
	from visual_element_reference with (nolock)
	where 
		checked_out_to_user_guid is not null and 
		checked_out_visual_element_package_id not in
		(
			select checked_out_package_id
			from gobject with (nolock)
			where checked_out_package_id > 0
		)
		              
    if @count = 0
        set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )

    -----------------------------------------------------------------------------------------
    -- test that each object has a corresponding row in the timestamp table
    -----------------------------------------------------------------------------------------
	-- if this test fails, GetVisualElementData can have major issues with returning correct data...
    set @test_name = 'All objects have a row in gobject_filter_info_timestamp'
    set @passed = 0
    select @count = count(1) 
	from gobject g
	left outer join gobject_filter_info_timestamp f
		on g.gobject_id = f.gobject_id
	where	
		g.is_template = 0 and
		f.gobject_id is null
			              
		if @count = 0
			set @passed = 1

    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )
-----------------------------------------------------------------------------------------
-- Check whether old_checked_in_packages is empty
-----------------------------------------------------------------------------------------
    set @test_name = 'Pervious checked in cleanup is finished'
    set @passed = 0
    insert into @t (gobject_id)
    select gobject_id from old_checked_in_packages
    select @count = count(1) from @t
		if @count = 0
			set @passed = 1
    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )  
    /* DATA INTEGRITY DETAILS*/
if @passed<>1
BEGIN
	SELECT 'Pervious checked in cleanup is finished'
	SELECT g.[gobject_id],p.package_type,g.tag_name,g.checked_in_package_id,g.checked_out_package_id,g.deployed_package_id
	,p.package_version,p.reference_status_id
	FROM gobject g
	INNER JOIN @t pr
		on pr.gobject_id=g.gobject_id
	INNER JOIN [package] p
		on p.gobject_id=g.gobject_id
	ORDER BY g.[gobject_id],p.package_type
END
    delete  @t;
-----------------------------------------------------------------------------------------
-- Check whether packages_to_be_deleted is empty
-----------------------------------------------------------------------------------------
    set @test_name = 'Other pervious checked in cleanup is finished'
    set @passed = 0
        insert into @t (gobject_id)
        select gobject_id from packages_to_be_deleted
    select @count = count(1) from  @t	
		if @count = 0
			set @passed = 1
    -- record single test result
    insert into @pass_fail values ( @passed, @test_name )
    if @passed<>1
BEGIN
	SELECT 'Other pervious checked in cleanup is finished'
	SELECT g.[gobject_id],p.package_type,g.tag_name,g.checked_in_package_id,g.checked_out_package_id,g.deployed_package_id
	,p.package_version,p.reference_status_id
	FROM gobject g
	INNER JOIN @t pr
		on pr.gobject_id=g.gobject_id
	INNER JOIN [package] p
		on p.gobject_id=g.gobject_id
	ORDER BY g.[gobject_id],p.package_type
END
    delete  @t;
-----------------------------------------------------------------------------------------
-- Check the integrity of visual_element_reference unbound has to have some data'
-----------------------------------------------------------------------------------------    
set @test_name = 'visual_element_reference integrity, unbound has to have some data,bound nulled'
set @passed = 0

INSERT INTO @t([gobject_id],[package_id],[mx_primitive_id],[visual_element_reference_index])
SELECT [gobject_id]
      ,[package_id]
      ,[mx_primitive_id]
      ,[visual_element_reference_index]
FROM dbo.visual_element_reference
WHERE 
visual_element_bind_status <>1
AND 
COALESCE 
(
	 checked_in_unbound_visual_element_name
	,checked_in_unbound_visual_element_type
	,checked_in_unbound_tag_name
	,checked_in_unbound_primitive_name
	,checked_in_unbound_relative_object_name
	,cast(checked_in_unbound_visual_element_id as  varchar(8000))
	,checked_out_unbound_visual_element_name
	,checked_out_unbound_visual_element_type
	,checked_out_unbound_tag_name
	,checked_out_unbound_primitive_name
	,checked_out_unbound_relative_object_name
	,cast(checked_out_unbound_visual_element_id as  varchar(8000))
) IS NULL
and COALESCE 
(
	 checked_in_bound_visual_element_gobject_id
	,checked_in_bound_visual_element_package_id
	,checked_in_bound_visual_element_mx_primitive_id
	,checked_out_bound_visual_element_gobject_id
	,checked_out_bound_visual_element_package_id
	,checked_out_bound_visual_element_mx_primitive_id
) IS NOT NULL

select @count = count(1) from @t	
		if @count = 0
			set @passed = 1
INSERT INTO @pass_fail values ( @passed, @test_name )   
if @passed<>1
/* DATA INTEGRITY DETAILS*/
begin
	SELECT  'visual_element_reference integrity, unbound has to have some data,bound nulled'
	SELECT 
		ver.gobject_id,
		case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name else g.tag_name end as visual_element_name, 
		p.package_id, 
		ver.mx_primitive_id,
		g.tag_name tag_name,
		pri.primitive_name, 
		g.tag_name gobject_tag_name,
		p.package_type,
		case when pri.primitive_name <> '' then g.hierarchical_name + '.' + pri.primitive_name else g.hierarchical_name end as hierarchical_visual_element_name, 
		g.hierarchical_name gobject_hierarchical_name,
		case when pri.primitive_name = '' then 1 else 0 end is_library_visual_element,
		ver.[visual_element_reference_index]
	FROM @t ver
	INNER JOIN gobject g on
		 ver.gobject_id = g.gobject_id
	INNER JOIN package p on 
		 ver.package_id = p.package_id
	INNER JOIN primitive_instance pri on           
		ver.package_id = pri.package_id and 
		ver.mx_primitive_id = pri.mx_primitive_id
end
delete  @t;
-----------------------------------------------------------------------------------------
-- Check the integrity of visual_element_reference table: 	visual_element_reference_index should be in sequence started from 1
-----------------------------------------------------------------------------------------    
set @test_name = 'visual_element_reference integrity, visual_element_reference_index should be in sequence started from 1 '
select @passed = 0,@count=0

if exists 
(
	SELECT 1
	FROM [visual_element_reference]
	GROUP BY  
	 [gobject_id]
	,[package_id]
	,[mx_primitive_id]
	HAVING max([visual_element_reference_index])-COUNT(1)>0
)
begin
	select @count = 1 
end
		if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )
/* DATA INTEGRITY DETAILS*/
if @passed<>1
begin
	SELECT 'visual_element_reference integrity, visual_element_reference_index should be in sequence started from 1 '
	SELECT 
		ver.gobject_id,
		case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name else g.tag_name end as visual_element_name, 
		p.package_id, 
		ver.mx_primitive_id,
		g.tag_name tag_name,
		pri.primitive_name, 
		g.tag_name gobject_tag_name,
		p.package_type,
		case when pri.primitive_name <> '' then g.hierarchical_name + '.' + pri.primitive_name else g.hierarchical_name end as hierarchical_visual_element_name, 
		g.hierarchical_name gobject_hierarchical_name,
		case when pri.primitive_name = '' then 1 else 0 end is_library_visual_element
	FROM 
	(	
	SELECT [gobject_id],[package_id],[mx_primitive_id]
	FROM [visual_element_reference]
	GROUP BY  
	 [gobject_id]
	,[package_id]
	,[mx_primitive_id]
	HAVING max([visual_element_reference_index])-COUNT(1)>0
	)	 ver
	INNER JOIN gobject g on
		 ver.gobject_id = g.gobject_id
	INNER JOIN package p on 
		 ver.package_id = p.package_id
	INNER JOIN primitive_instance pri on           
		ver.package_id = pri.package_id and 
		ver.mx_primitive_id = pri.mx_primitive_id
end
-----------------------------------------------------------------------------------------
-- Check the integrity of visual_element_version table to parent tables
-----------------------------------------------------------------------------------------    
set @test_name = 'visual_element_version integrity to Parent tables'
set @passed = 0
select @count = count(1) 
from dbo.visual_element_version  ver
where 
	   ver.gobject_id NOT IN (select t.gobject_id from dbo.gobject t )
	or ver.package_id NOT IN (select t.package_id from dbo.package t )
	or ver.mx_primitive_id NOT IN (select t.mx_primitive_id from dbo.primitive_instance t )
	---
	or ver.inherited_from_gobject_id NOT IN (select t.gobject_id from dbo.gobject t )
	or ver.inherited_from_package_id NOT IN (select t.package_id from dbo.package t )
	or ver.inherited_from_mx_primitive_id NOT IN (select t.mx_primitive_id from dbo.primitive_instance t )
	---
	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name ) 

/* DATA INTEGRITY DETAILS*/
if @passed<>1
BEGIN
	select 'visual_element_version integrity to Parent tables'
	SELECT 
		ver.gobject_id,
		case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name else g.tag_name end as visual_element_name, 
		p.package_id, 
		ver.mx_primitive_id,
		g.tag_name tag_name,
		pri.primitive_name, 
		g.tag_name gobject_tag_name,
		p.package_type,
		case when pri.primitive_name <> '' then g.hierarchical_name + '.' + pri.primitive_name else g.hierarchical_name end as hierarchical_visual_element_name, 
		g.hierarchical_name gobject_hierarchical_name,
		case when pri.primitive_name = '' then 1 else 0 end is_library_visual_element
	FROM 
	(	
	SELECT [gobject_id],[package_id],[mx_primitive_id]
	from dbo.visual_element_version  i
	where 
		   i.gobject_id NOT IN (select t.gobject_id from dbo.gobject t )
		or i.package_id NOT IN (select t.package_id from dbo.package t )
		or i.mx_primitive_id NOT IN (select t.mx_primitive_id from dbo.primitive_instance t )
		---
		or i.inherited_from_gobject_id NOT IN (select t.gobject_id from dbo.gobject t )
		or i.inherited_from_package_id NOT IN (select t.package_id from dbo.package t )
		or i.inherited_from_mx_primitive_id NOT IN (select t.mx_primitive_id from dbo.primitive_instance t )
	)	 ver
	INNER JOIN gobject g on
		 ver.gobject_id = g.gobject_id
	INNER JOIN package p on 
		 ver.package_id = p.package_id
	INNER JOIN primitive_instance pri on           
		ver.package_id = pri.package_id and 
		ver.mx_primitive_id = pri.mx_primitive_id
END

-----------------------------------------------------------------------------------------
-- Check the integrity of Package Table
-----------------------------------------------------------------------------------------    
set @test_name = 'Package Table clean up complete'
set @passed = 0
select @count = count(1) 
FROM 
(
	SELECT [gobject_id],[package_type], COUNT(1) CountProblems
	FROM [package]
	WHERE ISNUMERIC([package_type])=0
	GROUP BY [gobject_id],[package_type]
	HAVING COUNT(1)>1
) Q
	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )
/* DATA INTEGRITY DETAILS*/
if @passed<>1
BEGIN
	SELECT 'Package Table clean up complete'
	select g.[gobject_id],p.package_type,g.tag_name,g.checked_in_package_id,g.checked_out_package_id,g.deployed_package_id
	,p.package_version,p.reference_status_id
	from gobject g
	INNER JOIN 
		(
		SELECT [gobject_id],[package_type]
		FROM [package]
		WHERE ISNUMERIC([package_type])=0
		GROUP BY [gobject_id],[package_type]
		HAVING COUNT(1)>1
		) pr
		on pr.gobject_id=g.gobject_id
	INNER JOIN [package] p
		on p.gobject_id=g.gobject_id
	ORDER BY g.[gobject_id],p.package_type
END


-----------------------------------------------------------------------------------------
-- Check the integrity of visual_element_reference table again 
-----------------------------------------------------------------------------------------    
set @test_name = 'visual_element_reference Table has duplicates checked_out_bound_ Columns'
set @passed = 0
if exists 
(
	select 1
	from visual_element_reference
	where 
	checked_out_visual_element_package_id is not null
	GROUP BY package_id,
	gobject_id, checked_out_bound_visual_element_gobject_id,
	checked_out_bound_visual_element_package_id,
	checked_out_bound_visual_element_mx_primitive_id
	HAVING count(*) >1
)
begin
	select @count = 1 
end
	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )
/* DATA INTEGRITY DETAILS*/
if @passed<>1
BEGIN
	SELECT 'visual_element_reference Table HAS duplicates checked_out_bound_ Columns'
	select g.[gobject_id],p.package_type,g.tag_name,g.checked_in_package_id,g.checked_out_package_id,g.deployed_package_id
	,p.package_version,p.reference_status_id
	from gobject g
	INNER JOIN 
		(
		select 
		package_id,
		 gobject_id, checked_out_bound_visual_element_gobject_id,checked_out_bound_visual_element_package_id,
		checked_out_bound_visual_element_mx_primitive_id 
		from visual_element_reference
		where 
		checked_out_visual_element_package_id is not null
		GROUP BY package_id,
		gobject_id, checked_out_bound_visual_element_gobject_id,
		checked_out_bound_visual_element_package_id,
		checked_out_bound_visual_element_mx_primitive_id
		HAVING count(*) >1
		) pr
		on pr.gobject_id=g.gobject_id
	INNER JOIN [package] p
		on p.gobject_id=g.gobject_id
	ORDER BY g.[gobject_id],p.package_type
END
--start new validation based on changes from callisto to GT
-----------------------------------------------------------------------------------------
-- Validation on deployment_pending_status of gobject table 
-----------------------------------------------------------------------------------------    
set @test_name = 'deployment_pending_status of gobject table validation'
set @passed = 0
select @count = count(1) 
	from gobject
	where deployment_pending_status is NULL

if @count = 0
	set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )

-----------------------------------------------------------------------------------------
-- Validation on file_version of file_table table 
-----------------------------------------------------------------------------------------    
set @test_name = 'file_version of file_table validation'
set @passed = 0
select @count = count(1) 
	from file_table
	where file_version is NULL

	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )

-----------------------------------------------------------------------------------------
-- Validation on file_modified_time of file_table table 
-----------------------------------------------------------------------------------------    
set @test_name = 'file_modified_time of file_table validation'
set @passed = 0
select @count = count(1) 
	from file_table
	where file_modified_time is NULL

	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )

-----------------------------------------------------------------------------------------
-- Validation on file_modified_time of file_table table 
-----------------------------------------------------------------------------------------    
set @test_name = 'file_version of deployed_file validation'
set @passed = 0
select @count = count(1) 
	from deployed_file
	where file_version is NULL

	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )

-----------------------------------------------------------------------------------------
-- Validation on file_modified_time of file_table table 
-----------------------------------------------------------------------------------------    
set @test_name = 'file_modified_time of deployed_file validation'
set @passed = 0
select @count = count(1) 
	from deployed_file
	where file_modified_time is NULL

	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )
-----------------------------------------------------------------------------------------
-- Validation on gobject_id of intouchviewapptemplate_allsymbols table 
-----------------------------------------------------------------------------------------    
set @test_name = 'gobject_id of intouchviewapptemplate_allsymbols validation'
set @passed = 0
select @count = count(1) 
	from intouchviewapptemplate_allsymbols
	where gobject_id is NULL

	if @count = 0
			set @passed = 1
			
insert into @pass_fail values ( @passed, @test_name )
--end new validation based on changes from callisto to GT
    ---------------------------------------------------------------------------  
    -- tally results
    ---------------------------------------------------------------------------  
    declare @count_passed int
    declare @count_failed int

    select @count_passed = count(1) from @pass_fail where passed = 1
    select @count_failed = count(1) from @pass_fail where passed = 0

    if( @count_failed = 0 )
        select 'Passed'
    else
        select 'Failed'
    
    select * from @pass_fail

end
go

