--
-- Creates a single instance from the given template
--
-- returns the gobject_id of the instance created, or zero
-- if the operation failed.
--
-- Note that this does absolutely no validation of the created instance,
-- and is currently just for testing purposes
-- 
-- usage : 
--
-- declare  @new_instance_gobject_id int
-- exec internal_create_instance_from_template 1, 'TestGalaxy', @new_instance_gobject_id out
--
--
-- Creates a single template from the given template
--
-- returns the gobject_id of the template created, or zero
-- if the operation failed.
--
-- Note that this does absolutely no validation of the created instance,
-- and is currently just for testing purposes
-- 
-- usage : 
/*
	declare @newGuid int
	exec internal_create_template_from_template 1, '$AppEngine001', @newGuid output
	select @newGuid
*/
create proc dbo.internal_create_template_from_template
    @template_gobject_id int,
    @input_tag_name nvarchar(32),
    @new_instance_gobject_id int out,
    @derived_from_name nvarchar(32),
    @area_gobject_id int = 0,
    @hosted_by_gobject_id int = 0,
    @contained_by_gobject_id int = 0
as
set nocount on

declare @contained_by int
declare @contained_name nvarchar(32)
declare @tag_name nvarchar(32)
declare @namespace_id smallint

set @new_instance_gobject_id = 0

begin tran

----------------------------------------------
-- enforce derivation rule for InTouchViewApp
----------------------------------------------
declare @template_category_id int
declare @template_derived_from_gobject_id int

if exists(
            select '1'
            from gobject g with(nolock)
            inner join template_definition td with(nolock) on
                g.template_definition_id = td.template_definition_id and
                g.gobject_id = @template_gobject_id and
                td.category_id = 26 and
                g.derived_from_gobject_id > 0
            )
begin
RAISERROR('Cannot create more than one derivation level for object %s.',
				16, 1, 'InTouchViewApp')
rollback tran
return
end


    
select  @namespace_id = namespace_id
from    gobject
where   gobject_id = @template_gobject_id

if (len(@input_tag_name) = 0)
    exec internal_get_unique_name @derived_from_name, @namespace_id, @tag_name output
else
    set @tag_name = @input_tag_name    
    

if (exists(
    select  1
    from    gobject
    where   tag_name = @tag_name
    and     namespace_id = @namespace_id))
begin
    rollback tran
    return
end

---------------------------------------
-- get the contained name 
---------------------------------------

if @contained_by_gobject_id <> 0 
begin
select @contained_by = contained_by_gobject_id, @contained_name = contained_name
	from gobject with(nolock) 
	where gobject_id = @template_gobject_id
	IF @contained_by = 0  
		set @contained_name = ''
end
else
	set @contained_name = ''


---------------------------------------
-- create the gobject row
---------------------------------------

insert into gobject
(
    template_definition_id,
    derived_from_gobject_id,
    contained_by_gobject_id,
    area_gobject_id,
    hosted_by_gobject_id,
    default_symbol_gobject_id,
    default_display_gobject_id,
    checked_in_package_id,
    checked_out_package_id,
    deployed_package_id,
    tag_name,
    namespace_id,
    contained_name,
    identity_guid,
    configuration_guid,
    configuration_version,
    is_template,
    is_hidden,
    software_upgrade_needed,
    hosting_tree_level,
    hierarchical_name
)
select
    template_definition_id,				-- template_definition_id
    gobject_id,							-- derived_from_gobject_id
    @contained_by_gobject_id,			-- contained_by_gobject_id
    @area_gobject_id,					-- area_gobject_id
    @hosted_by_gobject_id,				-- hosted_by_gobject_id
    0,								    -- default_symbol_gobject_id
    0,									-- default_display_gobject_id
    0,									-- checked_in_package_id
    0,									-- checked_out_package_id
    0,									-- deployed_package_id
    @tag_name,							-- tag_name
    namespace_id,                       -- namespace_id
    @contained_name,					-- contained_name
    NewId(),							-- identity_guid
    NewId(),							-- configuration_guid
    1,									-- configuration_version
    1,									-- is_template
    0,									-- is_hidden
    0,									-- software_upgrade_needed
    0,									-- hosting_tree_level -- todo: modify this based on the template
    @tag_name							-- hierarchical_name   
from 
    gobject with(nolock) 
where 
    gobject_id = @template_gobject_id

select @new_instance_gobject_id = @@IDENTITY


-------------------------------------------------
--insert a record for a derived template in template table...
-----------------------------------------------
-- get the parent_package_id for a later join

declare @derived_from_package_id int

select	@derived_from_package_id = checked_in_package_id
from	gobject with(nolock) 
where	gobject_id = @template_gobject_id

---------------------------------------
-- insert information for template into folder_gobject_link
---------------------------------------
declare @folderId int
select	@folderId = folder_id
from	folder_gobject_link
where	
gobject_id = @template_gobject_id
and folder_type = 1

insert into folder_gobject_link(folder_id,folder_type,gobject_id)
values(@folderId,1,@new_instance_gobject_id)
---------------------------------------
-- create the checked_in_package
---------------------------------------


insert into package 
(
		gobject_id,
		status_id,
		security_group,
		derived_from_package_id
)
select	@new_instance_gobject_id,
		0, -- ePackageUnknownStatus
		security_group,
		package_id
from	package with(nolock) 
where	package_id = @derived_from_package_id
and     gobject_id = @template_gobject_id

declare @new_instance_package_id int
select @new_instance_package_id = @@IDENTITY


-- record checked_in_package_id
update	gobject 
set		checked_in_package_id = @new_instance_package_id
where	gobject_id = @new_instance_gobject_id


---------------------------------------
-- create primitive_instance rows
---------------------------------------


-- copy primitive_instance rows from template
insert into primitive_instance
(
	gobject_id,
    package_id,
    primitive_definition_id,
    primitive_name,
    mx_primitive_id,
    parent_mx_primitive_id,
    execution_group,
    execution_order,
	owned_by_gobject_id,
	extension_type,
	is_object_extension,
	entity_change_type,
	operation_on_primitive_mask,
    created_by_parent,
	status_id,
	ref_status_id,
--	primitive_attributes		
	mx_value_errors,
	mx_value_warnings,
	mx_value_reference_warnings		

)
select
    @new_instance_gobject_id,
    @new_instance_package_id,                   -- package_id
    primitive_instance.primitive_definition_id, -- primitive_definition_id
    primitive_instance.primitive_name,          -- primitive_name
    primitive_instance.mx_primitive_id,         -- mx_primitive_id
    primitive_instance.parent_mx_primitive_id,  -- parent_mx_primitive_id
    primitive_instance.execution_group,         -- execution_group,
    primitive_instance.execution_order,         -- execution_order
	primitive_instance.owned_by_gobject_id,		-- owned_by_gobject_id
	primitive_instance.extension_type ,  		-- extension_type
	primitive_instance.is_object_extension,		-- isObjectExtension
	1,
	0,
    1,
	status_id,
	ref_status_id,
--	primitive_attributes	
	mx_value_errors,
	mx_value_warnings,
	mx_value_reference_warnings		
	
from primitive_instance with(nolock) 
where primitive_instance.package_id = @derived_from_package_id
and   primitive_instance.gobject_id = @template_gobject_id


---------------------------------------
-- create template_attribute rows
---------------------------------------

-- insert appropriate attribute rows from the parent
insert into template_attribute
(
	gobject_id,
	package_id,
	mx_primitive_id,
    mx_attribute_id,
	security_classification,
	mx_data_type,
    mx_value,
	lock_type,
	original_lock_type
)
select 
    @new_instance_gobject_id,
    @new_instance_package_id,                   -- package_id
	template_attribute.mx_primitive_id,
    template_attribute.mx_attribute_id,       	-- mx_attribute_id
    template_attribute.security_classification, -- security_classification
    template_attribute.mx_data_type, 			-- mx_data_type
    template_attribute.mx_value, 				-- mx_value
    case when template_attribute.lock_type = 1 then
  		 2
  	else
         template_attribute.lock_type               	-- lock_type
    end
    as lock_type,
    case when template_attribute.lock_type = 1 then
  		 2
  	else
         template_attribute.lock_type               	-- lock_type
    end
    as original_lock_type
from template_attribute with(nolock) 
where template_attribute.package_id = @derived_from_package_id
and   template_attribute.gobject_id = @template_gobject_id

---------------------------------------
-- create dynamic_attribute rows
---------------------------------------
-- insert appropriate attribute rows from the parent
insert into dynamic_attribute
(
	gobject_id,
	package_id,
	mx_primitive_id,
	mx_attribute_id,
	attribute_name,
	mx_data_type,
	is_array,
	security_classification,
	mx_attribute_category,
	lock_type,
	mx_value,
	owned_by_gobject_id,
	original_lock_type,
    dynamic_attribute_type,
    bitvalues
)
select 
    @new_instance_gobject_id,
    @new_instance_package_id,                   -- package_id
    parent_dynamic_attribute.mx_primitive_id, 
    parent_dynamic_attribute.mx_attribute_id,       
	parent_dynamic_attribute.attribute_name,
	parent_dynamic_attribute.mx_data_type,
	parent_dynamic_attribute.is_array,
	parent_dynamic_attribute.security_classification,
	parent_dynamic_attribute.mx_attribute_category,

    case when parent_dynamic_attribute.lock_type = 1 then -- lock_type
  		 2
  	else
         parent_dynamic_attribute.lock_type               	
    end
    as lock_type,

	parent_dynamic_attribute.mx_value,
	case when parent_dynamic_attribute.mx_primitive_id = 2 then -- Common Primitive (UDAs)
  		 parent_dynamic_attribute.owned_by_gobject_id
  	else
         @new_instance_gobject_id               	
    end
    as owned_by_gobject_id,

    case when parent_dynamic_attribute.lock_type = 1 then -- lock_type
  		 2
  	else
         parent_dynamic_attribute.lock_type               	
    end
    as original_lock_type,

    parent_dynamic_attribute.dynamic_attribute_type,
    parent_dynamic_attribute.bitvalues

from  dynamic_attribute parent_dynamic_attribute with(nolock) 
where 
    parent_dynamic_attribute.package_id = @derived_from_package_id
and parent_dynamic_attribute.gobject_id = @template_gobject_id

---------------------------------------
-- create primitive_instance_feature_link
---------------------------------------
-- insert appropriate feature rows from the parent
insert into primitive_instance_feature_link
(
	gobject_id,
	package_id,
	mx_primitive_id,
    feature_id,
    feature_name,
    feature_type
)

select 
    @new_instance_gobject_id,
    @new_instance_package_id,						-- package_id
    primitive_instance_feature_link.mx_primitive_id,
    primitive_instance_feature_link.feature_id,
    primitive_instance_feature_link.feature_name,
    primitive_instance_feature_link.feature_type
from 
	primitive_instance_feature_link with(nolock) 
where 
    primitive_instance_feature_link.package_id = @derived_from_package_id
and primitive_instance_feature_link.gobject_id = @template_gobject_id


insert into proxy_timestamp(gobject_id)
				select @new_instance_gobject_id

insert into gobject_filter_info_timestamp(gobject_id)
				select @new_instance_gobject_id

commit

go

