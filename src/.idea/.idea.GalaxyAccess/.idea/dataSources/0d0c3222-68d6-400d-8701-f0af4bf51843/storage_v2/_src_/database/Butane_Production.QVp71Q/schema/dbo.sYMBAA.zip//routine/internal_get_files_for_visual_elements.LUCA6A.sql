create  procedure dbo.internal_get_files_for_visual_elements
            @visual_element_ids_file nvarchar(256),
            @node_name nvarchar(256)
as
begin
    begin transaction

    SET NOCOUNT ON

    create table #visual_element_ids_for_required_file(
                    visual_element_id int)

    create table #visual_element_required_file(
                    group_id  nvarchar(64)  COLLATE SQL_Latin1_General_CP1_CI_AS,
                    file_name nvarchar(256)  COLLATE SQL_Latin1_General_CP1_CI_AS,
                    vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS ,
                    subfolder_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS ,
                    registration_type int,
                    software_upgrade_needed int,
                    file_id int,
                    is_needed_for_package bit,
                    is_needed_for_editor bit,
                    is_needed_for_runtime bit)

    DECLARE @sql nvarchar(2000)
    SET @sql = 'BULK INSERT #visual_element_ids_for_required_file  FROM ''' + @visual_element_ids_file + ''' 
			    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
    EXEC sp_executesql @sql


--    exec internal_get_required_files_by_visual_element_ids @node_name, 2  -- eEditorAndPackageCodeModules

--  The following code are copied from internal_get_required_files_by_visual_element_ids.sql
--  For some reason, SQL server slows it down when we put the common code in a separate
--  stored procedure. Until we figure out the reason, here is the temporary solution.
-- 
    declare @codemodule int
    set @codemodule = 2

    BEGIN 

        begin transaction

        truncate table #visual_element_required_file
    
        if (@codemodule = 2) -- eEditorAndPackageCodeModules
        begin
                     
            insert into #visual_element_required_file
                    (group_id,
        	        file_name,
        	        vendor_name,
        	        subfolder_name,
        	        registration_type,
                    software_upgrade_needed,
                    file_id,
                    is_needed_for_package,
                    is_needed_for_editor,
                    is_needed_for_runtime)
            (

		 select  distinct
                        N'',
        	            f.file_name,
        	            f.vendor_name,
        	            f.subfolder,
        	            f.registration_type,
                        0,
                        f.file_id,
                        1,
                        1,
                        0
                from    file_table f
				inner join feature_file_link flink on
					flink.file_id = f.file_id
                inner join primitive_instance_feature_link primfeaturelink on
                        flink.feature_id = primfeaturelink.feature_id
                inner join primitive_instance pri on
                        primfeaturelink.gobject_id = pri.gobject_id and
                        primfeaturelink.package_id = pri.package_id and
                        primfeaturelink.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join visual_element_version vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id 
                inner join #visual_element_ids_for_required_file vei on    
                        vei.visual_element_id = vev.visual_element_id

				union

			    select  distinct
                        N'',
        	            f.file_name,
        	            f.vendor_name,
        	            f.subfolder,
        	            f.registration_type,
                        0,
                        f.file_id,
                        piftl.is_needed_for_package,
                        piftl.is_needed_for_editor,
                        0
                from    file_table f
                inner join primitive_instance_file_table_link piftl on
                        piftl.file_id = f.file_id
                inner join primitive_instance pri on
                        piftl.gobject_id = pri.gobject_id and
                        piftl.package_id = pri.package_id and
                        piftl.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join visual_element_version vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id 
                inner join #visual_element_ids_for_required_file vei on    
                        vei.visual_element_id = vev.visual_element_id
                where   (piftl.is_needed_for_editor = 1 or piftl.is_needed_for_package = 1)
		
            )    

--		select * from #visual_element_required_file
        end
        else if (@codemodule = 4) -- ePackageCodeModules
        begin

            insert into #visual_element_required_file
                    (group_id,
        	        file_name,
        	        vendor_name,
        	        subfolder_name,
        	        registration_type,
                    software_upgrade_needed,
                    file_id,
                    is_needed_for_package,
                    is_needed_for_editor,
                    is_needed_for_runtime)
            (
select  distinct
                        N'',
        	            f.file_name,
        	            f.vendor_name,
        	            f.subfolder,
        	            f.registration_type,
                        0,
                        f.file_id,
                        0,
                        1,
                        0
                from    file_table f
				inner join feature_file_link flink on
					flink.file_id = f.file_id
                inner join primitive_instance_feature_link primfeaturelink on
                        flink.feature_id = primfeaturelink.feature_id
                inner join primitive_instance pri on
                        primfeaturelink.gobject_id = pri.gobject_id and
                        primfeaturelink.package_id = pri.package_id and
                        primfeaturelink.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join visual_element_version vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id 
                inner join #visual_element_ids_for_required_file vei on    
                        vei.visual_element_id = vev.visual_element_id

				union
                select  distinct
                        N'',
        	            f.file_name,
        	            f.vendor_name,
        	            f.subfolder,
        	            f.registration_type,
                        0,
                        f.file_id,
                        piftl.is_needed_for_package,
                        0,
                        0
                from    file_table f
                inner join primitive_instance_file_table_link piftl on
                        piftl.file_id = f.file_id
                inner join primitive_instance pri on
                        piftl.gobject_id = pri.gobject_id and
                        piftl.package_id = pri.package_id and
                        piftl.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join visual_element_version vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id 
                inner join #visual_element_ids_for_required_file vei on    
                        vei.visual_element_id = vev.visual_element_id
                where   (piftl.is_needed_for_package = 1) 
            )    
        end
        else if (@codemodule = 8) -- eRuntimeCodeModules
        begin

            insert into #visual_element_required_file
                    (group_id,
        	        file_name,
        	        vendor_name,
        	        subfolder_name,
        	        registration_type,
                    software_upgrade_needed,
                    file_id,
                    is_needed_for_package,
                    is_needed_for_editor,
                    is_needed_for_runtime)
            (
select  distinct
                        N'',
        	            f.file_name,
        	            f.vendor_name,
        	            f.subfolder,
        	            f.registration_type,
                        0,
                        f.file_id,
                        0,
                        0,
                        1
                from    file_table f
				inner join feature_file_link flink on
					flink.file_id = f.file_id
                inner join primitive_instance_feature_link primfeaturelink on
                        flink.feature_id = primfeaturelink.feature_id
                inner join primitive_instance pri on
                        primfeaturelink.gobject_id = pri.gobject_id and
                        primfeaturelink.package_id = pri.package_id and
                        primfeaturelink.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join visual_element_version vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id 
                inner join #visual_element_ids_for_required_file vei on    
                        vei.visual_element_id = vev.visual_element_id

				union
                select  distinct
                        N'',
        	            f.file_name,
        	            f.vendor_name,
        	            f.subfolder,
        	            f.registration_type,
                        0,
                        f.file_id,
                        0,
                        0,
                        piftl.is_needed_for_runtime
                from    file_table f
                inner join primitive_instance_file_table_link piftl on
                        piftl.file_id = f.file_id
                inner join primitive_instance pri on
                        piftl.gobject_id = pri.gobject_id and
                        piftl.package_id = pri.package_id and
                        piftl.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join visual_element_version vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id 
                inner join #visual_element_ids_for_required_file vei on    
                        vei.visual_element_id = vev.visual_element_id
                where   (piftl.is_needed_for_runtime = 1) 
            )
        end





	/*****************************************
        *  set the software_upgrade_needed bit..
        ******************************************/
        if (@node_name is not null)
        begin
            update  #visual_element_required_file
            set     software_upgrade_needed = 1
            where   file_id in 
                (
                    select  file_id 
                    from    file_pending_update fp
	                where   fp.node_name =UPPER(@node_name)
                )
                
        --step 3 ...Add all the filelist required for Package or Editor Code Modules..which are required to be deleted as they are old..because they havent been removed
		--when template got deleted so we need to update them when a new template or file will come..
			update  #visual_element_required_file
			set     software_upgrade_needed = 1
			where   file_id in 
			(
				select file_id from deployed_file
				where need_to_delete = 1
				and deployed_file.node_name = UPPER(@node_name)					
			)
		end
        
        commit transaction
    END

-- End of temporary solution

    select  f.group_id,
            f.file_name,
        	f.vendor_name,
        	f.registration_type,
            f.software_upgrade_needed,
	        f.file_id,
	        f.subfolder_name
    from    #visual_element_required_file f
    where   f.file_id not in 
            (
                  select distinct file_id
                  from    deployed_file 
                  where   node_name = UPPER(@node_name)
				and ( (is_editor_deployed = 1) or 
			(is_package_deployed = 1) or (is_runtime_deployed = 1))
		  
            )
	or f.software_upgrade_needed = 1
	order by software_upgrade_needed DESC
	
    
     insert into deployed_file 
            (file_id, 
             node_name, 
             need_to_delete, 
             is_package_deployed, 
             is_editor_deployed,
             is_runtime_deployed,
             is_browser_deployed)
    (             
        select  file_id, 
                @node_name, 
                0 as need_to_delete, 
                is_needed_for_package as is_package_deployed,
                is_needed_for_editor as is_editor_deployed,
                is_needed_for_runtime as is_runtime_deployed,
                0 as is_browser_deployed
        from    #visual_element_required_file f
        where   f.file_id not in 
                (
                    select distinct file_id
                    from    deployed_file 
                    where   node_name = UPPER(@node_name)					
                )
    )
    
       update deployed_file
		set file_version = ft.file_version,
		file_modified_time = ft.file_modified_time
		from file_table ft, deployed_file df
		where df.file_id = ft.file_id  and
			  df.node_name = UPPER(@node_name)

    drop table #visual_element_ids_for_required_file

    drop table #visual_element_required_file

    commit transaction

end
go

