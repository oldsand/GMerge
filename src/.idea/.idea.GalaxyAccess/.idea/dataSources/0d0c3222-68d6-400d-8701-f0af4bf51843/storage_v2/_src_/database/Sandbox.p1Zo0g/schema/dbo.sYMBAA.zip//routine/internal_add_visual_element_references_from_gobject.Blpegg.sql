create procedure dbo.internal_add_visual_element_references_from_gobject
@gobject_id int,
@package_id int,
@source_object_gobject_id int,
@source_object_package_id int
as
begin tran

-- do not process backup objects...
declare @namespace_id smallint
select @namespace_id = namespace_id
from gobject 
where gobject_id = @gobject_id
if(@namespace_id = 2)
	return

if exists(select '*'
            from internal_visual_element_reference_view
            where gobject_id = @source_object_gobject_id and
              package_id = @source_object_package_id

           )
begin
    -- create temp table to store parents info...
     declare @my_parents_ve_references table
     (
        mx_primitive_id smallint,
        visual_element_reference_index int,
        reference_string nvarchar(395)
      )
      
    
    insert into 
        @my_parents_ve_references
    select
        distinct
        mx_primitive_id,
        visual_element_reference_index,
        reference_string
    from internal_visual_element_reference_view
    where gobject_id = @source_object_gobject_id and
          package_id = @source_object_package_id
          
    
    
    declare @mx_primitive_id smallint
    declare @visual_element_reference_index int
    declare @reference_string nvarchar(395)
    
    while exists(select '1' from @my_parents_ve_references)
    begin
        select top 1
            @mx_primitive_id = mx_primitive_id,
            @visual_element_reference_index = visual_element_reference_index,
            @reference_string = reference_string
        from @my_parents_ve_references             
        
        -- only add new references ....
        if not exists(
                        select '1' from
                        visual_element_reference 
                        where gobject_id = @gobject_id and
                              package_id = @package_id and
                              mx_primitive_id = @mx_primitive_id and
                              visual_element_reference_index = @visual_element_reference_index
                        )
        begin
            exec internal_add_visual_element_reference 
                @gobject_id,
                @package_id,
                @mx_primitive_id,
                @visual_element_reference_index,
                @reference_string,
                0
        end
    
        delete 
        from  @my_parents_ve_references
        where 
            @mx_primitive_id = mx_primitive_id and 
            @visual_element_reference_index = visual_element_reference_index and
           (@reference_string = reference_string or @reference_string is null )
    end


end    
commit
go

