-- This stored procedure is called when AAGR is started. It is executed only 
-- one time against each database. It cleans up the database if necessary.
-- 

create proc dbo.internal_cleanup_database
as
begin
    set nocount on

    begin tran

    set rowcount 0

    delete  deleted_gobject

	 truncate table visual_element_affected_by_undo_check_out

    commit

end
go

