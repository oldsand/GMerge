create procedure dbo.internal_bind_relative_visual_elements_for_gobject
@gobject_id int,
@package_id int
as

if exists(select 1 from galaxy where is_migration_in_progress = 1)
    return
    
begin tran 


    declare @checked_in_relative_unbound_elements_to_bind table
    (gobject_id int,
    package_id int,
    mx_primitive_id smallint,
    visual_element_reference_index int,
    checked_in_bound_visual_element_gobject_id int null,
    checked_in_bound_visual_element_package_id int null,
    checked_in_bound_visual_element_mx_primitive_id smallint null)
        
    declare @checked_out_relative_unbound_elements_to_bind table
    (gobject_id int,
    package_id int,
    mx_primitive_id smallint,
    visual_element_reference_index int,
    checked_out_bound_visual_element_gobject_id int null,
    checked_out_bound_visual_element_package_id int null,
    checked_out_bound_visual_element_mx_primitive_id smallint null,
    checked_out_visual_element_package_id int null,
    checked_out_to_user_guid uniqueidentifier null)
        

-- first, try to bind the checked-in VEs    
    if exists 
    (
        select 1 
        from internal_checked_in_unbound_relative_visual_element_reference_view (noexpand) 
        where checked_in_unbound_hierarchical_visual_element_name is not null 
    )
    begin
        insert into @checked_in_relative_unbound_elements_to_bind
        (gobject_id,
        package_id,
        mx_primitive_id ,
        visual_element_reference_index ,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id )    
        select
        u_view.gobject_id,
    	u_view.package_id,
    	u_view.mx_primitive_id ,
    	u_view.visual_element_reference_index,
        v.gobject_id,
        v.package_id,
        v.mx_primitive_id
        from  internal_checked_in_unbound_relative_visual_element_reference_view u_view (noexpand) 
        inner join internal_visual_element_description_view v (noexpand) on 
            v.hierarchical_visual_element_name = u_view.checked_in_unbound_hierarchical_visual_element_name and
            v.visual_element_type = u_view.checked_in_unbound_visual_element_type and
            v.checked_in_package_id = v.package_id
        where v.gobject_id = @gobject_id and
              v.package_id = @package_id
    
        --update the checked_in_bound ver columns....
        if exists(select 1 from @checked_in_relative_unbound_elements_to_bind)
        begin
            update  ver
            set 
                -- bound columns...
                ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
                ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
                ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
                -- unbound columns...
                ver.checked_in_unbound_visual_element_name = null,
                ver.checked_in_unbound_visual_element_type = null,
                ver.checked_in_unbound_tag_name = null,
                ver.checked_in_unbound_primitive_name = null,
                ver.checked_in_unbound_relative_object_name = null,
                ver.checked_in_unbound_visual_element_id = null
            from visual_element_reference ver 
            inner join @checked_in_relative_unbound_elements_to_bind wt on
                wt.gobject_id = ver.gobject_id and
                wt.package_id = ver.package_id and
                wt.mx_primitive_id = ver.mx_primitive_id and
                wt.visual_element_reference_index = ver.visual_element_reference_index
            where
                ver.is_relative_reference = 1 and
                ver.checked_in_bound_visual_element_gobject_id is null
         		and ver.checked_in_bound_visual_element_package_id is null
        	    and ver.checked_in_bound_visual_element_mx_primitive_id is null
        end
    end

    
        -- next, try to bind the checked-out VEs...
    if exists 
    (
        select 1 
        from internal_checked_out_unbound_relative_visual_element_reference_view (noexpand) 
        where checked_out_unbound_hierarchical_visual_element_name is not null 
    )
    begin
        insert into @checked_out_relative_unbound_elements_to_bind
        (gobject_id,
        package_id,
        mx_primitive_id ,
        visual_element_reference_index ,
        checked_out_bound_visual_element_gobject_id ,
        checked_out_bound_visual_element_package_id ,
        checked_out_bound_visual_element_mx_primitive_id,
        checked_out_visual_element_package_id ,
        checked_out_to_user_guid)  
        select
            u_view.gobject_id,
        	u_view.package_id,
        	u_view.mx_primitive_id ,
        	u_view.visual_element_reference_index,
            v.gobject_id,
            v.package_id,
            v.mx_primitive_id,
            v.package_id,
            v.checked_out_by_user_guid
        from  internal_checked_out_unbound_relative_visual_element_reference_view u_view (noexpand) 
        inner join internal_visual_element_description_view v (noexpand) on 
            v.hierarchical_visual_element_name = u_view.checked_out_unbound_hierarchical_visual_element_name and
            v.visual_element_type = u_view.checked_out_unbound_visual_element_type and
            v.checked_out_package_id = v.package_id
        where v.gobject_id = @gobject_id and
              v.package_id = @package_id

        
    
            --update the checked_out_bound ver columns....
            if exists(select 1 from @checked_out_relative_unbound_elements_to_bind)
            begin
                update  ver
                set 
                    -- bound columns...
                    ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
                    ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
                    ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
                    ver.checked_out_visual_element_package_id = wt.checked_out_visual_element_package_id,
                    ver.checked_out_to_user_guid = wt.checked_out_to_user_guid,
                    -- unbound columns...
                    ver.checked_out_unbound_visual_element_name = null,
                    ver.checked_out_unbound_visual_element_type = null,
                    ver.checked_out_unbound_tag_name = null,
                    ver.checked_out_unbound_primitive_name = null,
                    ver.checked_out_unbound_relative_object_name = null,
                    ver.checked_out_unbound_visual_element_id = null
                from @checked_out_relative_unbound_elements_to_bind wt 
                inner join visual_element_reference ver on
                    wt.gobject_id = ver.gobject_id and
                    wt.package_id = ver.package_id and
                    wt.mx_primitive_id = ver.mx_primitive_id and
                    wt.visual_element_reference_index = ver.visual_element_reference_index
                where
                    ver.is_relative_reference = 1 and
                    ver.checked_out_bound_visual_element_gobject_id is null
             		and ver.checked_out_bound_visual_element_package_id is null
            	    and ver.checked_out_bound_visual_element_mx_primitive_id is null
        end
    end
            
commit
go

