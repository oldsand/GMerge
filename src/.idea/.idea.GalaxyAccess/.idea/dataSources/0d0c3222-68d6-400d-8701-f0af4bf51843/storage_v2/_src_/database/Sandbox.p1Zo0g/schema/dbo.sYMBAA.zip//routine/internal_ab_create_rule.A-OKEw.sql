CREATE PROCEDURE dbo.internal_ab_create_rule
      @rule_name   nvarchar (329)
    , @input_spec  nvarchar (512)
	, @output_spec nvarchar (512) = NULL
as
begin
    set nocount on

	declare @result int
	set @result = -1

	if @input_spec IS NOT NULL
	begin

		insert into autobind_naming_rule (rule_name) values (@rule_name)
		if @@ROWCOUNT <> 0
		begin
			set @result = @@IDENTITY

			if @output_spec IS  NULL
				set @output_spec = @input_spec

			INSERT INTO autobind_naming_rule_spec (rule_id, io_type, rule_spec)
			VALUES	(@result, N'I', @input_spec),
					(@result, N'O', @output_spec)
		end
	end
    return @result
end
go

