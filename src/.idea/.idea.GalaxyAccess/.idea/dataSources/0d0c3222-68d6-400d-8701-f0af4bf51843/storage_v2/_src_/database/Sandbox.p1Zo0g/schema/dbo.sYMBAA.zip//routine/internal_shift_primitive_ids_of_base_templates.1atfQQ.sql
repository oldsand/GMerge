-----SHIFT PRIM ID FOR BASETEMPLATE
create proc dbo.internal_shift_primitive_ids_of_base_templates
@basetemplateName nvarchar(329)
as
begin
begin tran
declare @template_def_id int
declare @g_id int

set @g_id = 0
set @template_def_id = 0

select @g_id = base_gobject_id, 
@template_def_id = template_definition_id
from template_definition 
where 
original_template_tagname = @basetemplateName

print @template_def_id
print @g_id

if @g_id > 0
begin

	declare @max_primitive_id int
	select @max_primitive_id = max(pi.mx_primitive_id) from primitive_instance pi
	inner join gobject gi on pi.gobject_id = gi.gobject_id
	inner join template_definition td on 
	td.template_definition_id = gi.template_definition_id
	where td.category_id = 1
	
	
	print @max_primitive_id
	declare @delta int
	set @delta = (@max_primitive_id + 100)
	print @delta

	update primitive_definition
	set mx_primitive_id = mx_primitive_id + @delta
	from primitive_definition
	where mx_primitive_id > 102
	and template_definition_id = @template_def_id

	update primitive_definition
	set parent_mx_primitive_id = parent_mx_primitive_id + @delta
	from primitive_definition
	where parent_mx_primitive_id > 102
	and template_definition_id = @template_def_id


	create table dbo.temp_template_attribute (
		gobject_id      int not null,
		package_id      int not null,
		mx_primitive_id smallint not null,
		mx_attribute_id smallint not null,
		security_classification int not null,
		mx_data_type smallint not null,
		mx_value text not null,
		lock_type int not null,
		original_lock_type int not null default 0
	)
	
	insert into temp_template_attribute(gobject_id,package_id,
										mx_primitive_id,mx_attribute_id,
										security_classification,
										mx_data_type,mx_value,lock_type,
										original_lock_type)
	select gobject_id,package_id,mx_primitive_id,
			mx_attribute_id,security_classification,
			mx_data_type,mx_value,lock_type,original_lock_type 
	from  template_attribute
	where mx_primitive_id > 102 
	and gobject_id = @g_id

	update temp_template_attribute
	set mx_primitive_id = mx_primitive_id + @delta
	from temp_template_attribute
	where mx_primitive_id > 102
	and gobject_id = @g_id




	create table dbo.temp_primitive_instance(
	[gobject_id] [int] NOT NULL,
	[package_id] [int] NOT NULL,
	[mx_primitive_id] [smallint] NOT NULL,
	[primitive_definition_id] [int] NOT NULL,
	[primitive_name] [nvarchar](329) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[parent_mx_primitive_id] [smallint] NOT NULL,
	[execution_group] [int] NOT NULL,
	[execution_order] [int] NOT NULL DEFAULT ((-1)),
	[owned_by_gobject_id] [int] NOT NULL DEFAULT ((0)),
	[timestamp_of_last_change] [bigint] NULL DEFAULT ((0)),
	[max_child_timestamp] [bigint] NULL DEFAULT ((0)),
	[extension_type] [nvarchar](329) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[is_object_extension] [bit] NULL DEFAULT ((0)),
	[checked_in_primitive_version] [int] NOT NULL DEFAULT ((1)),
	[checked_out_primitive_version] [int] NOT NULL DEFAULT ((1)))

	insert into temp_primitive_instance(gobject_id,package_id,mx_primitive_id,primitive_definition_id,primitive_name,parent_mx_primitive_id,
		execution_group,execution_order,owned_by_gobject_id,timestamp_of_last_change,
		max_child_timestamp,extension_type,is_object_extension,checked_in_primitive_version,
		checked_out_primitive_version)
	select gobject_id,package_id,mx_primitive_id,primitive_definition_id,primitive_name,parent_mx_primitive_id,
		execution_group,execution_order,owned_by_gobject_id,timestamp_of_last_change,
		max_child_timestamp,extension_type,is_object_extension,checked_in_primitive_version,
		checked_out_primitive_version from primitive_instance
	where (mx_primitive_id >102 or parent_mx_primitive_id >102)
	and gobject_id = @g_id


	update temp_primitive_instance
	set mx_primitive_id = mx_primitive_id + @delta
	from temp_primitive_instance
	where mx_primitive_id >102
	and gobject_id = @g_id

	update temp_primitive_instance
	set parent_mx_primitive_id = parent_mx_primitive_id + @delta
	from temp_primitive_instance
	where parent_mx_primitive_id > 102
	and gobject_id = @g_id


	delete from template_attribute
	where mx_primitive_id > 102
	and gobject_id = @g_id 


	delete from primitive_instance
	where mx_primitive_id > 102
	and gobject_id = @g_id

	insert into primitive_instance(gobject_id,package_id,mx_primitive_id,primitive_definition_id,primitive_name,parent_mx_primitive_id,
		execution_group,execution_order,owned_by_gobject_id,timestamp_of_last_change,
		max_child_timestamp,extension_type,is_object_extension,checked_in_primitive_version,
		checked_out_primitive_version,mx_value_errors,mx_value_warnings,mx_value_reference_warnings)
	select gobject_id,package_id,mx_primitive_id,primitive_definition_id,primitive_name,parent_mx_primitive_id,
		execution_group,execution_order,owned_by_gobject_id,timestamp_of_last_change,
		max_child_timestamp,extension_type,is_object_extension,checked_in_primitive_version,
		checked_out_primitive_version,'0x00','0x00','0x00' from temp_primitive_instance
	
	insert into template_attribute(gobject_id,package_id,mx_primitive_id,mx_attribute_id,security_classification,mx_data_type,mx_value,lock_type,original_lock_type)
	select gobject_id,package_id,mx_primitive_id,mx_attribute_id,security_classification,mx_data_type,mx_value,lock_type,original_lock_type from  temp_template_attribute

	drop table temp_template_attribute
	drop table temp_primitive_instance
end


--select * from primitive_definition where template_definition_id = @template_def_id
--select * from primitive_instance where gobject_id = @g_id 
--select * from template_attribute where gobject_id = @g_id 
----------==============================================
commit
end



go

