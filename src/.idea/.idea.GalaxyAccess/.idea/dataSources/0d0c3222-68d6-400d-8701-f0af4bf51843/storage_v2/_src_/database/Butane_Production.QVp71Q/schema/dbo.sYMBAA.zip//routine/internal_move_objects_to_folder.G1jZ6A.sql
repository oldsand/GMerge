
/***********************************************************************************************************************************
If you change this you need to check w/ Foxboro. This is used by Foxboro objects in their MigratePrimitive methods -- HF1467 CR93406
************************************************************************************************************************************/

/**************************************************/
/*Object Name :  internal_move_objects_to_folder                            */
/*Object Type :  Stored Proc.								*/
/*Purpose :    move objects to target folder*/
/*Used By :    CDI									*/
/**************************************************/
create proc dbo.internal_move_objects_to_folder
@FileNameOfIds nvarchar (265),
@folder_Id int
 AS
begin
set nocount on
begin tran
declare @ErrorCode int

    CREATE TABLE  #input_object_ids ( gobject_id int)

    DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #input_object_ids  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'',ROWTERMINATOR = '','')'
    EXEC (@SQL)
    --get template ids
    CREATE TABLE  #input_template_Ids ( gobject_id int, is_template bit)
    insert into #input_template_Ids
        select i.gobject_id, g.is_template from #input_object_ids i 
        inner join gobject g
        on i.gobject_id = g.gobject_id
        where g.is_template = 1 and g.namespace_id = 1

    --get graphic ids
    CREATE TABLE  #input_graphic_ids ( gobject_id int)
    insert into #input_graphic_ids
        select i.gobject_id from #input_object_ids i 
        inner join gobject g
        on i.gobject_id = g.gobject_id
        where g.is_template = 0 and g.namespace_id = 3


declare @folder_type int
if(@folder_Id > 0)
begin
    select @folder_type = folder_type from folder where folder_id = @folder_Id
end
else
begin
    set @folder_type = 2
end


------------@callMoveSymbols---------------------------
if(@folder_type = 2)
begin
   if exists(select '*' from #input_template_Ids) 
   begin
        set @ErrorCode = 1000 --'templates cannot be assigned to VEL folder
        rollback
		return     
   end

    -- update folder_id of each symbol
    update folder_gobject_link 
    set folder_id = @folder_Id 
    from folder_gobject_link inner join
    #input_graphic_ids on 
    folder_gobject_link.gobject_id = #input_graphic_ids.gobject_id

    -- update contained name to set trigeer for each symbol
    UPDATE gobject SET contained_by_gobject_id = 0
    from gobject g inner join #input_graphic_ids it on 
    g.gobject_id = it.gobject_id

    update pt
    set pt.gobject_id = pt.gobject_id
    from proxy_timestamp pt
    inner join #input_graphic_ids gi on
        pt.gobject_id = gi.gobject_id

	update gift
	set gift.gobject_id = gift.gobject_id
	from #input_graphic_ids i
	inner join gobject_filter_info_timestamp gift on
		i.gobject_id = gift.gobject_id

    select gobject_id,1 from #input_graphic_ids  

end

------------@callMoveTemplates---------------------------
if(@folder_type = 1)
begin   
   if exists(select '*' from #input_graphic_ids) 
   begin
        set @ErrorCode = 1001 --'vel cannot be assigned to toolset folder
        rollback
		return     
   end
    -- get all Contained children for templates    
	CREATE TABLE  #child_gobjects ( gobject_id int, original_order int)
    insert  #child_gobjects (gobject_id,original_order)
    exec internal_get_all_my_contained_children_including_us @FileNameOfIds

    -- unmangle the tagnames for each templates which is coming in from the client
	CREATE TABLE  #input_template_ids_in_alpha_order ( gobject_id int)
	insert into #input_template_ids_in_alpha_order(gobject_id)
    SELECT g.gobject_id FROM #input_template_Ids t
		inner join gobject g on 
		t.gobject_id = g.gobject_id 
		order by g.tag_name
    
	DECLARE input_template_cursor CURSOR FOR 
    SELECT gobject_id FROM #input_template_ids_in_alpha_order
    OPEN input_template_cursor

    DECLARE @gobject_id int

    FETCH NEXT FROM input_template_cursor 
    INTO @gobject_id

    WHILE @@FETCH_STATUS = 0
    BEGIN
        exec internal_unmangle_template_name @gobject_id

        FETCH NEXT FROM input_template_cursor 
        INTO @gobject_id
    END

    CLOSE input_template_cursor
    DEALLOCATE input_template_cursor
	DROP TABLE #input_template_ids_in_alpha_order 

    -- update folder_id of each contained template
    update folder_gobject_link 
    set folder_id = @folder_Id 
    from folder_gobject_link inner join
    #child_gobjects  
    on 
    folder_gobject_link.gobject_id = #child_gobjects.gobject_id

	-- update the timestamp of container objects...
    update pt
    set pt.gobject_id = pt.gobject_id
    from #child_gobjects t
    inner join gobject g on
        g.gobject_id = t.gobject_id
    inner join proxy_timestamp pt on
        g.contained_by_gobject_id = pt.gobject_id

	update gift
	set gift.gobject_id = gift.gobject_id
	from #child_gobjects c
	inner join gobject_filter_info_timestamp gift on
		c.gobject_id = gift.gobject_id



    -- update contained name and id of input list...
    UPDATE gobject SET contained_by_gobject_id = 0, contained_name = '' 
        from gobject g inner join #input_template_Ids it on 
        g.gobject_id = it.gobject_id

    -- set hierchial name for only which is coming from the client
    DECLARE input_template_cursor1 CURSOR FOR 
    SELECT gobject_id FROM #input_template_Ids
    OPEN input_template_cursor1

    set @gobject_id = 0

    FETCH NEXT FROM input_template_cursor1 
    INTO @gobject_id

    WHILE @@FETCH_STATUS = 0
    BEGIN
        exec internal_set_full_hierarchical_name @gobject_id

        FETCH NEXT FROM input_template_cursor1 
        INTO @gobject_id
    END

    CLOSE input_template_cursor1
    DEALLOCATE input_template_cursor1

-- set hierchial name for only which is coming from the client
    DECLARE child_cursor1 CURSOR FOR 
    SELECT gobject_id FROM #child_gobjects
    OPEN child_cursor1

    set @gobject_id = 0

    FETCH NEXT FROM child_cursor1 
    INTO @gobject_id

    WHILE @@FETCH_STATUS = 0
    BEGIN
        exec internal_set_full_hierarchical_name @gobject_id

        FETCH NEXT FROM child_cursor1 
        INTO @gobject_id
    END

    CLOSE child_cursor1
    DEALLOCATE child_cursor1
    
    update pt
    set pt.gobject_id = pt.gobject_id
    from proxy_timestamp pt
    inner join #child_gobjects gi on
        pt.gobject_id = gi.gobject_id

		-- L00084934 (Start)
		declare @effectedTemplates table(gobject_id int);

		WITH DerviedTemplateHierarchy (gobject_id, derived_from_gobject_id) AS
		(
		-- Base case
		SELECT
			gobject_id,
			0 as derived_from_gobject_id
		FROM gobject
		WHERE gobject_id in (select gobject_id from #input_object_ids)  and is_template = 1

		UNION ALL

		-- Recursive step
		(SELECT
			g.gobject_id,
			g.derived_from_gobject_id
		FROM gobject g
			INNER JOIN DerviedTemplateHierarchy th ON
			g.derived_from_gobject_id = th.gobject_id and g.is_template = 1)
		)

		insert into #input_object_ids
		select gobject_id from DerviedTemplateHierarchy

		-------- L00084934 (end)
    select distinct gobject_id,2 from #input_object_ids i 
    
    drop table #child_gobjects
end
	
	update folder
    set has_objects = has_objects
    where folder_id = @folder_Id


	

    update galaxy
    set max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 
    
drop table #input_object_ids
drop table #input_graphic_ids
drop table #input_template_Ids

commit


end
go

