/*
returns information required for PackageServer::Upload operation

usage

for selected objects:

exec internal_get_upload_info '<r>
        <gobject id=''11''/>
        <gobject id=''12''/>
    </r>'

for entire galaxy:

exec internal_get_upload_info '<r></r>'

*/
create proc dbo.internal_get_upload_info
    @FileNameOfIds nvarchar (265)
as
begin
set nocount on
    -- populate mx_ids
        
	SET QUOTED_IDENTIFIER OFF

	create table #gobject_ids( gobject_id int )
	
	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #gobject_ids  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	EXEC (@SQL)

	-- we get the count of objects, if zero upload entire galaxy
    declare @object_count int
    select @object_count = count('*') from #gobject_ids

    if( @object_count <> 0 )
    begin
        -- return UploadInfo for passed in gobject_ids
        select gobject.gobject_id, gobject.checked_out_by_user_guid, instance.mx_platform_id, instance.mx_engine_id, instance.mx_object_id,
			   case when gobject.deployed_package_id = 0 				
					then dbo.is_partner_in_pending_update_state(gobject.gobject_id) 					 									
				else
			   case when ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version  
						<> deployed_package.deployable_configuration_version)
				then 1	else 0 	end 
				end as pending_update,		        
			  case when gobject.deployed_package_id = 0 
				then dbo.is_partner_deployed(gobject.gobject_id)
				else gobject.deployed_package_id 
				end,gobject.namespace_id,
				gobject.software_upgrade_needed
        from #gobject_ids gobject_ids
        inner join gobject on gobject.gobject_id = gobject_ids.gobject_id
        inner join instance on instance.gobject_id = gobject_ids.gobject_id
        left join package checked_in_package   on 
			gobject.gobject_id = checked_in_package.gobject_id and 
			gobject.checked_in_package_id = checked_in_package.package_id
		left join package deployed_package  on 
			gobject.gobject_id = deployed_package.gobject_id and 
			gobject.deployed_package_id = deployed_package.package_id
		order by instance.mx_platform_id, instance.mx_engine_id, instance.mx_object_id

    end
    else
    begin
        -- return UploadInfo for all deployed objects in galaxy
        select gobject.gobject_id, 
				gobject.checked_out_by_user_guid, 
				instance.mx_platform_id, 
				instance.mx_engine_id, 
				instance.mx_object_id,
				case when gobject.deployed_package_id = 0 
					then 0
				else
					case when (checked_in_package.deployable_configuration_version 
						<> deployed_package.deployable_configuration_version)
					then 1	else 0 	end 
				end as pending_update,				  
			    case when gobject.deployed_package_id = 0 
					then dbo.is_partner_deployed(gobject.gobject_id)
				else 
					gobject.deployed_package_id end,
				gobject.namespace_id,
				gobject.software_upgrade_needed
        from gobject 
        inner join instance on instance.gobject_id = gobject.gobject_id
		left join package checked_in_package   on 
			gobject.gobject_id = checked_in_package.gobject_id and 
			gobject.checked_in_package_id = checked_in_package.package_id
		left join package deployed_package  on 
			gobject.gobject_id = deployed_package.gobject_id and 
			gobject.deployed_package_id = deployed_package.package_id
        where gobject.deployed_package_id <> 0
		order by instance.mx_platform_id, instance.mx_engine_id, instance.mx_object_id
    end

    -- cleanup
    drop table #gobject_ids

set nocount off    
end


go

