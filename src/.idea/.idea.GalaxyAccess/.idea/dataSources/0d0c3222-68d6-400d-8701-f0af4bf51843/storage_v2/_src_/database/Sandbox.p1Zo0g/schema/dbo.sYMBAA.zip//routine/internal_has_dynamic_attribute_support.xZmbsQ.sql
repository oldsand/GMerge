/**************************************************/
/*Object Name :  internal_has_dynamic_attribute_support				*/
/*Object Type :  Stored Proc.										*/
/*Purpose :    Procedure to find out if the object has any primitive which supports dynamic attribute*/
/*Used By :    CDI													*/
/**************************************************/
create procedure dbo.internal_has_dynamic_attribute_support
@varTagName				nvarchar(329) ,
@varsupportdynamicattr  int   out
AS
begin
set nocount on
set @varsupportdynamicattr =  (select count(*) from primitive_definition pd,gobject g 
										where g.tag_name = @varTagName 
										and g.template_definition_id = pd.template_definition_id
										and g.namespace_id = 1  -- Automation Object
										and pd.supports_dynamic_attributes = 1 )



end
go

