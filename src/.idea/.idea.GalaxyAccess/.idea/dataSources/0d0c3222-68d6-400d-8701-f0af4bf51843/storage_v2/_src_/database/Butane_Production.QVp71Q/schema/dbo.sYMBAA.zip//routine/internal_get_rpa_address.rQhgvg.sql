-- Returns RPA for the input engineid
CREATE    procedure dbo.internal_get_rpa_address
    @engineId  int,
    @rpaAddress  nvarchar(256)  OUTPUT,
	@portNMX	integer OUTPUT,
	@portRMC	integer OUTPUT,
	@portRPC	integer OUTPUT,
	@partnerPlatformNetAddress nvarchar(256)  OUTPUT,
	@partnerMxPlatformId  smallint OUTPUT
as 
begin
set nocount on

declare @partnerPlatformId integer

declare @rmcAddress nvarchar(256)
declare @lastdeployedrmcAddress nvarchar(256)
set @rmcAddress = N''
set @lastdeployedrmcAddress = N''

declare @PartnerportNMX integer
declare @lastdeployedPartnerportNMX integer
set @PartnerportNMX = 0
set @lastdeployedPartnerportNMX = 0

declare @PartnerportRMC integer
declare @lastdeployedPartnerportRMC integer
set @PartnerportRMC = 0
set @lastdeployedPartnerportRMC = 0

declare @PartnerportRPC integer
declare @lastdeployedPartnerportRPC integer
set @PartnerportRPC = 0 
set @lastdeployedPartnerportRPC = 0

declare @PartnersNetAddress nvarchar(256)
declare @lastdeployedPartnersNetAddress nvarchar(256)
set @PartnersNetAddress = N''
set @lastdeployedPartnersNetAddress = N''
set @partnerMxPlatformId = 0


select  @rmcAddress = p.rmcNode_name,
	@lastdeployedrmcAddress = p.last_deployed_rmcNode_name,
	@partnerPlatformId = p.platform_gobject_id,
	@PartnerportNMX = p.portNMX,
	@lastdeployedPartnerportNMX = p.last_deployed_portNMX,
	@PartnerportRMC = p.portRMC,
	@lastdeployedPartnerportRMC = p.last_deployed_portRMC,
	@PartnerportRPC = p.portRPC,
	@lastdeployedPartnerportRPC = p.last_deployed_portRPC,
	@partnerMxPlatformId =  i.mx_platform_id,
	@PartnersNetAddress = p.node_name,
	@lastdeployedPartnersNetAddress = p.last_deployed_node_name

	from platform p inner join instance i
	on p.platform_gobject_id = i.gobject_id
        where i.mx_platform_id = (select ins.mx_platform_id  from instance ins where
	ins.gobject_id = dbo.get_failover_partner_id(@engineId)) and i.mx_object_id = 1 
	and i.mx_engine_id = 1

declare @isDeployed integer
select @isDeployed = deployed_package_id from gobject where gobject_id = @partnerPlatformId

if(@isDeployed <> 0 )
begin
	set @rpaAddress = @lastdeployedrmcAddress
	set @portNMX	= @lastdeployedPartnerportNMX
	set @portRMC	= @lastdeployedPartnerportRMC
	set @portRPC	= @lastdeployedPartnerportRPC
	set @partnerPlatformNetAddress = @PartnersNetAddress
end
else	
begin
	set @rpaAddress = @rmcAddress
	set @portNMX	= @PartnerportNMX
	set @portRMC	= @PartnerportRMC
	set @portRPC	= @PartnerportRPC
	set @partnerPlatformNetAddress = @lastdeployedPartnersNetAddress
end

set nocount off	
end


go

