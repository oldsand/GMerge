-- usage: exec internal_undo_checkout_gobject checkoutObjectId, checkoutUserId
-- Sample: exec internal_undo_checkout_gobject 10, 1
--
create proc dbo.internal_undo_checkout_gobject 
    @checkoutObjectId int,
    @checkoutUserId int,
	@output_errorcode int out,
	@output_errormsg nvarchar(64) out
as
begin
	declare @errorcode int
	declare @errormsg nvarchar(64)

	set @errorcode = 0
	set @errormsg = ''

	begin tran
    set nocount on    
    
    -- figure out the correct package_id for this user
    declare @gobject_id int
    declare @loggedin_user_id int
    declare @checkout_gobject_package_id int
    declare @is_template bit


	set @gobject_id = @checkoutObjectId
	set @loggedin_user_id = @checkoutUserId

	-- Check whether this is an instance or a template, get some info
	if (@errorcode = 0)
	begin
	    select 
			@checkout_gobject_package_id = g.checked_out_package_id
	    from 
	        gobject g
	    where
	        g.gobject_id = @gobject_id

		if (@@rowcount <> 1)
		begin
			set @errorcode = 1
			set @errormsg = 'Can not find gobject by gobject id.'
		end
	end

	if (@errorcode = 0)
	begin
		if (@checkout_gobject_package_id <> 0)
		begin
/*			if (@is_template <> 0) 
			begin
				-- Template attribute
				delete	template_attribute
				from	template_attribute ta,
						primitive_instance pri
				where	ta.primitive_instance_id = pri.primitive_instance_id and
						pri.package_id = @checkout_gobject_package_id
			end
		
			-- Now delete the primitive instance
			delete	primitive_instance
			where	package_id = @checkout_gobject_package_id
*/		
			-- Delete the package
			delete	package
			where	package_id = @checkout_gobject_package_id
		
			-- Update the gobject row
			update	gobject
			set		checked_out_by_user_guid = NULL,
					checked_out_package_id = 0
			where	gobject_id = @gobject_id

			if (@@error <> 0)
			begin
				set @errorcode = @@error
				set @errormsg = 'Fail in updating tables.'
			end
		end	
		else
		begin
			set @errorcode = 1
			set @errormsg = 'Can not find checkout package'
		end
	end

	-- Commit or rollback transaction
	if (@errorcode = 0)
		commit tran	
	else
		rollback tran

	set	@output_errorcode = @errorcode
	set @output_errormsg = @errormsg
end



go

