create proc dbo.internal_load_template_package
    @gobject_id int,
    @package_id int,
    @loggedin_user_id_guid nvarchar(38),
    @is_association int
as 
begin
    set nocount on
     
    select
        td.category_id
    from
        template_definition td
    inner join
        gobject g
    on 
        td.template_definition_id = g.template_definition_id
    where
        g.gobject_id = @gobject_id
 
    /*
    ** CR L00115843: 
    ** Summary of changes:
    ** - Don't call scalar function get_visual_element_id()
    ** - Avoid in-lined selects
    */
     
    -- load the primitive_instance rows
    select
        pri.primitive_definition_id,
        pri.primitive_name,
        pri.mx_primitive_id,
        pri.parent_mx_primitive_id,
        pri.execution_group,
        pri.execution_order, 
        pri.owned_by_gobject_id,
        pri.extension_type,
        pri.is_object_extension,
        pri.checked_in_primitive_version,
        pri.checked_out_primitive_version,
        isnull (vev.visual_element_id, 0), 
        case when owned_by_gobject_id > 0 then
          owning_object.tag_name
        else
          '' 
        end as inheritedfrom,
        pri.entity_change_type,
        pri.operation_on_primitive_mask,
        pri.created_by_parent,
        pri.status_id,
        pri.ref_status_id,
--        primitive_attributes
        pri.mx_value_errors,
        pri.mx_value_warnings,
        pri.mx_value_reference_warnings,
        pd.primitive_guid
    from
        primitive_instance pri
    inner join 
        primitive_definition pd
    on  pri.primitive_definition_id = pd.primitive_definition_id
    inner join gobject owning_object on
        owning_object.gobject_id = 
        case when owned_by_gobject_id > 0 then owned_by_gobject_id else pri.gobject_id end
    left outer join
		visual_element_version vev
	on  vev.gobject_id = pri.gobject_id
	and vev.package_id = pri.package_id
	and vev.mx_primitive_id = pri.mx_primitive_id
    where
        pri.gobject_id = @gobject_id
    and pri.package_id = @package_id
    order by
        pri.mx_primitive_id


    -- load the template_attribute rows
    select
        a.mx_primitive_id,
        a.mx_attribute_id,
        a.security_classification,
        a.mx_data_type,
        a.mx_value,
        a.lock_type,
        a.original_lock_type
    from 
        template_attribute a
    where 
        a.gobject_id = @gobject_id
    and a.package_id =  @package_id

    -- load the dynamic_attribute rows
    select
        da.mx_primitive_id,
        da.mx_attribute_id,
        da.attribute_name,
        da.mx_data_type,
        da.is_array,
        da.security_classification,
        da.mx_attribute_category,
        da.lock_type,
        da.mx_value,
        da.owned_by_gobject_id,
        da.original_lock_type,
        da.dynamic_attribute_type,
        case when owned_by_gobject_id > 0 then
          owning_object.tag_name
        else
          '' 
        end as dainheritedfrom,
        da.bitvalues    
    from
        dynamic_attribute da
    inner join gobject owning_object on
        owning_object.gobject_id = 
        case when owned_by_gobject_id > 0 then owned_by_gobject_id else da.gobject_id end
    where
        da.gobject_id = @gobject_id
    and da.package_id = @package_id
    
     -- load the package features
    exec internal_load_package_feature @gobject_id, @package_id
    
    -- load visual element refereneces
    if (@is_association = 0)
    begin
    select gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        reference_string,
        visual_element_bind_status
    from internal_visual_element_reference_per_user_view v
    where v.gobject_id = @gobject_id 
        and v.package_id = @package_id
        and v.user_guid = @loggedin_user_id_guid
    order by mx_primitive_id, visual_element_reference_index
    end
    else
    begin
    select gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        reference_string,
        visual_element_bind_status
    from internal_visual_element_reference_per_user_view_association v
    where v.gobject_id = @gobject_id 
        and v.package_id = @package_id
        and v.user_guid = @loggedin_user_id_guid
    order by mx_primitive_id, visual_element_reference_index
    end

    -- Load primitive_instance_file_table_link information
    select  mx_primitive_id,
            file_id,
            is_needed_for_package,
            is_needed_for_runtime,
            is_needed_for_editor
    from    primitive_instance_file_table_link
    where   gobject_id = @gobject_id
            and package_id = @package_id    
            
end
go

