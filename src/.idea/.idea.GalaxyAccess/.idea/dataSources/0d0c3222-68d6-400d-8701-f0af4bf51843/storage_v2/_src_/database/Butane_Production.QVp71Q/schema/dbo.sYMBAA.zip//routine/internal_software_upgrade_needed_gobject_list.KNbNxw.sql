create procedure dbo.internal_software_upgrade_needed_gobject_list
@FileNameOfIds nvarchar(400)
AS
set nocount on
begin

begin tran
	declare @runtime_files table( file_id int )
	
	create table #Temp_files ( file_id int )
	
	-- call the stored procedure 'internal_ConstructTableFromFile'
	exec internal_construct_table_from_file @FileNameOfIds, '#Temp_files'

	insert into @runtime_files(file_id) 
			( select distinct * from #Temp_files)

	drop table #Temp_files

	declare @gobject_id_effected table( gobject_id int )

	insert into @gobject_id_effected select g.gobject_id from gobject g 
		inner join primitive_definition pd on 
			pd.template_definition_id = g.template_definition_id
		inner join file_primitive_definition_link fdl on
			pd.primitive_definition_id = fdl.primitive_definition_id 			
		WHERE 
		(g.deployed_package_id <> 0 ) AND (fdl.file_id 	in (select * from @runtime_files ))	


	insert into @gobject_id_effected select g.gobject_id from gobject g 
		inner join primitive_instance_feature_link pfl on 
			pfl.gobject_id = g.gobject_id
		inner join feature_file_link fl on
			fl.feature_id = pfl.feature_id 			
	where 
		(g.deployed_package_id <> 0 ) and
		 (fl.file_id 	in (select * from @runtime_files ))	

	


    
	create  table #input_table
	(
		visual_element_id int,
		gobject_id int,
		package_id int,
		mx_primitive_id smallint
	)

	create table  #output_table 
	(
		visual_element_id int,
		gobject_id int,
		package_id int,
		mx_primitive_id smallint
	)

	insert into #input_table
	(
		visual_element_id,
		gobject_id,
		package_id,
		mx_primitive_id
	)
	select  distinct
		vev.visual_element_id,
		vev.gobject_id,
		vev.package_id,
		vev.mx_primitive_id       	            
	from    file_table f
	inner join feature_file_link flink on
		flink.file_id = f.file_id
	inner join primitive_instance_feature_link primfeaturelink on
		flink.feature_id = primfeaturelink.feature_id
	inner join primitive_instance pri on
		primfeaturelink.gobject_id = pri.gobject_id and
		primfeaturelink.package_id = pri.package_id and
		primfeaturelink.mx_primitive_id = pri.parent_mx_primitive_id 
	inner join visual_element_version vev on
		pri.gobject_id = vev.gobject_id and
		pri.package_id = vev.package_id and
		pri.mx_primitive_id = vev.mx_primitive_id   
	inner join @runtime_files rtf on
		rtf.file_id = f.file_id


	exec internal_get_recursively_referring_visual_elements



	insert into @gobject_id_effected 
	select g.gobject_id
	from visual_element_reference ver
	inner join #output_table t on 
		ver.checked_in_bound_visual_element_gobject_id = t.gobject_id and
		ver.checked_in_bound_visual_element_package_id = t.package_id and
		ver.checked_in_bound_visual_element_mx_primitive_id= t.mx_primitive_id
	inner join gobject g on
		ver.gobject_id = g.derived_from_gobject_id
	inner join deployed_intouch_viewapp dva on
		g.gobject_id = dva.gobject_id


	drop table #output_table 
	drop table #input_table 


	
	update gobject  set  gobject.software_upgrade_needed = 1 
	from gobject g inner join @gobject_id_effected ge
	on g.gobject_id = ge.gobject_id

	--// then select gobject
	select distinct  g.gobject_id, 1 from @gobject_id_effected g

	-- clean the deployed file table for runtime files
	update deployed_file set is_runtime_deployed = 0 where file_id in ( select file_id from file_pending_update )


	commit tran
end
go

