create proc [dbo].[internal_list_synched_files]
(
@nodename nvarchar(256),
@clientidentity nvarchar(256) output
)  
as

set nocount on

begin
		
declare @xmlDoc xml 
if exists (select client_unique_identifier from client_info	where UPPER(client_name)= UPPER(@nodename))
begin

	set @clientidentity = (select client_unique_identifier from client_info
	where UPPER(client_name)= UPPER(@nodename))

	
	set @xmlDoc = 	
	(	
	select TAG,PARENT,[SyncInfo!1!ClientIdentity],[SyncInfo!1!TimeStamp], [File_Info!2!File_Info],
	[File_Info!2!file_name],[File_Info!2!vendor_name],[File_Info!2!file_version],[File_Info!2!file_modified_time],
	[File_Info!2!registration_type]	 from 
	
	(
	
	Select 1 as Tag,
	NULL as Parent,
	client_unique_identifier as [SyncInfo!1!ClientIdentity] , 
	timestamp_of_last_synchronized as [SyncInfo!1!TimeStamp],	
	NULL as [File_Info!2!File_Info],
	NULL as [File_Info!2!file_name],
	NULL as [File_Info!2!vendor_name],
	NULL as [File_Info!2!file_version],
	NULL as [File_Info!2!file_modified_time],
	NULL as [File_Info!2!registration_type]	
	from client_info
	where client_name= @nodename	
	UNION 	
	select 2 as Tag,
	1 as Parent,
	null ,
	null,	
	null,
	file_table.file_name as [File_Info!3!file_name],
	file_table.vendor_name as [File_Info!3!vendor_name],
	df.file_version as [File_Info!3!file_version],
	df.file_modified_time as [File_Info!3!file_modified_time],
	file_table.registration_type as [File_Info!3!registration_type]	
	from file_table file_table
	inner join deployed_file df
	on file_table.file_id = df.file_id


	where 
		df.node_name = @nodename
	and 
		df.file_id not  in (select pf.file_id from primitive_instance_file_table_link pf inner join client_control_class_link cc on pf.gobject_id = cc.gobject_id)
	and 
		(df.is_editor_deployed = 1
		or 
		df.is_package_deployed = 1
		or
		df.need_to_delete = 1
		)
		) as A 
		
			FOR XML explicit	
			
			)
	
end
else
begin
set @xmlDoc = ''
end
	select @xmlDoc
	

end
go

