create proc dbo.internal_multi_load_gobject
	@loggedin_user_id_guid nvarchar(38),
	@FileName nvarchar (265),
  @is_association int	
as
begin tran
    set nocount on        
	 
	DECLARE @derivation_level_table table( 
							gobject_id int ,
							parent_gobject_id int,
							object_derivation_level smallint,
							alreadyset bit)
	
	-- figure out the correct package_id for this user
    declare @loggedin_user_id int
    declare @package_id int
	declare @template_definition_id int
    declare @is_template bit
	declare @is_checked_in bit

	SET QUOTED_IDENTIFIER OFF
	
	CREATE TABLE  #idstable ( gobject_id int Not NULL ,
				  nPackageType int default(0),
				  CONSTRAINT gobject_id PRIMARY KEY (gobject_id)	)

	DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #idstable  FROM ''' + @FileName+ ''' WITH(
			    FIELDTERMINATOR = '','',
				TABLOCK,
				DATAFILETYPE  = ''widechar''       
				)'
	EXEC (@SQL)
    
	create table #results_table ( 
		gobject_id int not null,
		package_id int not null,
		template_definition_id int,
		is_template bit,
		is_checked_in bit,
		derived_from_package_id int, 
		nPackageType int,
		last_deployed_package_id int,
		checked_in_package_id int,
		object_derivation_level smallint)
    	
    insert into #results_table( 
					gobject_id ,
					last_deployed_package_id,
					checked_in_package_id,
					template_definition_id ,
					is_template, 
					is_checked_in,
					nPackageType,
					package_id)
	select	o.gobject_id,
			o.last_deployed_package_id,					
			o.checked_in_package_id,					
			o.template_definition_id,
			o.is_template,		
			1,
			idst.nPackageType,
			case when (idst.nPackageType = 3) then 
		         o.last_deployed_package_id
		        else
		         o.checked_in_package_id
		        end 
    from	gobject o
		left join gobject t
			on t.gobject_id = o.derived_from_gobject_id
		inner join #idstable idst 
			on o.gobject_id = idst.gobject_id
	
	update	#results_table
	set		derived_from_package_id = p.derived_from_package_id
	from	#results_table rt
    inner join package p on
        rt.gobject_id = p.gobject_id and 
	    rt.package_id = p.package_id
			
	-- derivation level
	update	#results_table
	set		object_derivation_level = 0

	insert	into @derivation_level_table( 
							gobject_id,
							parent_gobject_id,
							object_derivation_level,
							alreadyset)
			select	gobject_id,
					gobject_id,
					0,
					0
			from	#results_table

	declare	@level smallint
	set	@level = -1

	while (1=1)
	begin
		update	@derivation_level_table
		set		object_derivation_level = @level,
				alreadyset = 1
		where	parent_gobject_id = 0
			and	alreadyset = 0

		if (not exists(select '*' from @derivation_level_table 
					where parent_gobject_id <> 0))
			break

		update	@derivation_level_table
		set		parent_gobject_id = go.derived_from_gobject_id
		from	gobject go, @derivation_level_table dl
		where	go.gobject_id = dl.parent_gobject_id 

		set		@level = @level + 1
	end

	update	#results_table
	set		object_derivation_level = dl.object_derivation_level
	from	#results_table rt, @derivation_level_table dl
	where	rt.gobject_id = dl.gobject_id
	
	-- Change: We want to retrieve two more fields: template_package_id 
	-- and deployed_template_package_id. The reason behind it is now we 
	-- need to keep different versions of the template an instance is 
	-- derived from. When an object is redeployed, we will load the right
	-- template package. 
	--
	-- When it is deployed package, we need to find the corresponding
	-- template package

	select	template_definition_id , 
			derived_from_package_id as package_id, -- for instance this is m_package_id for internal_load_template_package out side
			is_checked_in,
			gobject_id as gobject_id
	from	#results_table rt

    -- load gobject
    select 	p.package_id,
			p.gobject_id,
			p.status_id,
			p.reference_status_id,
			p.security_group,
			rt.derived_from_package_id ,
			g.gobject_id,
			g.template_definition_id,
			g.derived_from_gobject_id,
			g.contained_by_gobject_id,
			g.area_gobject_id,
			g.hosted_by_gobject_id,
			g.checked_out_by_user_guid,
			g.default_symbol_gobject_id,
			g.default_display_gobject_id,
			g.checked_in_package_id,
			g.checked_out_package_id,
			g.deployed_package_id,
			g.last_deployed_package_id,
			g.tag_name,
			g.contained_name,
			g.identity_guid,
			g.configuration_guid,
			case when (rt.nPackageType = 3) then 
		         g.deployed_version
		    else
		         g.configuration_version
		    end,			
			g.deployed_version,
			g.is_template,
			g.is_hidden,
			g.software_upgrade_needed,
			g.hosting_tree_level,
			g.hierarchical_name,
		instance.mx_platform_id,
        instance.mx_engine_id,
        instance.mx_object_id ,
			ghost.tag_name as host_name,
			gcontainer.tag_name as container_name,
			garea.tag_name as area_name,
			gderived.tag_name as derived_name,
			gbasedon.tag_name as basedon_name,
			gbeingeditedby.user_profile_name as beingeditedby_name,
            rt.object_derivation_level as derivation_level,
            g.namespace_id as namespace_id,
            gderived.configuration_version as template_configuration_version
	from 	package p
    inner join gobject g
        on p.gobject_id = g.gobject_id
	inner join #results_table rt
		on rt.gobject_id = g.gobject_id AND p.package_id =  rt.package_id
	left join instance
		on instance.gobject_id = g.gobject_id
	left join gobject ghost
		on g.hosted_by_gobject_id = ghost.gobject_id
	left join gobject gcontainer
		on g.contained_by_gobject_id = gcontainer.gobject_id
	left join gobject garea
		on g.area_gobject_id = garea.gobject_id
	left join gobject gderived
		on g.derived_from_gobject_id = gderived.gobject_id
	inner join template_definition td
		on g.template_definition_id = td.template_definition_id
	inner join gobject gbasedon
		on td.base_gobject_id = gbasedon.gobject_id
	left join user_profile gbeingeditedby
		on g.checked_out_by_user_guid = gbeingeditedby.user_guid    
	ORDER BY p.package_id


	select
		pri.primitive_definition_id,
		pri.primitive_name,
		pri.mx_primitive_id,
		pri.parent_mx_primitive_id,
		pri.execution_group,
		pri.execution_order,
		pri.owned_by_gobject_id,
		pri.extension_type,
		pri.is_object_extension,
		pri.checked_in_primitive_version,
		pri.checked_out_primitive_version,
		pri.created_by_parent,
		pri.primitive_attributes,		
        pri.package_id,
		pri.mx_value_errors,
		pri.mx_value_warnings,
		pri.mx_value_reference_warnings		        
	from
		primitive_instance pri
		inner join #results_table rt on 
			pri.gobject_id = rt.gobject_id and
			pri.package_id = rt.package_id	
	order by
		pri.package_id, pri.mx_primitive_id

	-- load the dynamic_attribute rows
	select
		da.mx_primitive_id,
		da.mx_attribute_id,
		da.attribute_name,
		da.mx_data_type,
		da.is_array,
		da.security_classification,
		da.mx_attribute_category,
		da.lock_type,
		da.mx_value,
		da.owned_by_gobject_id,
		da.package_id,
         da.dynamic_attribute_type,
        case when owned_by_gobject_id > 0 then
          (select gobj.tag_name from gobject gobj where gobj.gobject_id = owned_by_gobject_id)
        else
          '' 
        end as dainheritedfrom,
        da.bitvalues
	from
		dynamic_attribute da
	inner join #results_table rt on
		rt.gobject_id = da.gobject_id and
        rt.package_id = da.package_id	
	order by
		da.package_id

		
	-- Load the Feature Links
	SELECT  
		primitive_instance_feature_link.mx_primitive_id, 
		primitive_instance_feature_link.feature_id, 
		primitive_instance_feature_link.feature_name, 
        primitive_instance_feature_link.feature_type, 
		primitive_instance_feature_link.package_id
	FROM
	    primitive_instance_feature_link 
	inner join #results_table rt
		on rt.package_id = primitive_instance_feature_link.package_id	
		and rt.gobject_id = primitive_instance_feature_link.gobject_id
	


	-- Load the attribute_reference rows
	select a.referring_mx_primitive_id,
		   a.referring_mx_attribute_id,
		   a.element_index,
		   isnull(inst.mx_platform_id,0) as platform_id,
		   isnull(inst.mx_engine_id,0) as engine_id,
		   isnull(inst.mx_object_id,0 ) as object_id,
	       isnull(backup_engine.mx_platform_id,0) as redundant_engine_platform_id,
		   isnull(backup_engine.mx_engine_id,0) as redundant_engine_engine_id,		
		   object_signature,
		   reference_string,
		   context_string,
		   resolved_mx_primitive_id,
		   resolved_mx_attribute_id,
		   resolved_mx_property_id,
		   attribute_signature, 
		   lock_type,
		   attr_res_status,
		   rt.package_id,
		   isnull(g.tag_name,'') as tag_name,
		   a.attribute_index,
	   isnull(td.category_id,0) as cat_id
	  from 
	      attribute_reference a 
          left join instance inst
				on  a.resolved_gobject_id = inst.gobject_id
		  left join gobject g
				on  g.gobject_id = inst.gobject_id
		  left join template_definition td 
		   on	g.template_definition_id = td.template_definition_id
		  left join instance engine --get the engine object
		   on		inst.mx_platform_id = engine.mx_platform_id 
				and inst.mx_engine_id = engine.mx_engine_id
				and engine.mx_object_id = 1
		  left join redundancy redun --get the primary-backup row from redundancy table
		   on		redun.primary_gobject_id = engine.gobject_id
		  left join instance backup_engine -- get the backup engine from the redundancy table
		   on		backup_engine.gobject_id = redun.backup_gobject_id
		  inner join #results_table rt
				on  rt.package_id = a.package_id
				and rt.gobject_id = a.gobject_id  	
	  order by a.package_id,a.referring_mx_primitive_id,a.referring_mx_attribute_id,a.element_index 


       -- Load visual element references


	declare @reference_info table
	(
	    gobject_id int,
        package_id int,
	    mx_primitive_id smallint,
	    visual_element_reference_index int,
	    reference_string nvarchar(395) COLLATE SQL_Latin1_General_CP1_CI_AS,
	    visual_element_bind_status bit
	)

	--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
	
    declare temp_table cursor fast_forward for
    	select 
            gobject_id,
            package_id
        from #results_table
    open temp_table
    while( 1=1 )
    begin
        declare @temp_gobject_id int
        declare @temp_package_id int

        fetch next from temp_table into
		@temp_gobject_id,
        @temp_package_id

        if( @@fetch_status <> 0 ) break
    
		declare @actual_gobject_id int
		declare @actual_package_id int
		
		
		set @actual_gobject_id = @temp_gobject_id
		set @actual_package_id = @temp_package_id
			 
		declare @category_id int
		declare @derived_from_gobject_id int
		declare @derived_package_id int
			
		set @is_template = 0
			
		select @is_template = o.is_template
		from 
			gobject o
		where
			o.gobject_id = @temp_gobject_id
			
		select  @derived_from_gobject_id = derived_from_gobject_id
		from    gobject 
		where   gobject_id = @temp_gobject_id
			
		select @derived_package_id = checked_in_package_id from gobject where gobject_id = @derived_from_gobject_id

		select  @category_id = category_id 
			from gobject with (NOLOCK) 
			inner join template_definition on 
				gobject.template_definition_id = template_definition.template_definition_id
			where gobject_id = @derived_from_gobject_id

			
		if(@category_id = 26 AND @is_template = 0)
		begin
			set @temp_gobject_id = @derived_from_gobject_id
			set @temp_package_id = @derived_package_id
		end

		if (@is_association = 0)
		begin
			insert into @reference_info
			(gobject_id,
			 package_id ,
			 mx_primitive_id ,
			 visual_element_reference_index ,
			 reference_string ,
			 visual_element_bind_status)
				 select v.gobject_id,
					  v.package_id,
					  v.mx_primitive_id,
					  v.visual_element_reference_index,
					  v.reference_string,
					  v.visual_element_bind_status
			from  internal_visual_element_reference_per_user_view v	 
			 where v.gobject_id = @temp_gobject_id 
			  and   v.package_id = @temp_package_id
			  and   v.user_guid = @loggedin_user_id_guid
		end
		else
		begin
			insert into @reference_info
			(gobject_id,
			 package_id ,
			 mx_primitive_id ,
			 visual_element_reference_index ,
			 reference_string ,
			 visual_element_bind_status)
				 select v.gobject_id,
					  v.package_id,
					  v.mx_primitive_id,
					  v.visual_element_reference_index,
					  v.reference_string,
					  v.visual_element_bind_status
			from  internal_visual_element_reference_per_user_view_association v	 
			 where v.gobject_id = @temp_gobject_id 
			  and   v.package_id = @temp_package_id
			  and   v.user_guid = @loggedin_user_id_guid
		end

	--  order by v.package_id
		if(@category_id = 26 AND @is_template = 0)
		begin
			update @reference_info set gobject_id = @actual_gobject_id, 
			package_id = @actual_package_id from @reference_info where 
			gobject_id = @temp_gobject_id
		end
    end --End of while
    close temp_table
    deallocate temp_table 
	-- toDO: change * to columns.....
		
	select * 
	from @reference_info
	order by package_id

	drop table #idstable
    drop table #results_table

commit


go

