
/*
    Takes gobjectIds , find IntouchViewApp templates whose all instances are undeployed.
    returns tagnames
*/
create proc dbo.internal_get_itviewapp_templates_to_clean_deployed_folder
@FileNameOfIds nvarchar (265)	
as
begin

	create table  #gobjects_undeployed( gobject_id int primary key)
	DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #gobjects_undeployed  FROM ''' + @FileNameOfIds + ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
	EXEC (@SQL)
		
	create table #template_ids( gobject_id int primary key)
	insert into #template_ids
	(
		gobject_id
	)
	select g.derived_from_gobject_id
	from gobject g
	inner join #gobjects_undeployed gd
	on gd.gobject_id = g.gobject_id
	inner join template_definition td
	on td.template_definition_id = g.template_definition_id
		and td.category_id = 26
	
	select g.tag_name
	from gobject g
	inner join 	#template_ids ti
	on ti.gobject_id = g.gobject_id
	where not exists(	
		select  1 
		from deployed_intouch_viewapp div
		inner join gobject ggg on
		div.gobject_id = ggg.gobject_id and
		ggg.derived_from_gobject_id = ti.gobject_id   
    )
	
end
go

