/**************************************************/
/*Object Name :  internal_prepare_files_to_delete   */
/*Object Type :  Stored Proc.						*/
/*Purpose	  :  Procedure to return the list of files to be deleted if this object is a base template*/
/*Used By	  :  CDI(Cascade Deploy)				*/
/**************************************************/

CREATE  proc dbo.internal_prepare_files_to_delete
  @gobject_id int
as
begin
set nocount on

-- find out if this is base template then only we need to delete the files 
declare @filelist table ( file_id int)

-- add files used by primitives
-- find files currently used by primitives
declare @primitive_instance_file table (file_id int)
insert into @primitive_instance_file ( file_id ) 
    select file_id 
    from primitive_instance_file_table_link 
    where gobject_id = @gobject_id
-- remove primitive references
delete from primitive_instance_file_table_link where gobject_id = @gobject_id
-- add files no longer need to return list
insert into @filelist (file_id) 
    select file_id 
    from @primitive_instance_file f 
    where f.file_id not in ( select file_id from primitive_instance_file_table_link )

declare @derived_from int
set @derived_from = (select derived_from_gobject_id from gobject where gobject_id = @gobject_id)
if ( @derived_from <> 0 ) -- its not a base template
begin
	select file_id from @filelist
	return 2
end

-- get the list of primitive definitions for this gobject
declare primitive_definition_cursor cursor
for select primitive_definition_id,primitive_guid from primitive_definition pd
inner join template_definition td on td.template_definition_id = pd.template_definition_id
where td.base_gobject_id = @gobject_id
open primitive_definition_cursor
declare @prim_def_id int
declare @primitive_guid uniqueidentifier
fetch next from primitive_definition_cursor into @prim_def_id, @primitive_guid
while (@@fetch_status <> -1 )
begin
    declare file_primitive_cursor cursor 
    for select fpdl.file_id from  file_primitive_definition_link fpdl,primitive_definition pd 
                            where fpdl.primitive_definition_id = @prim_def_id and pd.primitive_definition_id = @prim_def_id and                
			         (   fpdl.is_needed_for_editor = 1 or fpdl.is_needed_for_package = 1 or fpdl.is_needed_for_browser = 1
						or fpdl.is_needed_for_runtime = 1 )
   
    open file_primitive_cursor
	 
    declare @fileid int
    fetch next from file_primitive_cursor into @fileid
    while (@@fetch_status <> -1 )
    begin
		-- Clean up the file_primitive_definition_link information for the 	file_id =  @fileid 
		-- and primitive_definition_id = @prim_def_id
	   delete from file_primitive_definition_link where file_id =  @fileid 
             and primitive_definition_id = @prim_def_id
		-- Add code here to get the list of files to be deleted and then delete them from the 
		-- file tables. Insert the file with the vendor name to the temporary table
       declare @isFileShared integer
       set @isFileShared = (select count(*) from file_primitive_definition_link where file_id = @fileid and primitive_definition_id <> @prim_def_id)
       
	   if @isFileShared = 0
       begin
            set @isFileShared = (select count(*) from feature_file_link where file_id = @fileid)
       end
	   
	   if @isFileShared = 0 -- Its not used by other primitives
	     begin
		 -- insert into the temporary table created some where up by fsobject delete proc
		 insert into @filelist(file_id) 
		 select ft.file_id
		 from   file_table ft
		 where  ft.file_id = @fileid
	     end
       -- fetch the next file id
      fetch next from file_primitive_cursor into @fileid
    end
  close file_primitive_cursor
  deallocate file_primitive_cursor
fetch next from primitive_definition_cursor into @prim_def_id, @primitive_guid
end
close primitive_definition_cursor
deallocate primitive_definition_cursor
select distinct file_id from @filelist

end
go

