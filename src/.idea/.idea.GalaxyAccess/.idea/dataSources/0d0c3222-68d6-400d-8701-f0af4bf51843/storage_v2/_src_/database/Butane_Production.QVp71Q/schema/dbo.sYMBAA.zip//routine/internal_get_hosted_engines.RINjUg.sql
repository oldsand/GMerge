/*
selects gobject_ids for all objects which are hosted by the platform
*/
CREATE    PROCEDURE dbo.internal_get_hosted_engines
    @gObjectId int,@eTypes int-- 0 = All, 1 == Failover enabled 
AS
set nocount on
--All the objects which need are contained_by,hosted_by or assigned to a gobject_id
--can be easily figure it out by either it is a platform,engine or area
--If it is a platform
declare @mx_platform_id int
declare @mx_engine_id int
declare @mx_object_id int
select @mx_platform_id = mx_platform_id,@mx_engine_id = mx_engine_id,
@mx_object_id = mx_object_id
from instance where instance.gobject_id = @gObjectId
--if it is platform
--if @mx_engine_id = 1 and @mx_object_id = 1 
if(@mx_engine_id = 1) AND (@mx_object_id = 1 )
begin
	if(@eTypes = 0)
	begin	
		select gobject_id from instance where mx_platform_id = @mx_platform_id	
		and gobject_id <> @gObjectId and mx_object_id = 1 
		return
	end
	else
	begin
		select gobject_id from instance where mx_platform_id = @mx_platform_id	
		and gobject_id <> @gObjectId and mx_object_id = 1 and 
		dbo.get_failover_partner_id(gobject_id)>0
		return
	end
end
else
begin
	if(@gObjectId = 0) -- UnAssign
	begin
		--Now check all or Failover enabled only
		if(@eTypes = 0)
		begin	
			select g.gobject_id from gobject g 
			inner join template_definition td 
			on td.template_definition_id = g.template_definition_id and td.category_id = 3
			and g.hosted_by_gobject_id = 0 and g.is_template = 0
			return
		end
		else
		begin
			select g.gobject_id from gobject g 
			inner join template_definition td 
			on td.template_definition_id = g.template_definition_id and td.category_id = 3
			and g.hosted_by_gobject_id = 0 and g.is_template = 0 and 
			dbo.get_failover_partner_id(gobject_id)>0
			return
		end
	end
	else
	begin
		--return no records recordset
		select * from platform where platform_id = -1
	end
end

go

