create procedure dbo.internal_sync_client_info
	@client_id nvarchar(4000),
	@client_name nvarchar(64),
	@return_client_id nvarchar(4000) out 
as
begin
	set nocount on
	begin tran
	set @return_client_id = @client_id;
	declare @filesdeployedtoclient int
	select @filesdeployedtoclient = count(*) from deployed_file df 
	where upper(df.node_name) = upper(@client_name) and
	df.file_id not in (select pf.file_id from primitive_instance_file_table_link pf inner join client_control_class_link cc on pf.gobject_id = cc.gobject_id)
	and (( df.is_editor_deployed = 1 or df.is_package_deployed = 1 or df.need_to_delete = 1)) 
	
	if exists( select '*' from client_info where client_name = @client_name)
	begin
		if exists( select '*' from client_info where client_unique_identifier = @client_id and upper(client_name) = upper(@client_name))
			begin
				set @return_client_id = @client_id
			end
			else
				begin
					if ( ISNULL(@client_id,'' ) = '' )
					begin
						set @return_client_id = @client_id;
					end
					else
					begin
						set @return_client_id = newID()
						update client_info
						set client_unique_identifier = @return_client_id ,
							deployed_files_count = @filesdeployedtoclient
								where upper(client_name) = upper(@client_name)
					end
				end
	end
	else
		begin		
			
			if ( ISNULL(@client_id,'' ) = '' )
			begin				
				
				set @return_client_id = @client_id;
			end
			else
			begin
				set @return_client_id = newID()
				insert into client_info
				values
				(@return_client_id, upper(@client_name),@filesdeployedtoclient, GetDate(),CAST ( @@dbts  AS timestamp ) )
			end
		end   
	commit
	set nocount off
end

go

