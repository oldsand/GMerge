
/**************************************************
This storec proc calculates and returns the list of Editor or Package files required
for provided gobject...
*************************************************/

create procedure dbo.internal_get_n_update_editor_package_files
        @Nodename nvarchar(256), 
        @gobjectId int, 
        @ecodemoduletype int
AS
begin
    SET NOCOUNT ON

    begin tran
	
	declare @upper_nodename nvarchar(256)
	set @upper_nodename = upper(@Nodename)

    declare @fileinfo table
        ( 
			primitive_guid uniqueidentifier, 
			file_id int, 
			file_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			subfolder_name nvarchar (256)  COLLATE SQL_Latin1_General_CP1_CI_AS ,
			registration_type int,
			file_version nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS ,
			file_modified_time nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS)


    ------------------------step 1 ...Get all the file required for Package or Editor Code Modules..
    IF (@ecodemoduletype = 4) -- Package code module type
    BEGIN
        insert into @fileinfo (primitive_guid, file_id , file_name, vendor_name, subfolder_name, registration_type,file_version,file_modified_time)
        (
            select distinct pd.primitive_guid, ft.file_id, ft.file_name, ft.vendor_name,ft.subfolder,  ft.registration_type, ft.file_version, ft.file_modified_time
            from gobject g
            inner join primitive_definition pd
                on g.template_definition_id = pd.template_definition_id
            inner join file_primitive_definition_link fpt
                on fpt.primitive_definition_id = pd.primitive_definition_id
                and fpt.is_needed_for_package = 1
            inner join file_table ft
                on ft.file_id = fpt.file_id   
            where gobject_id = @gobjectId 
        )
    END
    ELSE
        IF (@ecodemoduletype = 2) -- Package & Editor code module type
    BEGIN
        insert into @fileinfo (primitive_guid, file_id , file_name, vendor_name, subfolder_name, registration_type,file_version,file_modified_time)
        (
            select distinct pd.primitive_guid, ft.file_id, ft.file_name, ft.vendor_name, ft.subfolder, ft.registration_type, ft.file_version, ft.file_modified_time
            from gobject g
            inner join primitive_definition pd
                on g.template_definition_id = pd.template_definition_id
            inner join file_primitive_definition_link fpt
                on fpt.primitive_definition_id = pd.primitive_definition_id
                and ( fpt.is_needed_for_editor = 1 or fpt.is_needed_for_package = 1)
            inner join file_table ft
                on ft.file_id = fpt.file_id
            where gobject_id = @gobjectId 
        )
    END

------------------------step 1.1 (Handle visual element required file)-- if required!!!
 	if exists(
 	         select  '1'
 	         from    visual_element_version v
 	         inner join gobject g on 
 	             v.gobject_id = @gobjectId
 	             and v.package_id = g.checked_in_package_id
 	 			)
 	begin
 	    create table #visual_element_ids_for_required_file(
 	                    visual_element_id int)
 	
 	    create table #visual_element_required_file(
 	                    group_id  nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS ,
 	                    file_name nvarchar(256)  COLLATE SQL_Latin1_General_CP1_CI_AS,
 	                    vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS ,
						subfolder_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS ,
 	                    registration_type int,
 	                    software_upgrade_needed int,
 	                    file_id int,
 	                    is_needed_for_package bit,
 	                    is_needed_for_editor bit,
 	                    is_needed_for_runtime bit)
 	
 	    insert  #visual_element_ids_for_required_file(visual_element_id)
 	    (
 	         select  distinct v.visual_element_id
 	         from    visual_element_version v
 	         inner join gobject g on 
 	             v.gobject_id = @gobjectId
 	             and v.package_id = g.checked_in_package_id
 	    )
 	

 		exec internal_get_required_files_by_visual_element_ids @Nodename, @ecodemoduletype
 	

 	    insert into @fileinfo(primitive_guid, file_id, file_name, vendor_name, subfolder_name, registration_type, file_version, file_modified_time)
 	    (
 	        select  NULL, 
 	                file_id,
 	                file_name,
 	                vendor_name,
					subfolder_name,
 	                registration_type,
 	                '',
 	                ''
 	        from    #visual_element_required_file
 	    )

 	
 	    drop table #visual_element_required_file
 	
 	    drop table #visual_element_ids_for_required_file
 	end
    ------------------------End of step 1.1 (Load the visual elements )
    
    
    ------------------------step 2 ...Get all the filelist required for Package or Editor Code Modules..which are not yet deployed (new files)
    declare @filelist table
        ( 
			primitive_guid uniqueidentifier, 
			file_id int, 
			file_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			subfolder_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			registration_type int, 
			software_upgrade_needed int 
		)

    declare @nSUN int
    set @nSUN = 0

    insert into @filelist(primitive_guid, file_id , file_name, vendor_name, subfolder_name , registration_type,software_upgrade_needed)
    (
      select distinct ft.primitive_guid , ft.file_id,ft.file_name,ft.vendor_name ,ft.subfolder_name , ft.registration_type,@nSUN
      from @fileinfo ft 
	  where ft.file_id not in (
								select file_id 
								from deployed_file
						        where  
									deployed_file.node_name =@upper_nodename and
									(deployed_file.is_editor_deployed = 1  
										or deployed_file.is_package_deployed = 1 

										or deployed_file.need_to_delete = 1)
									)
							    )

    ------------------------step 3 ...Add all the filelist required for Package or Editor Code Modules..which are required to be deleted as they are old..because they havent been removed
    --when template got deleted so we need to update them when a new template or file will come..
    set @nSUN = 1
    insert into @filelist(primitive_guid, file_id , file_name, vendor_name, subfolder_name ,registration_type,software_upgrade_needed)
    (
      select distinct ft.primitive_guid , ft.file_id,ft.file_name,ft.vendor_name ,ft.subfolder_name , ft.registration_type,@nSUN
      from @fileinfo ft where ft.file_id in (select file_id from deployed_file
      where  deployed_file.node_name = @upper_nodename and need_to_delete = 1 )
    )

    ------------------------step 4 ..-- Update need_to_delete to 0 for all files in both deployed_file 
    -- @filelist table and update is_XX_deployed columns


   insert into deployed_file (file_id, node_name, need_to_delete, is_package_deployed, is_editor_deployed, is_runtime_deployed, is_browser_deployed)
    (
        select distinct file_id, @Nodename as node_name, 0 as need_to_delete,
            0 as is_editor_deployed,0 as is_package_deployed,0 as is_runtime_deployed,
            0 as is_browser_deployed
        from @fileinfo ft
        where ft.file_id not in (select distinct file_id from deployed_file where node_name = @upper_nodename )
    )
    
         update deployed_file
		set file_version = ft.file_version,
		file_modified_time = ft.file_modified_time
		from @fileinfo ft, deployed_file df
		where df.file_id = ft.file_id  and
			  df.node_name = @upper_nodename
    ------------------------step 5 ..-- Insert into deployed files which are new files..which r getting deployed for the first time..

    set @nSUN = 1
    insert into @filelist(primitive_guid, file_id , file_name, vendor_name, subfolder_name , registration_type,software_upgrade_needed )
    (
      select distinct ft.primitive_guid , ft.file_id,ft.file_name,ft.vendor_name ,ft.subfolder_name ,ft.registration_type,@nSUN
      from @fileinfo ft where ft.file_id in (select file_id from file_pending_update
      where  file_pending_update.node_name = @upper_nodename )
    )

    -- Get list of files that need to be installed on the specified node
    select  distinct 
            N'', 
            file_name, 
            vendor_name, 
            registration_type,
            software_upgrade_needed,
            file_id,
			subfolder_name
    from    @filelist 
    order by software_upgrade_needed DESC
    
    commit tran

end
go

