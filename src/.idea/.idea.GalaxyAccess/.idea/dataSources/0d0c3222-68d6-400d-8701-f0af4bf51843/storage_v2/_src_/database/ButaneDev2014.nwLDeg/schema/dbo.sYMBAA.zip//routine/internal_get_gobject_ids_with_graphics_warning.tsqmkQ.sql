/*
This stored procedure returns gobject ids which need to be validated after import...

usage
exec internal_get_gobject_ids_with_graphics_warning
*/
create procedure dbo.internal_get_gobject_ids_with_graphics_warning
@file_name_of_ids nvarchar (265)
as 
begin
	set nocount on		

	exec internal_bind_visual_element_references

	begin
		create table #work_table(gobject_id int)
		declare @final_result table (gobject_id int)
		
		create index tmp_idx_results_table on #work_table(gobject_id)
		
		DECLARE @SQL nvarchar(2000)
		SET @SQL = 'BULK INSERT #work_table  FROM ''' + @file_name_of_ids + ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
		EXEC (@SQL)	
	end		
		
		-- first get a list of objects whose visual elements
		-- are in a warning state, but who may have been fixed by this operation.
		insert into @final_result
        select rt.gobject_id 
        from #work_table rt 
        inner join visual_element_reference ver  on 
			rt.gobject_id = ver.gobject_id and
			ver.visual_element_bind_status = 1
		inner join primitive_instance pri on
			pri.gobject_id = ver.gobject_id and
			pri.package_id = ver.package_id and
			pri.mx_primitive_id = ver.mx_primitive_id and
			pri.status_id > 0


		-- first get a list of objects whose visual element's parent primitives
		-- are in a warning state, but who may have been fixed by this operation.
		insert into @final_result
        select rt.gobject_id 
        from #work_table rt 
        inner join visual_element_reference ver  on 
			rt.gobject_id = ver.gobject_id and
			ver.visual_element_bind_status = 1
		inner join primitive_instance pri on
			pri.gobject_id = ver.gobject_id and
			pri.package_id = ver.package_id and
			pri.mx_primitive_id = ver.mx_primitive_id 
		inner join primitive_instance parent_pri on
			pri.gobject_id = parent_pri.gobject_id and
			pri.package_id = parent_pri.package_id and
			pri.parent_mx_primitive_id = parent_pri.mx_primitive_id and
			parent_pri.status_id > 0

		-- now, get a list of gobjects with visual elements who are not
		-- in the warning state even though they have unbound references...
		insert into @final_result
        select rt.gobject_id 
        from #work_table rt 
        inner join visual_element_reference ver  on 
			rt.gobject_id = ver.gobject_id and
			ver.visual_element_bind_status = 0
		inner join primitive_instance pri on
			pri.gobject_id = ver.gobject_id and
			pri.package_id = ver.package_id and
			pri.mx_primitive_id = ver.mx_primitive_id and
			pri.status_id = 0		


		-- now, get a list of gobjects with visual element's parents who are not
		-- in the warning state even though they have unbound references...
		insert into @final_result
        select rt.gobject_id 
        from #work_table rt 
        inner join visual_element_reference ver  on 
			rt.gobject_id = ver.gobject_id and
			ver.visual_element_bind_status = 0
		inner join primitive_instance pri on
			pri.gobject_id = ver.gobject_id and
			pri.package_id = ver.package_id and
			pri.mx_primitive_id = ver.mx_primitive_id 
		inner join primitive_instance parent_pri on
			pri.gobject_id = parent_pri.gobject_id and
			pri.package_id = parent_pri.package_id and
			pri.parent_mx_primitive_id = parent_pri.mx_primitive_id and
			parent_pri.status_id = 0
		
		
		select distinct gobject_id
		from @final_result

		
	drop table #work_table	
	set nocount off
end

go

