-- This stored Procedure will be used if ParentId passed = 0 
-- Basically unassociation of Objects 

create proc dbo.internal_unset_association
							(@childIdList nvarchar(255),
						   	 @assocType smallint)
As

begin 
	set nocount on

	declare @retAffectedObjects table(gobject_id int, is_toolset bit, hierarchical_name nvarchar(329))

	-- Create table of child objects
	create table  #childList (gid int)
	DECLARE @gSQL nvarchar(2000)
	SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
				WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
	EXEC (@gSQL)

	declare @nLevel int
	-- unset Host: child can be engine, device or Area or AppObject
	IF @assocType = 1
	BEGIN
		-- Get objects information
		declare @ObjectInfo table( gobject_id int, cat_id smallint, my_container int, 
								   mx_platform_id smallint, mx_engine_id smallint, nLevel smallint, has_children bit)

		insert into @ObjectInfo select H.gid, T.category_id, G.contained_by_gobject_id, mx_platform_id, mx_engine_id, 1,
		case when exists ( select gobject_id from gobject where hosted_by_gobject_id = H.gid ) then 1 else 0 end
		from #childList H inner join gobject G on H.gid = G.gobject_id
		inner join template_definition T on T.template_definition_id = G.template_definition_id
		inner join instance I on G.gobject_id = I.gobject_id
        -------------------------for IONetwork and IODevice------------
		declare @hosting_tree_level int
		declare @DeviceInfo table(obj_id int, nLevel smallint, catid smallint default 0)
		set		@hosting_tree_level = 0
        --------------------------------------------------------------

		-- insert old hosts into affected list
		insert into @retAffectedObjects
		select distinct hosted_by_gobject_id, 0, '' 
		from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id


		insert into @retAffectedObjects
		select distinct contained_by_gobject_id, 0, '' 
		from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id


		IF exists ( select gobject_id from @ObjectInfo where cat_id = 10 OR cat_id = 25)
		BEGIN

			-- insert old container into affected list
			insert into @retAffectedObjects
			select distinct area_gobject_id, 0, '' 
			from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id

			declare @affected_objects table(gobject_id int)

			-- Update gobject table
			update gobject 
			set 
				hosted_by_gobject_id = 0, 
				area_gobject_id = 0, 
				contained_by_gobject_id = 0
			output 
				inserted.gobject_id
			into @affected_objects
			from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id
			where cat_id = 10 OR cat_id = 25

			-- update attribute_reference table		
			update attribute_reference 
			set is_valid = 1 
			output 
				inserted.gobject_id,
				0, ''
			into @retAffectedObjects
			from attribute_reference AR 
			inner join gobject G on 
				AR.reference_string Like ( G.hierarchical_name + '%' )
			inner join  @affected_objects ao on 
				ao.gobject_id = G.gobject_id

			-- set reference string 'myContainer' to dirty ( only for top level App object )
			update attribute_reference 
			set is_valid = 1
			output 
				inserted.gobject_id,
				0, ''
			into @retAffectedObjects
			from  attribute_reference AR 
			inner join @ObjectInfo O on 
				AR.gobject_id =  O.gobject_id
			where  reference_string like 'myContainer%'	

			-- insert any descendants of these AppObjects and set Hierarchical Name
			set @nLevel = 1
			while 1 > 0
			BEGIN

				-- insert any descendants which hierarchical name is changed
				if @nLevel > 1
					insert into @retAffectedObjects
					select O.gobject_id, 0, G.hierarchical_name from @ObjectInfo O inner join gobject G on
              G.gobject_id = O.gobject_id where nLevel = @nLevel

				-- set reference string to dirty
				update attribute_reference set is_valid = 1
				from  attribute_reference AR inner join @ObjectInfo O on AR.gobject_id =  O.gobject_id
				where (nLevel = @nLevel) and
				( reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' or reference_string like 'myArea.%' or reference_string like 'myHost.%')										

				-- Update the Hierarchical Name of any contained objects, this has to do in layer 
				update gobject set hosted_by_gobject_id = 0, area_gobject_id = 0, 
						hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
				from gobject G inner join @ObjectInfo O on G.gobject_id = O.gobject_id
				where nLevel = @nLevel and (cat_id = 10 OR cat_id = 25) and my_container <> 0

				insert into @ObjectInfo 
				select G.gobject_id, 10, G.contained_by_gobject_id, OI.mx_platform_id, OI.mx_engine_id, @nLevel + 1, 1
				from gobject G inner join @ObjectInfo OI on G.contained_by_gobject_id = OI.gobject_id
				where nLevel = @nLevel

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1				
			END

			-- update instance table
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @ObjectInfo OI on Inst.gobject_id = OI.gobject_id

			update package set reference_status_id = 2
			from @ObjectInfo O
			inner join gobject g on
				O.gobject_id = g.gobject_id
			inner join package PK on
				g.gobject_id = PK.gobject_id and
				g.checked_in_package_id = PK.package_id
			inner join attribute_reference AR on
				PK.gobject_id = AR.gobject_id and
				PK.package_id = AR.package_id and
				AR.is_valid = 1

			-- Remove these AppObjecs
			delete from @ObjectInfo where cat_id = 10 OR cat_id = 25	
		END

		-- Update gobject table for all other category except for category 11 and 12
		update gobject set hosted_by_gobject_id = 0
		from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id
		where cat_id not in (10,11,12,24,25) 	

        -- Children are IODevices
		IF exists ( select gobject_id from @ObjectInfo where cat_id = 12 )
		BEGIN

			insert into @DeviceInfo (obj_id , nLevel )
			(
				select o.gobject_id , 1
				from @ObjectInfo o inner join gobject G on o.gobject_id = G.gobject_id
				inner join template_definition T on T.template_definition_id = G.template_definition_id
				where T.category_id = 12
			)

			set @nLevel = 1					
			while 1 > 0
			BEGIN
                    select @hosting_tree_level = hosting_tree_level
                    from gobject where gobject_id in (select hosted_by_gobject_id from gobject where 
                    gobject_id in (select obj_id from @DeviceInfo where nLevel = @nLevel ))                       
    				-- Update the hosting_tree_level
    				update gobject set hosting_tree_level = @hosting_tree_level + 1
    				from gobject G inner join @DeviceInfo O on G.gobject_id = O.obj_id
    				where nLevel = @nLevel
                    --Get the next Level
    				insert into @DeviceInfo (obj_id , nLevel )
					(
    					select gobject_id,  @nLevel + 1 
    					from gobject G inner join @DeviceInfo CI on G.hosted_by_gobject_id = CI.obj_id
    					where nLevel = @nLevel                    
					)
                    
    				if @@rowcount = 0 break
    				set @nLevel = @nLevel + 1
    		END	-- while			
            
			-- update the hosted_bt_gobject_ids of the affected gobjects
			update gobject set hosted_by_gobject_id = 0
			from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id
			where cat_id = 12			
		--Get all the objects which are hosted by device and then device and then device so on..
           	insert into @ObjectInfo
    		select DI.obj_id, 12,0,0, 0,2,0 from --setting temporary values
            @DeviceInfo DI,@ObjectInfo O where DI.obj_id <> O.gobject_id            
            
            -- Update instance table
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @ObjectInfo OI on Inst.gobject_id = OI.gobject_id
			where cat_id = 12	

			-- set reference string to dirty
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @ObjectInfo O on AR.gobject_id =  O.gobject_id
			where reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' 													
		END
        -----------------------------------
        -- Children are IONetwork
		IF exists ( select gobject_id from @ObjectInfo where cat_id = 11 or cat_id = 24 )
		BEGIN

			insert into @DeviceInfo select O.gobject_id, 1 , T.category_id
			from @ObjectInfo O inner join gobject G on O.gobject_id = G.gobject_id
			inner join template_definition T on T.template_definition_id = G.template_definition_id
            where T.category_id = 11 or T.category_id = 24
			set @nLevel = 1					
			while 1 > 0
			BEGIN
                      
	                       
                    select @hosting_tree_level = hosting_tree_level
                    from gobject where gobject_id in (select hosted_by_gobject_id from gobject where 
                    gobject_id in (select obj_id from @DeviceInfo where nLevel = @nLevel ))                       
    				-- Update the hosting_tree_level
    				update gobject set hosting_tree_level = @hosting_tree_level + 1
    				from gobject G inner join @DeviceInfo O on G.gobject_id = O.obj_id
    				where nLevel = @nLevel
                    --Get the next Level
    				insert into @DeviceInfo
    				select gobject_id,  @nLevel + 1 , T.category_id
    				from gobject G inner join @DeviceInfo CI on G.hosted_by_gobject_id = CI.obj_id
					inner join template_definition T on T.template_definition_id = G.template_definition_id
					where nLevel = @nLevel                    
                    
    				if @@rowcount = 0 break
    				set @nLevel = @nLevel + 1
    		END	-- while	
    		-- update the hosted_bt_gobject_ids of the affected gobjects
			update gobject set hosted_by_gobject_id = 0
			from gobject G inner join @ObjectInfo OI on G.gobject_id = OI.gobject_id
			where cat_id = 11 or cat_id = 24 or cat_id = 12
            --Get all the objects which are hosted by device and then device and then device so on..			
           	insert into @ObjectInfo
    		select DI.obj_id, DI.catid,0,0, 0,2,0 from --setting temporary values
            @DeviceInfo DI,@ObjectInfo O where DI.obj_id <> O.gobject_id            

	            
            -- Update instance table
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @ObjectInfo OI on Inst.gobject_id = OI.gobject_id
			where cat_id = 11 or cat_id = 24 or cat_id = 12	

			-- set reference string to dirty
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @ObjectInfo O on AR.gobject_id =  O.gobject_id
			where reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' 													
		END
        -----------------------------------           
		-- Children are Area
		IF exists( select gobject_id from @ObjectInfo where cat_id = 13 )
		BEGIN
			IF exists( select gobject_id from @ObjectInfo where cat_id = 13 and has_children = 1 )
			BEGIN
				-- Get all AppObject under these Areas and put it into the table as type Area
				-- we only care about the gobject ID and cat_id here				
				insert into @ObjectInfo
				select G.gobject_id, 13, G.contained_by_gobject_id, 0, 0, 2, 0
				from gobject G inner join @ObjectInfo OI on G.hosted_by_gobject_id = OI.gobject_id
				where cat_id = 13
			END

			-- set Mx Ids of these Areas and descendants to 0
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @ObjectInfo OI on Inst.gobject_id = OI.gobject_id
			where cat_id = 13	

			-- set reference string to dirty
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @ObjectInfo O on AR.gobject_id =  O.gobject_id
			where reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' 															

			update package set reference_status_id = 2
			from @ObjectInfo O
			inner join gobject g on
				O.gobject_id = g.gobject_id
			inner join package PK on
				g.gobject_id = PK.gobject_id and
				g.checked_in_package_id = PK.package_id
			inner join attribute_reference AR on
				PK.gobject_id = AR.gobject_id and
				PK.package_id = AR.package_id and
				AR.is_valid = 1

			insert into @retAffectedObjects
			select O.gobject_id,0, G.hierarchical_name
			from @ObjectInfo O inner join gobject G on O.gobject_id = G.gobject_id
		END

		-- Children are Engines
		IF exists ( select gobject_id from @ObjectInfo where cat_id < 10 )
		BEGIN
			-- Remove any objects which is not an engine
			delete from @ObjectInfo where cat_id > 9 or mx_platform_id = 0
			declare @tempgObjID int
			declare @objcount int
			declare @prev_mx_platform_id smallint
			declare @prev_mx_engine_id smallint
			select @objcount = count(*) from @ObjectInfo
			while 1 > 0
			begin
				if ( @objcount = 0 ) break
				declare @mx_engine_id smallint	
				set @mx_engine_id = dbo.get_next_mx_engine_id(0)
				set @tempgObjID = (select top 1 gobject_id from @ObjectInfo group by gobject_id)
				
				select @prev_mx_platform_id = mx_platform_id,@prev_mx_engine_id=mx_engine_id
				from @ObjectInfo where gobject_id = @tempgObjID
				
                -- Leave the mx_object_id on this engine intact
                -- Set the engine and all the hosted objects mx_ids to the new id
				update instance set mx_platform_id = 0, mx_engine_id = @mx_engine_id
				from instance Inst where Inst.mx_platform_id = @prev_mx_platform_id
				and Inst.mx_engine_id = @prev_mx_engine_id

				-- set reference string to dirty
				update attribute_reference set is_valid = 1
				output 
					inserted.gobject_id,
					0, ''
				into @retAffectedObjects
				from  attribute_reference AR inner join instance Inst on AR.gobject_id =  Inst.gobject_id
				where ( reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' or reference_string like 'myhost.%' ) 
				and ( Inst.mx_platform_id = 0 and Inst.mx_engine_id = @mx_engine_id )															
				delete from @ObjectInfo where gobject_id = @tempgObjID
				set @objcount = @objcount - 1
			end
		END		

		-- Children are ViewApps
		IF exists ( 
                    select gobject_id 
                    from @ObjectInfo 
                    where cat_id = 17
                        or cat_id = 26)
		BEGIN

			-- Leave the mx_object_id on this engine intact
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @ObjectInfo oi 
			on Inst.gobject_id = oi.gobject_id
            where oi.cat_id = 17
                or oi.cat_id = 26

		END		
	END

	ELSE  -- Unset container or Area
	BEGIN
		declare @containeeInfo table(gobject_id int, cat_id smallint, my_container int, nLevel smallint, has_children bit)
		

		insert into @containeeInfo select H.gid, T.category_id, G.contained_by_gobject_id, 1,
		case when exists ( select gobject_id from gobject where contained_by_gobject_id = H.gid ) then 1 else 0 end
		from #childList H inner join gobject G on H.gid = G.gobject_id
		inner join template_definition T on T.template_definition_id = G.template_definition_id

		--L00021807 start
		declare @BackupAppEngines table(gobject_id int)
		insert into @BackupAppEngines select r.backup_gobject_id
		from #childList H inner join redundancy r on r.primary_gobject_id = H.gid
		
		update gobject set area_gobject_id = 0, contained_by_gobject_id = 0
		from gobject G inner join @BackupAppEngines b on b.gobject_id = G.gobject_id
		
		insert into @retAffectedObjects select distinct gobject_id, 0, '' 
		from @BackupAppEngines 
		--L00021807 end
		
		--insert objects referencing containee objects by hierarchical name to afected objects list
		if exists(
			select '1' 
			from @containeeInfo 
			where my_container > 0 or has_children = 1)
		begin
			insert into @retAffectedObjects select distinct AR.gobject_id, 0, '' 
			from attribute_reference AR inner join gobject G on AR.reference_string Like ( G.hierarchical_name + '%')
			inner join  @containeeInfo CI on CI.gobject_id = G.gobject_id


			-- update attribute_reference table		
			update attribute_reference set is_valid = 1 from attribute_reference AR inner join 
			gobject G on AR.reference_string Like ( G.hierarchical_name + '%' )
			inner join  @containeeInfo CI on CI.gobject_id = G.gobject_id
		end
			
		-- insert old containers to affected object list
		insert into @retAffectedObjects
		select distinct contained_by_gobject_id, 0, '' 
		from gobject G inner join @containeeInfo CI on G.gobject_id = CI.gobject_id	
		
		-- insert old area to affected object list
		insert into @retAffectedObjects
		select distinct area_gobject_id, 0, '' 
		from gobject G inner join @containeeInfo CI on G.gobject_id = CI.gobject_id	
			
		if @assocType = 2 -- Area unassignment
		begin
			-- If we're unassigning app objects from an area, also unassign their device linkages
			-- provided that they are linked to the same device as that to which the area they 
			-- are currently assigned to is.
			declare @unlinkedObj table (gobject_id int,dio_id int,sg_mx_primitive_id smallint)
			
			delete odl
			output deleted.* into @unlinkedObj 
			  from object_device_linkage odl
			inner join gobject g 
			    on g.gobject_id = odl.gobject_id
			   and g.is_template = 0
			inner join @containeeInfo appObj 
			    on appObj.gobject_id = g.gobject_id
			   and appObj.cat_id = 10
			inner join gobject area_gobject 
			    on area_gobject.gobject_id = g.area_gobject_id
			inner join object_device_linkage areaodl
			    on areaodl.gobject_id = area_gobject.gobject_id
			   and areaodl.dio_id = odl.dio_id
			   and areaodl.sg_mx_primitive_id = odl.sg_mx_primitive_id
			
			if(@@ROWCOUNT <> 0)
			begin
				delete ab_attr from autobound_attribute ab_attr
				inner join @unlinkedObj UObj on
				UObj.dio_id = ab_attr.dio_id and
				UObj.sg_mx_primitive_id = ab_attr.sg_mx_primitive_id and
				UObj.gobject_id = ab_attr.gobject_id
			end
		end
		-- update all objects in the original list 
		update gobject set area_gobject_id = 0, contained_by_gobject_id = 0
		from gobject G inner join @containeeInfo CI on G.gobject_id = CI.gobject_id

		-- set reference string to dirty
		update attribute_reference set is_valid = 1
		from  attribute_reference AR inner join @containeeInfo CI on AR.gobject_id =  CI.gobject_id
		where (reference_string = N'---Auto---' or reference_string like 'myDIO.%' or reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' or reference_string like 'myArea.%' or reference_string like 'myContainer%' or reference_string like 'myHost.%')
					
		-- Update the Hierarchical Name of any Area object which is contained by another area
		IF exists ( select gobject_id from @containeeInfo where cat_id = 13 and my_container <> 0 )
		BEGIN
			declare @AreaDescendant table(gobject_id int, nLevel smallint)
			insert into @AreaDescendant select gobject_id, 1
			from @containeeInfo where cat_id = 13 and my_container <> 0

			-- Looping to get contained Areas from these Areas
			set @nLevel = 1
			while 1 > 0
			BEGIN

				-- Insert any objects for which the hierarchical name is changed
				if @nLevel > 1
					insert into @retAffectedObjects
					select A.gobject_id, 0, G.hierarchical_name from @AreaDescendant A inner join gobject G on G.gobject_id = A.gobject_id where nLevel = @nLevel					


				-- Update the Hierarchical Name of any contained objects, this has to do in layer 
				update gobject set hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
				from gobject G inner join @AreaDescendant O on G.gobject_id = O.gobject_id
				where nLevel = @nLevel

				insert into @AreaDescendant 
				select G.gobject_id, @nLevel + 1
				from gobject G inner join @AreaDescendant CI on G.contained_by_gobject_id = CI.gobject_id
				where nLevel = @nLevel

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1

				-- set reference string to dirty for descendant area ( so my area and container are not affected )
				update attribute_reference set is_valid = 1
				from  attribute_reference AR inner join @AreaDescendant AD on AR.gobject_id =  AD.gobject_id
				where ( reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' ) and ( nLevel = @nLevel )
			END

			-- NOTE: we do not update instance table here because 
			-- when unset container of Area will not affect the host of these objects
		END

		IF exists ( select gobject_id from @containeeInfo where cat_id = 10 )
		BEGIN
			-- Update gobject table
			update gobject set hosted_by_gobject_id = 0, area_gobject_id = 0, contained_by_gobject_id = 0,
			hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
			from gobject G inner join @containeeInfo CI on G.gobject_id = CI.gobject_id
			where cat_id = 10


			-- insert any descendants of these AppObjects and set Hierarchical Name
			set @nLevel = 1
			while 1 > 0
			BEGIN

				-- Insert any objects for which the hierarchical name is changed
				if @nLevel > 1
					insert into @retAffectedObjects
					select C.gobject_id, 0, G.hierarchical_name from @containeeInfo C inner join gobject G on G.gobject_id = C.gobject_id where cat_id = 10 and nLevel = @nLevel					



				insert into @containeeInfo 
				select G.gobject_id, 10, G.contained_by_gobject_id, @nLevel + 1, 1
				from gobject G inner join @containeeInfo OI on G.contained_by_gobject_id = OI.gobject_id
				where nLevel = @nLevel

				insert into @retAffectedObjects select AR.gobject_id, 0, ''
				from attribute_reference AR 
				inner join gobject G on AR.resolved_gobject_id = G.gobject_id
				inner join  @containeeInfo CI on 
					   CI.gobject_id = G.gobject_id and CI.nLevel = @nLevel + 1

				
				-- update attribute_reference table		
				update attribute_reference set is_valid = 1 from attribute_reference AR inner join 
				gobject G on AR.resolved_gobject_id = G.gobject_id
				inner join  @containeeInfo CI on CI.gobject_id = G.gobject_id and CI.nLevel = @nLevel + 1

				-- Update the Hierarchical Name of any contained objects, this has to do in layer 
				update gobject set hosted_by_gobject_id = 0, area_gobject_id = 0, 
						hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
				from gobject G inner join @containeeInfo O on G.gobject_id = O.gobject_id
				where nLevel = @nLevel + 1 and cat_id = 10 and my_container <> 0

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1	

			END

			
			-- set reference string to dirty for contained app objects ( so my  container are not affected )
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @containeeInfo CI on AR.gobject_id =  CI.gobject_id
			where ( reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' or reference_string like 'myArea.%' or reference_string like 'myHost.%' )

			-- update instance table
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @containeeInfo oi on Inst.gobject_id = oi.gobject_id
			where (cat_id =10) or (cat_id =13) --only Area or ApplicationObjects are hosted by Area and there mx-ids shld get change
		END		

		-- Repeat code for custom category objects
		IF exists ( select gobject_id from @containeeInfo where cat_id = 25 )
		BEGIN
			-- Update gobject table
			update gobject set hosted_by_gobject_id = 0, area_gobject_id = 0, contained_by_gobject_id = 0,
			hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
			from gobject G inner join @containeeInfo CI on G.gobject_id = CI.gobject_id
			where cat_id = 25

			-- insert any descendants of these AppObjects and set Hierarchical Name
			set @nLevel = 1
			while 1 > 0
			BEGIN

				insert into @containeeInfo 
				select G.gobject_id, 25, G.contained_by_gobject_id, @nLevel + 1, 1
				from gobject G inner join @containeeInfo OI on G.contained_by_gobject_id = OI.gobject_id
				where nLevel = @nLevel

				-- update attribute_reference table		
				update attribute_reference set is_valid = 1 from attribute_reference AR inner join 
				gobject G on AR.resolved_gobject_id = G.gobject_id
				inner join  @containeeInfo CI on CI.gobject_id = G.gobject_id and CI.nLevel = @nLevel + 1

				-- Update the Hierarchical Name of any contained objects, this has to do in layer 
				update gobject set hosted_by_gobject_id = 0, area_gobject_id = 0, 
						hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
				from gobject G inner join @containeeInfo O on G.gobject_id = O.gobject_id
				where nLevel = @nLevel + 1 and cat_id = 25 and my_container <> 0

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1	

			END

			-- set reference string to dirty for contained app objects ( so my  container are not affected )
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @containeeInfo CI on AR.gobject_id =  CI.gobject_id
			where ( reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' or reference_string like 'myArea.%' or reference_string like 'myHost.%' )

			-- update instance table
			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @containeeInfo OI on Inst.gobject_id = OI.gobject_id
			where cat_id = 25
		END	
	END


	insert into @retAffectedObjects
	(
		gobject_id, 
		is_toolset,
    G.hierarchical_name
	)
	select 
		gid, 
		0,
    G.hierarchical_name
	from #childList inner join gobject G on G.gobject_id = gid
	where gid not in 
			(select gobject_id
			gobject_id 
			from @retAffectedObjects)
			
	-- set the package status
	update package set reference_status_id = 2
	from @retAffectedObjects ao
	inner join gobject g on
		ao.gobject_id = g.gobject_id
	inner join package PK on
		g.gobject_id = PK.gobject_id and
		g.checked_in_package_id = PK.package_id
	inner join attribute_reference AR on
		PK.gobject_id = AR.gobject_id and
		PK.package_id = AR.package_id and
		AR.is_valid = 1

	-- wipe out contained name of top level objects

	update gobject set contained_name = '' where contained_by_gobject_id = 0 and contained_name <> ''
	
	-- invalidate references...
	create table #reference_target(gobject_id int primary key)
	
	insert into #reference_target
	select gid
	from #childList

	exec internal_invalidate_references_to_objects

	drop table #reference_target

	select distinct * from @retAffectedObjects order by is_toolset
		
end
go

