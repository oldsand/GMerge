create procedure dbo.internal_update_timestamp_for_deleted_gobjects
@FileNameOfIds nvarchar (265)
as
begin tran

    set quoted_identifier off
    
    create table  #deleted_gobject_ids ( gobject_id int primary key)
    
    declare @sql nvarchar(2000)
    
    set @sql = 'bulk insert #deleted_gobject_ids  from ''' + @FileNameOfIds+ ''' with(tablock,datafiletype  = ''widechar'')'
    
    exec (@sql)

	insert	deleted_gobject(gobject_id)
    select gobject_id
    from #deleted_gobject_ids

    update galaxy
    set max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 
    
commit

go

