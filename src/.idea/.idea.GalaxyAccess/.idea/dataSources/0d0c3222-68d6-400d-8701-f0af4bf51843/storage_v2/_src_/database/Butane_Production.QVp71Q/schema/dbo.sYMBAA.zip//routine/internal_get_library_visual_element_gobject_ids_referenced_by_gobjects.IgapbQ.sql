create proc dbo.internal_get_library_visual_element_gobject_ids_referenced_by_gobjects
    -- comma separated list of visual element ids or file of ids
    @file_of_gobject_ids nvarchar(4000)
as
begin tran

    -- read file_of_gobject_ids
    create table  #gobject_ids ( gobject_id int)
    
    insert #gobject_ids(gobject_id)
        exec internal_select_ids @file_of_gobject_ids
 

    create table #gobjects
    (
        gobject_id int,
        package_id int
    )

    create table #next_gobjects
    (
        gobject_id int,
        package_id int
    )
 
    create table #next_gobjects_without_visual_element
    (
        gobject_id int,
        package_id int
    )
  
    create table #referenced_visual_elements
    (
        visual_element_id int
    )

    insert #next_gobjects(gobject_id, package_id) 
    ( 
        select vev.inherited_from_gobject_id, vev.inherited_from_package_id
        from    visual_element_version vev
        where   vev.gobject_id in (select gobject_id from #gobject_ids)
    )

     -- Handle ViewApp
    insert #next_gobjects_without_visual_element(gobject_id, package_id)
    (
        select  g.gobject_id, g.checked_in_package_id
        from    gobject g
        inner join #gobject_ids gids
            on gids.gobject_id = g.gobject_id
        inner join template_definition t 
            on g.template_definition_id = t.template_definition_id
        where t.category_id in (17,26)
    )

     -- Handle InTouchViewApp
    insert #next_gobjects_without_visual_element(gobject_id, package_id)
    (
        select  parent.gobject_id, parent.checked_in_package_id
        from    gobject parent
        inner join gobject g
            on parent.gobject_id = g.derived_from_gobject_id
        inner join #gobject_ids gids
            on gids.gobject_id = g.gobject_id
        inner join template_definition t 
            on g.template_definition_id = t.template_definition_id
        where t.category_id in (26) 
    )

    insert #next_gobjects(gobject_id, package_id)
    (
        select  distinct gobject_id, package_id 
        from    #next_gobjects_without_visual_element
    )

    while (1=1)
    begin
        insert  #referenced_visual_elements(visual_element_id)
        (
            select distinct bound_vev.visual_element_id
            from    visual_element_reference bver            
            inner join visual_element_version bound_vev on
                bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
			inner join gobject g on 
				bound_vev.gobject_id = g.gobject_id and
				g.namespace_id = 3 -- Symbol, not an automation object...

            inner join #next_gobjects n
            on      bver.package_id = n.package_id 
            union
            select distinct bound_vev.visual_element_id
            from    visual_element_reference bver            
            inner join visual_element_version bound_vev on
                bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
			inner join gobject g on 
				bound_vev.gobject_id = g.gobject_id and
				g.namespace_id = 3 -- Symbol, not an automation object...
            inner join #next_gobjects n
            on      bver.package_id = n.package_id 
        )
   
        truncate table #next_gobjects
       
        insert #next_gobjects(gobject_id, package_id)
        (
            select  v.gobject_id, v.package_id
            from    visual_element_version v
            inner join #referenced_visual_elements r
            on      v.visual_element_id = r.visual_element_id
            inner join gobject g
            on      v.gobject_id = g.gobject_id and v.package_id = g.checked_in_package_id
        )

        delete  #next_gobjects
        from    #next_gobjects n 
        inner join #gobjects g
        on      n.gobject_id = g.gobject_id
   
        if (exists (select 1 from #next_gobjects))
        begin
            insert #gobjects(gobject_id, package_id)
            (
                select  gobject_id, package_id
                from    #next_gobjects
            )
        end
        else
            break 
    end

    delete  #gobjects
    from    #gobjects gs
    inner join gobject g
    on      g.gobject_id = gs.gobject_id
    where   g.namespace_id <> 3

    select  gobject_id
    from    #gobjects

commit
go

