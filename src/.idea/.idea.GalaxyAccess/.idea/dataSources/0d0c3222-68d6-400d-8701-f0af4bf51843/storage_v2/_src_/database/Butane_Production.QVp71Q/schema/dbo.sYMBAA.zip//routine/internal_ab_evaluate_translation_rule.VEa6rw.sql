CREATE FUNCTION dbo.internal_ab_evaluate_translation_rule(
    @attr_ref             nvarchar(329) 
    , @xlate_rule_id      nvarchar(1000))
RETURNS nvarchar(329)
as
begin
  /*
  ** Function [internal_ab_evaluate_translation_rule]
  ** This function evaluates a translation rule (@gsub_str) for a given attribute reference.
  ** The translation rule specification is of the following format:
  **   search-replace-spec1|search-replace-spec2|...|search-replace-specn/
  ** where 'search-replace-spec' is a search and replace specification that bears the following format:
  **   search-string?replace-string
  ** The following is a translation spec that converts all occurrences of 'value' to 'val', 'temperature' to 'temp', and 'pressure' to 'prs'
  **   select internal_ab_evaluate_translation_rule (item_ref, N'value?val/temperature?temp/pressure?prs/') 
  ** An alternative spec that does the same thing:
  **   select internal_ab_evaluate_translation_rule (item_ref, N'ue?/erature?/pressure?prs/') -- eat 'temp{erature}' and 'val{ue}'
  */
  declare @gsub_str nvarchar(1024)
  declare @srstart  int
  declare @srsep    int 		-- search-and-replace token separator '/'
  declare @toksep   int 		-- '?' that separates search and replace strings withing a search-and-replace specification
  declare @len      int

  if (@xlate_rule_id > 0)
  begin
    SELECT @gsub_str = xlate_rule_gsub_str
      FROM autobind_translation_rule
     WHERE xlate_rule_id = @xlate_rule_id
    
    if @@ROWCOUNT = 1
	begin
		set @len = LEN (@gsub_str) 

		set @toksep = 1
		set @srstart = 1
		-- Eat leading '/'
		if (SUBSTRING(@gsub_str, @srstart, 1) = N'/')
  		  set @srstart += 1

		set @srsep = CHARINDEX (N'/', @gsub_str, @srstart)
		while (@srsep > 0)
		begin
    		set @toksep = CHARINDEX (N'?', @gsub_str, @toksep)
    		if (@toksep > 0 AND @toksep < @srsep)
    		begin
    			set @attr_ref = REPLACE (@attr_ref, SUBSTRING (@gsub_str, @srstart, @toksep - @srstart), SUBSTRING (@gsub_str, @toksep + 1, @srsep - (@toksep + 1)))
     			set @toksep = @toksep + 1
    			set @srstart = @srsep + 1
    			set @srsep = CHARINDEX (N'/', @gsub_str, @srstart)
    		end
    		else 
    			break
		end

		if (@srstart < @len)
		begin
    		-- Handle the case of the trailing string
    		set @toksep = CHARINDEX (N'?', @gsub_str, @srstart)
    		if (@toksep > 0)
    		begin
      			set @attr_ref = REPLACE (@attr_ref, SUBSTRING (@gsub_str, @srstart, @toksep - @srstart), SUBSTRING (@gsub_str, @toksep + 1, @len - @toksep))
    		end
		end
	  end
  end
  return @attr_ref

end
go

