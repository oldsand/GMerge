create proc dbo.internal_get_scangroup_info_for_gobject
@gobject_id int
 AS
begin
	SET NOCOUNT ON
	select g.gobject_id, p.mx_primitive_id, p.primitive_name
	from gobject g
	inner join primitive_instance p
	   on p.gobject_id = g.gobject_id
	   and p.package_id = g.checked_in_package_id
	inner join primitive_definition pd
	   on pd.primitive_definition_id = p.primitive_definition_id
	   and pd.primitive_name in (N'S', N'SG', N'ScanGroup1')
	inner join template_definition t
	   on t.template_definition_id = g.template_definition_id
	   and t.category_id in (11,12,24)
	where g.gobject_id = @gobject_id
end
go

