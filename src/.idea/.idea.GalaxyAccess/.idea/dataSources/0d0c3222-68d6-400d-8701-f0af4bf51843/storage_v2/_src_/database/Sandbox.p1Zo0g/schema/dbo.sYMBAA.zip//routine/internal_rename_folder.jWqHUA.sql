
/***********************************************************************************************************************************
If you change this you need to check w/ Foxboro. This is used by Foxboro objects in their MigratePrimitive methods -- HF1467 CR93406
************************************************************************************************************************************/

create proc dbo.internal_rename_folder
(
	@folder_id int,
	@folder_name nvarchar(64)
)
AS
begin

declare @ErrorCode int
 
    begin tran
	declare @parent_folder_id int
	declare @folder_type int
	select @parent_folder_id = parent_folder_id,
	@folder_type = folder_type
	from folder where folder_id = @folder_id

    	IF not exists(select folder_id from folder where folder_name = @folder_name 
		and parent_folder_id = @parent_folder_id and folder_type = @folder_type  )
	BEGIN
	    update folder set folder_name = @folder_name where folder_id = @folder_id		
	END	
	ELSE
	BEGIN
	    set @ErrorCode = 1000
        rollback
		return @ErrorCode
	END	


    set @ErrorCode = @@error
    if @ErrorCode <> 0 begin
        rollback
        return @ErrorCode
    end
    
    update folder
    set has_objects = has_objects
    where folder_id = @folder_id    
    
    update galaxy
    set max_proxy_timestamp = cast(@@dbts as bigint)
    
    commit
	return @ErrorCode
end
go

