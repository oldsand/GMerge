
/*
This procedure gives all the files which are deployed on 
the given node name

usage:
exec internal_get_files_deployed_to_node'
 'Nodename'
*/
create  proc dbo.internal_get_files_deployed_to_node
    @nodename nvarchar(256)
as
set nocount on
begin
	select file_name, vendor_name, registration_type from file_table ft
	inner join deployed_file df
	on ft.file_id = df.file_id
    where (node_name = @nodename)
    and
    (
    (is_package_deployed = 1 ) 
    or 
    (is_editor_deployed = 1) 
    or 
    (is_runtime_deployed = 1)
    )

end


go

