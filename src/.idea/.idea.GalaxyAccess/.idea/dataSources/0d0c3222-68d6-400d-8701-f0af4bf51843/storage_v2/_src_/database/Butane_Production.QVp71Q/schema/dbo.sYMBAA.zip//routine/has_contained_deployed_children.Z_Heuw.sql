create function dbo.has_contained_deployed_children( 
            @gobject_id int
            )
returns bit
as 
begin

declare @all_children table
(
	deployed_package_id int
)


	;With CTE
	(
		gobject_id,
		deployed_package_id 
	)
	as
	(
		select 
			g.gobject_id,
			g.deployed_package_id
		from gobject g
		where g.contained_by_gobject_id = @gobject_id
		union all
		select 
			g.gobject_id,
			g.deployed_package_id 
		from CTE  inner join gobject g on
			g.contained_by_gobject_id = CTE.gobject_id 
		

	)
	insert into
	@all_children
	select
		deployed_package_id
	from CTE
	
	declare @has_deployed_child bit

    if exists(select '*' from @all_children where deployed_package_id > 0 )
	begin
		set @has_deployed_child = 1
	end
	else
	begin
		set @has_deployed_child = 0
	end
   
	return @has_deployed_child

end
go

