/**************************************************/
/*Object Name :  internal_get_required_supported_features */
/*Object Type :  Stored Proc.								 */
/*Purpose :    Procedure to return required and supported feature of the gobject ids provided*/
/*Used By :    CDI									*/
/**************************************************/
create proc dbo.internal_get_required_supported_features
@requiredfeatureObjid int ,
@supportedfeatureobjid int ,
@requiredfeature uniqueidentifier out,
@supportedfeature uniqueidentifier out
as 
begin
  set @requiredfeature = (select required_features from internal_required_support_features  where gobject_id = @requiredfeatureObjid )
  set @supportedfeature = (select supported_features from internal_required_support_features  where gobject_id = @supportedfeatureobjid )
end
go

