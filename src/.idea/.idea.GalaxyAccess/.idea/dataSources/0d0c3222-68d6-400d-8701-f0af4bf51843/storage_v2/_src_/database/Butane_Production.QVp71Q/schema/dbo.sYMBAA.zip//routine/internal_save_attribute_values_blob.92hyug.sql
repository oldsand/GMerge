CREATE PROCEDURE dbo.internal_save_attribute_values_blob
(
  @gobject_id int,	
  @package_id int = 0,
  @attribute_values_blob image
)
AS
 
  RAISERROR('internal_save_attribute_values_blob should not be called', 16, 1) 
  goto OnExit
 
 declare @retcode int
 
 select @retcode = 0

if (@package_id = 0)
BEGIN
	  select @retcode=1
      Goto OnExit
END

    
  
     Update package
        Set instance_attributes = @attribute_values_blob
        where package_id = @package_id and gobject_id = @gobject_id

        if (@@Error <> 0) select @retcode=1
     
        Goto OnExit
OnExit:

    return @retcode
go

