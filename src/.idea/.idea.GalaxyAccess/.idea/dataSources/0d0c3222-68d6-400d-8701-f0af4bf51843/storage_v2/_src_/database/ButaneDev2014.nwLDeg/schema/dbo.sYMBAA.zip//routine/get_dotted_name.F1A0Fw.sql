create function dbo.get_dotted_name (@fullname nvarchar(max), @offset int)
returns nvarchar(max)
as
begin
  declare @s nvarchar(max)
  set @s = substring(@fullname, @offset, 9999)
  declare @end int
  set @end = charindex('.', @s) - 1
  if @end < 1 return @s
  return substring(@s, 1, @end)
end
go

