/*
    This procedure takes a file of visual element ids and 
    returns the names for them.  
*/

create procedure dbo.internal_get_visual_element_name_from_id
@file_name_of_ids nvarchar (265)
as
begin tran

    set quoted_identifier off
    
    create table  #visual_element_ids ( visual_element_id int )	
    
    declare @sql nvarchar(2000)
    
    set @sql = 'bulk insert #visual_element_ids  from ''' + @file_name_of_ids+ ''' with(tablock,datafiletype  = ''widechar'')'
    
    exec (@sql)

    declare  @visual_element_ids_ordered table
       (
        idx int identity (1,1),
        visual_element_id int) -- this table is to preserve original order...

    insert into @visual_element_ids_ordered (visual_element_id)
    select visual_element_id
    from #visual_element_ids

    select 
        isnull(v.visual_element_name, '')
    from @visual_element_ids_ordered vids
    left outer join internal_visual_element_description_view v (noexpand)on
        v.visual_element_id = vids.visual_element_id
    order by vids.idx

    drop table #visual_element_ids

commit

go

