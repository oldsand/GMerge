create trigger trigger_insert_folder_gobject_link
on folder_gobject_link
for insert
as
begin tran

/* Rule:
    Only Visual Elements(folder_type 2) can be
    put in folder_id 0.

    For all other scenarios, a coded "foreign key" 
    constraint must be put in place to replace:
    
    alter table folder_gobject_link add 
    	constraint fk_folder_gobject_link_folder_folder foreign key 
    	(
    		folder_id
    	) references folder (
    		folder_id
    	)

*/
    if exists
    (
        select '1'
        from inserted i
        where folder_id = 0 and
            i.folder_type <> 2            
    )
    begin
        raiserror('Only visual elements may be placed in folder 0.', 16, 1)
        rollback tran
    end

    if exists
    (
        select '1'
        from inserted i
        where i.folder_id > 0 and
            i.folder_id not in
            (
                select folder_id
                from folder
            )
    )
    begin
        raiserror('Cannot associate an object with an invalid folder_id', 16, 1)
        rollback tran
    end


    begin
        update f 
        set f.has_objects = 1
        from folder f
        inner join inserted i on
        f.folder_id = i.folder_id and 
        f.folder_type = i.folder_type

    end       

commit
go

