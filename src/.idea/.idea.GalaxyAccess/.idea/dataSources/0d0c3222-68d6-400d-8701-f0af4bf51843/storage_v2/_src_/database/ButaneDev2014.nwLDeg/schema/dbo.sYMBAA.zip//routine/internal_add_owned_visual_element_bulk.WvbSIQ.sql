create proc dbo.internal_add_owned_visual_element_bulk
    @gobject_id int,
    @package_id int,
    @file_has_content int,
    @visual_element_file nvarchar(255)
as
begin --1
    begin tran --2

    set nocount on
        
    create table #owned_visual_element (
        visual_element_id int,
        change_type int,
        visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS null,
        mx_primitive_id smallint,        
	    thumbnail image null ,
	    visual_element_definition image not null,
	    description nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS null default(N'')
	)

    if (@file_has_content = 1)
    begin --3
			DECLARE @query nvarchar(2000)
			SET @query = 'BULK INSERT #owned_visual_element  FROM ''' + @visual_element_file+ ''' 
						WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'',ROWTERMINATOR = ''	'') '
			EXEC sp_executesql @query
	    
			-- create a table to be used to iterate through while calling internal_add_owned_visual_element
			declare @owned_visual_element table (
				mx_primitive_id smallint,
				visual_element_id int,
				change_type int,
				visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS null,
				description nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS null
			)
			insert into @owned_visual_element
			select 	
				mx_primitive_id,
				visual_element_id,
				change_type,
				visual_element_type,
				description
			from #owned_visual_element


			declare @visual_element_id int
			declare @change_type int
			declare @visual_element_type nvarchar(32)
			declare @mx_primitive_id smallint
			declare @description nvarchar(1024)

			while exists(select 1 from @owned_visual_element)
			begin
				
				select top 1
					@visual_element_id = visual_element_id,
					@change_type = change_type,
					@visual_element_type = visual_element_type,
					@mx_primitive_id = mx_primitive_id,
					@description = description 
				from @owned_visual_element
					
				exec internal_add_owned_visual_element
				@visual_element_id,
				@change_type,
				@visual_element_type, 
				@gobject_id,
				@package_id,
				@mx_primitive_id,
				@description
				--@thumbnail image,
				--@velDefn   image

				delete from @owned_visual_element
				where @mx_primitive_id = mx_primitive_id

			end

			-- Iterate through all VEs and bind by ID
			declare @visual_element_to_bind_by_id table
			(
				visual_element_id int,
				visual_element_type nvarchar(32),
				mx_primitive_id smallint
			)
			insert into @visual_element_to_bind_by_id
			(
				visual_element_id,
				visual_element_type,
				mx_primitive_id
			)
			select
				visual_element_id,
				visual_element_type,
				mx_primitive_id
			from #owned_visual_element	
			
			while exists(select 1 from @visual_element_to_bind_by_id)
			begin --4	
				select top 1
					@visual_element_id = visual_element_id,
					@visual_element_type = visual_element_type,
					@mx_primitive_id = mx_primitive_id
				from @visual_element_to_bind_by_id

				--call bind here...
				if(@visual_element_id > 0) --L00079759
				begin
				exec internal_bind_visual_element_by_id_or_name
					@gobject_id,
					@package_id,
					@mx_primitive_id,
					@visual_element_id,
					@visual_element_type,
					N'',--@visual_element_name nvarchar(362),
					1 --@bind_by_id bit
				end
				delete from @visual_element_to_bind_by_id
				where @mx_primitive_id = mx_primitive_id
			end --4		

			-- bind by name
			-- fill temp table
			declare @visual_element_to_bind_by_name table
			(
				mx_primitive_id smallint,
				visual_element_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS null,
				visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS null
			)
			insert into @visual_element_to_bind_by_name
			(
				mx_primitive_id,
				visual_element_name,
				visual_element_type
			)
			select 
				v.mx_primitive_id,
				v.visual_element_name,
				v.visual_element_type
			from #owned_visual_element ove
			inner join internal_visual_element_description_view v
			on  v.gobject_id = @gobject_id and
				v.package_id = @package_id and
				v.mx_primitive_id = ove.mx_primitive_id

			--iterate through temp table...
			declare @visual_element_name nvarchar(32)
			
			while exists (select 1 from @visual_element_to_bind_by_name)
			begin --5
				select top 1
					@visual_element_name = visual_element_name,
					@visual_element_type = visual_element_type,
					@mx_primitive_id = mx_primitive_id
				from @visual_element_to_bind_by_name

				exec internal_bind_visual_element_by_id_or_name
					@gobject_id,
					@package_id,
					@mx_primitive_id,
					0,--@visual_element_id,
					@visual_element_type,
					@visual_element_name,
					0 --@bind_by_id bit

				delete from @visual_element_to_bind_by_name
				where @mx_primitive_id = mx_primitive_id
				

			end -- 5



		end --3

    exec internal_bind_relative_visual_elements_for_gobject 
        @gobject_id, @package_id

    commit --2
end --1
go

