--This function returns Attribute name from Reference String
-- For Example Reference String is "me.Effluent.ForceClose"
-- This function returns "ForceClose"


CREATE function dbo.get_attribute_name_from_reference_string( 
		@FullAttributeName as nvarchar(700), --700 because in Reference table reference string is 700
		@Resolve_Gobject_Id as int	)
returns nvarchar(329) -- Attribute Name is 329 
as
begin

	--@Part1_String is any one of Tag_Name, Hierarchical_Name, 
	--MyArea, MyHost, MyEngine, MyPlatForm, MyContainer, Me
	--@Part2_String is Attribute Name
	declare @Attribute_Name as nvarchar(329)
	declare @Part1_String as nvarchar(700)
	declare @Part2_String as nvarchar(700)	
	

	declare @Resolved_Gobject_Tag_Name as nvarchar(329)
	declare @Resolved_Gobject_Hierarchical_Name as nvarchar(329)
	declare @Resolved_Gobject_Hierarchical_NamePart1 as nvarchar(329)	
	

	select @Resolved_Gobject_Tag_Name = tag_name, @Resolved_Gobject_Hierarchical_Name = hierarchical_name  from gobject where gobject_id = @Resolve_Gobject_Id

	declare @firsttime as bit
	set @firsttime = 1

	while( CHARINDEX(N'.',@FullAttributeName) > 0)
	begin
		if (@firsttime = 1) 		
		begin
			set @Part1_String = ( LEFT(@FullAttributeName, CHARINDEX(N'.',@FullAttributeName) - 1))			
		end
		else 
		   set @Part1_String = @Part1_String + N'.'+ ( LEFT(@FullAttributeName, CHARINDEX(N'.',@FullAttributeName) - 1))
		

		set @Part2_String = (RIGHT(@FullAttributeName,LEN(@FullAttributeName)- CHARINDEX(N'.',@FullAttributeName)))		
		set @FullAttributeName = @Part2_String

		
		IF (@firsttime = 1) -- needs to check for first , part1 only
		begin
			set @firsttime = 0
			IF(@Part1_String = @Resolved_Gobject_Tag_Name)
				break

			IF( @Part1_String = N'Me' OR @Part1_String = N'MyArea' OR @Part1_String = N'MyHost' OR @Part1_String = N'MyEngine' OR @Part1_String = N'MyPlatForm' OR @Part1_String = N'MyContainer' )
			begin 
				--Compare @Resolved_Gobject_Hierarchical_Name part1 after '.' TO @Part2_String initial string, if same then heirarchical name 
				set @Resolved_Gobject_Hierarchical_NamePart1 = (RIGHT(@Resolved_Gobject_Hierarchical_Name,LEN(@Resolved_Gobject_Hierarchical_Name)- CHARINDEX(N'.',@Resolved_Gobject_Hierarchical_Name)))		
				
				if ( LEFT (@Part2_String, LEN(@Resolved_Gobject_Hierarchical_NamePart1) ) = @Resolved_Gobject_Hierarchical_NamePart1 )
				begin
					set @FullAttributeName = (RIGHT(@Part2_String,LEN(@Part2_String) - LEN(@Resolved_Gobject_Hierarchical_NamePart1)-1 ) )					
				end	
				break			
			end			
		end

		if(@Part1_String = @Resolved_Gobject_Hierarchical_Name )
				break
		
	end
	return @FullAttributeName

end
go

