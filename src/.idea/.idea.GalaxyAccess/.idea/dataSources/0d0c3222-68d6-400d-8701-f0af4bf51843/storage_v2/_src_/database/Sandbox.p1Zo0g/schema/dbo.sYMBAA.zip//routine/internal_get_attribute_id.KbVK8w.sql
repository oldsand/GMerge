/**************************************************/
/*Object Name :  internal_get_attribute_id				*/
/*Object Type :  Stored Proc.						*/
/*Purpose	  :  Procedure to get the attribute ID for a given package id, */
/*               primitive id and attribute name .  */
/*Used By	  :  CDI(Resolve references)			*/
/**************************************************/
create procedure dbo.internal_get_attribute_id
@varpkgID    int,
@vargobjectId int,
@varAttrname nvarchar(700),
@varPrimID   smallint,
@varAttrID   smallint out
AS
SET NOCOUNT ON
begin
    set @varAttrID = 0

    select 
		@varAttrID = attr_def.mx_attribute_id 
    from 
		primitive_instance prim_inst 
    inner join attribute_definition attr_def on 
        prim_inst.primitive_definition_id = attr_def.primitive_definition_id
    where 
		prim_inst.gobject_id = @vargobjectId
	and prim_inst.package_id = @varpkgID
	and prim_inst.mx_primitive_id = @varPrimID 
	and attr_def.attribute_name = @varAttrname

	--If Not found, look in the dynamic_attribute table
	if (@varAttrID = 0)
	begin
		    select 
				@varAttrID = dyna_attr.mx_attribute_id 
			from 
				dynamic_attribute dyna_attr 
			where 
				dyna_attr.gobject_id = @vargobjectId 
			and dyna_attr.package_id = @varpkgID
			and dyna_attr.mx_primitive_id = @varPrimID 
			and dyna_attr.attribute_name = @varAttrname
			and dyna_attr.mx_attribute_category <> 16  -- MxCategory_SystemInternal_Browsable
			and dyna_attr.mx_attribute_category <> 17  -- MxCategory_PackageOnly_Calculated
	end
end
go

