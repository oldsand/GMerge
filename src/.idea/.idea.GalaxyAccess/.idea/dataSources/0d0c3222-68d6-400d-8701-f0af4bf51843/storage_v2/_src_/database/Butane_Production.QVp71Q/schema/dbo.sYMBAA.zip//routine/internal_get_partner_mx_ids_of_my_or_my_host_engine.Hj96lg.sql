--This stored procedure will return the mx_ids of partner Engine for the input GobjectId ( can be AppEngine or Application object)
--If GobjectId is Application Object it will find Host Engine & find his Partner mx_ids
CREATE procedure dbo.internal_get_partner_mx_ids_of_my_or_my_host_engine
@GobjectID int,
@PartnerPlatformId smallint  OUTPUT,
@PartnerEngineId smallint  OUTPUT
AS
begin
SET NOCOUNT ON

set @PartnerPlatformId  = dbo.get_mx_platform_id_of_redundant_engine(@GobjectID)
set @PartnerEngineId = dbo.get_mx_engine_id_of_redundant_engine(@GobjectID)


end
go

