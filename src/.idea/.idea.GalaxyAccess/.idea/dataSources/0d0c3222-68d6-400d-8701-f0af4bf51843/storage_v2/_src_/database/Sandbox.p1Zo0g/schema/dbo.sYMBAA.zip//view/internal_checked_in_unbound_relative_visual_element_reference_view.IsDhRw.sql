create view
    dbo.internal_checked_in_unbound_relative_visual_element_reference_view
with schemabinding 
as
select 
    ver.gobject_id,
    ver.package_id,
    ver.mx_primitive_id,
    ver.visual_element_reference_index,
    ver.checked_in_unbound_visual_element_type,
    referer_gobject.hierarchical_name + 
        case when (
                    (
                        len(checked_in_unbound_relative_object_name) = 0
                         or
                        checked_in_unbound_relative_object_name is null
                     )
                    ) then
               ''
        else
            '.' + checked_in_unbound_relative_object_name
        end 
        + '.' + checked_in_unbound_primitive_name 
        as checked_in_unbound_hierarchical_visual_element_name
from dbo.visual_element_reference ver
inner join dbo.gobject referer_gobject on 
    ver.gobject_id = referer_gobject.gobject_id
 where 
     is_relative_reference = 1 and
     checked_in_bound_visual_element_gobject_id is null and
     checked_in_bound_visual_element_package_id is null and 
     checked_in_bound_visual_element_mx_primitive_id is null

go

create unique clustered index idx_internal_checked_in_unbound_relative_visual_element_reference_view_multi
    on internal_checked_in_unbound_relative_visual_element_reference_view (checked_in_unbound_hierarchical_visual_element_name,
                                                                           checked_in_unbound_visual_element_type,
                                                                           gobject_id, package_id, mx_primitive_id,
                                                                           visual_element_reference_index)
go

create index idx_internal_checked_in_unbound_relative_visual_element_reference_view_name_type
    on internal_checked_in_unbound_relative_visual_element_reference_view (checked_in_unbound_hierarchical_visual_element_name,
                                                                           checked_in_unbound_visual_element_type)
go

create index idx_internal_checked_in_unbound_relative_visual_element_reference_view_package_id
    on internal_checked_in_unbound_relative_visual_element_reference_view (package_id)
go

