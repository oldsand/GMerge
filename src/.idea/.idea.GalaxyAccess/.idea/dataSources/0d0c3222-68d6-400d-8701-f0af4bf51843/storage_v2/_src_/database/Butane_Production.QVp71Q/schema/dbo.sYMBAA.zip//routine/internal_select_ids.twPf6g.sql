-- Selects integers passed in @ids_or_file_of_ids,
-- providing a method for external clients to pass a large
-- number of integers to a stored procedure for bulk processing.
--
-- IDs can either be passed as a comma separated list or 
-- from a file with one id per line.
--
-- For smaller data sets, passing CSV string is faster than passing
-- ids in file.  For larger sets, only a file will work because of
-- the string length limitation
--
-- Note:
--     - CSV string should not have any spaces, only numbers and commas
--     - file path must not begin with a number
--
-- Returns: 
--     table { id int }
--
-- Example 1 - passing as a CSV string:
--
--     exec internal_select_ids '1,2,3,4,5'
--
-- Example 2 - passing a file path:
--
--     exec internal_select_ids 'c:\ids.txt'
--
-- Example 3 - using from a stored procedure: 
--
--     create proc use_ids( @ids_or_file_of_ids nvarchar(4000) ) as 
--     begin
--        create table #ids ( id int )
--        insert into #ids exec internal_select_ids @ids_or_file_of_ids
--        < use #ids here >
--        drop table #ids
--     end

create proc dbo.internal_select_ids( @ids_or_file_of_ids nvarchar(4000) ) as
begin
    if( isnumeric( substring( @ids_or_file_of_ids,1,1) )=1 or len(@ids_or_file_of_ids)=0 ) 
        begin
    	declare @id varchar(10), @pos int, @start int
        declare @split table
        (
        	id int
        )
    
    	set @ids_or_file_of_ids = @ids_or_file_of_ids+ ','
        set @start = 0
    	set @pos = charindex(',',@ids_or_file_of_ids)
    
    	while @pos > 0
    	begin
    		set @id = substring(@ids_or_file_of_ids, @start, @pos - @start)
    		if @id <> ''
    		begin
    			insert into @split (id) 
    			values (cast(@id as int))
    		end
            set @start = @pos+1
    		set @pos = charindex(',', @ids_or_file_of_ids, @start)
    	end
        select * from @split
    end
    else
    begin
        create table #internal_select_ids ( id int )
    	DECLARE @gSQL nvarchar(2000)
    	SET @gSQL = 'bulk insert #internal_select_ids  FROM ''' + @ids_or_file_of_ids + '''
        WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
    	EXEC (@gSQL)        

       
        select * from #internal_select_ids
        drop table #internal_select_ids
    end
end
go

