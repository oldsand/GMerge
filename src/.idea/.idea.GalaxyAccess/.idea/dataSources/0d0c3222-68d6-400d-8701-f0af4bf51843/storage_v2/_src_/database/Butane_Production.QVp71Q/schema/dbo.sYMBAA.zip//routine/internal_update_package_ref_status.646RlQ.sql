/********************************************************************/
/*Object Name	:  internal_update_package_ref_status		            */
/*Object Type	:  Stored Proc.										*/
/*Purpose		:  to update the package table's reference status	*/
/*Used By		:  CDI												*/
/********************************************************************/
CREATE   PROCEDURE dbo.internal_update_package_ref_status
@FileNameOfdata nvarchar (265)
 AS
begin
	set nocount on


	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #results_table ( pkg_id int,ref_status_id int)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfdata + ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '

	EXEC (@SQL)

	update package set reference_status_id = #results_table.ref_status_id
	FROM package INNER JOIN #results_table ON package.package_id = #results_table.pkg_id

		
	drop table #results_table


	
end
go

