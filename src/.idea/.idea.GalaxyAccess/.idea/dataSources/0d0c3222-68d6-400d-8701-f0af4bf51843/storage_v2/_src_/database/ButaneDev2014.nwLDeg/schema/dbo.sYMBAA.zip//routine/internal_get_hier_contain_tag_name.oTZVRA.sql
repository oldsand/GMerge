-- Procedure to find out if the given contained name is valid
create procedure dbo.internal_get_hier_contain_tag_name
@varContainerTagName nvarchar(64),
@varContainedName    nvarchar(700),
@varTagName          nvarchar(64) out,
@vargObjectId        int         out
AS
begin
set nocount on
set @vargObjectId = 0
set @varTagName = ''	
begin tran

    SELECT @varTagName = containee.tag_name, @vargObjectId = containee.gobject_id 
	FROM gobject containee
	INNER JOIN gobject container
	ON containee.contained_by_gobject_id = container.gobject_id 
    WHERE container.tag_name = @varContainerTagName
	AND containee.contained_name = @varContainedName AND containee.namespace_id = 1 -- Automation Object

commit tran


end
go

