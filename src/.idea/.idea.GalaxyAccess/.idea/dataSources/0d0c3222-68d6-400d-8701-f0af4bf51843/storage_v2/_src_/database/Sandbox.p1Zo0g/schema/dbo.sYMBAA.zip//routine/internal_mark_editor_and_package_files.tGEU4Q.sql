/**************************************************
This storec proc mark the Editor and Package files which will get deployed
*************************************************/

/**************************************************/
CREATE  PROCEDURE dbo.internal_mark_editor_and_package_files
@FileNameOfIds nvarchar(400), 
@ecodemoduletype int, 
@nodename nvarchar(256)
 AS
begin	
	set nocount on
	-- Create client control exclusion list
	CREATE TABLE  #cc_file_exclusion_table ( 
		file_id				int
	); 

	-- Populate it per the stored procedure. Once populated, this file will contain a list
	-- of file-ids representing client-control objects. These are not undeployed from 
	-- the client node by GOCS.
	insert into		#cc_file_exclusion_table
	select			pf.file_id 
	from			primitive_instance_file_table_link pf 
	inner join		client_control_class_link cc 
			on		pf.gobject_id = cc.gobject_id
			
	begin tran
	
		CREATE TABLE #results_table ( file_id int )		
		
		-- call the stored procedure 'internal_construct_table_from_file'
		EXEC internal_construct_table_from_file @FileNameOfIds, '#results_table'

		IF (@ecodemoduletype = 4) -- Package code module type
			begin
				update deployed_file
							 set deployed_file.is_package_deployed = 1,
							 deployed_file.need_to_delete = 0
				from deployed_file INNER JOIN #results_table r ON 
				deployed_file.file_id = r.file_id 
				where deployed_file.node_name = @nodename
			end
		ELSE
			begin
			   IF (@ecodemoduletype = 2) -- Package & Editor code module type
				begin
					update deployed_file 
						set deployed_file.is_package_deployed = 1,
							 deployed_file.is_editor_deployed = 1,
							 deployed_file.need_to_delete = 0
					from deployed_file INNER JOIN #results_table r ON 
					deployed_file.file_id = r.file_id 
					where deployed_file.node_name = @nodename
				end
			end
		
		if (@nodename != HOST_NAME())
		begin
			declare @filesdeployedtoclient int
			select @filesdeployedtoclient = count(*) from deployed_file df 
			left outer join  #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id
			where upper(df.node_name) = upper(@nodename)
			and		cx.file_id is null	
			and (df.is_editor_deployed = 1 or df.is_package_deployed = 1 or df.need_to_delete = 1)
			
			declare @newFilesToDeploy int
			select @newFilesToDeploy = count(*) from deployed_file df inner join #results_table r on df.file_id = r.file_id
			left outer join  #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id 
			where  cx.file_id is null	
			
			if( @newFilesToDeploy > 0 )
			begin
				declare @new_timestamp_of_last_deployed_files bigint
				exec internal_get_next_timestamp @new_timestamp_of_last_deployed_files out

				update client_info
						set deployed_files_count = @filesdeployedtoclient,
						time_of_last_deployed_object_components = GetDate(),
						timestamp_of_last_synchronized = @new_timestamp_of_last_deployed_files --CAST ( @@dbts  AS timestamp )
				where client_name = @nodename -- note that make it like
			end
		end
		DROP TABLE #results_table
		DROP TABLE #cc_file_exclusion_table
	commit tran



end



go

