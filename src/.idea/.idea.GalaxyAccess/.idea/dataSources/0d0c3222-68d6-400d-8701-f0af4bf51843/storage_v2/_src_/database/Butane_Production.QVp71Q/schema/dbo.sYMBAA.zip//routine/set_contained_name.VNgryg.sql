CREATE function dbo.set_contained_name( 
	@gobjectId as int, 
	@containerId as int
	)
returns nvarchar(32)
as
begin
	-- If the object is top level, then set contained name to blank
	-- Or if it is invalid then also return
	if @containerId = 0 or @gobjectId = 0 return ''

	declare @ContainedName nvarchar(32)
	declare @TagName nvarchar(32)
	declare @istemplate bit
	declare @tempName nvarchar(32)	
	declare @count int
	declare @newcount int
	declare @startSuffix int

	select @TagName = tag_name, @ContainedName = contained_name, @istemplate = is_template from gobject where gobject_id = @gobjectId

	if len(@ContainedName) = 0		
	begin
		if @istemplate = 1 
			set @ContainedName = substring(@TagName, 2, 31)
		else 
			set @ContainedName = @TagName
	end
	
	set @tempName = @ContainedName
	set @startSuffix = 1
	set @count = 1
	set @newcount = 1

	while (@count > 0) OR (@newcount > 0)
	begin
		
		select @count = count(*) from gobject
		where contained_by_gobject_id = @containerId and contained_name = @tempName and gobject_id <> @gobjectId


		select @newcount = count(*) from CurrentSessionContainedName
		where @gobjectId <> obj_id and containedname = @tempName 
	
		if (@count <> 0) OR (@newcount <> 0)
		begin 
			set @tempName = substring(@ContainedName, 1, 31 - len(cast(@startSuffix as nvarchar))) + '_' + cast(@startSuffix as nvarchar)
			set @startSuffix = @startSuffix + 1
		end

	end

	return @tempName
end
go

