create  proc dbo.internal_set_container_association(
	@childIdList nvarchar(255),
	@parentId int,
	@assocType smallint,
	@updatecontainname int,
	@operationStatus int out)
As
begin
	if @parentId = 0 return	-- UNASSIGNMENT, should call internal_unset_association

	begin tran
	set nocount on



	-- ASSIGNMENT
	
	declare @retAffectedObjects table(gobject_id int, is_toolset bit)

	declare @mx_platform_id smallint, @mx_engine_id smallint, @mx_object_id	smallint
	declare @childId int, @child_platform_id smallint, @child_engine_id smallint
	declare @parentCategory int, @childCategory int, @my_container int 
	declare @objCount int, @nLevel smallint
	declare @is_template bit    
		declare @bit as bit

	select @parentCategory = category_id, @is_template = is_template
	from gobject inner join template_definition
	on gobject.template_definition_id = template_definition.template_definition_id
	where gobject_id = @parentId

	create table  #childList (gid int primary key)
	--delete from childList
	DECLARE @gSQL nvarchar(2000)
	SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
				WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
	EXEC (@gSQL)
	
	exec internal_filter_deployed_objects_from_input_list
	
	truncate table CurrentSessionContainedName 

	declare @count	int
	declare @baseid int
	declare @i		int

	if @assocType = 3		-- SET CONTAINER: Parent can be Areas or App Objects
	begin

		IF @parentCategory = 13		-- Parent is Area, child can only be Area
		BEGIN
			declare @AreaInfo table
			(
				obj_id int, 
				cat_id smallint, 
				nLevel smallint,
				contained_by_gobject_id int, 
				contained_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
				is_template bit 
			)

			insert into @AreaInfo select H.gid, T.category_id, 1, G.contained_by_gobject_id, 
			G.contained_name,G.is_template
			from #childList H inner join gobject G on H.gid = G.gobject_id
			inner join template_definition T on T.template_definition_id = G.template_definition_id
			where T.category_id = 13


			-- Add the old Container into list of affected objects since the Area is changed
			insert into @retAffectedObjects
			select contained_by_gobject_id, 0 from @AreaInfo 

			--L00013135
			truncate table CurrentSessionContainedName 

			insert into CurrentSessionContainedName 
				select CI.obj_id as obj_id , contained_name
				from @AreaInfo CI 

			select @count = count(Uniqeid) from CurrentSessionContainedName
			if (@count > 0)
			begin
				set @baseid = 1 

				set @i = 0
				while (@i < @count)
				begin
					update	CurrentSessionContainedName 
					set		containedname = dbo.set_contained_name(obj_id, @parentId)
					where	Uniqeid = @i + @baseid

					set @i = @i + 1
				end
			end

			-- update gobject table
			update gobject set contained_by_gobject_id = @parentId, area_gobject_id = @parentId, contained_name = CSC.containedname
			from gobject inner join CurrentSessionContainedName CSC on gobject_id = CSC.obj_id

            declare  @updateHierachialName table(obj_id int primary key)

			-- Update hierarchical Name of these objects and their descendants
			set @nLevel = 1					
			while 1 > 0
			BEGIN

				-- Update the Hierarchical Name of any contained objects, this has to do in layer 
				update gobject set hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
				from gobject G inner join @AreaInfo O on G.gobject_id = O.obj_id
				where nLevel = @nLevel

                insert into @updateHierachialName
                select G.gobject_id from gobject G inner join @AreaInfo O on G.gobject_id = O.obj_id
				where nLevel = @nLevel

				

				insert into @AreaInfo 
				select gobject_id, 13, @nLevel + 1, G.contained_by_gobject_id,
				G.contained_name,G.is_template 
				from gobject G inner join @AreaInfo CI on G.contained_by_gobject_id = CI.obj_id
				where nLevel = @nLevel

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1
			END	-- while	


			if ( @nLevel > 1 )
			BEGIN
				-- Add any objects which the hierarchical name changed
				insert into @retAffectedObjects
				select obj_id, 0 from @AreaInfo where cat_id = 13 
				and nLevel >= 1 and nLevel <= @nLevel
			END

			-- set the dirty flag for reference string for descendant
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @AreaInfo on AR.gobject_id = obj_id
			where  nLevel >= 1 and nLevel <= @nLevel and
			          ( reference_string like 'myPlatform.%'  or reference_string like 'myEngine.%' or reference_string like 'myHost.%' or reference_string like 'myContainer%'  or reference_string like 'myArea.%' )									


			set @bit = 1		
			update package set reference_status_id = 2
			from package PK inner join attribute_reference AR on 
			PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
			inner join @AreaInfo on AR.gobject_id = obj_id
			where is_valid = @bit 


			insert into @retAffectedObjects select ar.gobject_id,0 from attribute_reference ar inner join
			@AreaInfo on ar.resolved_gobject_id = obj_id

			set @bit = 1	

			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @AreaInfo on AR.resolved_gobject_id = obj_id

			update package set reference_status_id = 2
			from package PK inner join attribute_reference AR on 
			PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
			inner join @AreaInfo on AR.resolved_gobject_id = obj_id
			where is_valid = @bit 
					
		END

		ELSE IF @parentCategory = 10 OR @parentCategory = 25	-- Parent is AppObject, child can only be AppObject
		BEGIN

			declare @AppObjInfo table
			( 
				idx int identity(1,1), 
				obj_id int, 
				cat_id smallint, 
				mx_platform_id smallint, 
				mx_engine_id smallint, 
				nLevel smallint,
				hosted_by_gobject_id int, 
				contained_by_gobject_id int, 
				contained_name nvarchar(32)COLLATE SQL_Latin1_General_CP1_CI_AS,
				is_template bit 
			)
			declare @validChildCategory int
			set @validChildCategory = 10
			if @parentCategory = 25
			  set @validChildCategory = 25
	
			if @is_template = 0
				insert into @AppObjInfo select H.gid, T.category_id, mx_platform_id, mx_engine_id, 1,
				G.hosted_by_gobject_id, G.contained_by_gobject_id, G.contained_name, G.is_template
				from #childList H inner join gobject G on H.gid = G.gobject_id
				inner join template_definition T on T.template_definition_id = G.template_definition_id
				inner join instance I on G.gobject_id = I.gobject_id
				where T.category_id = @validChildCategory
			else
				insert into @AppObjInfo select H.gid, T.category_id, 0, 0, 1,
				G.hosted_by_gobject_id, G.contained_by_gobject_id, G.contained_name,G.is_template
				from #childList H inner join gobject G on H.gid = G.gobject_id
				inner join template_definition T on T.template_definition_id = G.template_definition_id
				where T.category_id = @validChildCategory

			-- First, we have to set the Host, Area and Container for this App Object in the gobject table
			declare @myHostId int, @myAreaId int,@my_hosting_tree_level int
			select @myHostId = hosted_by_gobject_id, 
				@myAreaId = area_gobject_id, 
				@my_hosting_tree_level = hosting_tree_level
			from gobject where gobject_id = @parentId
	
			-- Add the old Host ( also is its Area ) into list of affected objects since the Area is changed
			insert into @retAffectedObjects
			select hosted_by_gobject_id, 0 from @AppObjInfo 

			-- Add the old Container into list of affected objects since the container is changed
			insert into @retAffectedObjects
			select contained_by_gobject_id, 0 from @AppObjInfo

			--L00013135
			truncate table CurrentSessionContainedName 
			insert into CurrentSessionContainedName 
				select CI.obj_id as obj_id , contained_name
				from @AppObjInfo CI 

			select @count = count(Uniqeid) from CurrentSessionContainedName
			if (@count > 0)
			begin
				set @baseid = 1

				set @i = 0
				while (@i < @count)
				begin
					update	CurrentSessionContainedName 
					set		containedname = dbo.set_contained_name(obj_id, @parentId)
					where	Uniqeid = @i + @baseid

					set @i = @i + 1
				end
			end

			-- Update gobject table
			update gobject set hosted_by_gobject_id = @myHostId, area_gobject_id = @myAreaId, contained_by_gobject_id = @parentId, 
							   contained_name = CSC.containedname 
			from gobject G 			
			inner join CurrentSessionContainedName CSC on CSC.obj_id = G.gobject_id

			-- Update hierachical name ( child has new container ) and toolset ID in case of template
--			declare @new_toolset_id int
            declare @new_folder_id int
			if @is_template = 1
			BEGIN
--				select @new_toolset_id = toolset_id from template where gobject_id = @parentId

				select @new_folder_id = folder_id 
                from folder_gobject_link 
                where gobject_id = @parentId	
				
				-- Add the target toolset to affected list
				insert into @retAffectedObjects values(@new_folder_id, 1)

			
			END

			set @nLevel = 1					
			while 1 > 0
			BEGIN

				-- Update the Hierarchical Name of any contained objects, this has to do in layer 
				update gobject set hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
				from gobject G inner join @AppObjInfo O on G.gobject_id = O.obj_id
				where nLevel = @nLevel
			
				insert into @AppObjInfo 
				select gobject_id, 10, CI.mx_platform_id, CI.mx_engine_id, @nLevel + 1 ,
				G.hosted_by_gobject_id, G.contained_by_gobject_id, G.contained_name, G.is_template
				from gobject G inner join @AppObjInfo CI on G.contained_by_gobject_id = CI.obj_id
				where nLevel = @nLevel

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1
			END	-- while
		
			IF ( @nLevel > 1 )
			BEGIN
				-- Add any objects which the hierarchical name changed
				insert into @retAffectedObjects
				select obj_id, 0 from @AppObjInfo where cat_id = 10 
				and nLevel >= 1 and nLevel <= @nLevel 
			END


			IF ( @is_template = 1 )
			BEGIN
				update gobject set tag_name = hierarchical_name
				from gobject G inner join @AppObjInfo O on G.gobject_id = O.obj_id
				where nLevel >= 1 and nLevel <= @nLevel


				-- Add the source toolsets to affected list before update them
				insert into @retAffectedObjects 
				select distinct folder_id, 1 
				from folder_gobject_link T inner join @AppObjInfo O on T.gobject_id = O.obj_id
				where nLevel >= 1 and nLevel <= @nLevel


				-- update folder_gobject_link
                update folder_gobject_link set folder_id = @new_folder_id
				from folder_gobject_link FT inner join @AppObjInfo O on FT.gobject_id = O.obj_id
				where nLevel >= 1 and nLevel <= @nLevel
                and folder_id <> @new_folder_id


			END


			if @is_template = 0
			BEGIN
							
				-- Get the target platform id and engine id
				select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id from instance where gobject_id = @parentId
				
				update gobject set hosted_by_gobject_id = @myHostId,area_gobject_id = @myAreaId,hosting_tree_level = @my_hosting_tree_level  
				from gobject gobj inner join @AppObjInfo CI on gobj.gobject_id = CI.obj_id

				-- set the dirty flag for reference string for objects and all descendant
				update attribute_reference set is_valid = 1
				from  attribute_reference AR inner join @AppObjInfo on AR.gobject_id = obj_id
				where (reference_string like 'myPlatform.%' and mx_platform_id <>@mx_platform_id ) 
				           or (reference_string like 'myEngine.%' and (mx_platform_id <> @mx_platform_id or  mx_engine_id <> @mx_engine_id)  )
				           or reference_string like 'myHost.%' or reference_string like 'myContainer%'  or reference_string like 'myArea.%'

				insert into @retAffectedObjects select ar.gobject_id,0 from attribute_reference ar inner join
				@AppObjInfo on ar.resolved_gobject_id = obj_id

				set @bit = 1

				update attribute_reference set is_valid = 1
				from  attribute_reference AR inner join @AppObjInfo on AR.resolved_gobject_id = obj_id

				update package set reference_status_id = 2
				from package PK inner join attribute_reference AR on 
				PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
				inner join @AppObjInfo on AR.resolved_gobject_id = obj_id
				where is_valid = @bit 

				

-- new or changed

				update package set reference_status_id = 2
				from package PK inner join attribute_reference AR on 
				PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
				inner join @AppObjInfo on AR.gobject_id = obj_id
				where is_valid = @bit 
				-- Removing objects moving within its engine
				delete from @AppObjInfo where mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id
	
				-- Update instance table if this is instant's containment
				select @objCount = count(*) from @AppObjInfo 
				IF @objCount > 0 and @is_template = 0
				BEGIN				
					update instance set mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id, mx_object_id = MxIdList.mxId
					from instance Inst inner join @AppObjInfo Objs on Inst.gobject_id = Objs.obj_id
					inner join dbo.get_mx_object_ids(@mx_platform_id, @mx_engine_id, @objCount) MxIdList
					on Objs.idx = MxIdList.idx

				END
			END
		end -- Parent is AppObject, child can only be AppObject
	end 	-- SET CONTAINER

	-- Check if we have any object over the limit
	if exists ( select mx_engine_id from instance where mx_engine_id > 1000 and mx_platform_id = @mx_platform_id )
	begin
		rollback tran

		set @operationStatus = 0x80040550 -- E_ASSIGN_ENGINE_EXCEED_LIMIT
	end

	else if exists ( select mx_object_id from instance where mx_object_id > 30000 and mx_platform_id = @mx_platform_id
				and mx_engine_id = @mx_engine_id)
	begin
		rollback tran
		set @operationStatus = 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
	end

	else
	begin
	
		-- wipe out contained name of top level objects
		if ( @updatecontainname > 0 )
		begin
  		  update gobject set contained_name = '' 
		  from gobject g inner join #childList ch on ch.gid = g.gobject_id where g.contained_by_gobject_id = 0 and g.contained_name <> ''
		end

		commit tran
		set @operationStatus = 0 -- S_OK

		-------- L00084934 (start)
		-- Get the derived templates from the childList and add them to the @retAffectedObjects 
		-- since the derived templates need to be flushed out from the template-cache to take care of the 
		-- hirerchial name change.
		declare @effectedTemplates table(gobject_id int);

		WITH DerviedTemplateHierarchy (gobject_id, derived_from_gobject_id) AS
		(
		-- Base case
		SELECT
			gobject_id,
			0 as derived_from_gobject_id
		FROM gobject
		WHERE gobject_id in (select obj_id from @AppObjInfo)  and is_template = 1

		UNION ALL

		-- Recursive step
		(SELECT
			g.gobject_id,
			g.derived_from_gobject_id
		FROM gobject g
			INNER JOIN DerviedTemplateHierarchy th ON
			g.derived_from_gobject_id = th.gobject_id and g.is_template = 1)
		)

		insert into @retAffectedObjects
		select gobject_id,0 from DerviedTemplateHierarchy

		-------- L00084934 (end)

		delete from @retAffectedObjects where gobject_id = 0
		select distinct * from @retAffectedObjects order by is_toolset
	end
    exec internal_bind_visual_element_references
    exec internal_bind_relative_visual_elements_for_gobjects


	
end
go

