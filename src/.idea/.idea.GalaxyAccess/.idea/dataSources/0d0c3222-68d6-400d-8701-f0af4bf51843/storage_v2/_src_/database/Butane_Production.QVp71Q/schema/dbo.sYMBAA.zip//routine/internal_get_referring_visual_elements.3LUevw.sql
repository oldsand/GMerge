create proc dbo.internal_get_referring_visual_elements
    (
    -- visual element being referred to
    @referredToVisualElementId int,

    -- 1: Get visual elements which directly reference 
    --    the queried visual element.
    -- 0: Get all visual elements which directly/indirectly
    --    reference the queried visual element.
    -- n: Get all visual elements which directly/indirectly
    --    reference the queried visual element up to n level.
    @usageLevel int,
    -- 1: Return only the viewapp gobject_ids without the visual_element_ids.
    -- 0: Return visual_element_ids + list of referring viewapps.
    -- 2: Return visual_element_ids; do not return any information on viewapps.
    @viewAppsOnly int
    )
as begin


    if(@viewAppsOnly = 1) set @usageLevel = 0

    declare @level int
    set @level = 0


    declare @all table
    (
        visual_element_id int primary key
    )
    declare @next table
    (
        visual_element_id int primary key
    )
    declare @prev table
    (
        visual_element_id int primary key
    )

    declare @children_of_passed_in_visual_element table
    (
        visual_element_id int primary key
    )



    declare @referrer table
    (
        visual_element_id int primary key
    )

    declare @view_app table
    (
        gobject_id int,
        tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
    )

    -- put top visual element into list to get things started

	-- include the children of the passed-in visual_element
	-- for CRL00047520.
	insert into @children_of_passed_in_visual_element(visual_element_id)
	select distinct vev.visual_element_id 
	from visual_element_version vev
	where vev.inherited_from_visual_element_id = @referredToVisualElementId and
		vev.visual_element_id <> @referredToVisualElementId

    insert into @prev( visual_element_id) values( @referredToVisualElementId );

	insert @prev(visual_element_id)
	select visual_element_id 
	from @children_of_passed_in_visual_element
	
	insert into @all( visual_element_id) values( @referredToVisualElementId );	
	
	insert @all(visual_element_id)
	select visual_element_id 
	from @children_of_passed_in_visual_element


    

    -- add referring objects
    while( 1 = 1 )
    begin
        set @level = @level + 1

        -- add next level of references
        insert into @next
        select distinct ve.visual_element_id 
            from @prev existing 
            inner join visual_element_version bound_vev on
                 existing.visual_element_id = bound_vev.visual_element_id
            inner join visual_element_reference bver on 
                 (bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                  bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                  bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id)
            inner join visual_element_version ve on 
                bver.gobject_id = ve.gobject_id and 
                bver.package_id = ve.package_id and 
                bver.mx_primitive_id = ve.mx_primitive_id
        where ve.visual_element_id not in (
            select visual_element_id from @all)
        union
        select distinct ve.visual_element_id 
            from @prev existing 
            inner join visual_element_version bound_vev on
                 existing.visual_element_id = bound_vev.visual_element_id
            inner join visual_element_reference bver on 
                bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
            inner join visual_element_version ve on 
                bver.gobject_id = ve.gobject_id and 
                bver.package_id = ve.package_id and 
                bver.mx_primitive_id = ve.mx_primitive_id
        where ve.visual_element_id not in (
            select visual_element_id from @all)

        insert @all select * from @next

        if ( not exists ( select 1 from @next ) or @level = @usageLevel ) 
        begin
			break
		end

        delete from @prev
        insert @prev select * from @next
        delete from @next

    end
			--if (@viewAppsOnly <> 2)
			--begin
				-- add the view apps
				insert into @view_app(gobject_id,tag_name)
				select distinct gobject.gobject_id,gobject.tag_name
				from @all existing
				inner join visual_element_version bound_vev on
					 existing.visual_element_id = bound_vev.visual_element_id
				inner join visual_element_reference bver on
					bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
					bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
					bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
				inner join gobject on 
					bver.gobject_id = gobject.gobject_id
				inner join template_definition t
					on gobject.template_definition_id = t.template_definition_id
				where 
					bver.mx_primitive_id = 100 -- top level
					and (t.category_id = 17 or t.category_id = 26  ) -- view app or InTouchViewApp
				union
				select distinct gobject.gobject_id,gobject.tag_name
				from @all existing
				inner join visual_element_version bound_vev on
					 existing.visual_element_id = bound_vev.visual_element_id
				inner join visual_element_reference bver on
					bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
					bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
					bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
				inner join gobject on 
					bver.gobject_id = gobject.gobject_id
				inner join template_definition t
					on gobject.template_definition_id = t.template_definition_id
				where 
					bver.mx_primitive_id = 100 -- top level
					and (t.category_id = 17 or t.category_id = 26  ) -- view app or InTouchViewApp
				
				--TFS_358426
				--After the ITVA light changes as we are reffering to parent visual elements for ITVA instances,
				--The instances of ITVA are not getting displayed in ReferencedBy Column of Symbol delete dialog
				--Changes done to get the instances also incase Of ITVA.

				insert into @view_app(gobject_id,tag_name) select g.gobject_id,g.tag_name 
				from gobject g
				inner join @view_app v on
				g.derived_from_gobject_id = v.gobject_id 				
				inner join template_definition t on
				g.template_definition_id = t.template_definition_id
				where t.category_id=26 -- Only for InTouchViewApps
			--end

    -- remove self from list
    delete 
	from @all 
	where visual_element_id = @referredToVisualElementId

	delete a
	from @all a
	inner join @children_of_passed_in_visual_element c on
		a.visual_element_id = c.visual_element_id
		

    if @viewAppsOnly = 0
    begin
        -- return visual element ids
       select visual_element_id from @all
        -- return view app tagnames
       select tag_name from @view_app
    end
    else if @viewAppsOnly = 1
       select gobject_id from @view_app
    else if @viewAppsOnly = 2
    begin
       select 0, visual_element_id from @all
       select 1, gobject_id from @view_app
    end
end

go

