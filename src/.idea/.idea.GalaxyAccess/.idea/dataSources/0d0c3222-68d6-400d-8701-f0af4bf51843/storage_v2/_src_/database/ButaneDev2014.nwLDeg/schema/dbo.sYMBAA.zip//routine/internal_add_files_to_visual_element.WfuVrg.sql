create procedure dbo.internal_add_files_to_visual_element
    @gobject_id int,
    @package_id int,
    @mx_primitive_id int,
    @file_info_file_name nvarchar(256),
    @errorcode int output
as
begin
    set @errorcode = 0

    begin transaction

    -- Load the file names from external file
    create table #files_in(
        file_name nvarchar (256) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
        subfolder_name nvarchar (256) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
        vendor_name nvarchar (256) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
        registration_type int not null,
        is_needed_for_package bit not null default 0,
        is_needed_for_runtime bit not null default 0,   
        is_needed_for_editor  bit not null default 0,
    )
	-- table to mark dependent visual element thumbnails as dirty
	create table #modified_primitive 
		(
			gobject_id int, 
			package_id int,
			mx_primitive_id smallint
		)


    DECLARE @gSQL nvarchar(2000)
    SET @gSQL = 'BULK INSERT #files_in  FROM ''' + @file_info_file_name + ''' 
                WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
    EXEC sp_executesql @gSQL

    declare @file_name nvarchar (256)
    declare @subfolder_name nvarchar (256)
    declare @vendor_name nvarchar (256)
    declare @registration_type int
    declare @file_id int
    declare @is_needed_for_package bit
    declare @is_needed_for_runtime bit
    declare @is_needed_for_editor  bit

    while exists(select 1 from #files_in)
    begin
        select top 1  
                @file_id = ft.file_id,
                @file_name = fi.file_name,
                @vendor_name = fi.vendor_name,
                @subfolder_name	= fi.subfolder_name,
                @registration_type = fi.registration_type,
                @is_needed_for_package = fi.is_needed_for_package,
                @is_needed_for_runtime = fi.is_needed_for_runtime,
                @is_needed_for_editor = fi.is_needed_for_package
        from    #files_in fi left outer join file_table ft on 
                ft.file_name = fi.file_name 
            and ft.vendor_name = fi.vendor_name
            and ft.subfolder = fi.subfolder_name
        
        if (@file_id is null)
        begin
            set @errorcode = 1
            rollback
            return
        end
        else
        begin
            if not exists(
                select  1 
                from    primitive_instance_file_table_link
                where   gobject_id = @gobject_id 
                    and package_id = @package_id 
                    and mx_primitive_id = @mx_primitive_id 
                    and file_id = @file_id)
            begin
                insert into  primitive_instance_file_table_link(
                                gobject_id,
                                package_id,
                                mx_primitive_id, 
                                file_id,
                                is_needed_for_package,
                                is_needed_for_runtime,
                                is_needed_for_editor)
                values  (@gobject_id,
                        @package_id,
                        @mx_primitive_id,
                        @file_id,
                        @is_needed_for_package,
                        @is_needed_for_runtime,
                        @is_needed_for_editor)

                if @errorcode <> 0 
                begin
                    set @errorcode = 2
                    rollback
                    return
                end
           
			end
				-- Mark Client Control's thumbnail as dirty...
				insert into #modified_primitive
				(
					gobject_id ,
					package_id ,
					mx_primitive_id
				)
				select 
				ove.gobject_id,
				ove.package_id,
				ove.mx_primitive_id
				from owned_visual_element ove
				inner join visual_element ve on
					ove.visual_element_id = ve.visual_element_id and
					ve.visual_element_type = 'ClientControl'
				inner join primitive_instance pri on
					ove.gobject_id = pri.gobject_id and
					ove.package_id = pri.package_id and
					ove.mx_primitive_id = pri.mx_primitive_id
				inner join primitive_instance_file_table_link pifl on
					pri.gobject_id = pifl.gobject_id and
					pri.package_id = pifl.package_id and
					pri.parent_mx_primitive_id = pifl.mx_primitive_id and
					pifl.file_id = @file_id


        end

        delete  #files_in 
        where   file_name = @file_name 
            and vendor_name = @vendor_name
            and subfolder_name = @subfolder_name
    end    
	-- Mark Client Control's thumbnail as dirty...
	exec internal_mark_dependent_visual_element_thumbnails_as_dirty

    drop table #files_in      
	drop table #modified_primitive
                         
    commit transaction
    
end
go

