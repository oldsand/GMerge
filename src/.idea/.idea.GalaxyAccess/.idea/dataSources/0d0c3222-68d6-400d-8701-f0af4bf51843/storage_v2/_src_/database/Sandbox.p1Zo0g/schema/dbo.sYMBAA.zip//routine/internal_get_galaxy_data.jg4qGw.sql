
/**************************************************/
/*Object Name :  internal_get_galaxy_data									*/
/*Object Type :  Stored Proc.												*/
/*Purpose :    Procedure to get galaxy wide data for given data type. */
/*				user must have called internal_set_galaxy_data*/		
/*Used By :    PackageServerNet												*/
/**************************************************/
create  proc dbo.internal_get_galaxy_data
@data_type nvarchar(256)
as
begin

select data from galaxy_data  
where data_type = @data_type	

end


go

