-- loads data for a single template_definition
-- used by GObject
create proc dbo.internal_load_template_definition
    @template_definition_id int
as 
begin
    set nocount on

	-- load template_definition (1 row)
	select
		required_features,
		supported_features,
		category_id,
		category_clsid,
		runtime_clsid,
		codebase,
		codebase_minor_version,
        event_mask
	from 
		template_definition
	where
		template_definition.template_definition_id
			= @template_definition_id

    -- load primitive_definitions
    select
        primitive_definition_id,
		parent_mx_primitive_id,
        mx_primitive_id,
		primitive_name,
        execution_group,
        is_virtual,
        primitive_guid, 
        runtime_handler_clsid,
        package_handler_clsid,
        supports_dynamic_attributes,
		major_version
    from
        primitive_definition
    where template_definition_id = @template_definition_id

    -- load attribute_definitions
    select
        attribute_definition_id,
        attribute_definition.primitive_definition_id,
        attribute_name,
        mx_attribute_id,
        has_config_set_handler,
        mx_data_type,
        is_array,
        security_classification,
		security_classification_needs_deployed,
--        is_attribute_override,
        mx_attribute_category,
        is_frequently_accessed,
        is_locked,
		is_locked_needs_deployed,
        mx_value,
		mx_value_needs_deployed
    from
        primitive_definition
    inner join attribute_definition
        on attribute_definition.primitive_definition_id
            = primitive_definition.primitive_definition_id
    where
        primitive_definition.template_definition_id
            = @template_definition_id
end
go

