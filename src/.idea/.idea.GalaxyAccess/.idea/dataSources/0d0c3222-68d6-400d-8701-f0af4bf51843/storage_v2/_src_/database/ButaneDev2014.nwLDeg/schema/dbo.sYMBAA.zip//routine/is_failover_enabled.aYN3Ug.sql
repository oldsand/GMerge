
--***********************************************************************************************************************
--***      
--***      OBJECT NAME:  is_failover_enabled
--***      DESCRIPTION:  Function is used to find out if a gobject is failover enabled or not
--***      
--***      USAGE:      dbo.is_failover_enabled('AppEngine001') --(where 'AppEngine001' is the tag name)
--***                  Function is used by view: internal_proxyobj
--***      RESTRICTIONS: This function can be used only for Instance objects. NOT FOR TEMPLATE
--***      RETURNS :
--***      =========
--***      >1 - If object is failover enabled
--***      0  - If object is not failover enabled
--***      0  - If @tag_name is Template or object not exist in database
--***********************************************************************************************************************


CREATE  function dbo.is_failover_enabled( 
            @tag_name nvarchar(329)
            )
returns smallint
as
begin
            declare @is_failover_enabled smallint               
            declare @retval smallint

            select @is_failover_enabled = count(*) + 1
            from
            redundancy           
            where
            primary_gobject_id in (select gobject_id from gobject where
            tag_name = @tag_name)

            return @is_failover_enabled
end
go

