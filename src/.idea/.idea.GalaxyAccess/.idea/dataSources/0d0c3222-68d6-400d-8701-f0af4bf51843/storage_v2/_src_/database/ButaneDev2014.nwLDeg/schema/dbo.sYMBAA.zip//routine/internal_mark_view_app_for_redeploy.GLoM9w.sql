create proc dbo.internal_mark_view_app_for_redeploy
as

begin

set nocount on

if not exists ( 
    select gobject_id 
    from internal_all_view_app_view  )
    begin
      select 0 id where 1=0 -- force an empty result set
      return
    end
    
--Check if any deployed view app instance without pending status
if not exists ( 
select g.gobject_id from deployed_intouch_viewapp div
inner join gobject g on g.gobject_id = div.gobject_id 
where g.deployed_package_id = g.checked_in_package_id 
and g.deployed_package_id <> 0
)
begin
select 0 id where 1=0 -- force an empty result set
      return
end



begin tran

declare @work_has_been_done bit
set @work_has_been_done = 0

CREATE TABLE #ids_table ( 
	id int primary key,
	new_derived_from_package_id int default 0) 
-- new_derived_from_package_id is used for IntouchViewapp instances only
	
CREATE TABLE #template_ids_table (id int primary key)

--Collect all view app templates which are mark for "deploy all symbol" and 
-- atleast one instance has deployed status. start

CREATE TABLE #template_gids_of_deployed_viewapp (gobject_id int, package_id int, category_id smallint)
CREATE TABLE #template_gids_of_deployed_viewapp_with_allSymbols (gobject_id int primary key)

insert into #template_gids_of_deployed_viewapp_with_allSymbols
(
	gobject_id	
)	
 
select distinct g.derived_from_gobject_id
from gobject g
inner join deployed_intouch_viewapp depview
on depview.gobject_id = g.gobject_id
inner join intouchviewapptemplate_allsymbols itvtempall
on itvtempall.gobject_id =  g.derived_from_gobject_id
where g.deployed_package_id = g.checked_in_package_id 
and g.deployed_package_id <> 0

--select * from #template_gids_of_deployed_viewapp
--drop table #template_gids_of_deployed_viewapp
if exists (select gobject_id from #template_gids_of_deployed_viewapp_with_allSymbols)
begin

	--Check any symbol change since last deployed time
	declare @minlastdeploytime bigint
	
	select @minlastdeploytime = min(depview.timestamp_of_deploy) 
	from gobject g
	inner join deployed_intouch_viewapp depview
	on depview.gobject_id = g.gobject_id
	inner join intouchviewapptemplate_allsymbols itvtempall
	on itvtempall.gobject_id =  g.derived_from_gobject_id
	where g.deployed_package_id = g.checked_in_package_id 
	and g.deployed_package_id <> 0

	declare @latestsymbolchangetimefromgalaxy bigint
	select @latestsymbolchangetimefromgalaxy = MAX(primi.timestamp_of_last_change) 
	from primitive_instance primi
	inner join gobject g 
	on g.checked_in_package_id = primi.package_id
	where extension_type = N'SymbolExtension' or g.namespace_id = 3 --CRL00131713 - Added where clause after removing fix for CRL00120090
	
	--get latest delete ve time
	declare @latestsymboldeletedtimestamp bigint
	select @latestsymboldeletedtimestamp = max(timestamp_of_delete) from deleted_visual_element
	
	
	if( @latestsymbolchangetimefromgalaxy > @minlastdeploytime) or (@latestsymboldeletedtimestamp > @minlastdeploytime)
	begin
		insert into #template_gids_of_deployed_viewapp
		(
			gobject_id,
			package_id,
			category_id 
		)		
		select itvatempview.gobject_id, g.checked_in_package_id, itvatempview.category_id 
		from #template_gids_of_deployed_viewapp_with_allSymbols tempdepv
		inner join internal_all_view_app_view itvatempview
		on itvatempview.gobject_id = tempdepv.gobject_id
		inner join gobject g
		on g.gobject_id = tempdepv.gobject_id
		
	end	

end
--Collect all view app templates which are mark for "deploy all symbol" and 
-- atleast one instance has deployed status. end

	--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
	-- FOR POC start
	-- Update the gObject table with pending deploy status for the instances derived from the template
	if exists (select count(1) from #template_gids_of_deployed_viewapp)
	begin
		update g
		set g.deployment_pending_status = 1
		from 
		gobject g
		where g.derived_from_gobject_id IN 
		   (select temp.gobject_id from #template_gids_of_deployed_viewapp temp , visual_element_reference ref
		   where temp.gobject_id = ref.gobject_id)
	end
	--ITVAPP POC end

	-- now add templates which has direct or indirect ve reference updated or new
	insert into #template_gids_of_deployed_viewapp
	(
		gobject_id,
		package_id,
		category_id	
	)	 
	select distinct g.gobject_id,
				pri.package_id,
				category_id 
		from internal_all_view_app_view g
		inner join gobject go on
		go.gobject_id = g.gobject_id    
		inner join package p on
		p.package_id = go.checked_in_package_id and
		p.gobject_id = g.gobject_id      
		inner join primitive_instance pri on
				pri.gobject_id = g.gobject_id and
				pri.package_id = p.package_id and
				pri.max_child_timestamp > pri.timestamp_of_last_change
		where g.gobject_id not in(select gobject_id from #template_gids_of_deployed_viewapp_with_allSymbols)
	        


	declare @intouch_viewapp_instances table 
	(gobject_id int)
	declare @ids_for_config_version_update table
	(id int)

	declare viewapp_gobject_ids cursor fast_forward for

		select distinct gobject_id,
				package_id,
				category_id 
		from #template_gids_of_deployed_viewapp
	 

	open viewapp_gobject_ids
	while( 1=1 )
	 begin
		declare @viewapp_gobjectid int
		declare @intouch_viewapp_template_packageid int
		declare @category_id int
		fetch next from viewapp_gobject_ids into
		   @viewapp_gobjectid,
		   @intouch_viewapp_template_packageid,
		   @category_id

		if( @@fetch_status <> 0 ) break

		declare @packagecount int
		declare @package_type nvarchar
		set @package_type = 'N'
		select @package_type = package_type   
		from package 
		where gobject_id = @viewapp_gobjectid
		and package_type = 'D'
	
		select @packagecount = count(*)
		from package
		where gobject_id = @viewapp_gobjectid


		if(@category_id=17 and @packagecount = 1 and @package_type = 'D' )  -- if deployed than only mark haspending
		begin
		--create check in package with new deployed_config_verion
			--exec internal_create_checked_in_package @viewapp_gobjectid
			insert into #ids_table values(@viewapp_gobjectid,0)
		
		end
		else
		if(@category_id = 26)
		begin
		
			delete from @intouch_viewapp_instances

			insert into @intouch_viewapp_instances
			(
				gobject_id
			)	
			select g.gobject_id 
    		from gobject g        
			--Following 3 lines doesn't do any help
			--inner join package p 
			--on g.gobject_id = p.gobject_id
			--and g.checked_in_package_id = p.package_id
			where --g.deployed_package_id <> 0 and --commented for L00115894 
			g.derived_from_gobject_id = @viewapp_gobjectid
		


		
			if exists(select 1 from @intouch_viewapp_instances)
			begin

				/*
					create another package for the template based on the checked in
					package & update all deployed instances "derived_package_id" to 
					point to this new package.
				*/			
				insert into #template_ids_table values(@viewapp_gobjectid)


				exec internal_create_checked_in_package_for_intouch_viewapp_template
				set @work_has_been_done = 1

				insert into #ids_table 
				select child.gobject_id, 
					   parent.checked_in_package_id
				from @intouch_viewapp_instances child
				inner join gobject gchild
				on gchild.gobject_id = child.gobject_id
				inner join gobject parent
				on gchild.derived_from_gobject_id = parent.gobject_id
	--			L00084793
	--			this block has been moved to the end of the procedure
	--			-- update the proxy timestamps of the instances...
	--			 update pt
	--				set pt.gobject_id = pt.gobject_id
	--			 from proxy_timestamp pt
	--			 inner join @intouch_viewapp_instances ivi on
	--					pt.gobject_id = ivi.gobject_id 
	--
	--
	--			declare @max_proxy_timestamp bigint
	--			select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 
	--
	--			update galaxy
	--			set max_proxy_timestamp = @max_proxy_timestamp
	--    


			
			end--if exists(select 1 from #intouch_viewapp_instances)
		end--if(@category_id = 26)
	
		if ( @packagecount = 2 and @package_type = 'D' ) 
		begin

		--check if we have second package is checked out package than create checked in package also		
			select @package_type = package_type   
			from package 
			where gobject_id = @viewapp_gobjectid
			and package_type = 'O'	
			if ( @package_type = 'O') 
			begin
				--exec internal_create_checked_in_package @viewapp_gobjectid
				insert into #ids_table values(@viewapp_gobjectid,0)
			end
			else
			begin
				insert into @ids_for_config_version_update 
				values(@viewapp_gobjectid)
			end
		end
		else
		begin
				insert into @ids_for_config_version_update 
				values(@viewapp_gobjectid)
	
		end
		truncate table #template_ids_table
	 end
	close viewapp_gobject_ids
	deallocate viewapp_gobject_ids

	if (exists ( select 1 from @ids_for_config_version_update ) and @work_has_been_done = 1)
	begin
		update	gobject

    				set	gobject.configuration_version =  gobject.configuration_version + 1 
    				from	gobject gobject
    				inner join  @ids_for_config_version_update ids on
					gobject.gobject_id = ids.id
	end

	--ITVAPP POC: Here the SP will be called but VER entrites will be blocked for instances
		if exists(  select 1 from #ids_table ) 
		begin
			--Now create checked in package for multi
			exec internal_create_checked_in_package
		end
	

	--update all deployed IntouchViewApp instances "derived_from_package_id" to point to this new package.

	update package 
		set package.derived_from_package_id = idt.new_derived_from_package_id
		from package package
		inner join #ids_table idt
		on idt.id = package.gobject_id
		inner join gobject g
		on g.checked_in_package_id = package.package_id
		where idt.new_derived_from_package_id > 0





		if (@work_has_been_done = 1)
		begin

			-- update the proxy timestamps of the instances...
			 update pt
				set pt.gobject_id = pt.gobject_id
			 from proxy_timestamp pt
			 inner join gobject g
			 on g.gobject_id = pt.gobject_id
			 inner join #template_gids_of_deployed_viewapp gtemp
			 on gtemp.gobject_id = g.derived_from_gobject_id
		 
			 --inner join @intouch_viewapp_instances ivi on
			--		pt.gobject_id = ivi.gobject_id 


			declare @max_proxy_timestamp bigint
			select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

			update galaxy
			set max_proxy_timestamp = @max_proxy_timestamp
		end

drop table #ids_table
drop table #template_ids_table
drop table #template_gids_of_deployed_viewapp_with_allSymbols
drop table #template_gids_of_deployed_viewapp
commit tran

end
go

