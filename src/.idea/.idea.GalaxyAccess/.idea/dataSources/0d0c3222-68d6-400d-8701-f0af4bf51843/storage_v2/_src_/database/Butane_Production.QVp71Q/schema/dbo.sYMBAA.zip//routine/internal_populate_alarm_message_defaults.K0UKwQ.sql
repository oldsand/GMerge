CREATE PROCEDURE dbo.internal_populate_alarm_message_defaults
(
	@filepath_of_default_messages nvarchar(265)
	-- Format is UNICODE CSV one message per line: 
	-- [gObjectId],[PackageId],[mx_primitive_id],[default alarm message]
)
AS
BEGIN
	set nocount on

	CREATE TABLE #default_messages 
	(
		gobject_id int not null,
		package_id int not null,
		mx_primitive_id smallint not null,
		default_message nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS not null
	)

	alter table #default_messages
		add constraint pk_default_messages 
		primary key 
		( 
			gobject_id,
			package_id,
			mx_primitive_id
		) 

	DECLARE @SQL nvarchar(2000)
	
	SET @SQL = 'BULK INSERT #default_messages FROM ''' + @filepath_of_default_messages + ''' WITH(
			    FIELDTERMINATOR = '','',
				TABLOCK,
				DATAFILETYPE  = ''widechar''       
				)'
	EXEC (@SQL)

	CREATE TABLE #gobjects_being_populated 
	(
		gobject_id int not null primary key
	)

	insert into #gobjects_being_populated
	select distinct gobject_id from #default_messages

	--
	-- insert default messages to alarm_message_defaults if not present
	--
	insert into alarm_message_defaults (default_message)
	select distinct dms.default_message from #default_messages dms
	where not exists 
		(select 1 from alarm_message_defaults amd 
		 where amd.default_message = dms.default_message)

	--
	-- update alarm_message_timestamps to indicate that the alarms for that object is now up to date
	--
	-- First delete any existing ones
	delete from alarm_message_timestamps 
	from alarm_message_timestamps amts
	inner join #gobjects_being_populated gbp on gbp.gobject_id = amts.gobject_id

	-- Then add the updated rows
	insert into alarm_message_timestamps (gobject_id, timestamp_of_populate)
	select gbp.gobject_id, pt.timestamp_of_last_change from #gobjects_being_populated gbp
	inner join proxy_timestamp pt on pt.gobject_id = gbp.gobject_id
	
	-- ALTERNATE IMPLEMENTATON: 
	-- -- First update the existing ones
	-- update alarm_message_timestamps 
	-- set alarm_message_timestamps.timestamp_of_populate = pt.timestamp_of_last_change
	-- from alarm_message_timestamps amts
	-- inner join proxy_timestamp pt on pt.gobject_id = amts.gobject_id
	-- inner join #gobjects_being_populated gbp on gbp.gobject_id = pt.gobject_id
	-- 
	-- -- Then add the ones that don't exist
	-- insert into alarm_message_timestamps (gobject_id, timestamp_of_populate)
	-- select gbp.gobject_id, pt.timestamp_of_last_change from #gobjects_being_populated gbp
	-- inner join proxy_timestamp pt on pt.gobject_id = gbp.gobject_id
	-- where not exists 
	-- 	(select 1 from alarm_message_timestamps amts 
	-- 	 where amts.gobject_id = gbp.gobject_id)
		
	--
	-- delete all alarm_messages for the objects we are populating
	--
	delete from alarm_messages 
	from alarm_messages ams
	inner join #gobjects_being_populated gbp on gbp.gobject_id = ams.gobject_id

	--
	-- insert records into alarm_messages and point to matching phrase_id.
	--
	insert into alarm_messages (gobject_id, package_id,	mx_primitive_id, phrase_id)
	select dms.gobject_id, dms.package_id,	dms.mx_primitive_id, amds.phrase_id from #default_messages dms
	inner join alarm_message_defaults amds on amds.default_message = dms.default_message

	drop table #default_messages 
	drop table #gobjects_being_populated

	
END
go

