/*
This procedure will get called when ExportAll function is called.
This procedure returns all derived template details.

usage:

exec internal_getBaseTemplateDetails 

*/

create procedure dbo.internal_get_base_template_details
 AS
begin
	set nocount on
        select  
			g.tag_name,
			g.gobject_id,
			rtrim(td.base_template_location),
			td.codebase_minor_version,
			td.codebase,
			g.configuration_guid,
			toolset_name = dbo.get_folder_path(g.gobject_id,1)                
		from gobject g 
		inner join template_definition td on
				g.gobject_id = td.base_gobject_id 
		where g.is_hidden = 0

    set nocount off
end
go

