
create proc dbo.internal_get_old_attribute_handle
	@tag_name nvarchar(1000),
	@primitiveId smallint,    
	@attributeId smallint,    
    @oldPrimitiveId int out,
	@oldAttributeId int out
as
begin	
	declare @pId smallint
	declare @aId smallint
	set @pId = 0
	set @aId = 0

	--Fix for CR L00138248. Ported changes from L00137902. Check for existence of at least one row in attributes_translation_table.
	if exists(select 1 from attributes_translation_table) 
	begin
		select @pId = att.old_primitive_id,@aId = att.old_attribute_id
		from attributes_translation_table att
		inner join gobject g
		on att.gobject_id = g.gobject_id
		and g.tag_name = @tag_name
		and att.new_primitive_id = @primitiveId
		and att.new_attribute_id = @attributeId
	end
	
	if(@pId > 0)
	begin
		set @oldPrimitiveId = @pId
		set @oldAttributeId = @aId		
	end
	else
	begin
		set @oldPrimitiveId = @primitiveId
		set @oldAttributeId = @attributeId
	end
	
end
go

