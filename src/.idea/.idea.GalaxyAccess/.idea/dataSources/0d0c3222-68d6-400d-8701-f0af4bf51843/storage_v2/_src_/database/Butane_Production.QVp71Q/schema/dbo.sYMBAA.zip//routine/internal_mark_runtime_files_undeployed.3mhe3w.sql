/*
This stored procedure gets called by internal_multi_save_for_setundeploystatus just after
undeployment of objects occurs.

After a set of gobjects gets undeployed from a single platform, this proc will mark 
the runtime files as undeployed. This will also update the references to deployed
files such as the file_pending_update.

Gobjects being marked as undeployed should be passed using the temporary
table #gobjects_undeployed, all gobjects passed must be hosted by the
platform passed in @mx_platform_id and @node_name.

usage:
populate #gobjects_undeployed

exec internal_mark_runtime_files_undeployed
     1, 'Nodename'

*/
CREATE  proc dbo.internal_mark_runtime_files_undeployed
    @mx_platform_id int, --mx_platform_id to which objects are getting deployed
    @node_name nvarchar(256) --node_name to which these objects are getting deployed
as
set nocount on
begin

begin tran

	declare @platformcount int
	select @platformcount = count(*) from platform where 
		platform.platform_gobject_id in (select GObjectId from #gobjects_undeployed)

	if(@platformcount >0)
		begin 
			---1 Update file_pending_update table..remove the entries for all the files from file_pending_update which will get removed on undeploy
			delete from file_pending_update where 
			((node_name = @node_name) and 
				(	file_id in (select distinct file_id from 
					deployed_file where 
					deployed_file.is_runtime_deployed = 1 and 
					deployed_file.is_package_deployed = 0 and
					deployed_file.is_editor_deployed = 0
				)
			)) 
			---2 Update deployed_file table
			update deployed_file
			set is_runtime_deployed = 0			
			where deployed_file.is_runtime_deployed = 1 and	
					  deployed_file.node_name = @node_name 
		end
	else
		begin
			create table #deploy_file_ids( file_id int )
			exec internal_get_runtime_files_for_packages_needed_on_platform @mx_platform_id, @node_name

			--1 Get list of files in #deploy_file_ids that needs to be undeployed/removed
			-- (based on deployed_file table).
			declare @undeploy_file_ids table ( file_id int )
			insert into @undeploy_file_ids
				select deployed_file.file_id
				from deployed_file
				inner join #deploy_file_ids ufi
				on ufi.file_id = deployed_file.file_id and
				   deployed_file.is_package_deployed = 0 and
				   deployed_file.is_editor_deployed = 0 and
				   deployed_file.node_name = @node_name

			---2 Update file_pending_update table..remove the entries for all the files from file_pending_update which will get removed on undeploy
			delete from file_pending_update where 
			(
				(node_name = @node_name) and 
				(
					file_id in 
						(select file_id from @undeploy_file_ids)
				)
			) 
			
							
			--3 Mark the all the files which are getting removed..	
			-- For each file in #deploy_file_ids that's not in @undeploy_file_ids,
			-- update corresponding deployed_file table's is_runtime_deployed
			-- column record to 0. These files will not be undeployed.
			--
			update deployed_file
			set is_runtime_deployed = 0
			from deployed_file, #deploy_file_ids dfi
			where 
				deployed_file.file_id = dfi.file_id and
				deployed_file.is_runtime_deployed = 1 and
				deployed_file.node_name = @node_name 		


			drop table #deploy_file_ids
		end
commit tran
end


go

