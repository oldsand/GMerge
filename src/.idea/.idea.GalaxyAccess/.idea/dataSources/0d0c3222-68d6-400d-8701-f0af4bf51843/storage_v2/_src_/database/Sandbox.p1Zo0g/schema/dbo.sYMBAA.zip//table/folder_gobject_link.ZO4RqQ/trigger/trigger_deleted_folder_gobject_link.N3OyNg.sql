
create trigger trigger_deleted_folder_gobject_link
on folder_gobject_link
for delete
as
begin tran

    begin
        update folder 
        set has_objects = 0
        from folder f
        inner join deleted d on
            f.folder_id = d.folder_id and
            f.folder_id not in  
        (select fg.folder_id from folder_gobject_link fg 
         inner join deleted d on 
            fg.folder_type = d.folder_type and fg.folder_id = d.folder_id  )
    end
       
commit

go

