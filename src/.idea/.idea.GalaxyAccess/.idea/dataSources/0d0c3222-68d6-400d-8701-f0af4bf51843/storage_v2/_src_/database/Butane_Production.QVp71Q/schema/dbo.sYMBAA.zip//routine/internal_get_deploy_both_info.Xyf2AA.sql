/**************************************************/
/*Object Name :  internal_get_deploy_both_info	  */
/*Object Type :  Stored Proc.			  */
/*Purpose	  :  Proc. to get list of Primary and Backup Engines Object Info */
/*               for deploying/undeploying a list of primary engines for deployBoth option*/
/*				 of objects in a defined order of */
/*				-Engine */
/*Used By	  :  CDI() */
/**************************************************/

create  procedure dbo.internal_get_deploy_both_info
-- send list of object ids to sql as XMLDoc
@FileNameOfIds nvarchar(400)
AS    
SET NOCOUNT ON
begin

    CREATE TABLE #gobject_ids (gobject_id int)    
    -- call the stored procedure 'internal_construct_table_from_file'
    EXEC internal_construct_table_from_file @FileNameOfIds, '#gobject_ids'
    -- step 1 - All input engines = primary engines 	
    declare @inputPE integer
    declare @actualPE integer
    select  @inputPE = count(gobject_id) from #gobject_ids	
    select  @actualPE = count(gobject.gobject_id) from #gobject_ids ids
    left join gobject  on gobject.gobject_id = ids.gobject_id 	
    where (gobject.hosting_tree_level = 2) and (gobject.namespace_id = 1) 

    if(@inputPE <> @actualPE ) return 1  	        

    --step 2 Get Primary Engine order deployment...
    --create this table where sorted list of gobjects will be stored
    declare @deploymentOrder_gobject_ids table 
    (
		gobject_id int,
		tag_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS
	)
    insert into @deploymentOrder_gobject_ids
        select
        gobject.gobject_id,gobject.tag_name
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
            left join instance
        on instance.gobject_id = gobject.gobject_id
        where gobject.hosting_tree_level = 2
        order by 
            gobject.hosting_tree_level asc, 
            instance.mx_platform_id asc,
    	    instance.mx_engine_id asc,
            gobject.tag_name asc

    ----step 3 All the PE's  = Failover enabled-- we r skipping right now..
    --declare @actualBE integer
    --select  distinct @actualBE = count(gobject.gobject_id) from gobject 
    --where (gobject.tag_name in (select tag_name from @deploymentOrder_gobject_ids)
    --and (gobject.namespace_id = 2) )
	
    --if(@actualBE <> @actualPE) return 2 -- 

    -- step 4 Get the deploy info 	
    --Get the ObjectInfo of all the above sorted Objects
    select
        gobject.gobject_id,
        gobject.tag_name,
        gobject.hosting_tree_level,
        template_definition.category_clsid category_clsid,
        gobject.hosted_by_gobject_id hosted_by_gobject_id,
        case gobject.deployed_package_id when 0 then 0 else 1 end as is_deployed,
        case host.deployed_package_id when 0 then 0 else 1 end as host_deployed,
        case when ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version) then 1 else 0 end as has_pending_updates,
        gobject.checked_in_package_id checked_in_package_id,
        gobject.checked_out_package_id checked_out_package_id,
        instance.mx_platform_id,
        instance.mx_engine_id,
        instance.mx_object_id,
        template_definition.category_id,
        gobject.deployed_package_id,
        gobject.last_deployed_package_id,
        package.status_id,
    	gobject.software_upgrade_needed
    from gobject  
    left join @deploymentOrder_gobject_ids ids 
        on gobject.tag_name = ids.tag_name
    left join gobject host
        on gobject.hosted_by_gobject_id = host.gobject_id
    left join template_definition
        on template_definition.template_definition_id = gobject.template_definition_id
    left join instance
        on instance.gobject_id = gobject.gobject_id
    left join package
        on package.gobject_id = gobject.gobject_id and package.package_id = gobject.checked_in_package_id
    left outer join package checked_in_package on -- To Do: change to an inner join - Anand
        gobject.checked_in_package_id = checked_in_package.package_id
    left outer join package deployed_package on 
        gobject.deployed_package_id = deployed_package.package_id

    where gobject.tag_name = ids.tag_name
    order by ids.tag_name asc,
	gobject.namespace_id asc
    
    
    ---drop the table 
    DROP TABLE #gobject_ids

    return 0 	
end

go

