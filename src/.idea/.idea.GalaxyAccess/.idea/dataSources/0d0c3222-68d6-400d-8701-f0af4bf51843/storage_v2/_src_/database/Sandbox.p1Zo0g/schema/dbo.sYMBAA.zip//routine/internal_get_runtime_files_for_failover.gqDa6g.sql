---This stored procedure will return all the files required by the input packages
CREATE  PROC dbo.internal_get_runtime_files_for_failover
    @FileNameOfIds nvarchar(400)  
as
set nocount on
begin
begin tran
	create table #file_ids( file_id int )
	create table #package_ids( package_id int )
	-- populate #package_ids	
	exec internal_get_package_ids_from_xml @FileNameOfIds
	exec internal_get_runtime_files_for_packages 

	select ft.file_id,file_name, vendor_name, registration_type , subfolder from file_table ft
	inner join #file_ids dfi
	on ft.file_id = dfi.file_id

	drop table #package_ids
	drop table #file_ids

commit tran
set nocount off
end
go

