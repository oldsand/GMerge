create proc dbo.internal_get_folder_children
	@parent_folder_id int,
	@folder_type smallint,
	@depth smallint
as
begin
	set nocount on	

    if(@depth = 0) return

    declare @folders table(folderid int,myparent int,nLevel smallint)
    insert  into  @folders(folderid,myparent,nLevel)
	select folder_id,parent_folder_id,1	from folder 
	where parent_folder_id = @parent_folder_id 
	and folder_type = @folder_type		


    declare @objCount integer
	declare @nLevel integer
	select @objCount = count(*) from @folders

	IF @objCount > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN	
            if (@nLevel  = @depth) break           
            insert into @folders
			select f.folder_id, f.parent_folder_id, @nLevel + 1
			from folder f inner join @folders fs on f.parent_folder_id = fs.folderid
			where nLevel = @nLevel

			if @@rowcount = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END

    select  
        f.folder_id,
		f.parent_folder_id, 
		f.depth,  
		f.folder_name,
		f.has_objects, 
		f.has_folders
	from folder f inner join @folders fs
     on f.folder_id = fs.folderid

	set nocount off
end
go

