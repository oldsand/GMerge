/*
** Procedure [internal_ab_prime_dio_for_autobind]
** This is typically called when a DIO instance is checked in, and accounts for changes--additions and subtractions--to its list of scan-groups.
** It is also called from internal_ab_set_linkage
** Returns: 0: Success; 1: Failure (dio_id refers to an invalid oo unassignable DIO)
** NOTE: This sproc needs to be invoked from the gobject_checkin sproc, when the gobject being checked-in refers to a DIO.
*/
CREATE PROCEDURE dbo.internal_ab_prime_dio_for_autobind
    @dio_id int 
	, @dio_rule_id int = NULL
as
begin
    set nocount on
    declare @result int
    declare @abd_ruleid int
	declare @abd_dio_id int

    set @result = -1

    /*
    ** Verify the following:
    ** 1. @dio_id represents an instance of a DIO
    ** 2. Whether or not we need to create an entry in autobind_rules for the default naming rule for @dio_id's object category
    ** 3. Whether or not we need to create an entry in autobind_device for @dio_id
    */
    SELECT @abd_dio_id = abdev.dio_id, @abd_ruleid = abdev.overridden_naming_rule_id
    FROM gobject g 
    INNER JOIN template_definition td
    ON  td.template_definition_id = g.template_definition_id
    INNER JOIN lookup_category lcat
    ON  lcat.category_id = td.category_id
    AND lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
    LEFT OUTER JOIN autobind_device abdev
    ON  abdev.dio_id = g.gobject_id
    WHERE 
        g.is_template = 0
    AND g.gobject_id = @dio_id

    if @@ROWCOUNT != 0   -- @@ROWWOUNT would be 0 if @dio_id doesn't exist, or belongs to a category that doesn't support I/O auto-binding.
    begin
        /*
        ** @dio_id is a DIO. First, check if there is an entry for it in autobind_device (@abd_ruleid will not be NULL in this case).
        */
        if (@abd_dio_id IS NULL)
			INSERT INTO autobind_device (dio_id, overridden_naming_rule_id) VALUES (@dio_id, @dio_rule_id)
		else if (@abd_ruleid IS NULL AND @dio_rule_id IS NOT NULL)
			UPDATE autobind_device SET overridden_naming_rule_id = @dio_rule_id WHERE dio_id = @dio_id

        -- Finally, add the DIO's scan-groups to autobind_device_topics if newly added
       if (@abd_dio_id IS NULL)
       begin
        execute @result = internal_ab_refresh_dio_topics @dio_id
    end
       else
           set @result = 0
    end

    return @result
end
go

