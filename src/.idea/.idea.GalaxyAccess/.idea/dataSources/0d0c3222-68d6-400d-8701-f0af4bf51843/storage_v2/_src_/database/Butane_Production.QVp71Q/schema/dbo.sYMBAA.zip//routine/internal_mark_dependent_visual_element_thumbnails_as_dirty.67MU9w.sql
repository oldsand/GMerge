
/*
	Procedure will use #modified_primitive as its input table:
    create table #modified_primitive 
            (gobject_id int, 
            package_id int,
            mx_primitive_id smallint)
	
	This table will contain a list of modified primitives.
	Proc will mark all dependent
*/
create procedure dbo.internal_mark_dependent_visual_element_thumbnails_as_dirty
as
begin 

   create  table #input_table
   (
	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint
	)

   create table  #output_table 
    (
		visual_element_id int ,
        gobject_id int,
	    package_id int,
	    mx_primitive_id smallint
    )

	-- insert all modified visual elements as well as
	-- visual elements that inherit from them...
	insert into #input_table
	select
		vev.visual_element_id,
		vev.gobject_id,
		vev.package_id,
		vev.mx_primitive_id
	from #modified_primitive mp
	inner join visual_element_version vev on
		mp.gobject_id = vev.inherited_from_gobject_id and
		mp.package_id = vev.inherited_from_package_id and
		mp.mx_primitive_id = vev.inherited_from_mx_primitive_id


	if(@@rowcount) > 0
	begin
		exec internal_get_recursively_referring_visual_elements
	
	update ove
	set is_thumbnail_dirty = 1
	from #output_table ot
	inner join owned_visual_element  ove on
		ot.gobject_id = ove.gobject_id and
		ot.package_id = ove.package_id and
		ot.mx_primitive_id = ove.mx_primitive_id
		
	end

	drop table #input_table
	drop table #output_table


end

go

