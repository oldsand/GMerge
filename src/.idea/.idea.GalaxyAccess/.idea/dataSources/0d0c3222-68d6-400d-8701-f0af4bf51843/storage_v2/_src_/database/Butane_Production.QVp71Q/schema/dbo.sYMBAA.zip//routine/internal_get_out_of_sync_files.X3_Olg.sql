-- To get the files which are either not available in deployed file table
-- or its version/time stamp doesnot match with files contained in deployed file table
create procedure dbo.internal_get_out_of_sync_files
(
   @xmlDoc  XML,
   @Nodename nvarchar(256)
)
as
begin
    
SET NOCOUNT ON

-- Create client control exclusion list
	CREATE TABLE  #cc_file_exclusion_table ( 
		file_id				int
	); 

	-- Populate it per the stored procedure. Once populated, this file will contain a list
	-- of file-ids representing client-control objects. These are not undeployed from 
	-- the client node by GOCS.
	insert into		#cc_file_exclusion_table
	select			pf.file_id 
	from			primitive_instance_file_table_link pf 
	inner join		client_control_class_link cc 
			on		pf.gobject_id = cc.gobject_id
			
if (convert(varchar(max), @xmlDoc, null) <>  '')
begin

	DECLARE @handle INT

	EXEC sp_xml_preparedocument @handle OUTPUT, @xmlDoc
	
	CREATE TABLE  #results_table ( file_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS,
	 file_version nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, file_modified_time nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS,registration_type int)

	insert into  #results_table  
	select * FROM OPENXML (@handle, '/SyncInfo/File_Info', 9) WITH   
		(
		file_name nvarchar(256),   
		vendor_name nvarchar(256),   
		file_version nvarchar(50),
		file_modified_time nvarchar(50),
		registration_type int
		)
    EXEC sp_xml_removedocument @handle

	--L00110927 START:Need to delete file information related to "ClusterPrimitive2.dll" from table #results_table
	--This table is populated from the xml passed to this SP. 
	--This resulted into..file "ClusterPrimitive2.dll" is not undeployed from the client node by GOCS.
	delete from #results_table
	where  file_name like 'ClusterPrimitive%.dll' and vendor_name = 'ArchestrA'
	--L00110927 END
	
	
	-- Create the matching deployed file exclusion list
	CREATE TABLE  #current_deployed_exclusion_table ( 
		file_id				int
	); 

	-- Populate this temporary table contains a list of file-ids representative of object components in the
	-- deployed_file table that are present and accounted for in the customer's SIX. These 
	-- files are _not_ to be uninstalled from the client node under ordinary circumstances.
	insert into		#current_deployed_exclusion_table
	select distinct df.file_id 
	from			deployed_file df
	inner join		file_table ft		
			on		ft.file_id = df.file_id
	inner join		#results_table v	
			on		v.file_name = ft.file_name
		  and		v.file_modified_time = df.file_modified_time
		  and		v.file_version = df.file_version

	delete df
	from			deployed_file df
	left outer join #current_deployed_exclusion_table dx
			on		dx.file_id = df.file_id
	left outer join #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id
	where			node_name = @Nodename
			and		( df.is_editor_deployed = 1
				 or	  df.is_package_deployed = 1 
				 or	  df.need_to_delete = 1 )
			and		df.is_runtime_deployed <>1
			and		dx.file_id is null
			and		cx.file_id is null

	update	df 
	set		is_editor_deployed = 0
				 ,	is_package_deployed = 0
	from deployed_file df
	left outer join #current_deployed_exclusion_table dx
			on		dx.file_id = df.file_id
	left outer join #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id	
			
	where			is_runtime_deployed = 1
			and		dx.file_id is null
			and		cx.file_id is null			
			

	select  v.file_name, v.vendor_name, v.file_version, 
	v.file_modified_time,v.registration_type from #results_table v where v.file_name not in (select file_name from file_table where file_name = v.file_name)

	union all

	select  v.file_name, v.vendor_name, v.file_version, 
	v.file_modified_time,v.registration_type from #results_table v 
	inner join file_table ft on v.file_name = ft.file_name
	where file_id not in(select file_id from deployed_file where upper(node_name) = upper(@Nodename))

	union all

	select rt.file_name,rt.vendor_name, rt.file_version, rt.file_modified_time, rt.registration_type
	from #results_table rt left join file_table ft on rt.file_name = ft.file_name
	left join deployed_file df on ft.file_id = df.file_id and df.node_name = @Nodename 
	where rt.file_version <> df.file_version or rt.file_modified_time <> df.file_modified_time
	DROP TABLE #current_deployed_exclusion_table
end
else
begin
	-- if xmldoc is empty delete everything
	delete df
	from			deployed_file df
	left outer join #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id
	where			node_name = @Nodename
			and		( df.is_editor_deployed = 1
				 or	  df.is_package_deployed = 1 
				 or	  df.need_to_delete = 1 )
			and		df.is_runtime_deployed <>1
			and		cx.file_id is null

	update	df 
	set		is_editor_deployed = 0
		,	is_package_deployed = 0
	from deployed_file df
	left outer join #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id				
	where			is_runtime_deployed = 1
			and		cx.file_id is null	
	
end

declare @filesdeployedtoclient int
	select @filesdeployedtoclient = count(*) from deployed_file df 
									left outer join #cc_file_exclusion_table cx 
									on	cx.file_id = df.file_id	
	where upper(df.node_name) = upper(@Nodename) 
	and ((df.is_editor_deployed = 1 or df.is_package_deployed = 1 or df.need_to_delete = 1))
	and cx.file_id is null

update client_info
	set deployed_files_count = @filesdeployedtoclient
	where upper(client_name) = upper(@Nodename)
DROP TABLE #cc_file_exclusion_table
end
go

