/*
This procedure will verify that input gobject_id = platform or not
usage:
declare @P1 int
exec internal_IsPlatform
     gobject_id = 23, @P1
*/
CREATE PROCEDURE dbo.internal_is_platform
@gobject_id  nvarchar(400),
@isPlatform int  OUTPUT
 AS
begin
SET NOCOUNT ON
	set @isPlatform = 0

	SELECT @isPlatform = COUNT(gobject_id) FROM instance 
	where mx_engine_id = 1 and mx_object_id = 1
    and gobject_id = @gobject_id

SET NOCOUNT OFF
end



go

