-- Procedure to return required files for deployment for based on 
-- visual element ids. 
-- 
-- !!!!!!!!!!!!!
-- !! WARNING !!
-- !!!!!!!!!!!!!
-- 
-- 1. This procedure is called by different procedures to retrieve
--    file dependency for visual element data, including 
--    a. Loading visual element object.
--    b. Embed visual elements.
--    c. Deploy visual elements.
--
-- 2. When this procedure is called, it is assumed that there are 
--    two temporary tables created:
--    #visual_element_ids_for_required_file: Visual element ids to be queried
--    #visual_element_required_file: Required files 
--
--    #visual_element_ids_for_required_file is created by a script similar to
--       create  table #visual_element_ids_for_required_file(
--                      visual_element_id int)
--
--    #visual_element_required_file is created by a script similar to
--       create table #visual_element_required_file(
--                      group_id  nvarchar(64),   -- Currently not being used
--                      file_name nvarchar(256),
--                      vendor_name nvarchar(256),
--                      registration_type int,
--                      software_upgrade_needed int,
--                      file_id int,
--                      is_needed_for_package bit,
--                      is_needed_for_editor bit,
--                      is_needed_for_runtime bit)
-- 
-- 3. It is the caller's reponsibility to clear up these two tables.
--
-- 4. @codemodule = 2  eEditorAndPackageCodeModules
--                = 4  ePackageCodeModules
--                = 8  eRuntimeCodeModules
--

create proc dbo.internal_get_required_files_by_visual_element_ids(
        @node_name nvarchar(256),
        @codemodule int)
as
BEGIN 

    begin transaction

    truncate table #visual_element_required_file
    
    if (@codemodule = 2) -- eEditorAndPackageCodeModules
    begin
        insert into #visual_element_required_file
                (group_id,
        	    file_name,
        	    vendor_name,
				subfolder_name,
        	    registration_type,
                software_upgrade_needed,
                file_id,
                is_needed_for_package,
                is_needed_for_editor,
                is_needed_for_runtime)
        (
            select  distinct
                    N'',
        	        f.file_name,
        	        f.vendor_name,
					f.subfolder,
        	        f.registration_type,
                    0,
                    f.file_id,
                    piftl.is_needed_for_package,
                    piftl.is_needed_for_editor,
                    0
            from    file_table f
            inner join primitive_instance_file_table_link piftl on
                    piftl.file_id = f.file_id
            inner join primitive_instance pri on
                    piftl.gobject_id = pri.gobject_id and
                    piftl.package_id = pri.package_id and
                    piftl.mx_primitive_id = pri.parent_mx_primitive_id 
            inner join visual_element_version vev on
                    pri.gobject_id = vev.gobject_id and
                    pri.package_id = vev.package_id and
                    pri.mx_primitive_id = vev.mx_primitive_id 
            inner join #visual_element_ids_for_required_file vei on    
                    vei.visual_element_id = vev.visual_element_id
            where   (piftl.is_needed_for_editor = 1 or piftl.is_needed_for_package = 1)
        )    
    end
    else if (@codemodule = 4) -- ePackageCodeModules
    begin
        insert into #visual_element_required_file
                (group_id,
        	    file_name,
        	    vendor_name,
				subfolder_name,
        	    registration_type,
                software_upgrade_needed,
                file_id,
                is_needed_for_package,
                is_needed_for_editor,
                is_needed_for_runtime)
        (
            select  distinct
                    N'',
        	        f.file_name,
        	        f.vendor_name,
					f.subfolder,
        	        f.registration_type,
                    0,
                    f.file_id,
                    piftl.is_needed_for_package,
                    0,
                    0
            from    file_table f
            inner join primitive_instance_file_table_link piftl on
                    piftl.file_id = f.file_id
            inner join primitive_instance pri on
                    piftl.gobject_id = pri.gobject_id and
                    piftl.package_id = pri.package_id and
                    piftl.mx_primitive_id = pri.parent_mx_primitive_id 
            inner join visual_element_version vev on
                    pri.gobject_id = vev.gobject_id and
                    pri.package_id = vev.package_id and
                    pri.mx_primitive_id = vev.mx_primitive_id 
            inner join #visual_element_ids_for_required_file vei on    
                    vei.visual_element_id = vev.visual_element_id
            where   (piftl.is_needed_for_package = 1) 
        )    
    end
    else if (@codemodule = 8) -- eRuntimeCodeModules
    begin
        insert into #visual_element_required_file
                (group_id,
        	    file_name,
        	    vendor_name,
				subfolder_name,
        	    registration_type,
                software_upgrade_needed,
                file_id,
                is_needed_for_package,
                is_needed_for_editor,
                is_needed_for_runtime)
        (
            select  distinct
                    N'',
        	        f.file_name,
        	        f.vendor_name,
					f.subfolder,
        	        f.registration_type,
                    0,
                    f.file_id,
                    0,
                    0,
                    piftl.is_needed_for_runtime
            from    file_table f
            inner join primitive_instance_file_table_link piftl on
                    piftl.file_id = f.file_id
            inner join primitive_instance pri on
                    piftl.gobject_id = pri.gobject_id and
                    piftl.package_id = pri.package_id and
                    piftl.mx_primitive_id = pri.parent_mx_primitive_id 
            inner join visual_element_version vev on
                    pri.gobject_id = vev.gobject_id and
                    pri.package_id = vev.package_id and
                    pri.mx_primitive_id = vev.mx_primitive_id 
            inner join #visual_element_ids_for_required_file vei on    
                    vei.visual_element_id = vev.visual_element_id
            where   (piftl.is_needed_for_runtime = 1) 
        )
    end

    /*****************************************
    *  set the software_upgrade_needed bit..
    ******************************************/
    if (@node_name is not null)
    begin
        update  #visual_element_required_file
        set     software_upgrade_needed = 1
        where   file_id in 
            (
                select  file_id 
                from    deployed_file d
	            where   d.node_name =UPPER(@node_name)
            )
    end

    commit transaction
END
go

