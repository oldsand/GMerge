create proc dbo.internal_get_browser_files
    @location nvarchar(256)
as
begin
    SET NOCOUNT ON

    declare @browser_required_file table(file_id int)

    insert  @browser_required_file
        select  distinct file_id 
        from    file_primitive_definition_link fl
        where   fl.is_needed_for_browser = 1


    delete  @browser_required_file
    from    @browser_required_file br
    inner join deployed_file df
        on  br.file_id = df.file_id
    where   df.node_name = @location
        and df.is_browser_deployed = 1
		and df.file_id not in (select file_id from file_pending_update)


	insert into deployed_file
	(
		file_id,
		node_name,
		need_to_delete,
		is_package_deployed,
		is_editor_deployed,
		is_runtime_deployed,
        is_browser_deployed
	)
    select  f.file_id,
            UPPER(@location),
            0,
            0,
            0,
            0,
            0
    from    file_table f
    inner join @browser_required_file br
        on  f.file_id = br.file_id

    select  f.file_id,
            f.file_name,
            f.vendor_name,
            f.registration_type
    from    file_table f
    inner join @browser_required_file br
        on  f.file_id = br.file_id
end
go

