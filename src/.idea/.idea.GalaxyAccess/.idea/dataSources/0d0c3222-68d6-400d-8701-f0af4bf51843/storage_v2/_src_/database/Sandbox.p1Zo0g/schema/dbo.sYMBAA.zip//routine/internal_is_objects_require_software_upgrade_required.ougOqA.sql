---This stored procedure will return the object count of software_upgrade_needed 
-- for the given input object ids

create procedure dbo.internal_is_objects_require_software_upgrade_required
-- send list of object ids to sql as XMLDoc
@FileNameOfIds nvarchar(400),
@SUR as int out
AS
SET NOCOUNT ON
begin
	CREATE TABLE #gobject_ids (gobject_id int)    
    -- call the stored procedure 'internal_ConstructTableFromFile'
    
    EXEC internal_construct_table_from_file @FileNameOfIds, '#gobject_ids'
    --create this table where sorted list of gobjects will be stored
    
    set @SUR = 0
         
	select @SUR = count('*') from gobject g inner join 	
	#gobject_ids gi on g.gobject_id = gi.gobject_id
	where g.software_upgrade_needed = 1
	
	DROP TABLE #gobject_ids	
	
end



go

