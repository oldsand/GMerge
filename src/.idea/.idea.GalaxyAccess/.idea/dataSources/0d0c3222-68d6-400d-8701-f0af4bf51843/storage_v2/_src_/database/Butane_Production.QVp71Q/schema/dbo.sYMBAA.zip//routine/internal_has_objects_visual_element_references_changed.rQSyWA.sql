/*
	Compares the checked in and checked out package of an object
	and return true if the visual element references are different
*/
create procedure dbo.internal_has_objects_visual_element_references_changed
@gobject_id int,
@change_has_occurred bit output
as
begin
	set @change_has_occurred = 0
	declare @checked_out_package_id int
	declare @checked_in_package_id int 
	select 
		@checked_out_package_id = checked_out_package_id,
		@checked_in_package_id = checked_in_package_id
	from gobject
	where gobject_id = @gobject_id

	if(@checked_out_package_id = 0)
	begin
		set @change_has_occurred = 0
		return
	end


	-- return false if the reference counts do not match...
	declare @checked_in_ref_count int
	declare @checked_out_ref_count int
	
	select @checked_in_ref_count = count(gobject_id)
	from visual_element_reference 
	where gobject_id = @gobject_id and
		package_id = @checked_in_package_id

	select @checked_out_ref_count = count(gobject_id)
	from visual_element_reference 
	where gobject_id = @gobject_id and
		package_id = @checked_out_package_id
	
	if(@checked_in_ref_count <> @checked_out_ref_count)
	begin
		set @change_has_occurred = 1
		return
	end

	-- the count matches...now compare each row...
	if exists(
		select '1'
		from visual_element_reference checked_in_visual_element_reference
		inner join visual_element_reference checked_out_visual_element_reference on
			checked_in_visual_element_reference.gobject_id = checked_out_visual_element_reference.gobject_id and
			checked_in_visual_element_reference.package_id = @checked_in_package_id and
			checked_in_visual_element_reference.mx_primitive_id = checked_out_visual_element_reference.mx_primitive_id and
			checked_in_visual_element_reference.visual_element_reference_index = checked_out_visual_element_reference.visual_element_reference_index
		where 
			checked_in_visual_element_reference.gobject_id = @gobject_id and
			checked_in_visual_element_reference.package_id = @checked_in_package_id and
		(
		  checked_in_visual_element_reference.is_relative_reference <> checked_out_visual_element_reference.is_relative_reference 
		  or isnull(checked_in_visual_element_reference.checked_in_bound_visual_element_gobject_id,0) <> isnull(checked_out_visual_element_reference.checked_in_bound_visual_element_gobject_id,0)
		  or isnull(checked_in_visual_element_reference.checked_in_bound_visual_element_package_id,0) <> isnull(checked_out_visual_element_reference.checked_in_bound_visual_element_package_id,0)
		  or isnull(checked_in_visual_element_reference.checked_in_bound_visual_element_mx_primitive_id,0) <> isnull(checked_out_visual_element_reference.checked_in_bound_visual_element_mx_primitive_id,0)
		  or isnull(checked_in_visual_element_reference.checked_out_bound_visual_element_gobject_id,0) <> isnull(checked_out_visual_element_reference.checked_out_bound_visual_element_gobject_id,0)
		  or isnull(checked_in_visual_element_reference.checked_out_bound_visual_element_package_id,0) <> isnull(checked_out_visual_element_reference.checked_out_bound_visual_element_package_id,0)
		  or isnull(checked_in_visual_element_reference.checked_out_bound_visual_element_mx_primitive_id,0) <> isnull(checked_out_visual_element_reference.checked_out_bound_visual_element_mx_primitive_id,0)
		  or isnull(checked_in_visual_element_reference.checked_in_unbound_visual_element_name,'') <> isnull(checked_out_visual_element_reference.checked_in_unbound_visual_element_name,'')
		  or isnull(checked_in_visual_element_reference.checked_in_unbound_visual_element_type,'') <> isnull(checked_out_visual_element_reference.checked_in_unbound_visual_element_type,'')
		  or isnull(checked_in_visual_element_reference.checked_in_unbound_tag_name,'') <> isnull(checked_out_visual_element_reference.checked_in_unbound_tag_name,'')
		  or isnull(checked_in_visual_element_reference.checked_in_unbound_primitive_name,'') <> isnull(checked_out_visual_element_reference.checked_in_unbound_primitive_name,'')
		  or isnull(checked_in_visual_element_reference.checked_in_unbound_relative_object_name,'') <> isnull(checked_out_visual_element_reference.checked_in_unbound_relative_object_name,'')
		  or isnull(checked_in_visual_element_reference.checked_in_unbound_visual_element_id,0) <> isnull(checked_out_visual_element_reference.checked_in_unbound_visual_element_id,0)
		  or isnull(checked_in_visual_element_reference.checked_out_unbound_visual_element_name,'') <> isnull(checked_out_visual_element_reference.checked_out_unbound_visual_element_name,'')
		  or isnull(checked_in_visual_element_reference.checked_out_unbound_visual_element_type,'') <> isnull(checked_out_visual_element_reference.checked_out_unbound_visual_element_type,'')
		  or isnull(checked_in_visual_element_reference.checked_out_unbound_tag_name,'') <> isnull(checked_out_visual_element_reference.checked_out_unbound_tag_name,'')
		  or isnull(checked_in_visual_element_reference.checked_out_unbound_primitive_name,'') <> isnull(checked_out_visual_element_reference.checked_out_unbound_primitive_name,'')
		  or isnull(checked_in_visual_element_reference.checked_out_unbound_relative_object_name,'') <> isnull(checked_out_visual_element_reference.checked_out_unbound_relative_object_name,'')
		  or isnull(checked_in_visual_element_reference.checked_out_unbound_visual_element_id,0) <> isnull(checked_out_visual_element_reference.checked_out_unbound_visual_element_id,0)
		  or isnull(checked_in_visual_element_reference.checked_out_visual_element_package_id,0) <> isnull(checked_out_visual_element_reference.checked_out_visual_element_package_id,0)
		  or isnull(checked_in_visual_element_reference.checked_out_visual_element_gobject_id,0) <> isnull(checked_out_visual_element_reference.checked_out_visual_element_gobject_id,0))
	)
	begin
		set @change_has_occurred = 1
		return
	end

    
end

go

