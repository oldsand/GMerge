--Description :: This storec_proc filters the list and output the list whose any of the child object is checled out
create proc dbo.internal_filter_template_list_for_checked_out_objects
    -- send list of object ids to sql as XMLDoc
    @FileNameOfIds nvarchar (265)
AS
SET NOCOUNT ON
begin

    --reasoncode 
    --1 : Object is not exist
    --2 : Object or it some of the children is already Checked_out

    declare @gobjects_info table (
        gobject_id  int primary key,
        reasoncode  int default 0,
        object_is_valid bit default 0,
        entity_change_type smallint default 1,
        graphic_changed bit default 0,
        automation_changed bit default 0,
        automation_other_than_lockedscript_and_uda_changed bit default 0,
        uda_changed bit default 0,
        lockedscript_changed bit default 0,
        event_mask int default 0
    )


    SET QUOTED_IDENTIFIER OFF

    CREATE TABLE  #results_table (
        gobject_id int primary key
    )

    DECLARE @SQL nvarchar(2000)

    SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds +
                 ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')'    

    EXEC sp_executesql @SQL

    declare     @gobject_id int
    declare     @object_is_valid bit 
    declare     @entity_change_type smallint      
    declare     @graphic_changed bit 
    declare     @automation_changed bit 
    declare     @automation_other_than_lockedscript_and_uda_changed bit 
    declare     @uda_changed bit 
    declare     @lockedscript_changed bit 
    declare     @objectcount int
    declare     @reasoncode int
        
    set @gobject_id = 0 
    set @objectcount = 0 
    
    -- select each element    
    select @objectcount = count(*) from #results_table
    while(@objectcount > 0)
    BEGIN
        -- 
        select  TOP 1 @gobject_id = gobject_id from #results_table
        -- then check  for checked out object
        EXEC internal_has_checked_out_object_in_derivation_tree 
            @gobject_id, @reasoncode output
        -- then update     
       
        exec internal_get_object_change_type 
                @gobject_id, 
                @object_is_valid output, 
                @entity_change_type output, 
                @graphic_changed output,
                @automation_changed output,
                @automation_other_than_lockedscript_and_uda_changed output,
                @uda_changed output,
                @lockedscript_changed output
                        
        begin                               
            insert into @gobjects_info(
                        gobject_id, 
                        reasoncode, 
                        object_is_valid, 
                        entity_change_type, 
                        graphic_changed, 
                        automation_changed,
                        automation_other_than_lockedscript_and_uda_changed,
                        uda_changed,
                        lockedscript_changed)
            values  (@gobject_id, 
                    @reasoncode, 
                    @object_is_valid,
                    @entity_change_type, 
                    @graphic_changed, 
                    @automation_changed,
                    @automation_other_than_lockedscript_and_uda_changed,
                    @uda_changed,
                    @lockedscript_changed)
        end
                
        -- remove @gobject_ids table 
        delete from #results_table where gobject_id = @gobject_id    
        select @objectcount = count(*) from #results_table
    END 
    ----------------------------------------------------------------        
    drop table #results_table
    ----------------------------------------------------------------    
    --Now return all
    
    update  gi
    set     gi.event_mask = td.event_mask
    from    
            @gobjects_info gi
    inner join 
            gobject g
    on      
            gi.gobject_id = g.gobject_id
    inner join
            template_definition td
    on      g.template_definition_id = td.template_definition_id
    
    select  gobject_id,
            reasoncode ,
            object_is_valid,
            entity_change_type, 
            graphic_changed, 
            automation_changed,
            automation_other_than_lockedscript_and_uda_changed,
            uda_changed,
            lockedscript_changed,
            event_mask
    from    @gobjects_info

end
go

