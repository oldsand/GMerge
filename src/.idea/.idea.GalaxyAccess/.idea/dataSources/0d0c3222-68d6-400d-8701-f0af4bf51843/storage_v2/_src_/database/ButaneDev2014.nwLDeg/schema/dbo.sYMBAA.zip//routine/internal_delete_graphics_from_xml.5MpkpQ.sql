/*
** Procedure [internal_delete_graphics_from_xml]
** This procedure is delete the graphics in the passed XML file.
*/
create proc dbo.internal_delete_graphics_from_xml 
( 
    @XMLpath      nvarchar(265) 
)
AS 
begin
	set nocount on
	
	if (len(@XMLpath) = 0)
		return
	 
    declare @xmldoc xml 
    declare @gSQL nvarchar(2000)  
    declare @paramDef nvarchar(1000)
     
    SET @gSQL = N'SELECT @xmlOut = CONVERT (XML, BulkColumn) 
    FROM OPENROWSET (BULK ''' + @XMLpath + N''', SINGLE_BLOB) AS x'         
	
	SET @paramDef = N'@xmlOut XML OUTPUT'
    
    EXEC sp_executesql  
         @gSQL
       , @paramDef
       , @xmlOut = @xmldoc OUTPUT
 	
	 
	DECLARE @handle INT
	EXEC sp_xml_preparedocument @handle OUTPUT, @xmldoc 
	
	declare @SymbolNames table ( tag_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS )

	--Here we have two options one is OPENXML and X-Query
	--As performance of OPENXML is good comapred to X-Query, we will go with OPENXML with edge table 
	--START OPENXML
	insert into  @SymbolNames
	select text FROM OPENXML (@handle, '/symbols/symbol') where nodetype = 3
		
    EXEC sp_xml_removedocument @handle
    --END OPENXML   
	
	--START X-Query
	--insert into  @SymbolNames
	--select symbols.symbol.value('.', 'varchar(256)') as tag_name
	--	from @xmldoc.nodes('/symbols/symbol') symbols(symbol)
	--END X-Query
	
	--Get the gobject IDS from the symbol names
	if exists (select 1 from @SymbolNames)
	begin
		
		declare @SymbolIds table(id int)

		insert into @SymbolIds 
		select g.gobject_id from  gobject g
		inner join @SymbolNames snames on
		snames.tag_name = g.tag_name and 
		g.namespace_id = 3 --only graphics
		
			
		if exists (select 1 from @SymbolIds)
		begin
			while exists(select 1 from @SymbolIds)
				begin
					declare @gobject_id int
					set @gobject_id = (select top 1 id from @SymbolIds)
					exec internal_delete_fsobject_association @gobject_id, -1, ''
					delete from @SymbolIds where id = @gobject_id
				end
		end
	end
end
go

