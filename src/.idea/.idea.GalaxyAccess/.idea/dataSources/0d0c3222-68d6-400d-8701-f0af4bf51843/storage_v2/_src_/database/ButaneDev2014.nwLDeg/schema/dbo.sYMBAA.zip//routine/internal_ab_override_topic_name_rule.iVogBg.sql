/*
** Procedure [internal_ab_override_topic_name_rule]
** This sproc asserts a naming-rule at the scan-group scope.
*/
CREATE PROCEDURE dbo.internal_ab_override_topic_name_rule
    @dio_id                 int
    , @sg_mx_primitive_id   smallint
    , @apply_naming_rule    int = NULL
    , @force_override       bit = 0
as
begin
    set nocount on

    /*
    ** Don't verify that sg_mx_primitive_id is valid. Assert a default topic-level naming rule if the topic exists, 
    ** and doesn't already have one (unless @force_override == 1).
    */
    UPDATE autobind_device_topic
    SET overridden_naming_rule_id = @apply_naming_rule
    WHERE
        dio_id = @dio_id
    AND sg_mx_primitive_id = @sg_mx_primitive_id
    AND (@force_override = 1 OR overridden_naming_rule_id IS NULL)

    if @@ROWCOUNT = 0
        RETURN 1    -- Return 1 to indicate that a default topic-level naming rule was not asserted.


  --  EXECUTE internal_ab_refresh_attribute_aliases 0, @dio_id, @sg_mx_primitive_id

    RETURN 0
end
go

