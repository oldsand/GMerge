create procedure dbo.internal_bind_visual_element_by_id_or_name
@gobject_id int,
@package_id int,
@mx_primitive_id smallint,
@visual_element_id int,
@visual_element_type nvarchar(32),
@visual_element_name nvarchar(362),
@bind_by_id bit
as

if exists(select 1 from galaxy where is_migration_in_progress = 1)
    return


begin tran--1

    -- create a temp table to store all affected object for polling purposes...
    declare @all_affected_objects table(gobject_id int)


    declare @affected_checked_in_unbound_elements table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        checked_in_bound_visual_element_gobject_id int not null,
        checked_in_bound_visual_element_package_id int not null,
        checked_in_bound_visual_element_mx_primitive_id smallint not null,
        primary key
        (
            gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )
    
    declare @affected_checked_out_unbound_elements table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        checked_out_bound_visual_element_gobject_id int not null,
        checked_out_bound_visual_element_package_id int not null,
        checked_out_bound_visual_element_mx_primitive_id smallint  not null
        primary key
        (
            gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )
    
    --if (@tag_name is null) -- try to bind VisualElement based on scenario #1 (add_visual_element)
    --begin

        declare @checked_in_gobject_id int
        declare @checked_in_package_id int
        declare @checked_in_mx_primitive_id int
set @checked_in_gobject_id = @gobject_id
set @checked_in_package_id = @package_id
set @checked_in_mx_primitive_id = @mx_primitive_id

--		if(@bind_by_id = 1)
--			begin        
--			select 
--				@checked_in_gobject_id  = vev.gobject_id,
--				@checked_in_package_id = vev.package_id,
--				@checked_in_mx_primitive_id  = vev.mx_primitive_id 
--			from visual_element_version vev
--			inner join gobject g
--				on vev.gobject_id = g.gobject_id
--				and vev.package_id = g.checked_in_package_id
--			where vev.visual_element_id = @visual_element_id
--		end
--		else
--		begin -- bind by name
--			if exists(select 1 from gobject where gobject_id = @gobject_id and checked_out_gobject_id > 0)
--			begin
--			select 
--				@checked_in_gobject_id  = v.gobject_id,
--				@checked_in_package_id = v.package_id,
--				@checked_in_mx_primitive_id  = v.mx_primitive_id 
--			from internal_visual_element_description_view v
--			inner join gobject g
--				on v.gobject_id = g.gobject_id
--				and v.package_id = g.checked_in_package_id
--			where v.visual_element_name = @visual_element_name
--			end
--			else--object is checked out
--			begin
--			select 
--				@checked_in_gobject_id  = v.gobject_id,
--				@checked_in_package_id = v.package_id,
--				@checked_in_mx_primitive_id  = v.mx_primitive_id 
--			from internal_visual_element_description_view v
--			inner join gobject g
--				on v.gobject_id = g.gobject_id
--				and v.package_id = g.checked_out_package_id
--			where v.visual_element_name = @visual_element_name
--			end
--			
--		end

		-- first by ID
        if( @checked_in_package_id is not null )
        begin--2		
			if(@bind_by_id = 1)
			begin
				-- first try to bind any checked-in VEs....
				insert into @affected_checked_in_unbound_elements
				(gobject_id,
				package_id,
				mx_primitive_id ,
				visual_element_reference_index ,
				checked_in_bound_visual_element_gobject_id ,
				checked_in_bound_visual_element_package_id ,
				checked_in_bound_visual_element_mx_primitive_id )    
				select 
					u.gobject_id,
					u.package_id,
					u.mx_primitive_id,
					u.visual_element_reference_index,
					@checked_in_gobject_id,
					@checked_in_package_id,
					@checked_in_mx_primitive_id
				from visual_element_reference u 
				where 
					(u.checked_in_unbound_visual_element_type = @visual_element_type and
					 u.checked_in_unbound_visual_element_id = @visual_element_id)

				if exists( select 1 from @affected_checked_in_unbound_elements )
				begin--3
					--update the checked_in_bound ver columns....
					update  ver
					set 
						-- bound columns...
						ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
						ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
						ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
						--ver.visual_element_bind_status = 1,-- now a calculated column..
						-- unbound columns...
						ver.checked_in_unbound_visual_element_name = null,
						ver.checked_in_unbound_visual_element_type = null,
						ver.checked_in_unbound_tag_name = null,
						ver.checked_in_unbound_primitive_name = null,
						ver.checked_in_unbound_relative_object_name = null,
						ver.checked_in_unbound_visual_element_id = null
					output inserted.gobject_id
					into @all_affected_objects
					from visual_element_reference ver 
					inner join @affected_checked_in_unbound_elements wt on
						wt.gobject_id = ver.gobject_id and
						wt.package_id = ver.package_id and
						wt.mx_primitive_id = ver.mx_primitive_id and
						wt.visual_element_reference_index = ver.visual_element_reference_index
				end--3
			
			delete from @affected_checked_in_unbound_elements
		end
		else
		begin
-- now, by Name
			if( @checked_in_package_id is not null )
			begin--4

				-- first try to bind any checked-in VEs....
				insert into @affected_checked_in_unbound_elements
				(gobject_id,
				package_id,
				mx_primitive_id ,
				visual_element_reference_index ,
				checked_in_bound_visual_element_gobject_id ,
				checked_in_bound_visual_element_package_id ,
				checked_in_bound_visual_element_mx_primitive_id )    
				select 
					u.gobject_id,
					u.package_id,
					u.mx_primitive_id,
					u.visual_element_reference_index,
					@checked_in_gobject_id,
					@checked_in_package_id,
					@checked_in_mx_primitive_id
				from visual_element_reference u 
				where 
					(u.checked_in_unbound_visual_element_type = @visual_element_type and
					 u.checked_in_unbound_visual_element_name = @visual_element_name)
	                 

				if exists( select 1 from @affected_checked_in_unbound_elements )
				begin--5
					--update the checked_in_bound ver columns....
					update  ver
					set 
						-- bound columns...
						ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
						ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
						ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
						--ver.visual_element_bind_status = 1,-- now a calculated column..
						-- unbound columns...
						ver.checked_in_unbound_visual_element_name = null,
						ver.checked_in_unbound_visual_element_type = null,
						ver.checked_in_unbound_tag_name = null,
						ver.checked_in_unbound_primitive_name = null,
						ver.checked_in_unbound_relative_object_name = null,
						ver.checked_in_unbound_visual_element_id = null
					output inserted.gobject_id
					into @all_affected_objects
					from visual_element_reference ver 
					inner join @affected_checked_in_unbound_elements wt on
						wt.gobject_id = ver.gobject_id and
						wt.package_id = ver.package_id and
						wt.mx_primitive_id = ver.mx_primitive_id and
						wt.visual_element_reference_index = ver.visual_element_reference_index
				end--5

		end
-- End checked in by Name





        end

        -- bind checked out elements
        declare @checked_out_gobject_id int
        declare @checked_out_package_id int
        declare @checked_out_mx_primitive_id int

        select 
            @checked_out_gobject_id  = vev.gobject_id,
            @checked_out_package_id = vev.package_id,
            @checked_out_mx_primitive_id  = vev.mx_primitive_id 
        from visual_element_version vev
        inner join gobject g
            on vev.gobject_id = g.gobject_id
            and vev.package_id = g.checked_out_package_id
        where vev.visual_element_id = @visual_element_id

-- by id first...
        if( @checked_out_package_id is not null )
        begin--6
			if(@bind_by_id = 1)
			begin
				-- next, try to bind any checked-out VEs....
				insert into @affected_checked_out_unbound_elements
				(gobject_id,
				package_id,
				mx_primitive_id ,
				visual_element_reference_index ,
				checked_out_bound_visual_element_gobject_id ,
				checked_out_bound_visual_element_package_id ,
				checked_out_bound_visual_element_mx_primitive_id )    
				select 
					ver.gobject_id,
					ver.package_id,
					ver.mx_primitive_id,
					ver.visual_element_reference_index,
					@checked_out_gobject_id,
					@checked_out_package_id,
					@checked_out_mx_primitive_id
				from visual_element_reference ver
				where 
					(ver.checked_out_unbound_visual_element_type = @visual_element_type and
					 ver.checked_out_unbound_visual_element_id = @visual_element_id)


				if exists ( select 1 from @affected_checked_out_unbound_elements )
				begin--7
					--update the checked_out_bound ver columns....
					update  ver
					set 
						-- bound columns...
						ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
						ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
						ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
						--ver.visual_element_bind_status = 1, -- now a calculated column..
						-- unbound columns...
						ver.checked_out_unbound_visual_element_name = null,
						ver.checked_out_unbound_visual_element_type = null,
						ver.checked_out_unbound_tag_name = null,
						ver.checked_out_unbound_primitive_name = null,
						ver.checked_out_unbound_relative_object_name = null,
						ver.checked_out_unbound_visual_element_id = null
					output inserted.gobject_id
					into @all_affected_objects
					from visual_element_reference ver 
					inner join @affected_checked_out_unbound_elements wt on
						wt.gobject_id = ver.gobject_id and
						wt.package_id = ver.package_id and
						wt.mx_primitive_id = ver.mx_primitive_id and
						wt.visual_element_reference_index = ver.visual_element_reference_index
				end--7
			end--6

			delete from @affected_checked_out_unbound_elements
	end
	else
	begin
	-- now checked out by name...
		   if( @checked_out_package_id is not null )
			begin--6

				-- next, try to bind any checked-out VEs....
				insert into @affected_checked_out_unbound_elements
				(gobject_id,
				package_id,
				mx_primitive_id ,
				visual_element_reference_index ,
				checked_out_bound_visual_element_gobject_id ,
				checked_out_bound_visual_element_package_id ,
				checked_out_bound_visual_element_mx_primitive_id )    
				select 
					ver.gobject_id,
					ver.package_id,
					ver.mx_primitive_id,
					ver.visual_element_reference_index,
					@checked_out_gobject_id,
					@checked_out_package_id,
					@checked_out_mx_primitive_id
				from visual_element_reference ver
				where 
					(ver.checked_out_unbound_visual_element_type = @visual_element_type and
					 ver.checked_out_unbound_visual_element_name = @visual_element_name)

				if exists ( select 1 from @affected_checked_out_unbound_elements )
				begin--7
					--update the checked_out_bound ver columns....
					update  ver
					set 
						-- bound columns...
						ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
						ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
						ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
						--ver.visual_element_bind_status = 1, -- now a calculated column..
						-- unbound columns...
						ver.checked_out_unbound_visual_element_name = null,
						ver.checked_out_unbound_visual_element_type = null,
						ver.checked_out_unbound_tag_name = null,
						ver.checked_out_unbound_primitive_name = null,
						ver.checked_out_unbound_relative_object_name = null,
						ver.checked_out_unbound_visual_element_id = null
					output inserted.gobject_id
					into @all_affected_objects
					from visual_element_reference ver 
					inner join @affected_checked_out_unbound_elements wt on
						wt.gobject_id = ver.gobject_id and
						wt.package_id = ver.package_id and
						wt.mx_primitive_id = ver.mx_primitive_id and
						wt.visual_element_reference_index = ver.visual_element_reference_index
				end--7
			end--6
	        
		end--4
	end	
-- iteration 1 (bind by ID...)




	if exists(select '1' from @all_affected_objects)
	begin
			declare @distinct_affected_objects table(gobject_id int primary key)

			insert into @distinct_affected_objects
			select distinct gobject_id
			from @all_affected_objects

			--For ITVAPP POC changes START
			--Here the VER table is used lot of placess hence instead of 
			--handling ITVAPP instance in each query, handled here; only instances only
			insert into @distinct_affected_objects 
			select g.gobject_id from gobject g
			inner join @distinct_affected_objects tmpl
			on tmpl.gobject_id = g.derived_from_gobject_id
			inner join template_definition td on
			td.template_definition_id = g.template_definition_id
			and td.category_id = 26
			--END

			update pt
			set pt.gobject_id = pt.gobject_id
			from proxy_timestamp pt
			inner join @distinct_affected_objects dao on
				pt.gobject_id = dao.gobject_id 

			update gfi
			set gfi.gobject_id = gfi.gobject_id
			from gobject_filter_info_timestamp gfi
			inner join @distinct_affected_objects dao on
				gfi.gobject_id = dao.gobject_id 


			declare @max_proxy_timestamp bigint
			select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

			update galaxy
			set max_proxy_timestamp = @max_proxy_timestamp
	end
    


commit--1
go

