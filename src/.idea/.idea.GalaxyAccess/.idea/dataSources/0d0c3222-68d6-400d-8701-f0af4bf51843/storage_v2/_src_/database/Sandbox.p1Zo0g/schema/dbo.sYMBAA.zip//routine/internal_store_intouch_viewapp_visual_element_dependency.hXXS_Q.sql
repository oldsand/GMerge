create procedure dbo.internal_store_intouch_viewapp_visual_element_dependency
@gobject_id int
as
begin tran

declare @viewAppName nvarchar(329)
select @viewAppName = tag_name
from gobject 
where gobject_id = @gobject_id 

delete 
from deployed_intouch_viewapp_visual_element_dependency
where gobject_id = @gobject_id 
	
create table #temp
(
    visual_element_id int,
    visual_element_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    visual_element_reference_index int
)
	--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
	--ITVAPP START START
	insert into #temp
	exec internal_get_visual_elements_for_view_app_deploy @viewAppName, 0
	
	--ITVAPP START END

insert into deployed_intouch_viewapp_visual_element_dependency

select 
	@gobject_id, 
	v.visual_element_name
from #temp t
inner join internal_visual_element_description_view v (noexpand)
	on t.visual_element_id = v.visual_element_id
 

drop table #temp

commit

go

