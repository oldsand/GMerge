CREATE   proc dbo.internal_set_host_association(
	@childIdList nvarchar(255),
	@parentId int,
	@assocType smallint,
	@updatecontainname int,
	@operationStatus int out)
As
begin
	
	if @parentId = 0 return	-- UNASSIGNMENT, should call internal_unset_association

	begin tran
	set nocount on

	-- ASSIGNMENT
	
	declare @retAffectedObjects table(gobject_id int, is_toolset bit)
	declare @mx_platform_id smallint, @mx_engine_id smallint, @mx_object_id	smallint
	declare @childId int, @child_platform_id smallint, @child_engine_id smallint
	declare @parentCategory int, @childCategory int, @my_container int 
	declare @objCount int, @nLevel smallint
	declare @is_template bit   

	declare @parentHostDepth int
    	declare @newAppobjects int
	declare @MaxObjectsinInstanceTable int

	select @parentCategory = category_id, @is_template = is_template
	from gobject inner join template_definition
	on gobject.template_definition_id = template_definition.template_definition_id
	where gobject_id = @parentId

	create table  #childList (gid int primary key)
	DECLARE @gSQL nvarchar(2000)
	SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
				WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
	EXEC (@gSQL)

	exec internal_filter_deployed_objects_from_input_list
	
	declare @maxid int
	declare @ii int


	
	if @assocType = 1 	-- SET HOST : Parent can be PLATFORM / ENGINE / DEVICE
	begin	
		
		declare @ObjectInfo table(idx int identity(1,1), obj_id int, cat_id smallint, mx_platform_id smallint, mx_engine_id smallint, has_children bit)

		insert into @ObjectInfo select H.gid, T.category_id, mx_platform_id, mx_engine_id,
		case when exists ( select gobject_id from gobject where hosted_by_gobject_id = H.gid ) then 1 else 0 end
		from #childList H inner join gobject G on H.gid = G.gobject_id
		inner join template_definition T on T.template_definition_id = G.template_definition_id
		inner join instance I on G.gobject_id = I.gobject_id
		
		
		--declare thse variables for setting hosting_tree_level for DIDevice objects
		declare @DeviceObjectInfo table( gobject_id int)    
		declare @hosting_tree_level int
		declare @DeviceInfo table(tmpid int identity(1,1) primary key clustered,obj_id int, nLevel smallint, catid smallint default 0) --  primary key is added for CR  L00117071
		set		@hosting_tree_level = 0  


		IF @parentCategory = 4          -- Parent = ViewEngine
		BEGIN
			-- Remove any non-assignable objects
			delete from @ObjectInfo where cat_id not in (17,26)
			
			-- Update gobject table for any child who is an Area or Device
			update gobject set hosted_by_gobject_id = @parentId, hosting_tree_level = 4
			from gobject inner join @ObjectInfo on gobject_id = obj_id
		
			-- set mx ids
			select @mx_platform_id = mx_platform_id from instance where gobject_id = @parentId
			select @mx_engine_id = mx_engine_id from instance where gobject_id = @parentId
				
			select @objCount = count(*) from @ObjectInfo
			
			update instance set mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id, mx_object_id = MxIdList.mxId
			from instance Inst inner join @ObjectInfo Objs on Inst.gobject_id = Objs.obj_id
			inner join dbo.get_mx_object_ids(@mx_platform_id, @mx_engine_id, @objCount) MxIdList
			on Objs.idx = MxIdList.idx
			
			set @operationStatus = 0 -- S_OK
			set @parentCategory	= 255


		END
            
		IF ((@parentCategory = 23) or  (@parentCategory = 25))  -- Parent = Galaxy Node or Custom Object
		BEGIN
			-- Remove any non-custom objects
			delete from @ObjectInfo where cat_id <> 25
			
			if @parentCategory = 23
			begin
				set @parentHostDepth = 3 -- so that @parentHostDepth + 1 will be 4 for code reuse
			end
			   
			if @parentCategory = 25
			begin
				select @parentHostDepth = hosting_tree_level from gobject where gobject_id = @parentId			
			end			
	
    			insert into @DeviceInfo select H.obj_id, 4, T.category_id
    			from @ObjectInfo H inner join gobject G on H.obj_id = G.gobject_id
				inner join template_definition T on T.template_definition_id = G.template_definition_id
                	where T.category_id = 23 or T.category_id = 25

			-- Update gobject table for any child who is an Area or Device
			update gobject set hosted_by_gobject_id = @parentId, hosting_tree_level = (@parentHostDepth + 1)
			from gobject inner join @ObjectInfo on gobject_id = obj_id

			set @nLevel = 4					
    			while 1 > 0
    			BEGIN

				if(@nLevel <> 4) 
				begin	
		                        select @hosting_tree_level = hosting_tree_level
        		                from gobject where gobject_id in (select hosted_by_gobject_id from gobject where 
                		        gobject_id in (select obj_id from @DeviceInfo where nLevel = @nLevel ))                       
				end
				else
				begin
					set @hosting_tree_level = @parentHostDepth 
				end
				-- Update the hosting_tree_level
				update gobject set hosting_tree_level = @hosting_tree_level + 1
				from gobject G inner join @DeviceInfo O on G.gobject_id = O.obj_id
				where nLevel = @nLevel

	                        --Get the next Level
				insert into @DeviceInfo
				select gobject_id,  @nLevel + 1 , T.category_id 
				from gobject G inner join @DeviceInfo CI on G.hosted_by_gobject_id = CI.obj_id
					inner join template_definition T on T.template_definition_id = G.template_definition_id

		                where nLevel = @nLevel
				
                
				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1
        		END	-- while	

			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join @ObjectInfo Objs on Inst.gobject_id = Objs.obj_id
					
			set @nLevel = 1

			create table #ContainedChildren (gobject_id int, nLevel int)
			insert into #ContainedChildren 
				select gobject_id , @nLevel
				from gobject
				inner join @ObjectInfo on contained_by_gobject_id = obj_id

			if @@rowcount != 0
			begin
		
				while 1 > 0
				begin
					insert into #ContainedChildren
					select G.gobject_id, @nLevel + 1 
					from gobject G 
					inner join #ContainedChildren CC on G.contained_by_gobject_id = CC.gobject_id
					where CC.nLevel = @nLevel
			
					if @@rowcount = 0 break
					set @nLevel = @nLevel + 1
				end
			end		



			update gobject set hosted_by_gobject_id = @parentId, hosting_tree_level = (@parentHostDepth + 1)
			from gobject G inner join #ContainedChildren CC on G.gobject_id = CC.gobject_id

			update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
			from instance Inst inner join #ContainedChildren CC on Inst.gobject_id = CC.gobject_id
			

			drop table #ContainedChildren

			set @operationStatus = 0 -- S_OK
			set @parentCategory	= 255

		END

		IF @parentCategory = 1 			-- Parent = Platform
		BEGIN
			-- Delete any children which is not an engine, we may return this set as an error objects set
			-- Only engines can be assigned to Platform
			delete from @ObjectInfo where cat_id = 1 or cat_id > 9


			-- Children are engines
			declare @engineCount int
			select @engineCount = count(*) from @ObjectInfo
	
--check for max 1000 Appengines


	-- Get the new mx_paltform_id and mx_engine_id for which these Appenigne will move to
	select @mx_platform_id = mx_platform_id from instance where gobject_id = @parentId 
	
	select @MaxObjectsinInstanceTable  = count(*) 
	from instance where  mx_platform_id = @mx_platform_id and mx_engine_id <> 1 and mx_object_id = 1
	
	if (@mx_engine_id > 0)
	begin
		set @MaxObjectsinInstanceTable = @MaxObjectsinInstanceTable 
		IF ( @MaxObjectsinInstanceTable > 1000 )
		begin
			rollback tran
			set @operationStatus = 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
				
			return
	
		end
	end



			IF @engineCount > 0 
			BEGIN

				-- Add the old host into list of affected objects since the old host is changed
				insert into @retAffectedObjects
				select hosted_by_gobject_id, 0 from gobject inner join @ObjectInfo on gobject_id = obj_id

				-- Update gobject table
				update gobject set hosted_by_gobject_id = @parentId
				from gobject inner join @ObjectInfo on gobject_id = obj_id

				-- Get the new platform Id ( inherit from the target parent )
				select @mx_platform_id = mx_platform_id from instance where gobject_id = @parentId
			
				-- Update instance table
				while exists ( select obj_id from @ObjectInfo )
				BEGIN 
					select @childId = obj_id, @child_platform_id = mx_platform_id, @child_engine_id = mx_engine_id from @ObjectInfo	

					-- Get the next available mx_engine_id from the new platform
					set @mx_engine_id = dbo.get_next_mx_engine_id(@mx_platform_id)

					-- Engine is moving from a Platform to another Platform
					IF @child_platform_id > 0
					BEGIN	
						update 	instance set mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id 
						where 	mx_platform_id = @child_platform_id and mx_engine_id = @child_engine_id
					END

					ELSE	
					BEGIN
						update 	instance 
						set 	mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id, mx_object_id = 1
						where 	gobject_id = @childId
					
						-- Get all descendant hosted by this engine
						create table #HostedChildren(idx int identity(2,1),  gobject_id int)
						insert into #HostedChildren select objectId from dbo.get_hosted_objects(@childId)
						
						declare @count int
						select @count = count(*) from #HostedChildren

						IF @count > 0 
						BEGIN
							update instance 
							set mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id, mx_object_id = HC.idx
							from instance Inst inner join #HostedChildren HC on Inst.gobject_id = HC.gobject_id
						END

						drop table #HostedChildren
					END
					
					-- Set any string reference to 'myPlatform' to invalid
					update attribute_reference set is_valid = 1
					from instance Inst inner join attribute_reference AR on Inst.gobject_id = AR.gobject_id
					where mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id 
						  and (reference_string like 'myPlatform.%' or (reference_string like 'myHost.%' and mx_object_id = 1) )

					-- Remove this engine from the list and continue with the rest
					delete from @ObjectInfo where obj_id = @childId		
								
				END				
			END
		END		-- Parent is Platform
		ELSE IF @parentCategory < 10	-- Parent = Engine	--> Children are Areas, and IONetwork
		BEGIN -- This check is not needed, we should remove it if it is safe
			-- Remove any non-assignable objects
			
			delete from @ObjectInfo where cat_id < 11 or cat_id = 12 or (cat_id > 13 and cat_id <> 24)


			--check for max 1000 Appengines 
			-- Get the new mx_paltform_id and mx_engine_id for which these app object will move to
			select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id from instance where gobject_id = @parentId
			select @newAppobjects = count(*) from @ObjectInfo
			select @MaxObjectsinInstanceTable  = count(*) 
			from instance where  mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id
			
			declare @allObjectsUnderChildren int
			select @allObjectsUnderChildren = count(*) from 
			gobject g where area_gobject_id in (select gid from #childList)

			if (@mx_engine_id > 0)
			begin
				set @MaxObjectsinInstanceTable = @MaxObjectsinInstanceTable + @newAppobjects + @allObjectsUnderChildren
				IF ( @MaxObjectsinInstanceTable > 30000 )
				begin
					rollback tran
					set @operationStatus = 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
						
					return
			
				end
			end
		
			-- Add the old host into list of affected objects since the old host is changed
			insert into @retAffectedObjects
			select hosted_by_gobject_id, 0 from gobject inner join @ObjectInfo on gobject_id = obj_id


			-- Update gobject table for any child who is an Area or Device
			update gobject set hosted_by_gobject_id = @parentId
			from gobject inner join @ObjectInfo on gobject_id = obj_id

			-- Update the Objects hosted by Area
			IF exists ( select obj_id from @ObjectInfo where has_children = 1 )
				insert into @ObjectInfo 
				select gobject_id, 10, OI.mx_platform_id, OI.mx_engine_id, 0
				from gobject G inner join @ObjectInfo OI on G.hosted_by_gobject_id = OI.obj_id
			        where OI.cat_id = 13 --Area



            --update the hosting_tree_level		    
    		IF exists ( select obj_id from @ObjectInfo where cat_id = 11 or cat_id = 24)
    		BEGIN
    
    			insert into @DeviceInfo select H.obj_id, 1, T.category_id
    			from @ObjectInfo H inner join gobject G on H.obj_id = G.gobject_id
    			inner join template_definition T on T.template_definition_id = G.template_definition_id
                where T.category_id = 11 or T.category_id = 24


    			set @nLevel = 1					
    			while 1 > 0
    			BEGIN
                        select @hosting_tree_level = hosting_tree_level
                        from gobject where gobject_id in (select hosted_by_gobject_id from gobject where 
                        gobject_id in (select obj_id from @DeviceInfo where nLevel = @nLevel ))                       
        				-- Update the hosting_tree_level
        				update gobject set hosting_tree_level = @hosting_tree_level + 1
        				from gobject G inner join @DeviceInfo O on G.gobject_id = O.obj_id
        				where nLevel = @nLevel
                        --Get the next Level
        				insert into @DeviceInfo
        				select gobject_id,  @nLevel + 1 , T.category_id 
        				from gobject G inner join @DeviceInfo CI on G.hosted_by_gobject_id = CI.obj_id
						inner join template_definition T on T.template_definition_id = G.template_definition_id
		                where nLevel = @nLevel
        				
                        
        				if @@rowcount = 0 break
        				set @nLevel = @nLevel + 1
        		END	-- while						
    		END

			-- Get the new mx_platform_id and mx_engine_id from the parent
			select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id from instance where gobject_id = @parentId

            -- This fix has been done to set the @mx_platform_id,@mx_engine_id,@mx_object_id for all
            -- the objects which are under network-device-device so that multi host assign shld 
            -- set the correct mx_id when they are assigned.


insert into @ObjectInfo
    select DI.obj_id, DI.catid, @mx_platform_id, @mx_engine_id, 1 from 
    @DeviceInfo DI left join @ObjectInfo O on DI.obj_id = O.obj_id
    where O.obj_id is null


			-- If the parent object is under Unassigned Host, then set all Mx Ids to 0
			IF @mx_engine_id = 0
				update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
				from instance inner join @ObjectInfo on gobject_id = obj_id
			ELSE
			BEGIN

				-- Get the number of mx_object_id will be needed ( to supply to get_mx_object_ids() )
				select @objCount = count(*) from @ObjectInfo
			
				update instance set mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id, mx_object_id = MxIdList.mxId
				from instance Inst inner join @ObjectInfo Objs on Inst.gobject_id = Objs.obj_id
				inner join dbo.get_mx_object_ids(@mx_platform_id, @mx_engine_id, @objCount) MxIdList
				on Objs.idx = MxIdList.idx				
			END	

			-- set the dirty flag for reference string only if the platform has changed  ( in case of engine, mx_engine_id is not unique )
			update attribute_reference set is_valid = 1
			from  attribute_reference AR inner join @ObjectInfo on AR.gobject_id = obj_id
			where (reference_string like 'myPlatform.%' and mx_platform_id <> @mx_platform_id) 
			           or ( reference_string like 'myEngine.%' and (mx_platform_id <> @mx_platform_id or mx_engine_id <> @mx_engine_id)  )
			           or ( reference_string like 'myHost.%' )
		END

		ELSE IF (@parentCategory = 12 or @parentCategory = 11 or @parentCategory = 24)	-- Parent is Device or IONetwork-- > Children are Devices only
		BEGIN			
			-- Remove any non-assignable objects
			delete from @ObjectInfo where cat_id <> 12 

			-- Add the old host into list of affected objects since the old host is changed
			insert into @retAffectedObjects
			select hosted_by_gobject_id, 0 from gobject inner join @ObjectInfo on gobject_id = obj_id


			-- Update gobject table
			update gobject set hosted_by_gobject_id = @parentId
			from gobject inner join @ObjectInfo on gobject_id = obj_id

            --update the hosting_tree_level		    
    		IF exists ( select obj_id from @ObjectInfo where cat_id = 12 )
    		BEGIN
    
    			insert into @DeviceInfo (obj_id , nLevel )
				(
					select H.obj_id, 1
    				from @ObjectInfo H inner join gobject G on H.obj_id = G.gobject_id
    				inner join template_definition T on T.template_definition_id = G.template_definition_id
					where T.category_id = 12
				)

    			set @nLevel = 1					
    			while 1 > 0
    			BEGIN
                        select @hosting_tree_level = hosting_tree_level
                        from gobject where gobject_id in (select hosted_by_gobject_id from gobject where 
                        gobject_id in (select obj_id from @DeviceInfo where nLevel = @nLevel ))                       
        				-- Update the hosting_tree_level
        				update gobject set hosting_tree_level = @hosting_tree_level + 1
        				from gobject G inner join @DeviceInfo O on G.gobject_id = O.obj_id
        				where nLevel = @nLevel
                        --Get the next Level
        				insert into @DeviceInfo (obj_id , nLevel )
						(
        					select gobject_id,  @nLevel + 1 
        					from gobject G inner join @DeviceInfo CI on G.hosted_by_gobject_id = CI.obj_id
        					where nLevel = @nLevel
						)
                        
        				if @@rowcount = 0 break
        				set @nLevel = @nLevel + 1
        		END	-- while						
    		END
            -----------------------------------

			-- Get the target mx_platform_id and mx_engine_id
			select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id from instance where gobject_id = @parentId

			-- Remove any objects moving within its host engine
			delete from @ObjectInfo where mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id

            -- For now Device can host only 1 level down, add any child under these devices
            -- This fix has been done to set the @mx_platform_id,@mx_engine_id,@mx_object_id for all
            -- the objects which are under device-device so that multi host assign shld 
            -- set the correct mx_id when they are assigned
            
        	insert into @ObjectInfo
    		select DI.obj_id, 12, @mx_platform_id, @mx_engine_id, 1 from 
			    @DeviceInfo DI left join @ObjectInfo O on DI.obj_id = O.obj_id
			    where O.obj_id is null
            
            select @objCount = count(*) from @ObjectInfo			
			IF @objCount > 0
			BEGIN
				IF @mx_engine_id = 0	-- Target is an Device under Unassigned Host
					update instance set mx_platform_id = 0, mx_engine_id = 0, mx_object_id = 0
					from instance inner join @ObjectInfo on gobject_id = obj_id

				ELSE
					update instance set mx_platform_id = @mx_platform_id, mx_engine_id = @mx_engine_id, mx_object_id = MxIdList.mxId
					from instance Inst inner join @ObjectInfo Objs on Inst.gobject_id = Objs.obj_id
					inner join dbo.get_mx_object_ids(@mx_platform_id, @mx_engine_id, @objCount) MxIdList
					on Objs.idx = MxIdList.idx

				-- set the dirty flag for reference string only if the platform has changed  ( in case of engine, mx_engine_id is not unique )
				update attribute_reference set is_valid = 1
				from  attribute_reference AR inner join @ObjectInfo on AR.gobject_id = obj_id
				where (reference_string like 'myPlatform.%' and mx_platform_id <> @mx_platform_id) 
				          or (reference_string like 'myEngine.%' and (mx_platform_id <> @mx_platform_id or mx_engine_id <> @mx_engine_id ) )
				          or ( reference_string like 'myHost.%' )												
			END		
		END	
	END

	-- Check if we have any object over the limit
	if exists ( select mx_engine_id from instance where mx_engine_id > 1000 and mx_platform_id = @mx_platform_id )
	begin
		rollback tran
		set @operationStatus = 0x80040550 -- E_ASSIGN_ENGINE_EXCEED_LIMIT
	end

	else if exists ( select mx_object_id from instance where mx_object_id > 30000 and mx_platform_id = @mx_platform_id
				and mx_engine_id = @mx_engine_id)
	begin
		rollback tran
		set @operationStatus = 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
	end

	else
	begin
		-- set the object status
		update package set reference_status_id = 2
		from package PK inner join attribute_reference AR on PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
		where is_valid = 1
	
		-- wipe out contained name of top level objects
		if ( @updatecontainname > 0 )
		begin
  		  update gobject set contained_name = '' 
		  from gobject g inner join #childList ch on ch.gid = g.gobject_id where g.contained_by_gobject_id = 0 and g.contained_name <> ''
		end

		commit tran
		set @operationStatus = 0 -- S_OK
		delete from @retAffectedObjects where gobject_id = 0
		select distinct * from @retAffectedObjects order by is_toolset
	end

	

end
go

