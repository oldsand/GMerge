/**************************************************
Object Name :  internal_get_which_package_to_use
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieve the some information of a gobject
			   to help determine which package of an object to use. 
Used By	    :  
Example	    :  exec internal_get_which_package_to_use N'{00000000-0000-0000-0000-000000000001}'
exec internal_get_which_package_to_use @gobjectid = 10
**************************************************/
create proc dbo.internal_get_which_package_to_use
	@gobjectid INT
as
begin
	
	SET NOCOUNT ON
	
	select	g.checked_in_package_id as checked_in_package_id,
			g.checked_out_package_id as checked_out_package_id,
			g.checked_out_by_user_guid as checked_out_by_user_gobject_id
	from	gobject g
	where	g.gobject_id = @gobjectid

	SET NOCOUNT OFF
end
go

