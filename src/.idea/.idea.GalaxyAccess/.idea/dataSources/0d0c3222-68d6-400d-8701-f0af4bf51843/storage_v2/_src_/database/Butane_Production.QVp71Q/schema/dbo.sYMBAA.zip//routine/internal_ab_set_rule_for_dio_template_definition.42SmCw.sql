CREATE PROCEDURE dbo.internal_ab_set_rule_for_dio_template_definition
	  @dio		int
    , @rule_id  int = NULL
	, @force	bit = 0
as
begin
    set nocount on

	declare @set_templ_id int
	declare @abd_templ_id int
	declare @abd_templ_rule_id int

	select @set_templ_id = dio.template_definition_id, @abd_templ_id = ab_templ.template_definition_id, @abd_templ_rule_id = ab_templ.rule_id
	FROM gobject dio
	INNER JOIN template_definition td
	  ON td.template_definition_id = dio.template_definition_id
	INNER JOIN lookup_category lcat
	  ON lcat.category_id = td.category_id
	 AND lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
	LEFT OUTER JOIN autobind_device_template ab_templ
	  ON ab_templ.template_definition_id = td.template_definition_id

	if @@ROWCOUNT = 0
		return -1

	if @abd_templ_id IS NULL
		INSERT INTO autobind_device_template (template_definition_id, rule_id) VALUES (@set_templ_id, @rule_id)
	else if @abd_templ_rule_id IS NULL AND @rule_id IS NOT NULL OR @force = 1
		UPDATE autobind_device_template SET rule_id = @rule_id WHERE template_definition_id = @abd_templ_id
	else
		return 1

    -- EXECUTE internal_ab_refresh_attribute_aliases 0, 0, 0, @abd_templ_id, 0

    return 0
end
go

