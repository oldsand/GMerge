-- update the TimeofLastConfigChange  in Galaxy Table
create  procedure dbo.internal_update_time_of_last_config_change
as 
begin
	UPDATE galaxy SET time_of_last_config_change = getDate()
    
end



go

