create view dbo.internal_visual_element_reference_per_user_view
as
select  distinct
        ver.gobject_id, 
        ver.package_id, 
        ver.mx_primitive_id,
        ver.visual_element_bind_status,
        ver.visual_element_reference_index,
        checked_in_vev.visual_element_id,
        ver.checked_in_unbound_visual_element_name, -- ubve
        checked_in_ve.visual_element_type,
        checked_in_pri.primitive_name,
        gobject_referee_in.tag_name,
        case when ((ver.checked_out_visual_element_package_id is null) or
            ver.checked_out_to_user_guid <> vp.user_guid) then -- not checked out to this user....
             case when  ver.checked_in_bound_visual_element_gobject_id is not null then  -- checked_in version is bound...
                 case when ver.is_relative_reference = 0 then                        
                     (case when checked_in_pri.primitive_name <> ''  then 
                         checked_in_ve.visual_element_type + ':' + gobject_referee_in.tag_name + 
                         '.' + checked_in_pri.primitive_name 
                      else 
                         checked_in_ve.visual_element_type + ':' + gobject_referee_in.tag_name 
                      end) 
                 else
		             case when(len(gobject_referee_in.hierarchical_name) - len(gme.hierarchical_name) >=0) then
		                     checked_in_ve.visual_element_type + ':' + 'me'+ 
		                     right(gobject_referee_in.hierarchical_name, 
		                     (len(gobject_referee_in.hierarchical_name)  - len(gme.hierarchical_name)) )  +
		                     '.' + checked_in_pri.primitive_name    
    		         else
	    	            null
		             end
                 end
             else 
                ver.checked_in_unbound_visual_element_type + ':'+ ver.checked_in_unbound_visual_element_name --ubve
            end
        else -- target VE is checked out to this user..
            case when  ver.checked_out_bound_visual_element_gobject_id is not null then -- checked_out version is bound...
                case when ver.is_relative_reference = 0 then                        
                    (case when checked_out_pri.primitive_name <> ''  then 
                        checked_out_ve.visual_element_type + ':' + gobject_referee_out.tag_name + 
                        '.' + checked_out_pri.primitive_name 
                     else 
                         checked_out_ve.visual_element_type + ':' + gobject_referee_out.tag_name 
                     end) 
                else
                        case when(len(gobject_referee_out.hierarchical_name) - len(gme.hierarchical_name)>=0) 
                        then
            				checked_out_ve.visual_element_type + ':' + 'me'+ 
            				right(gobject_referee_out.hierarchical_name, 
            				(len(gobject_referee_out.hierarchical_name)  - len(gme.hierarchical_name)) )  +
            				'.' + checked_out_pri.primitive_name           
            			else
			                 null
            			end        
                end
            else 
                ver.checked_out_unbound_visual_element_type + ':'+ ver.checked_out_unbound_visual_element_name --ubve
            end
        end         
        as reference_string,
        case when ver.visual_element_bind_status = 1 then 
            case when ver.is_relative_reference = 0 then        

                (case when checked_in_pri.primitive_name <> ''  then 
                    gobject_referee_in.tag_name + '.' + checked_in_pri.primitive_name 
                 else 
                     gobject_referee_in.tag_name 
                 end) 
            else
     		     case when(len(gobject_referee_in.hierarchical_name) >= len(gme.hierarchical_name)) then
			        'me'+ right(gobject_referee_in.hierarchical_name,
                        (len(gobject_referee_in.hierarchical_name)- len(gme.hierarchical_name)) )  
                        +   '.' + checked_in_pri.primitive_name           

    		     else
	    	        ''
		         end

            end
        else 
            ver.checked_in_unbound_visual_element_name-- ubve
        end as calculated_visual_element_name,
        case when ver.visual_element_bind_status = 1 then 
            checked_in_ve.visual_element_type
        else 
            ver.checked_in_unbound_visual_element_type -- ubve
        end as calculated_visual_element_type,
        vp.user_guid,
        p.package_type,
        ver.is_relative_reference
from visual_element_reference ver
inner join gobject gme on ver.gobject_id = gme.gobject_id
cross join user_profile vp 
inner join package p on 
	ver.gobject_id = p.gobject_id and
	ver.package_id = p.package_id
-- checked-in section....
left outer join visual_element_version checked_in_vev on
        checked_in_vev.gobject_id = ver.checked_in_bound_visual_element_gobject_id and
        checked_in_vev.package_id = ver.checked_in_bound_visual_element_package_id and
        checked_in_vev.mx_primitive_id = ver.checked_in_bound_visual_element_mx_primitive_id
left outer join visual_element checked_in_ve on
        checked_in_vev.visual_element_id = checked_in_ve.visual_element_id
left outer join primitive_instance checked_in_pri on
        checked_in_vev.gobject_id = checked_in_pri.gobject_id and
        checked_in_vev.package_id = checked_in_pri.package_id and
        checked_in_vev.mx_primitive_id = checked_in_pri.mx_primitive_id
left outer join gobject gobject_referee_in on 
        ver.checked_in_bound_visual_element_gobject_id = gobject_referee_in.gobject_id
-- checked-out section....
left outer join visual_element_version checked_out_vev on
        checked_out_vev.gobject_id = ver.checked_out_bound_visual_element_gobject_id and
        checked_out_vev.package_id = ver.checked_out_bound_visual_element_package_id and
        checked_out_vev.mx_primitive_id = ver.checked_out_bound_visual_element_mx_primitive_id
left outer join visual_element checked_out_ve on
        checked_out_vev.visual_element_id = checked_out_ve.visual_element_id
left outer join primitive_instance checked_out_pri on
        checked_out_vev.gobject_id = checked_out_pri.gobject_id and
        checked_out_vev.package_id = checked_out_pri.package_id and
        checked_out_vev.mx_primitive_id = checked_out_pri.mx_primitive_id
left outer join gobject gobject_referee_out on 
        ver.checked_out_bound_visual_element_gobject_id = gobject_referee_out.gobject_id
go

