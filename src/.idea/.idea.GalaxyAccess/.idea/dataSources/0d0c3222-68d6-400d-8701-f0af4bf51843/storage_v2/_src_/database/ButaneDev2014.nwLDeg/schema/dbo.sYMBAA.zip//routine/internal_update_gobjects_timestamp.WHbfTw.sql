
create procedure dbo.internal_update_gobjects_timestamp
@FileNameOfIds nvarchar (265),
@update_gobject_filter_info_timestamp bit = 0

as
begin tran

    set quoted_identifier off
    
    create table  #gobject_ids ( gobject_id int)
	declare @gobject_ids_with_key table ( gobject_id int primary key)	
	
    
    declare @sql nvarchar(2000)
    
    set @sql = 'bulk insert #gobject_ids  from ''' + @FileNameOfIds+ ''' with(tablock,datafiletype  = ''widechar'')'
    
    exec (@sql)

	insert into @gobject_ids_with_key
	select distinct gobject_id from #gobject_ids 
	
    update pt
    set pt.gobject_id = pt.gobject_id
    from proxy_timestamp pt
    inner join @gobject_ids_with_key gi on
        pt.gobject_id = gi.gobject_id 
	
	if(@update_gobject_filter_info_timestamp = 1)
    begin
		update gfi
		set gfi.gobject_id = gfi.gobject_id
		from gobject_filter_info_timestamp gfi
		inner join @gobject_ids_with_key gi on
			gfi.gobject_id = gi.gobject_id 
	end

    declare @max_proxy_timestamp bigint
    select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

    update galaxy
    set max_proxy_timestamp = @max_proxy_timestamp
    
    drop table #gobject_ids

commit


go

