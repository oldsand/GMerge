create function dbo.get_mx_object_ids(
	@my_platform_id smallint,
	@my_engine_id smallint,
	@count smallint
	)
returns @retTable table(idx int IDENTITY(1,1), mxId smallint)
as
begin
	
	-- Look for an empty slot for the next mx_object_id
	declare @MxObjIds table( mx_object_id smallint )

	insert into @MxObjIds  
	select i.mx_object_id + 1 from instance i 
	where not exists (  select mx_object_id from instance 
						where mx_object_id - 1 = i.mx_object_id 
						and mx_platform_id = i.mx_platform_id 
						and mx_engine_id = i.mx_engine_id )
	and i.mx_platform_id = @my_platform_id and i.mx_engine_id = @my_engine_id
	order by i.mx_object_id

	declare @mx_obj_id smallint
	while @count > 0
	begin
		select @mx_obj_id = min(mx_object_id) from @MxObjIds			
		delete from @MxObjIds where mx_object_id = @mx_obj_id
		insert into @retTable values(@mx_obj_id)
		set @count = @count - 1

		while not exists ( select gobject_id from instance where mx_platform_id = @my_platform_id and
						   mx_engine_id = @my_engine_id and mx_object_id = @mx_obj_id + 1 ) and @count > 0
		begin
			set @mx_obj_id = @mx_obj_id + 1
			insert into @retTable values(@mx_obj_id)
			set @count = @count - 1
		end				
	end

	return

end
go

