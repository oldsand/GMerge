CREATE  procedure dbo.internal_get_operations
as
select top 5
    r.operation_id,
    up.user_profile_name,
    r.start_time,
    o.operation_name,
    lu.status_name
from operation r 
inner join operation o on
    r.operation_id = o.operation_id
inner join operation_status rs on
    r.operation_id = rs.operation_id
inner join operation_status_look_up lu on
    rs.status = lu.status
inner join user_profile up on
    r.user_profile_id = up.user_profile_id
order by r.operation_id desc
go

