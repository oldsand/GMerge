---- This Stored Proc is Creating Object with checkin package
---- Used after CreateInMemory

create procedure dbo.internal_save_create_gobject
    @user_guid nvarchar(64),
    @area_gobject_name nvarchar(329),
    @hosted_by_gobject_name nvarchar(329),
    @contained_name nvarchar(329),
    @container_by_gobject_name nvarchar(329),
    @template_gobject_id int,
    @New_Tag_name  nvarchar(329),
    @xmlschema ntext,
	@templateattributefile nvarchar(255),
	@templateattributefileisempty int,    
    @dynamicattributefile nvarchar(255),
    @dynamicattributefileisempty int,
    @primitive_instance_attributes_file nvarchar(255),
    @primitive_instance_attributes_file_has_content int,
    @xmlrefschema ntext,
    --    @attribute_values_blob image,
    @automation_object_change_has_occured bit,
    @graphic_change_has_occured bit,
    @record_change bit
as 
begin tran
	
	set nocount on
	declare @h int
	declare @status_id smallint
	execute sp_xml_preparedocument @h output,@xmlschema

	-- find out if this is a template
	declare @isTemplate nvarchar(32)
	declare @gobjectid  int
	declare @package_id integer
	declare @checked_in_pkg_id int
	declare @deploy_pkg_id int
	declare @last_deploy_pkg_id int
	declare @deployversion int
	declare @configversion int
	declare @sec_group nvarchar(32)
	declare @bFor_GobjectOnly int
	declare @reference_status int
	declare @WantToCreate_Checked_out_Package bit


	set @gobjectid = 0
--	set @isTemplate = 0
	set @isTemplate = N''
	set @package_id = 0
	set @status_id = 0
	set @reference_status = 0
	set @checked_in_pkg_id = 0
	set @deploy_pkg_id = 0
	set @last_deploy_pkg_id = 0
	set @deployversion = 0
	set @configversion = 0
	set @bFor_GobjectOnly = -1
	set @WantToCreate_Checked_out_Package = 0
	
	
	select	@gobjectid = o.id,@isTemplate = o.is_template,
			@package_id = o.package_id,
			@status_id = o.status_id,
			@reference_status = o.reference_status_id,
			@checked_in_pkg_id = o.checked_in_package_id,
			@deploy_pkg_id = o.deployed_package_id,
			@last_deploy_pkg_id = o.last_deployed_package_id,
			@deployversion = o.deploy_version,
			@configversion = o.config_version,
			@sec_group = o.sec_group,
			@bFor_GobjectOnly = o.bFor_GobjectOnly
	from openxml (@h,'/ROOT/gObject',1)
	with (   id int './@id',
		 is_template nvarchar(32) './@is_template',
		 package_id int './@package_id',
		 status_id int './@status_id',
		 reference_status_id int './@reference_status_id',
		 checked_in_package_id int './@checked_in_package_id',
		 deployed_package_id int './@deployed_package_id',
		 last_deployed_package_id int './@last_deployed_package_id',
		 deploy_version int './@deploy_version',
		 config_version int './@config_version',
		 sec_group nvarchar(32) './@sec_grp',
		 bFor_GobjectOnly int './@bFor_GobjectOnly' ) o
	
	set @sec_group = isnull(@sec_group, N'')
	set @sec_group = isnull(@sec_group, N'')

    declare @host_tree_level smallint   
    declare @category_id smallint   
    declare @namespace_id smallint

    select  @category_id = category_id, 
            @host_tree_level = case when category_id = 1 then 1 when category_id < 10 then 2 when category_id = 13 then 3 else 4 end, 
            @namespace_id = gobject.namespace_id
    from gobject with (NOLOCK) 
	inner join template_definition on 
		gobject.template_definition_id = template_definition.template_definition_id
    where gobject_id = @template_gobject_id 

    
	if ( @gobjectid = 0 ) --if @gobjectid <>0 means we have to create checked_out_package , used by check in logic
	begin
		
		declare @countofGobjects smallint
        select  @countofGobjects = count(gobject_id) 
		from gobject with(NOLOCK)
		where gobject.tag_name = @New_Tag_name 
            and gobject.namespace_id = @namespace_id
		-- Check @New_Tag_name  is exist then stop creating again
		if  ( @countofGobjects  <> 0 )
		begin
			select 0 as gobjectid, 0 as package_id
			rollback tran
			EXECUTE sp_xml_removedocument @h
			RETURN
		end
	end
	else
	begin 
		set @WantToCreate_Checked_out_Package = 1
	end

	declare @contained_by_gobject_id int
	declare @hosted_by_gobject_id int 
	declare @area_gobject_id int
	
	set @contained_by_gobject_id = 0
	set @hosted_by_gobject_id = 0
	set @area_gobject_id = 0

	select @contained_by_gobject_id = gobject_id 
	from gobject with(NOLOCK)
	where gobject.tag_name = @container_by_gobject_name
        and gobject.namespace_id = @namespace_id
	
	select @hosted_by_gobject_id = gobject_id 
	from gobject with(NOLOCK)
	where gobject.tag_name = @hosted_by_gobject_name
        and gobject.namespace_id = @namespace_id
	
	select @area_gobject_id = gobject_id 
	from gobject with(NOLOCK)
	where gobject.tag_name = @area_gobject_name
        and gobject.namespace_id = @namespace_id
	
	if(@category_id = 10) --AppObjects category is 10
	begin
		if ( (@area_gobject_id <> 0) and (@hosted_by_gobject_id = 0) )  set @hosted_by_gobject_id = @area_gobject_id
	end
	if @contained_by_gobject_id = 0  	 
	begin
		set @contained_name = ''
	end
	else
	begin
		--check @contained_name is not empty & unique under same container
		select  @countofGobjects = count(gobject_id) from gobject where (gobject.contained_by_gobject_id = @contained_by_gobject_id) AND (gobject.contained_name <> @contained_name)
		--if empty OR its not unique then give contained_name same as tag_name 
		if ((@countofGobjects <> 0) OR (@contained_name = ''))  set @contained_name = @New_Tag_name  -- set default contained name same as Tag_name
	end

	
declare @template bit
set @template = 0
if ( @isTemplate = 'True' )
begin
  set @template = 1	
end	
	
if (@WantToCreate_Checked_out_Package = 0)
begin
	insert into gobject
	(
	template_definition_id,
	derived_from_gobject_id,
	contained_by_gobject_id,
	area_gobject_id,
	hosted_by_gobject_id,
	default_symbol_gobject_id,
	default_display_gobject_id,
	checked_in_package_id,
	checked_out_package_id,
	deployed_package_id,
	tag_name,
    namespace_id,
	contained_name,
	identity_guid,
	configuration_guid,
	configuration_version,
	is_template,
	is_hidden,
	software_upgrade_needed,
	hosting_tree_level,
	hierarchical_name
	)
	select
	gobject.template_definition_id,		-- template_definition_id
	gobject.gobject_id,					-- derived_from_gobject_id
	@contained_by_gobject_id,			-- contained_by_gobject_id
	@area_gobject_id,					-- area_gobject_id
	@hosted_by_gobject_id,				-- hosted_by_gobject_id
	0,									-- default_symbol_gobject_id
	0,									-- default_display_gobject_id
	0,									-- checked_in_package_id
	0,									-- checked_out_package_id
	0,									-- deployed_package_id
	@New_Tag_name ,						-- tag_name
    gobject.namespace_id,               -- namespace_id
	@contained_name,				    -- contained_name
	NewId(),							-- identity_guid
	NewId(),							-- configuration_guid
	1,									-- configuration_version
	@template,						-- is_template
	gobject.is_hidden,					-- is_hidden
	0,									-- software_upgrade_needed
	@host_tree_level,				-- hosting_tree_level 
	@New_Tag_name 					-- hierarchical_name   
	from  gobject gobject	with(NOLOCK)
	where @template_gobject_id = gobject.gobject_id 

	select @gobjectid = @@IDENTITY
end


---------------------------------------
-- create the instance row
---------------------------------------
if (@WantToCreate_Checked_out_Package = 0 and @template = 0)
begin
	if ( @host_tree_level = 2 )
		insert into instance ( gobject_id, mx_engine_id, mx_object_id ) values ( @gobjectid, dbo.get_next_mx_engine_id(0), 1 )
	else
		insert into instance ( gobject_id ) values ( @gobjectid )
end

declare @derived_from_package_id int

if (@WantToCreate_Checked_out_Package = 0)
begin 
	select	@derived_from_package_id = checked_in_package_id 
	from	gobject
	where	gobject_id = @template_gobject_id
end
else
begin
	select	@derived_from_package_id = checked_out_package_id 
	from	gobject
	where	gobject_id = @template_gobject_id
end

    -- get the current version deployable_configuration_version of the object that we are changing....
declare @current_deployable_configuration_version int
declare @new_deployable_configuration_version int
set @current_deployable_configuration_version = 0
set @new_deployable_configuration_version = 0 
select  @current_deployable_configuration_version  =  deployable_configuration_version from 
    package with(NOLOCK)where gobject_id = @gobjectid
 
set @new_deployable_configuration_version = @automation_object_change_has_occured + @current_deployable_configuration_version

insert into package 
(
		gobject_id,
		status_id,
		security_group,
		derived_from_package_id,
        deployable_configuration_version
)
select	@gobjectid,
		0, -- ePackageUnknownStatus
		security_group,
		package_id,
        @new_deployable_configuration_version        
        

from	package with(NOLOCK)
where	package_id = @derived_from_package_id


select @package_id = @@IDENTITY
set @checked_in_pkg_id = @package_id
--UPDATE PACKAGE TABLE
--declare @blobTable table( blobValue text )
--declare @blobTable table( blobValue image )
--insert into @blobTable select o.Attribute_Values from openxml (@h,'/ROOT/gObject',1) with (Attribute_Values image './Attribute_Values') o 
--	( select o.Attribute_Values from openxml (@h,'/ROOT/gObject',1) with (Attribute_Values text './Attribute_Values') o    )



-- update the configuration_guid of the gobject everytime there is a save happening on this

if (@WantToCreate_Checked_out_Package = 0) 
begin
	update package 
	set 
		status_id = isnull(@status_id, 0),
		reference_status_id = @reference_status,
		security_group = @sec_group,
        deployable_configuration_version = @new_deployable_configuration_version,
        package_type = 'I'
	from package with(NOLOCK)
	where gobject_id = @gobjectid and 
	    package_id = @package_id
	    
 
	update	gobject 
	set		gobject.configuration_guid = NewId(),			
			gobject.checked_in_package_id = @checked_in_pkg_id						
	from	gobject 
	where	gobject.gobject_id = @gobjectid

	if( @configversion <> 0 )
		update gobject set gobject.configuration_version = @configversion from gobject where gobject.gobject_id = @gobjectid
end
else
begin
	update package 
	set 
		status_id = isnull(@status_id, 0),
		reference_status_id = @reference_status,
		security_group = @sec_group,
		operation_status = 2,
        package_type = 'O'
        --deployable_configuration_version = @new_deployable_configuration_version
	where gobject_id = @gobjectid and 
	    package_id = @package_id
	    
	update	gobject 
	set		gobject.configuration_guid = NewId(),						
			gobject.checked_out_package_id = @checked_in_pkg_id,
			gobject.checked_out_by_user_guid = @user_guid
	from	gobject 
	where	gobject.gobject_id = @gobjectid
end



-- Primitive Instance Table
  declare @prim_inst table
  (
    package_id int,
    primitive_definition_id int,
    primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    mx_primitive_id int,
    parent_mx_primitive_id int,
    execution_group int,
    execution_order int,
	owned_by_gobject_id int,
	extension_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	is_object_extension bit,
	checked_in_primitive_version int,
    checked_out_primitive_version int,
    entity_change_type int,
    operation_on_primitive_mask int,
    created_by_parent smallint,
    status_id smallint,
    ref_status_id smallint,    
    primitive_attributes image,
    mx_value_errors text not null,    
    mx_value_warnings text not null,    
    mx_value_reference_warnings text not null    
   )
   insert into @prim_inst 
   select	o.package_id,
			o.primitive_definition_id,
			o.primitive_name,
			o.mx_primitive_id,
			o.parent_mx_primitive_id,
			o.execution_group,
			o.execution_order,
			o.owned_by_gobject_id,
			o.extension_type,
			o.is_object_extension,
			o.checked_in_primitive_version,
            o.checked_out_primitive_version,
              --o.entity_change_type, 
            -- CRL00085028 During Import,Restore,GRLoad entity_change_type should be set to 1
            -- Check Out package should be excluded
            case when @WantToCreate_Checked_out_Package = 0 then
				1 
			else 
				o.entity_change_type
			end 
			as entity_change_type,
            o.operation_on_primitive_mask,
            o.created_by_parent,
            o.status_id,
            o.ref_status_id,
			NULL,
--            o.primitive_attributes
		    o.mx_value_errors,
		    o.mx_value_warnings,
		    o.mx_value_reference_warnings		
            
   from openxml (@h,'/ROOT/gObject/Primitive_Inst',1) 
   with (  package_id int './../@package_id',
	       primitive_definition_id int './@primitive_definition_id',
	       primitive_name nvarchar(329) './@primitive_name',
	       mx_primitive_id int './@mx_primitive_id',
	       parent_mx_primitive_id int './@parent_mx_primitive_id',
	       execution_group int './@execution_group',
	       execution_order int './@execution_order',
		   owned_by_gobject_id int './@owned_by_gobject_id',
		   extension_type nvarchar(329) './@extension_type',
		   is_object_extension bit './@is_object_extension',
		   checked_in_primitive_version int './@checked_in_primitive_version',
           checked_out_primitive_version int './@checked_out_primitive_version',
           entity_change_type int './@entity_change_type',
           operation_on_primitive_mask int './@operation_on_primitive_mask',
           created_by_parent int './@created_by_parent',
           status_id int './@status_id',
           ref_status_id int './@ref_status_id',
           mx_value_errors  text './@mx_value_errors',
           mx_value_warnings  text './@mx_value_warnings',
           mx_value_reference_warnings  text './@mx_value_reference_warnings') o

	--Cascade checkin will only have @WantToCreate_Checked_out_Package == 1
	--If cascade checkin then Own primitive will have
	--	checked_out_primitive_version = checked_in_primitive_version
	if(@WantToCreate_Checked_out_Package = 1)
	begin
	
		update priminst
			set priminst.checked_in_primitive_version = ancestor_primitive.checked_in_primitive_version,
			priminst.checked_out_primitive_version = ancestor_primitive.checked_out_primitive_version
		from @prim_inst priminst
		inner join gobject ancestor
		on priminst.owned_by_gobject_id = ancestor.gobject_id
		and priminst.owned_by_gobject_id <> @gobjectid
		inner join primitive_instance ancestor_primitive
		on ancestor.gobject_id = ancestor_primitive.gobject_id
		and ancestor.checked_out_package_id = ancestor_primitive.package_id
		and priminst.mx_primitive_id = ancestor_primitive.mx_primitive_id
		and ancestor_primitive.extension_type = N'SymbolExtension'
		
		update  priminst
        set     priminst.checked_in_primitive_version= priminst.checked_out_primitive_version
        from    @prim_inst priminst
        where   owned_by_gobject_id = @gobjectid
	end
	
    if (@primitive_instance_attributes_file_has_content = 1 )
    begin
        CREATE TABLE  #primitive_instance_attributes_table ( 
            mx_primitive_id        smallint,
            primitive_attributes   image
        )
        
        DECLARE @pSQL nvarchar(2000)
        SET @pSQL = 'BULK INSERT #primitive_instance_attributes_table  FROM ''' + @primitive_instance_attributes_file+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@pSQL)

        update  pi
        set     pi.primitive_attributes = temppi.primitive_attributes
        from    
                @prim_inst pi
        inner join
                #primitive_instance_attributes_table temppi
        on
                pi.mx_primitive_id = temppi.mx_primitive_id
    end

   -- Insert Into Primitive Instance Table
    insert into primitive_instance with(UPDLOCK )(
					gobject_id,
					package_id,
					primitive_definition_id,
					primitive_name,
					mx_primitive_id,
					parent_mx_primitive_id,
					execution_group,
					execution_order,
					owned_by_gobject_id,
					extension_type,
					is_object_extension,
					checked_in_primitive_version,
                    checked_out_primitive_version,
                    entity_change_type,
                    operation_on_primitive_mask,
                    created_by_parent,
                    status_id,
                    ref_status_id,              
                    primitive_attributes,
		            mx_value_errors,
		            mx_value_warnings,
		            mx_value_reference_warnings)
                    
	select	@gobjectid,
			@package_id,
			o.primitive_definition_id,
			o.primitive_name,
			o.mx_primitive_id,
			o.parent_mx_primitive_id,
			o.execution_group,
			o.execution_order, 
            case when o.owned_by_gobject_id = 0 then 
                @gobjectid
            else
                o.owned_by_gobject_id
            end
            as owned_by_gobject_id,
            o.extension_type,
            o.is_object_extension,
            o.checked_in_primitive_version,
            o.checked_out_primitive_version,
            o.entity_change_type,
            o.operation_on_primitive_mask,
            o.created_by_parent,
            o.status_id,
            o.ref_status_id,                            
            o.primitive_attributes,
		    o.mx_value_errors,
		    o.mx_value_warnings,
		    --o.mx_value_reference_warnings		
		    '0x00'
	from	@prim_inst o



-- retain the timestamps of this object's primitive instances...
    update pri 
    set 
        pri.timestamp_of_last_change = previousPri.timestamp_of_last_change,
        pri.max_child_timestamp = previousPri.max_child_timestamp
    from primitive_instance pri with(UPDLOCK)
    inner join gobject g on 
        pri.gobject_id = g.gobject_id and
        g.gobject_id = @gobjectid
    inner join primitive_instance previousPri with(NOLOCK) on 
        pri.gobject_id = previousPri.gobject_id and
        pri.extension_type = previousPri.extension_type and
        UPPER(pri.primitive_name) = UPPER(previousPri.primitive_name) and
        pri.extension_type = N'SymbolExtension' and
        --pri.mx_primitive_id = previousPri.mx_primitive_id and
        previousPri.package_id = g.checked_in_package_id
        
-- Attribute Template Table
   if ( @isTemplate = 'True' )
      begin
      
		-- Create the temporary table 
		CREATE TABLE  #template_attributes_table
        (
			mx_primitive_id				smallint,
			mx_attribute_id				smallint,
			security_classification		int,
			mx_data_type				int,				
			lock_type					int,
			original_lock_type			int,
			mx_value					text
        )
        
		if (@templateattributefileisempty = 0)
		begin
			DECLARE @SQLTEMP nvarchar(2000)
			SET @SQLTEMP = 'BULK INSERT #template_attributes_table FROM ''' + @templateattributefile+ ''' 
						WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
			EXEC (@SQLTEMP)
		end
			          
       delete from template_attribute where gobject_id = @gobjectid and package_id =  @package_id 
       
       --insert the template attributes
		if (@templateattributefileisempty = 0)
			begin       
				insert into template_attribute ( gobject_id,
												 package_id,
												 mx_primitive_id,
												 mx_attribute_id,
												 security_classification,
												 mx_data_type,
												 mx_value,
												 lock_type,
												 original_lock_type)
							select	@gobjectid,
									@package_id,
									a_temp.mx_primitive_id,
									a_temp.mx_attribute_id,
									a_temp.security_classification,
									a_temp.mx_data_type,
									a_temp.mx_value,
									a_temp.lock_type,
									a_temp.original_lock_type
							from	#template_attributes_table a_temp
				end
				
			drop table #template_attributes_table
      end
   else if  ( @isTemplate = 'False' )
   begin

        declare @attr_instance table
        (
             mx_primitive_id            smallint,
             mx_attribute_id            smallint,
             mx_value                   text
        )
    
        insert into @attr_instance 
        select   o.mx_primitive_id,
                o.mx_attribute_id,
                o.mx_value
        from openxml (@h,'/ROOT/gObject/Primitive_Inst/InstanceAttribute',1)
        with ( mx_primitive_id smallint './../@mx_primitive_id' ,
              mx_attribute_id smallint './@mx_attribute_id',
              mx_value  text './mx_value' ) o

	declare @hRefXML int
	execute sp_xml_preparedocument @hRefXML output,@xmlrefschema
	declare @attr_reference_inst table
	(
		gobject_id   int,
		package_id   int,
		referring_mx_primitive_id smallint,
		referring_mx_attribute_id smallint,
		element_index             smallint,
		dest_object_name          nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS ,
		resolved_gobject_id      int,
		reference_string          nvarchar(700) COLLATE SQL_Latin1_General_CP1_CI_AS,
		context_string            nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
		object_signature          int,
		resolved_mx_primitive_id  smallint,
		resolved_mx_attribute_id  smallint,
		resolved_mx_property_id   smallint,
		attribute_signature       int,
		lock_type                 int,
		attr_res_status           int,
		attribute_index           smallint,
		is_valid				  bit		 
	)
	insert   into   @attr_reference_inst
		  select @gobjectid,
				 @package_id,
				 o.referring_mx_primitive_id,
				 o.referring_mx_attribute_id,
				 o.element_index,
				 o.dest_object_name,
				 0,
				 o.reference_string,
				 o.context_string,
				 o.object_signature,
				 o.resolved_mx_primitive_id,
				 o.resolved_mx_attribute_id,
				 o.resolved_mx_property_id,
				 o.attribute_signature,
				 o.lock_type,
				 o.attr_res_status,
				 o.attr_index,
				 o.is_dirty
		  from   openxml (@hRefXML, '/ROOT/gRef',1 )
		  with ( gobject_id int './@gobject_id',
				 package_id int './@package_id',
				 referring_mx_primitive_id smallint './@refPrimid',
				 referring_mx_attribute_id smallint './@refAttrid',
				 dest_object_name          nvarchar(32) './@destObjName',
				 element_index             smallint './@index',
				 reference_string          nvarchar(700) './@fullreference',
				 context_string            nvarchar(32)  './@context',
				 object_signature          int           './@objsign',
				 resolved_mx_primitive_id  smallint      './@resPrimid',
				 resolved_mx_attribute_id  smallint      './@resAttrid',
				 resolved_mx_property_id   smallint      './@resPropid',
				 attribute_signature       int           './@attrsign',
				 lock_type                 int           './@lock',
				 attr_res_status           int           './@attrResStatus',
				 attr_index                smallint      './@attribute_index',
				 is_dirty                  bit           './@is_dirty' ) o
                 
	EXECUTE sp_xml_removedocument @hRefXML
	update attr_ref
		set    resolved_gobject_id = ( select isnull(gobj.gobject_id,0)
										from gobject gobj
                                        where gobj.tag_name = attr_ref.dest_object_name and gobj.namespace_id = 1)  -- Automation Object


    from @attr_reference_inst attr_ref

	update attr_ref
	set    resolved_gobject_id = 0 
	from @attr_reference_inst attr_ref
	where attr_ref.resolved_gobject_id is null 

	insert into attribute_reference(gobject_id,
							   package_id,
							   referring_mx_primitive_id,
							   referring_mx_attribute_id,
							   element_index,
							   resolved_gobject_id,
							   reference_string,
							   context_string,
							   object_signature,
							   resolved_mx_primitive_id,
							   resolved_mx_attribute_id,
							   resolved_mx_property_id,
							   attribute_signature,
							   lock_type,
							   is_valid,
							   attr_res_status,
							   attribute_index )
	   select attr_ref.gobject_id,
			  attr_ref.package_id,
			  attr_ref.referring_mx_primitive_id,
			  attr_ref.referring_mx_attribute_id,
			  attr_ref.element_index,
			  attr_ref.resolved_gobject_id,
			  attr_ref.reference_string,
			  attr_ref.context_string,
			  attr_ref.object_signature,
			  attr_ref.resolved_mx_primitive_id,
			  attr_ref.resolved_mx_attribute_id,
			  attr_ref.resolved_mx_property_id,
			  attr_ref.attribute_signature,
			  attr_ref.lock_type,
			  attr_ref.is_valid,
			  attr_ref.attr_res_status,
			  attr_ref.attribute_index
	   from   @attr_reference_inst attr_ref       

	end --   else if  ( @isTemplate = 'False' )


	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #dynamic_attributes_table ( 
		 gobject_id                 int,
		 package_id					int,
		 mx_attribute_id			smallint,
         mx_primitive_id			int,
		 attribute_name				nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
		 mx_data_type				smallint,
		 is_array					bit,
		 security_classification	smallint,
		 mx_attribute_category		int,
		 lock_type					int,
		 mx_value					text,
		 owned_by_gobject_id		int,
		 original_lock_type			int,
         dynamic_attribute_type     smallint,
         bitvalues					smallint     
	)

	if (@dynamicattributefileisempty = 0)
	begin
		DECLARE @SQL nvarchar(2000)
		SET @SQL = 'BULK INSERT #dynamic_attributes_table  FROM ''' + @dynamicattributefile+ ''' 
					WITH (FIELDTERMINATOR = '',\t'', TABLOCK, DATAFILETYPE  = ''widechar'') '
		EXEC (@SQL)
	end


	--update the primitive_instance_id & package_id with the new ids
		update dinst
		set dinst.gobject_id = @gobjectid , dinst.package_id = @package_id
		from #dynamic_attributes_table dinst

	--insert the dynamic attributes
	if (@dynamicattributefileisempty = 0)
	begin
		if (exists(select * from #dynamic_attributes_table))
		begin
			insert into dynamic_attribute (
						gobject_id,
						package_id,
						mx_primitive_id,
						mx_attribute_id,
						attribute_name, 
						mx_data_type, 
						is_array, 
						security_classification, 
						mx_attribute_category, 
						lock_type, 
						mx_value, 
						owned_by_gobject_id,
						original_lock_type,
			                        dynamic_attribute_type,
						bitvalues)
			select	@gobjectid,@package_id,
					dInst.mx_primitive_id,
					dInst.mx_attribute_id, 
					dInst.attribute_name, 
					dInst.mx_data_type, 
					dInst.is_array, 
					dInst.security_classification, 
					dInst.mx_attribute_category, 
					dInst.lock_type, 
					dInst.mx_value, 
					case when  dInst.owned_by_gobject_id = 0 then						
						@gobjectid
					else
						dInst.owned_by_gobject_id
					end
					as owned_by_gobject_id,
					dInst.original_lock_type,
                    			dInst.dynamic_attribute_type,
					dInst.bitvalues
			from	#dynamic_attributes_table dInst
		end
	end

-- END : Update dynamic attributes associated with this package

-- BEGIN : Update features assocaited with this gObject

	declare @pinst_feature table
	(
	 feature_id int,
	 feature_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS ,
	 feature_type nvarchar(256)  COLLATE SQL_Latin1_General_CP1_CI_AS,
	 mx_primitive_id int,
 	 package_id int
	)

	--Load all the primitive_instnaces from XML DOM whos feature list needs to be updated
	insert into @pinst_feature
	select *
	from openxml (@h, '/ROOT/gObject/Primitive_Inst/Feature', 1)
	with (	 feature_id int				'./@feature_id',
			 feature_name nvarchar(256)	'./@feature_name',
			 feature_type nvarchar(256)	'./@feature_type',
			 mx_primitive_id int		'./../@mx_primitive_id' ,
	         package_id int				'./../../@package_id' ) o

	--update the primitive_instance_id with the new ids
	update finst
		set finst.package_id = @package_id
		from @pinst_feature finst

	--Insert the new feature associations 
	insert into primitive_instance_feature_link
    (
      gobject_id,
      package_id,
      mx_primitive_id,
      feature_id,
      feature_name,
      feature_type
    )

	select 
        @gobjectid,
        @package_id,
        pif.mx_primitive_id, 
        isnull(f.feature_id,0), 
        isnull(pif.feature_name,''),
        isnull(pif.feature_type,'') 
	from @pinst_feature pif
	left outer join feature f --Find the feature_id
		on  pif.feature_name = f.feature_name 
		and pif.feature_type = f.feature_type

-- END : Update features assocaited with this gObject
    
    if(@WantToCreate_Checked_out_Package = 0)
    begin
        insert into proxy_timestamp(gobject_id)
        select @gobjectid
        
        insert into gobject_filter_info_timestamp(gobject_id)
        select @gobjectid

    end



-- BEGIN : Update primitive_instance_file_table_link this gObject

	declare @pinst_file_table table
	(
	 file_id int,
     is_needed_for_package bit,
     is_needed_for_runtime bit,
     is_needed_for_editor bit,
	 mx_primitive_id int,
 	 package_id int
	)
	--Load all the primitive_instance_file_table_link from XML DOM whos feature list needs to be updated
	insert into @pinst_file_table
	select *
	from openxml (@h, '/ROOT/gObject/Primitive_Inst/FileDependency', 1)
	with (	 file_id int				'./@file_id',
             is_needed_for_package bit  './@is_needed_for_package',
             is_needed_for_runtime bit  './@is_needed_for_runtime',
             is_needed_for_editor bit   './@is_needed_for_editor',
			 mx_primitive_id int		'./../@mx_primitive_id' ,
	         package_id int				'./../../@package_id' ) o

	--update the primitive_instance_id with the new ids
	update  pfinst
    set     pfinst.package_id = @package_id
    from    @pinst_file_table pfinst

	--Insert the new feature associations 
	insert into primitive_instance_file_table_link
    (
      gobject_id,
      package_id,
      mx_primitive_id,
      file_id,
      is_needed_for_package,
      is_needed_for_runtime,
      is_needed_for_editor
    )
	select 
        @gobjectid,
        @package_id,
        mx_primitive_id, 
        file_id,
        is_needed_for_package,
        is_needed_for_runtime,
        is_needed_for_editor
    from @pinst_file_table


-- END : Update primitive_instance_file_table assocaited with this gObject


	drop table #dynamic_attributes_table
	select @gobjectid as gobjectid, @package_id as package_id

    EXECUTE sp_xml_removedocument @h
	if(@namespace_id <>2)
	begin

		--ITVAPP POC integration START
		--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
 	 	
		if(@category_id <> 26 or @template <> 0)
		begin
		exec internal_add_visual_elements_from_parent @gobjectid, @package_id

		declare @parent_package_type nchar
		declare @parent_package_id int -- CR L00123287 cloned from HF CR# L00123250 
		select  @parent_package_type = parent_package.package_type,
				@parent_package_id = parent_package.package_id -- CR L00123287 cloned from HF CR# L00123250 
		from package parent_package with(NOLOCK) 
		inner join package own_package on
			parent_package.package_id = own_package.derived_from_package_id and
			own_package.package_id = @package_id and
			own_package.gobject_id = @gobjectid
		exec internal_add_visual_element_references_from_parent @gobjectid, @package_id, @parent_package_type, @parent_package_id -- CR L00123287 cloned from HF CR# L00123250 
		-- bind the references....
		-- exec internal_bind_relative_visual_elements_for_gobject @gobjectid, @package_id -- this is called from the above stored proc already
		exec internal_bind_visual_element_references -- CR 117307
		end
	end
    

if (@record_change = 1) -- log event if flag was passed...
begin
    -- Validate the user guid that has been passed in....
    if exists(select '*' from user_profile where user_guid = @user_guid)
           if exists(select '*' from user_profile where user_guid = @user_guid)
        begin
            declare @operationId int
            declare @comment nvarchar(256)
            if ((@automation_object_change_has_occured = 1 and @graphic_change_has_occured = 0)
                or (@automation_object_change_has_occured = 0 and @graphic_change_has_occured = 0))
            begin
                set @operationId = 37
                set @comment = 'Updated configuration.'
            end
            else if (@automation_object_change_has_occured = 1 and @graphic_change_has_occured = 1)
            begin
                set @operationId = 39
                set @comment = 'Updated configuration and graphics.'
            end
            else if (@automation_object_change_has_occured = 0 and @graphic_change_has_occured = 1)
            begin
                set @operationId = 38
                set @comment = 'Updated graphics.'
            end

            exec internal_log_changes @gobjectid, @user_guid, @operationId, ''
        end
        else
        begin    
            rollback tran
            return
            /*     this block should be modified to return an error code
                   to indicate that the userId was invalid. -- Anand                 
            */
		end
end


commit tran


go

