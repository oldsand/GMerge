/************************************************************************************/
/*Object Name :  internal_get_graphic_attribute_references                          */
/*Object Type :  Stored Proc.                                                       */
/*Purpose     :  Proc. to retrieve attribute '_AttributeReferenceList' from         */
/*               checked_out_package and checked_in_package of a template           */
/*Used By     :  PackageServer                                                      */
/************************************************************************************/

create proc dbo.internal_get_graphic_attribute_references
    @gobject_id int
as

begin

    set nocount on

    declare @checked_out_package_id int
    declare @checked_in_package_id int

    select  @checked_out_package_id = checked_out_package_id,
            @checked_in_package_id = checked_in_package_id
    from    gobject
    where   gobject_id = @gobject_id


    select  
        pri.gobject_id,
        pri.package_id,
        pri.mx_primitive_id,
        pri.entity_change_type,
        ta.mx_attribute_id,
        ta.mx_value
    from    
        template_attribute ta
    inner join 
        primitive_instance pri
    on  ta.gobject_id = pri.gobject_id
    and ta.package_id = pri.package_id
    and ta.mx_primitive_id = pri.mx_primitive_id
    inner join
        primitive_definition pd
    on  pri.primitive_definition_id = pd.primitive_definition_id
    inner join
        attribute_definition ad
    on  pd.primitive_definition_id = ad.primitive_definition_id
    and ad.mx_attribute_id = ta.mx_attribute_id
    where   
        ad.attribute_name = '_AttributeReferenceList'
    and (pd.primitive_name = 'SymbolExtension'or pd.primitive_name = 'DisplayExtension')
    and pri.gobject_id = @gobject_id
    and pri.package_id = @checked_out_package_id
--    and pri.entity_change_type > 1
    and datalength(ta.mx_value) > 4


    select  
        pri.gobject_id,
        pri.package_id,
        pri.mx_primitive_id,
        pri.entity_change_type,
        ta.mx_attribute_id,
        ta.mx_value
    from    
        template_attribute ta
    inner join 
        primitive_instance pri
    on  ta.gobject_id = pri.gobject_id
    and ta.package_id = pri.package_id
    and ta.mx_primitive_id = pri.mx_primitive_id
    inner join
        primitive_definition pd
    on  pri.primitive_definition_id = pd.primitive_definition_id
    inner join
        attribute_definition ad
    on  pd.primitive_definition_id = ad.primitive_definition_id
    and ad.mx_attribute_id = ta.mx_attribute_id
    where   
        ad.attribute_name = '_AttributeReferenceList'
    and (pd.primitive_name = 'SymbolExtension'or pd.primitive_name = 'DisplayExtension')
    and pri.gobject_id = @gobject_id
    and pri.package_id = @checked_in_package_id
    and datalength(ta.mx_value) > 4


    
end
go

