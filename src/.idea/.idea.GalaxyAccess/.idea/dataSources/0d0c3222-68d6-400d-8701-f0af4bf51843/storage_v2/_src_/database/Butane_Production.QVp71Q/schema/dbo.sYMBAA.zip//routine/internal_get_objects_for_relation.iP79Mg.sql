
/**************************************************
Object Name :  internal_get_objects_for_relation
Object Type :  Stored Proc. 
Purpose	    :  returns gobjectids under given parent for given relation
Used By	    :  packageservernet
typedef [v1_enum] enum ERELATIONSHIP
{
	// Physical/System view
	eAssignment = 1,    	

	// Logical/Factory view
	eContainment,       

	// Derivation view
	eDerivation,        

	// returns objects whose area_gobject_id matches specified object
	eArea,

	// returns objects whose area_gobject_id matches specified object and 
	// are not contained by another gObject.
	eAreaAndNotContained,

	// returns objects whose hosted_by_gobject_id matches specified object
	// and are not contained by another gObject
	eHostAndNotContained,

	// returns all top level areas
	eTopLevelAreas,

	// returns all unassigned gobjects
	eUnassignedObjects,

	// returns all top level gobjects that are not assigned to a platform
	eUnassignedHosts,

	// returns all platforms
	ePlatforms

} ERELATIONSHIP;

**************************************************/

CREATE   PROCEDURE dbo.internal_get_objects_for_relation
@parentgobjectid int,
@relationship int
 AS
begin
SET NOCOUNT ON


--if relation = eArea then
--    if @parentgobjectid.category = area then
--        get all object which has area_gobject_id = @parentgobjectid
--        This will have contained area also because contained area has 
--        contained_gobject_id = area_gobject_id for area category type
--    else
--        return all objects for which contained_gobject_id = @parentgobjectid
--        use internal_get_all_objects_contained_by_gobject
--    end if
--end if
--if relation = eAssignment
--    else if @parentgobjectid.category = Appobject
--        return objects for which contained_by_gobject_id = @parentgobjectid
--        use internal_get_all_objects_contained_by_gobject
--    else 
--        get all objects for which hosted_by_gobject_id = @parentgobjectid
--        -- use internal_get_deployment_view_children
--    end if
--end if
  declare @parentcategory integer
    select
           @parentcategory = td.category_id
     from gobject
     inner join template_definition td
     on td.template_definition_id = gobject.template_definition_id
   
if @relationship = 4 
begin
    if @parentcategory = 13 --idxCategoryArea
        select g.gobject_id from gobject g where area_gobject_id = @parentgobjectid
    else
        exec internal_get_all_objects_contained_by_gobject @parentgobjectid   
end

if @relationship = 1
begin
    if @parentcategory = 10 --idxCategoryApplicationObject
        exec internal_get_all_objects_contained_by_gobject @parentgobjectid
    else
        exec internal_get_deployment_view_children @parentgobjectid
end


SET NOCOUNT OFF

end


go

