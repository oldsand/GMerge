create procedure dbo.internal_update_gobject_timestamp
	@gobject_id int,
	@update_gobject_filter_info_timestamp bit = 0
as
begin
	set nocount on
	begin tran

	delete from
    proxy_timestamp
    where gobject_id = @gobject_id

    insert into proxy_timestamp (gobject_id)
    select @gobject_id 
	
	if(@update_gobject_filter_info_timestamp =1)
	begin
		delete 
		from gobject_filter_info_timestamp
		where gobject_id = @gobject_id

		insert into gobject_filter_info_timestamp (gobject_id)
		select @gobject_id 
	end
    
	update galaxy
    set max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 
   
   
	commit
	set nocount off
end
go

