
/***********************************************************************************************************************************
If you change this you need to check w/ Foxboro. This is used by Foxboro objects in their MigratePrimitive methods -- HF1467 CR93406
************************************************************************************************************************************/

--add folder with given input name
--if input folder_name is empty then use base_folder_name
--to construct new folder name  
--
--
--declare @P1 int
--set @P1=50
--exec internal_add_folder @folder_type = 1, @folder_name = N'      ', @base_folder_name = N'New Folder_012', @parent_folder_id = 49, @new_folder_id = @P1 output
--select @P1

create proc dbo.internal_add_folder
(
	@folder_type smallint,
	@folder_name nvarchar(64),
	@base_folder_name nvarchar(64),
	@parent_folder_id int,
	@new_folder_id int out
)
AS
begin

	declare @ErrorCode int
    set @new_folder_id = 0
    
    begin tran

    if(len(LTRIM(RTRIM(@folder_name))) = 0)
    begin
        if(len(LTRIM(RTRIM(@base_folder_name))) = 0)
        begin
            set @ErrorCode = 1003 -- @base_folder_name and @folder_name cannot be null
            rollback
            return @ErrorCode    
        end        
        else
           begin
                declare @uniqueName nvarchar(64)
                exec internal_get_unique_folder_name    @base_folder_name,
                                             @parent_folder_id,
                                             @folder_type,
                                             @uniqueName out 
                set @folder_name = @uniqueName
            end
    end

    declare @depth int
    declare @parent_folder_type int
    set @parent_folder_type = 0
    set  @depth = 1
    if (@parent_folder_id <> 0) 
    begin
       select @depth = depth, @parent_folder_type = folder_type from folder where folder_id = @parent_folder_id
       set @depth = @depth + 1     

       if(@folder_type <> @parent_folder_type)
       begin
           set @ErrorCode = 1000 -- folder_type of parent_folder should be same as that of newly added folder
           rollback
           return @ErrorCode
       end
    end 


    if(@depth > 10)
    begin
        set @ErrorCode = 1001 -- depth cannot be more than 10
        rollback
        return @ErrorCode
    end

    if(exists(select '*' from folder where folder_name = @folder_name
    and folder_type = @folder_type and parent_folder_id = @parent_folder_id))
    begin
        set @ErrorCode = 1002 -- folder name cannot be duplicated in same parent
        rollback
        return @ErrorCode
    end
    

    
        insert into folder 
        (folder_type,folder_name,parent_folder_id,depth,has_objects,has_folders)
        values
        (@folder_type,@folder_name,@parent_folder_id,@depth,0,0)

        update folder set has_folders = 1 
        where folder_id = @parent_folder_id

    set @ErrorCode = @@error
    if @ErrorCode <> 0 begin
        rollback
        return @ErrorCode
    end



	set @new_folder_id = @@identity

    update galaxy
    set max_proxy_timestamp = CAST ( @@dbts  AS timestamp )     


    commit
	return @ErrorCode

end
go

