/**************************************************/
/*Object Name :  internal_isListMixedCustomPackages			  */
/*Object Type :  Stored Proc.					  */
/*Purpose	  :  Proc. to count the unique custom category packages in the listed objects */
/*Used By	  :  CDI() */
/**************************************************/

create	procedure dbo.internal_is_list_mixed_custom_packages
    @FileNameOfIds nvarchar (265),
	@isMixedCustomPackages int output,
	@isCustomPackages int output
AS
begin
	set QUOTED_IDENTIFIER OFF

    create table #input_table ( gobject_id int)
    
	declare @template_ids table ( ids int, gobject_id int)
	
	declare @SQL nvarchar(2000)

	set @SQL = 'BULK INSERT #input_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	exec (@SQL)


	insert into @template_ids 
    (
        ids, 
        gobject_id 
    )
	select 
        template_definition.category_id, 
        g.gobject_id
	from template_definition
	inner join gobject g 
        on template_definition.template_definition_id = g.template_definition_id
	inner join #input_table idTable on 
        idTable.gobject_id = g.gobject_id	

	select 1 from @template_ids ti
	where ti.ids = 25	

	if (@@ROWCOUNT = 0)
	begin
		set @isMixedCustomPackages = 0
		set @isCustomPackages = 0
	end
	else
	begin
		set @isCustomPackages = 1

		select distinct template_definition.category_clsid
		from template_definition
		inner join @template_ids ti
		    on template_definition.category_id = ti.ids
		inner join gobject g
		    on template_definition.template_definition_id = g.template_definition_id
		where ti.gobject_id = g.gobject_id

		if (@@ROWCOUNT = 1)
		begin
			set @isMixedCustomPackages = 0
		end
		else
		begin
			set @isMixedCustomPackages = 1
		end
	end


end

go

