create proc dbo.internal_can_assign_objects(
	@childIdList nvarchar(255),
	@parentId int,
	@assocType smallint ) 
As
BEGIN
	set nocount on
	
	declare @gobject_id int
	declare @parentHeight int	

	create table  #childList (gobject_id int)
	DECLARE @gSQL nvarchar(2000)
	SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
				WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
	EXEC sp_executesql @gSQL
	
	declare @InvalidObjects table(gobject_id int, error_code smallint)

	declare @CanAssignTable table(gobject_id int, cat_id smallint, is_deployed bit, descendant_depth smallint, my_container int, deployed_package int)
	insert into @CanAssignTable 
	select 	G.gobject_id, 
			T.category_id,
			case when deployed_package_id > 0 then 1 else 0 end,
			1,
			H.gobject_id, 
			G.deployed_package_id
	from #childList H inner join gobject G on H.gobject_id = G.gobject_id
	inner join template_definition T on T.template_definition_id = G.template_definition_id



	declare @nChildDepth smallint

	-- Get the type of the parent
	declare @parentCategory smallint
	select @parentCategory = category_id
	from gobject inner join template_definition
	on gobject.template_definition_id = template_definition.template_definition_id
	where gobject_id = @parentId	

	-- Cannot assign any deployed object
	insert into @InvalidObjects select gobject_id, 1 from @CanAssignTable where is_deployed = 1
	delete from @CanAssignTable where is_deployed = 1


	-- Cannot assign any objects which contain deployed objects..
	declare @objects_that_have_been_invalidated_by_last_check table (gobject_id int)

	insert into @InvalidObjects
	output inserted.gobject_id into @objects_that_have_been_invalidated_by_last_check
	select 
		c.gobject_id, 
		3
	from @CanAssignTable c
	where (dbo.has_contained_deployed_children(c.gobject_id)>0)
	
	delete cat
	from @CanAssignTable cat
	inner join @objects_that_have_been_invalidated_by_last_check i on
		cat.gobject_id = i.gobject_id

	delete 
	from @objects_that_have_been_invalidated_by_last_check

	
	--Cannot UnAssign NTPlatForm or AppEngine if Childreens are deployed. L00024190
	IF @parentId = 0
	BEGIN
		insert into @InvalidObjects 
		select gobject_id, 3 from @CanAssignTable 
		where dbo.is_gobject_has_deployed_hosted_objects(gobject_id) <> 0 and (cat_id = 3 or cat_id = 1)

		delete from @CanAssignTable 
		where dbo.is_gobject_has_deployed_hosted_objects(gobject_id) <> 0 and (cat_id = 3 or cat_id = 1)
	END


	IF @assocType = 1 	-- SET HOST : Parent can be PLATFORM / ENGINE / DEVICE
	BEGIN
		IF @parentCategory = 1  			-- Platform , children have to be engines
			insert into @InvalidObjects 
			select gobject_id, 2 from @CanAssignTable
			where cat_id = 1 or cat_id > 9
		ELSE IF @parentCategory = 4
		BEGIN
			-----------------------------
			declare @hosted_child_list table(gid int,derived_from_gobject_id int)			
			--we may have duplicate gid when object is allready assigned & try to assigned to same parent
			
			--get all existing childs
			insert into	@hosted_child_list
			select g.gobject_id , g.derived_from_gobject_id 
			from gobject g 			
			where  @parentId = g.hosted_by_gobject_id
            and hosting_tree_level = 4
			
			--add @ObjectInfo
			insert into	@hosted_child_list
			select g.gobject_id , g1.derived_from_gobject_id 
			from @CanAssignTable g 
            inner join gobject g1
            on g.gobject_id = g1.gobject_id

			--@InvalidObjects
			insert into @InvalidObjects
			select g.gobject_id,6
			from @CanAssignTable g 
            inner join @hosted_child_list hl 
            on hl.gid = g.gobject_id 
			where hl.derived_from_gobject_id in (select derived_from_gobject_id from @hosted_child_list where gid <> g.gobject_id)
			and g.cat_id = 26
			-------------------			
		END

		ELSE IF @parentCategory < 10		-- Parent is Engine, chidren has to be Area,Device or IONetwork
		BEGIN	-- This check is not needed but we are leaving it as such
			insert into @InvalidObjects	
			select gobject_id, 2 from @CanAssignTable
			where cat_id < 11 or (cat_id > 13 and cat_id <> 24)
			
		END

		ELSE IF (@parentCategory = 12 or @parentCategory = 11 or @parentCategory = 24) 
			insert into @InvalidObjects	
			select gobject_id, 2 from @CanAssignTable
			where cat_id <> 12

		ELSE IF @parentCategory = 23 
			insert into @InvalidObjects	
			select gobject_id, 2 from @CanAssignTable
			where cat_id <> 25

	END	

	ELSE IF @assocType = 2  -- SET AREA: Parent can only be AREA, Children have to be Engines, Devices, IONetworks,Areas or AppObjects
	BEGIN

		insert into @InvalidObjects
		select gobject_id, 2 from @CanAssignTable
		where (cat_id < 1  or (cat_id > 13 and cat_id <> 24 and cat_id <> 25  and cat_id <> 17 and cat_id <> 26) )

		insert into @InvalidObjects
		select gobject_id, 5 from @CanAssignTable
		where (cat_id = 3) and ( dbo.is_partner_deployed(gobject_id) = 1)	

			IF exists ( select gobject_id from @CanAssignTable where cat_id = 13 )
			BEGIN
				-- Add all descendants of Areas ( by containment )
				set @nChildDepth = 1
				
				-- Get all contained descendants  
				WHILE 1 > 0
				BEGIN
					insert into @CanAssignTable 
					select A.gobject_id, A.cat_id, A.is_deployed, A.descendant_depth + 1, G.gobject_id, 
					case when A.deployed_package > 0 then A.deployed_package else G.deployed_package_id end
					from @CanAssignTable A inner join gobject G on G.contained_by_gobject_id = A.my_container
					where A.descendant_depth = @nChildDepth
					if @@rowcount = 0 break
				
					set @nChildDepth = @nChildDepth + 1
				END
				
				-- set the depth level and has children deployed
				update @CanAssignTable set deployed_package = CD.deploy_package
				from  @CanAssignTable A inner join (select 	gobject_id, 															
															max(deployed_package) as deploy_package
													from 	@CanAssignTable where descendant_depth > 1
													group by gobject_id ) CD
				on A.gobject_id = CD.gobject_id
				
				-- Remove all the child level added
				delete from @CanAssignTable where gobject_id <> my_container			

				-- Check if any assignment will result more than 10 levels
				set @gobject_id = @parentId
				set @parentHeight = 0

				while @gobject_id <> 0
				BEGIN
					set @parentHeight = @parentHeight + 1
					select @gobject_id = contained_by_gobject_id 
					from gobject where gobject_id = @gobject_id
				END
				
				insert into @InvalidObjects select gobject_id, 4 from @CanAssignTable
				where descendant_depth > ( 10 - @parentHeight )

			END

	END
	
	ELSE IF @assocType = 3
	BEGIN
		-- Remove any objects which is not an Area or AppObject
		IF @parentCategory = 13
		BEGIN
			insert into @InvalidObjects
			select gobject_id, 2 from @CanAssignTable
			where cat_id <> 13

			delete from @CanAssignTable
			where cat_id <> 13
		END

		ELSE IF @parentCategory = 10
		BEGIN
			insert into @InvalidObjects
			select gobject_id, 2 from @CanAssignTable
			where cat_id <> 10

			delete from @CanAssignTable
			where cat_id <> 10
		END

		-- Add all descendants of Areas or AppObjects		
		set @nChildDepth = 1
		
		-- Get all contained descendants  
		WHILE 1 > 0
		BEGIN
			insert into @CanAssignTable 
			select A.gobject_id, A.cat_id, A.is_deployed, A.descendant_depth + 1, G.gobject_id, 
			case when A.deployed_package > 0 then A.deployed_package else G.deployed_package_id end
			from @CanAssignTable A inner join gobject G on G.contained_by_gobject_id = A.my_container
			where A.descendant_depth = @nChildDepth
			if @@rowcount = 0 break
		
			set @nChildDepth = @nChildDepth + 1
		END
		
		-- set the depth level and has children deployed
		update @CanAssignTable set descendant_depth = CD.depth, deployed_package = CD.deploy_package
		from  @CanAssignTable A inner join (select 	gobject_id,  
													max(descendant_depth) as depth, 
													max(deployed_package) as deploy_package
											from 	@CanAssignTable where descendant_depth > 1
											group by gobject_id ) CD
		on A.gobject_id = CD.gobject_id
		
		-- Remove all the child level added
		delete from @CanAssignTable where gobject_id <> my_container

		-- Check if any assignment will result more than 10 levels
		set @gobject_id = @parentId
		set @parentHeight = 0

		while @gobject_id <> 0
		BEGIN
			set @parentHeight = @parentHeight + 1
			select @gobject_id = contained_by_gobject_id 
			from gobject where gobject_id = @gobject_id
		END
		
		insert into @InvalidObjects select gobject_id, 4 from @CanAssignTable
		where descendant_depth > ( 10 - @parentHeight )

		-- And any objects which has children deployed
		insert into @InvalidObjects select gobject_id, 3 from @CanAssignTable
		where deployed_package > 0
			
	END

		-- FOR CUSTOM CATEGORY OBJECTS CHECK THE HOST/CONTAINED RELATIONSHIP TO CHECK
		-- WHETHER OBJECTS CAN BE ASSIGNED OR NOT
		declare @nLevel int
		IF @parentCategory = 25
		BEGIN 
			declare @ObjectTree table(obj_id int, nLevel smallint, hosted_by_gobject_id int)
			
			insert into @ObjectTree select 
			g.gobject_id,1,g.hosted_by_gobject_id
			from gobject g where gobject_id = @parentId
		
			set @nLevel = 1	
			while 1 > 0
			BEGIN
				 --Get the next Level
				insert into @ObjectTree
					select G.gobject_id,  @nLevel + 1 ,G.hosted_by_gobject_id
						   from gobject G inner join @ObjectTree OT 
							on G.gobject_id = OT.hosted_by_gobject_id
				where OT.nLevel = @nLevel

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1
			END	-- while	
			
			insert into @InvalidObjects	
			select ct.gobject_id, 2 from @CanAssignTable ct
			inner join @ObjectTree ot on 
			(ct.gobject_id = ot.obj_id) or (ct.cat_id <> 25)
		END

		IF @parentCategory = 25
		BEGIN 

			declare @ObjectTree1 table(obj_id int, nLevel smallint, contained_by_gobject_id int)
			
		
			insert into @ObjectTree1 select 
			g.gobject_id,1,g.contained_by_gobject_id
			from gobject g where gobject_id = @parentId
		
			set @nLevel = 1	
			while 1 > 0
			BEGIN
				 --Get the next Level
				insert into @ObjectTree1
					select G.gobject_id,  @nLevel + 1 ,G.contained_by_gobject_id
						   from gobject G inner join @ObjectTree1 OT 
							on G.gobject_id = OT.contained_by_gobject_id
				where OT.nLevel = @nLevel

				if @@rowcount = 0 break
				set @nLevel = @nLevel + 1
			END	-- while	
			
			insert into @InvalidObjects	
			select ct.gobject_id, 2 from @CanAssignTable ct
			inner join @ObjectTree1 ot on 
			(ct.gobject_id = ot.obj_id) or (ct.cat_id <> 25)
		END

	select distinct * from @InvalidObjects
	
END


go

