-- Not being used ???
--
create proc dbo.internal_create_descendents_package_from_template
    @user_guid nvarchar(64),
    @template_gobject_id int,
	@FileNameOfIds nvarchar (265),
	@result int out
as
begin
	set nocount on
	
	begin transaction

	
	DECLARE @descendent_id_table table( gobject_id int )


	-- Now the @descendent_id_table holds all the objects 
	-- which are descedents of @template_gobject_id

			
	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #results_table ( gobject_id int)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	EXEC sp_executesql @SQL

	insert into @descendent_id_table( gobject_id )
		( select gobject_id from #results_table )

	drop table #results_table

	declare @descendent_object_id int

	while (select count(*) from @descendent_id_table) > 0
	begin
		set rowcount 1

		set	@descendent_object_id = 0

		select	@descendent_object_id = gobject_id
		from	@descendent_id_table

		set rowcount 0

		if (@descendent_object_id <> 0)
		begin

			-- Create the package row
			insert into package
			(
					gobject_id,
					status_id,
					operation_status,
					security_group,
					derived_from_package_id
			)
			select	@descendent_object_id,
					pa.status_id,
					1,
					pa.security_group,
					go.checked_out_package_id
			from	package pa,
					gobject go
			where	pa.package_id = go.checked_out_package_id
				and go.gobject_id = @template_gobject_id

			if (@@error <> 0)
				break

			-- Update the gobject row
			update	gobject
			set		checked_out_package_id = pa.package_id,
					checked_out_by_user_guid = @user_guid
			from	gobject go,
					package pa
			where	go.gobject_id = @descendent_object_id
			and		go.gobject_id = pa.gobject_id
			and		pa.operation_status = 1

			if (@@error <> 0)
				break

			-- Now make a copy of the primitive instance
			insert into primitive_instance
			(
					gobject_id,
					package_id,
					primitive_definition_id,
					primitive_name,
					mx_primitive_id,
					parent_mx_primitive_id,
					execution_group,
					execution_order,
					owned_by_gobject_id,
					extension_type,
					is_object_extension,
					entity_change_type,
					operation_on_primitive_mask
			)
			select	go.gobject_id,
					go.checked_out_package_id,
					primitive_definition_id,
					primitive_name,
					mx_primitive_id,
					parent_mx_primitive_id,
					execution_group,
					execution_order,
					owned_by_gobject_id,
					extension_type,
					is_object_extension,
					1,
					0
					
			from	gobject go,
					primitive_instance pri,
					gobject tpgo
			where	go.gobject_id = @descendent_object_id
				and	pri.package_id = tpgo.checked_out_package_id
				and	tpgo.gobject_id = @template_gobject_id

			if (@@error <> 0)
				break


			-- Template attribute
			if (exists(select * from gobject where gobject_id = @descendent_object_id and is_template=1))
			begin
				insert into template_attribute
				(
						gobject_id,
						package_id,
						mx_primitive_id,
						mx_attribute_id,
						security_classification,
						mx_data_type,
						mx_value,
						lock_type,
						original_lock_type
				)
				select	go.gobject_id,
						go.checked_out_package_id,
						ta.mx_primitive_id,
						ta.mx_attribute_id,       				-- mx_attribute_id
						ta.security_classification, 			-- security_classification
						ta.mx_data_type, 						-- mx_data_type
						ta.mx_value, 							-- mx_value

						case when ta.lock_type = 0 then			-- UnLocked
							case when ta.original_lock_type = 2 then	-- If original lock is lock_in_parent
								1										-- then it should be lock_in_me
							when ta.original_lock_type = 1 then			-- If original lock is lock_in_me
								1										-- then it should be lock_in_parent.
							else
								0										-- Otherwise, it should be unlocked
							end
						when ta.lock_type = 1 then			-- MxLockedInMe
							2										-- Same
						when ta.lock_type = 2 then			-- MxLockedInParent
							2										-- same
						end,

						case when ta.lock_type = 0 then			-- UnLocked
							case when ta.original_lock_type = 2 then	-- If original lock is lock_in_parent
								1										-- then it should be lock_in_me
							when ta.original_lock_type = 1 then			-- If original lock is lock_in_me
								1										-- then it should be lock_in_me.
							else
								0										-- Otherwise, it should be unlocked
							end
						when ta.lock_type = 1 then			-- MxLockedInMe
							2										-- Same
						when ta.lock_type = 2 then			-- MxLockedInParent
							2										-- same
						end


				from 	template_attribute ta,
						gobject            go,
						gobject            tpgo						
				where	tpgo.gobject_id =  @template_gobject_id
					and ta.package_id = tpgo.checked_out_package_id
					and go.gobject_id = @descendent_object_id

				if (@@error <> 0)
					break
			end

			-- Now make a copy of dynamic attributes
			insert into dynamic_attribute
			(
					gobject_id,
					package_id,
					mx_primitive_id,
					mx_attribute_id,
					attribute_name,
					mx_data_type,
					is_array,
					security_classification,
					mx_attribute_category,
					lock_type,
					mx_value,
					owned_by_gobject_id,
					original_lock_type,
                    dynamic_attribute_type,
                    bitvalues

			)
			select	go.gobject_id,
					go.checked_out_package_id,
					da.mx_primitive_id,
					da.mx_attribute_id,       
					da.attribute_name,
					da.mx_data_type,
					da.is_array,
					da.security_classification,
					da.mx_attribute_category,

					case when go.is_template = 1 then	-- If it is template
						case when da.lock_type = 0 then			-- UnLocked
							case when da.original_lock_type = 2 then	-- If original lock is lock_in_parent
								1										-- then it should be lock_in_me
							when da.original_lock_type = 1 then			-- If original lock is lock_in_me
								1										-- then it should be lock_in_parent.
							else
								0										-- Otherwise, it should be unlocked
							end
						when da.lock_type = 1 then			-- MxLockedInMe
							2										-- Same
						when da.lock_type = 2 then			-- MxLockedInParent
							2										-- same
						end
					else									-- If it is instance
						case when da.lock_type = 0 then			-- UnLocked
							0										-- Otherwise, it should be unlocked
						when da.lock_type = 1 then			-- MxLockedInMe
							2										-- Same
						when da.lock_type = 2 then			-- MxLockedInParent
							2										-- same
						end
					end,				
					da.mx_value,
					da.owned_by_gobject_id,

					case when da.lock_type = 0 then			-- UnLocked
						case when da.original_lock_type = 2 then	-- If original lock is lock_in_parent
							1										-- then it should be lock_in_me
						when da.original_lock_type = 1 then			-- If original lock is lock_in_me
							1										-- then it should be lock_in_parent.
						else
							0										-- Otherwise, it should be unlocked
						end
					when da.lock_type = 1 then			-- MxLockedInMe
						2										-- Same
					when da.lock_type = 2 then			-- MxLockedInParent
						2										-- same
					end,

                    da.dynamic_attribute_type,
                    da.bitvalues

			from 	dynamic_attribute da,
					gobject           tpgo,
					gobject           go
			where	tpgo.gobject_id = @template_gobject_id
			and     da.package_id = tpgo.checked_out_package_id
			and     go.gobject_id = @descendent_object_id

			if (@@error <> 0)
				break

			-- Now make a copy of features
			insert into primitive_instance_feature_link
			(
					gobject_id,
					package_id,
					mx_primitive_id,
					feature_id,
					feature_name,
					feature_type
			)
			select	go.gobject_id,
					go.checked_out_package_id,
					f.mx_primitive_id,
					f.feature_id,
					f.feature_name,
					f.feature_type
			from	primitive_instance_feature_link f,
					gobject                         tpgo,
					gobject                         go
			where   tpgo.gobject_id = @template_gobject_id
			and     f.package_id = tpgo.checked_out_package_id
			and     go.gobject_id = @descendent_object_id

			if (@@error <> 0)
				break

			--update package status
			update	package
			set		operation_status = 2
			from	package pa,
					gobject go
			where	pa.package_id = go.checked_out_package_id
				and	go.gobject_id = @descendent_object_id


			-- Delete it and go to next one
			delete	@descendent_id_table
			where	gobject_id = @descendent_object_id
		end
		else
		begin
			break
		end
	end


	if (@@error <> 0)
	begin
		rollback transaction
		set @result = 0
	end
	else
	begin
		commit transaction
		set @result = 1
	end

	
end
go

