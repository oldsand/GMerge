/**************************************************
Object Name :  internal_migrate_objects_info.sql
Object Type :  Stored Proc. 
Purpose     :  This procedure migrates object information from old objects
               to new objects and remove oldobjects.
Example     :  exec internal_migrate_objects_info 'c:\temp\3.txt'
***************************************************/

create PROCEDURE dbo.internal_migrate_objects_info
    @FileNameOfIds nvarchar (400)
as
begin
begin tran
    set nocount on

    create table #ObjectsMap ( 
                old_gobject_id int, 
                new_gobject_id int, 
                nLevel int)

    create index i1 on #ObjectsMap(old_gobject_id)
    create index i2 on #ObjectsMap(new_gobject_id)


    DECLARE @SQL nvarchar(2000) 
    SET @SQL = 'BULK INSERT #ObjectsMap FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE = ''widechar'', FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'')'
    EXEC (@SQL)

    -- Update old, new gobject_id
    update gobject set hosted_by_gobject_id = map.new_gobject_id
    from gobject inner join #ObjectsMap map on hosted_by_gobject_id = map.old_gobject_id

    update gobject set area_gobject_id = map.new_gobject_id
    from gobject inner join #ObjectsMap map on area_gobject_id = map.old_gobject_id

    update gobject set contained_by_gobject_id = map.new_gobject_id
    from gobject inner join #ObjectsMap map on contained_by_gobject_id = map.old_gobject_id



   
    declare @nLevel int
    select  @nLevel = max(nLevel) 
    from    #ObjectsMap

    while (@nLevel >= 0)
    begin
   
		-- Update the gobject table
		update  VS8
		set     tag_name = VS7.tag_name,
				contained_by_gobject_id = VS7.contained_by_gobject_id,
				area_gobject_id = VS7.area_gobject_id,
				hosted_by_gobject_id = VS7.hosted_by_gobject_id,
				contained_name = VS7.contained_name,
				configuration_version = VS7.configuration_version,
				hosting_tree_level = case when  VS7.hosting_tree_level > 0 then VS7.hosting_tree_level else VS8.hosting_tree_level end,
				hierarchical_name = VS7.hierarchical_name
		from    gobject VS8 
				inner merge join #ObjectsMap on VS8.gobject_id = new_gobject_id
				inner hash join gobject VS7 on VS7.gobject_id = old_gobject_id
				where #ObjectsMap.nLevel = @nLevel
		



        -- go to next level
        set @nLevel = @nLevel -1
    end


   
    -- Update the platform table, we have to delete the new entry first before we can update platform_gobject_id
    -- Note that we delete the newly created platforms instead of old ( so that we can preserve the old platform id )
    delete  platform 
    from    platform plat inner join #ObjectsMap map on plat.platform_gobject_id = map.new_gobject_id

    update  platform 
    set     platform_gobject_id = map.new_gobject_id
    from    platform inner join #ObjectsMap map on platform_gobject_id = map.old_gobject_id 

    -- Update the change log
    -- Delete the log messages created by migration
    delete  gobject_change_log
    from    gobject_change_log inner join #ObjectsMap map on gobject_id = map.new_gobject_id
	where map.nLevel > 0
    
	update  gobject_change_log
    set     gobject_id = map.new_gobject_id
    from    gobject_change_log inner join #ObjectsMap map on gobject_id = map.old_gobject_id
	where   map.nLevel > 0
    
	-- Update the folder_gobject_link table
	delete folder_gobject_link 
	from 	folder_gobject_link inner join 
	#ObjectsMap map 
	on gobject_id = map.new_gobject_id

    update  folder_gobject_link
    set     gobject_id = map.new_gobject_id
    from    folder_gobject_link inner join #ObjectsMap map 
	on gobject_id = map.old_gobject_id  

    select  inst.* into #instance_bak
    from    instance inst,
            #ObjectsMap map
    where   inst.gobject_id = map.old_gobject_id

    update  #instance_bak
    set     gobject_id = map.new_gobject_id
    from    #instance_bak instbak,
            #ObjectsMap map
    where   instbak.gobject_id = map.old_gobject_id

	create index ib on #instance_bak(gobject_id)
        
	update gobject set derived_from_gobject_id = 0
	from gobject, #ObjectsMap map
	where gobject.gobject_id = map.old_gobject_id


    insert into alarm_message_timestamps(gobject_id, timestamp_of_populate)
		select map.new_gobject_id, amt.timestamp_of_populate from alarm_message_timestamps as amt 
		inner join #ObjectsMap map on  amt.gobject_id = map.old_gobject_id
	
    update alarm_messages
	set gobject_id = map.new_gobject_id,
	package_id = g.checked_in_package_id
	from alarm_messages am
	inner join #ObjectsMap map on am.gobject_id = map.old_gobject_id
	inner join gobject g on g.gobject_id =  map.new_gobject_id
	
    delete alarm_message_timestamps
	from alarm_message_timestamps ams inner join #ObjectsMap map on ams.gobject_id = map.old_gobject_id

	--SAL object protection logic
	insert into gobject_protected (gobject_id) 
	select map.new_gobject_id from #ObjectsMap map
	inner join gobject_protected gp on gp.gobject_id = map.old_gobject_id and map.nLevel > 0
			
    delete  gobject_protected 
    from    gobject_protected gp, #ObjectsMap map
    where   gp.gobject_id = map.old_gobject_id
	and   map.nLevel > 0
	--SAL end

    delete  gobject 
    from    gobject go, #ObjectsMap map
    where   go.gobject_id = map.old_gobject_id
	and   map.nLevel > 0
   
    update  attribute_reference 
    set     is_valid = 1,
            resolved_mx_primitive_id=0 
    from    attribute_reference ar inner join #ObjectsMap map
        on  ar.resolved_gobject_id = map.old_gobject_id  
	where   map.nLevel > 0


    update  instance
    set     mx_platform_id = instbak.mx_platform_id,
            mx_engine_id = instbak.mx_engine_id,
            mx_object_id = instbak.mx_object_id
    from    instance inst inner join #instance_bak instbak on inst.gobject_id = instbak.gobject_id 
	

    delete  template_definition
    from    template_definition td inner join #ObjectsMap map on td.base_gobject_id = map.old_gobject_id    
    where   map.nLevel > 0


    update  attribute_reference
    set     context_string = gobject.tag_name
    from    attribute_reference 
	inner join gobject on gobject.gobject_id = attribute_reference.gobject_id
	inner join #ObjectsMap map on map.new_gobject_id = gobject.gobject_id
    where   map.nLevel > 0


    


    
commit tran

end
go

