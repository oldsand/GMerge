CREATE PROCEDURE dbo.internal_ab_create_xlate_rule
      @rule_name    nvarchar (329)
    , @gsub_pattern nvarchar (1024)
as
begin
    set nocount on

	declare @result int
	set @result = -1

	insert into autobind_translation_rule (xlate_rule_name, xlate_rule_gsub_str) values (@rule_name, @gsub_pattern)
	if @@ROWCOUNT <> 0
	begin
		set @result = @@IDENTITY
	end
    return @result
end
go

