create procedure dbo.internal_is_client_out_of_sync
	@client_id nvarchar(4000),
	@client_name nvarchar(64),
	@last_synchronized_timestamp bigint,
    @out_of_sync int out, -- 0 implies in sync, 1 implies out of sync
	@return_client_id nvarchar(4000) out 
as
begin
	set nocount on
	-- Create client control exclusion list
	CREATE TABLE  #cc_file_exclusion_table ( 
		file_id				int
	); 

	-- Populate it per the stored procedure. Once populated, this file will contain a list
	-- of file-ids representing client-control objects. These are not undeployed from 
	-- the client node by GOCS.
	insert into		#cc_file_exclusion_table
	select			pf.file_id 
	from			primitive_instance_file_table_link pf 
	inner join		client_control_class_link cc 
			on		pf.gobject_id = cc.gobject_id
	begin tran

	set @return_client_id = @client_id;
	
	declare @filesdeployedtoclient int
	select @filesdeployedtoclient = count(*) from deployed_file df 	
	 left outer join  #cc_file_exclusion_table cx
			on		cx.file_id = df.file_id
			where upper(df.node_name) = upper(@client_name)	and	cx.file_id is null	and (( df.is_editor_deployed = 1 or df.is_package_deployed = 1 or df.need_to_delete = 1))

	if exists( select '*' from client_info where upper(client_name) = upper(@client_name))
	begin
		if exists( select '*' from client_info where client_unique_identifier = @client_id and upper(client_name) = upper(@client_name))
			begin
				if exists( select 1 from client_info where client_unique_identifier = @client_id and upper(client_name) = upper(@client_name)
						and timestamp_of_last_synchronized = @last_synchronized_timestamp)
					begin
						set @out_of_sync = 0;
					end
				else
					begin
						set @out_of_sync = 1;
					end
			end
		else
			begin
				if ( ISNULL(@client_id,'' ) = '' )
				begin										
					set @out_of_sync = 0;
					set @return_client_id = newID();
					update client_info
					set client_unique_identifier = @return_client_id,
					timestamp_of_last_synchronized = @last_synchronized_timestamp,
					deployed_files_count = @filesdeployedtoclient
							where upper(client_name) = upper(@client_name) 
					
					-- if ClientID is Null, which means Client if fresh, then if Server has got some information which got deployed to the client
					-- then we need clean up the server. and make sync with Client , so that next time when client access the object, new files will be deployed
					-- This is very rare case scenario but tried to address all if else conditions knowingly what is going to happen

					delete df  from deployed_file df
					left outer join  #cc_file_exclusion_table cx	
							on		cx.file_id = df.file_id
				     where upper(node_name) = upper(@client_name)
				     	and		cx.file_id is null							
						and ((is_editor_deployed = 1	or is_package_deployed = 1 or need_to_delete = 1)and is_runtime_deployed <> 1)
							
					update df set is_editor_deployed = 0,is_package_deployed = 0
						from deployed_file df left outer join  #cc_file_exclusion_table cx	
							on		cx.file_id = df.file_id
					  where upper(node_name) = upper(@client_name) 	
					  	and		cx.file_id is null						
						and (is_runtime_deployed = 1)
				end
				else
				begin
					set @out_of_sync = 1
				end		
			end
	end
	else
	begin
		if ( ISNULL(@client_id,'' ) = '' )
		begin				
			set @out_of_sync = 0
			set @return_client_id = newID()
			

			insert into client_info
			values
			(@return_client_id, 
			upper(@client_name),
			@filesdeployedtoclient,
			 GetDate(),
			 @last_synchronized_timestamp )
		end
		-- For CR L00106583 
		else
		begin
		if ( @last_synchronized_timestamp = 0 )
		begin				
			set @out_of_sync = 0
			set @return_client_id = newID()
			

			insert into client_info
			values
			(@return_client_id, 
			upper(@client_name),
			@filesdeployedtoclient,
			 GetDate(),
			 @last_synchronized_timestamp )
		end
		else
		begin
			set @out_of_sync = 1				
		end
						
		end
		end
  DROP TABLE #cc_file_exclusion_table
	commit
	
end
go

