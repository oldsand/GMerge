
create  trigger trigger_insert_primitive_instance 
on primitive_instance
for insert
as
set nocount on
-- obtain a new timestamp to insert into primitive_instance..
declare @new_timestamp bigint    
exec internal_get_next_timestamp @new_timestamp out

update  pri 
    set     timestamp_of_last_change = @new_timestamp
    from    primitive_instance pri
    inner   join inserted i on 
            i.gobject_id = pri.gobject_id and 
            i.package_id = pri.package_id and
            i.mx_primitive_id = pri.mx_primitive_id and
            i.timestamp_of_last_change = 0

go

