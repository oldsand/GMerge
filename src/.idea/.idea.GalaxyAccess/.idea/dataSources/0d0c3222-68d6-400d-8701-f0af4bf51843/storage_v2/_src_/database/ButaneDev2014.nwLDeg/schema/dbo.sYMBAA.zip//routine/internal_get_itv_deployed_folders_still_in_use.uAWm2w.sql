
/*
    takes gobject_ids of objects being undeployed.
	does the following:
	1) Returns the template names and their deployed folder still in use

*/

create proc dbo.internal_get_itv_deployed_folders_still_in_use
@file_name_of_ids nvarchar (265)	
as
begin tran

	create table  #undeployed_objects( gobject_id int primary key)
	declare @sql nvarchar(2000)
	set @sql = 'bulk insert #undeployed_objects  from ''' + @file_name_of_ids + ''' with(tablock,datafiletype  = ''widechar'')'
	exec (@sql)
		
	create table #parent
	( 
		gobject_id int,
		tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
	)
	insert into #parent
	(
		gobject_id,
		tag_name
	)
	select 
		distinct
		instance_g.derived_from_gobject_id,
		template_g.tag_name
	from gobject instance_g
	inner join #undeployed_objects gd on 
		gd.gobject_id = instance_g.gobject_id
	inner join gobject template_g on
		instance_g.derived_from_gobject_id = template_g.gobject_id
	inner join template_definition td on 
		td.template_definition_id = template_g.template_definition_id and 
		td.category_id = 26
	
	declare @in_use_deployed_package_info table
	( 
	  parent_tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
	  in_use_deployed_package_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
	)


			
	insert into @in_use_deployed_package_info 
	( 
	  parent_tag_name,
	  in_use_deployed_package_name
	)
	select 
		distinct
		p.tag_name,
		case when 
			instance_p.derived_from_package_id is null
		then 'None in use'
		else
			'Deployed_' + cast(instance_p.derived_from_package_id as nvarchar)
		end 
	from #parent p
	inner join  gobject instance_g on
		instance_g.derived_from_gobject_id = p.gobject_id
	left outer join package instance_p on
		instance_p.gobject_id = instance_g.gobject_id and
		instance_p.package_id = instance_g.deployed_package_id
		

	-- return a list of template names and the deployed folders of theirs that 
	-- are being used.
	delete 
	from @in_use_deployed_package_info
	where in_use_deployed_package_name = 'None in use' and
		parent_tag_name in
							( select parent_tag_name
							  from @in_use_deployed_package_info
							  where in_use_deployed_package_name <> 'None in use' )

	select 
		parent_tag_name,
		in_use_deployed_package_name
	from @in_use_deployed_package_info
	
--Delete unused packages for
  exec internal_delete_unused_packages

commit
go

