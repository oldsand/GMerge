create trigger trigger_delete_primitive_instance
    on primitive_instance
    instead of delete
as
set nocount on
if not exists(select 1 from deleted)
begin
    return
end

-- delete all children....
delete dynamic_attribute
from dynamic_attribute, deleted
where  dynamic_attribute.gobject_id = deleted.gobject_id and
       dynamic_attribute.package_id = deleted.package_id and
       dynamic_attribute.mx_primitive_id = deleted.mx_primitive_id


delete primitive_instance_feature_link
from primitive_instance_feature_link, deleted
where  primitive_instance_feature_link.gobject_id = deleted.gobject_id and
       primitive_instance_feature_link.package_id = deleted.package_id and
       primitive_instance_feature_link.mx_primitive_id = deleted.mx_primitive_id

if exists(
	select '1'
	from visual_element_version, deleted
	where  visual_element_version.gobject_id = deleted.gobject_id and
		   visual_element_version.package_id = deleted.package_id and
		   visual_element_version.mx_primitive_id = deleted.mx_primitive_id)
begin
	delete visual_element_version
	from visual_element_version, deleted
	where  visual_element_version.gobject_id = deleted.gobject_id and
		   visual_element_version.package_id = deleted.package_id and
		   visual_element_version.mx_primitive_id = deleted.mx_primitive_id

end

if exists(
			select '1'
			from visual_element_reference, deleted
			where  visual_element_reference.gobject_id = deleted.gobject_id and
				   visual_element_reference.package_id = deleted.package_id and
				   visual_element_reference.mx_primitive_id = deleted.mx_primitive_id)
begin
	delete visual_element_reference
	from visual_element_reference, deleted
	where  visual_element_reference.gobject_id = deleted.gobject_id and
		   visual_element_reference.package_id = deleted.package_id and
		   visual_element_reference.mx_primitive_id = deleted.mx_primitive_id
end





delete attribute_reference
from attribute_reference, deleted
where  attribute_reference.gobject_id = deleted.gobject_id and
       attribute_reference.package_id = deleted.package_id and
       attribute_reference.referring_mx_primitive_id = deleted.mx_primitive_id

delete primitive_instance_file_table_link
from primitive_instance_file_table_link, deleted
where  primitive_instance_file_table_link.gobject_id = deleted.gobject_id and
       primitive_instance_file_table_link.package_id = deleted.package_id and
       primitive_instance_file_table_link.mx_primitive_id = deleted.mx_primitive_id

delete template_attribute
from template_attribute, deleted
where  template_attribute.gobject_id = deleted.gobject_id and
       template_attribute.package_id = deleted.package_id and
       template_attribute.mx_primitive_id = deleted.mx_primitive_id


-- delete row from target table..
delete primitive_instance
from primitive_instance, deleted
where  primitive_instance.gobject_id = deleted.gobject_id and
       primitive_instance.package_id = deleted.package_id and
       primitive_instance.mx_primitive_id = deleted.mx_primitive_id


go

