
/***********************************************************************************************************************************
If you change this you need to check w/ Foxboro. This is used by Foxboro objects in their MigratePrimitive methods -- HF1467 CR93406
************************************************************************************************************************************/

create proc dbo.internal_get_folder_id
	@folder_type smallint,
    @path nvarchar(1000),
    @folder_Id int out 
As

    declare @folder_name_split table(folder_name int )
	declare @folder_name nvarchar(64), @pos int, @start int

	set @path = @path + '$'
    set @start = 0
	set @pos = charindex('$',@path)
    declare @parent_folder_id int    
    set @parent_folder_id = 0     
    set @folder_Id = 0     
	while @pos > 0
	begin
		set @folder_name = substring(@path, @start, @pos - @start)
		if @folder_name <> ''
		begin
            set @folder_Id = 0
            select	@folder_Id = folder_id from folder 
                        where folder_name = @folder_name
                        and parent_folder_id = @parent_folder_id
						and folder_type = @folder_type

            if(@folder_Id <> 0)
            begin
                set @parent_folder_id = @folder_Id
            end
            else                
            begin
                return               
            end
		end
        set @start = @pos+1
		set @pos = charindex('$', @path, @start)
	end

go

