create proc [dbo].[internal_get_template_hierarchical_name]
@template_name nvarchar(329)
as
begin
Declare @tag_name nvarchar (329)
set @tag_name = '$%.' + @template_name
set @template_name = '$' + @template_name

	select hierarchical_name from gobject where [tag_name] = @template_name or [tag_name]like @tag_name

end
go

