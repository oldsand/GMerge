-- uses #visual_element_reference_string table
-- finds VE type, tagname, primitivename, VE name, hierarchical VE name,isrelativereference,relativeobjectname,
-- ishierarchicalvisualelementname based on the reference string
create proc dbo.internal_resolve_visual_element_reference3  
    @is_association int
as
begin
    set nocount on

	
	declare visual_element_reference_string_cursor cursor fast_forward for
	select distinct reference_string, is_relative_reference		
		from #visual_element_reference_string
		
	open visual_element_reference_string_cursor
    
	while( 1=1 )
	begin
		declare @reference_string nvarchar(3620)
		declare @visual_element_type nvarchar(329)
		declare @tag_name nvarchar(32)
		declare @primitive_name nvarchar(329)
		declare @visual_element_name nvarchar(3260)		
		declare @hierarchical_visual_element_name nvarchar(3260)
		declare @is_relative_reference bit
		declare @is_relative_reference_orig bit
		declare @relative_object_name nvarchar(329)
		declare @is_hierarchical_visual_element_name bit
        
        fetch next from visual_element_reference_string_cursor into
            @reference_string, @is_relative_reference_orig        
            
            
        if( @@fetch_status <> 0 ) break
        	
        	exec internal_parse_visual_element_reference_string
			@reference_string,
			@visual_element_type output,
			@tag_name output,
			@primitive_name output,
			@visual_element_name output,
			@is_relative_reference output,
			@relative_object_name output,
			@is_hierarchical_visual_element_name output
    
        update #visual_element_reference_string 
        set visual_element_type = @visual_element_type,
        tag_name = case when @is_relative_reference = 0
					then @tag_name
					else null
					end,
        primitive_name = @primitive_name,
        visual_element_name = case when @is_hierarchical_visual_element_name = 0
					then @visual_element_name 
					else null
					end,
	hierarchical_visual_element_name = case when @is_hierarchical_visual_element_name = 1
							then @visual_element_name
							else null
							end,
        is_relative_reference = case when @is_association = 1
					then @is_relative_reference_orig
					else @is_relative_reference
					end,
         relative_object_name = @relative_object_name,
        is_hierarchical_visual_element_name = @is_hierarchical_visual_element_name 
	where reference_string = @reference_string
    
    end

    close visual_element_reference_string_cursor
    deallocate visual_element_reference_string_cursor
    
   insert into #visual_element_reference_info
           (gobject_id,
            package_id,
            mx_primitive_id,    
            visual_element_reference_index,
            is_relative_reference,
            visual_element_name,
            hierarchical_visual_element_name,
            visual_element_type,
            tag_name,
            primitive_name ,
            relative_object_name) 
            select distinct          
            vers.gobject_id,
            vers.package_id,
            vers.mx_primitive_id,
            vers.visual_element_reference_index,
            vers.is_relative_reference,		-- start of temp
            vers.visual_element_name,
            vers.hierarchical_visual_element_name,
            vers.visual_element_type,
            vers.tag_name,
            vers.primitive_name,
            vers.relative_object_name from #visual_element_reference_string vers   

	
end

go

