/**************************************************/
/*Object Name :  internal_MarkRuntimeFiles                            */
/*Object Type :  Stored Proc.								   */
/*Purpose :    Used by Deploy/Undeploy methods to mark runtime files for deploy/undeploy*/
/*Used By :    CDI									*/
/**************************************************/
CREATE     PROCEDURE dbo.internal_mark_runtime_files
	@FileNameContainingFileNames nvarchar(400),
	@Location nvarchar(256),
	@markDeployed int -- 1:Deployed 0:Undeployed
 AS
begin
set nocount on
begin tran
SET QUOTED_IDENTIFIER OFF

CREATE TABLE  #results_table ( file_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS not null) 

DECLARE @SQL nvarchar(2000)

SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameContainingFileNames + ''' WITH(TABLOCK, DATAFILETYPE=''widechar'')'

EXEC (@SQL)

update deployed_file 
	set deployed_file.is_runtime_deployed  = @markDeployed
	from deployed_file 
	inner join file_table ft
		on deployed_file.file_id = ft.file_id
	inner join #results_table rt
		on (ft.file_name) = (rt.file_name)
	where deployed_file.node_name = @Location


drop table #results_table
commit tran

end
go

