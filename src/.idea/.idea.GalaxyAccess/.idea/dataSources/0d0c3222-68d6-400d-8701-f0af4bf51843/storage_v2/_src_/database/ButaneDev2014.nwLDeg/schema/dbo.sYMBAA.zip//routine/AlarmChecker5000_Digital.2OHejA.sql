
-- =============================================
-- Author:		Travis Johnston
-- Create date: 10/3/2018
-- Description:	This stored procedure will compare analog alarm setpoints to our template and output any differences found.
-- =============================================
CREATE PROCEDURE [dbo].[AlarmChecker5000_Digital] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  DECLARE @archive_digital TABLE
(
   ActionType varchar(50),
   TemplateAlarm varchar(50),
   TemplateDelay int,
   TemplateParameter1 varchar(50),   
   TemplateParameter1Val float,
   TemplateParameter2 varchar(50),   
   TemplateParameter2Val float,      
   TemplateEnabled bit,
   SiteAlarm varchar(50),
   SiteDelay int,
   SiteParameter1 varchar(50),   
   SiteParameter1Val float,
   SiteParameter2 varchar(50),   
   SiteParameter2Val float,      
   SiteEnabled bit

);

CREATE TABLE #TempTarget_Digital(
	Alarm varchar(50),
	Delay int,
	Parameter1 varchar(50),
	Parameter1Val float,
	Parameter2 varchar(50),
	Parameter2Val float,
	Enabled bit
);


INSERT INTO #TempTarget_Digital 
SELECT Alarm,Delay,Parameter1,Parameter1Val,Parameter2,Parameter2Val,Enabled FROM AlarmScraper_DigitalAlarms


--BEGIN TRY
	MERGE #TempTarget_Digital AS TARGET
	USING (Select Alarm,Delay,Parameter1,Parameter1Val,Parameter2,Parameter2Val,Enabled from AlarmScraper_DigitalTemplate) AS SOURCE 
	ON (RIGHT(Target.Alarm, (LEN(Target.Alarm)-8)) = Source.Alarm)	
	WHEN MATCHED AND 
		TARGET.DELAY <> SOURCE.DELAY 
		OR TARGET.ENABLED <> SOURCE.ENABLED 
		OR TARGET.Parameter1 <> SOURCE.Parameter1 
		OR TARGET.Parameter1Val <> SOURCE.Parameter1Val
		OR TARGET.Parameter2 <> SOURCE.Parameter2
		OR TARGET.Parameter2Val <> SOURCE.Parameter2Val		
	THEN 
	UPDATE 
	SET
		TARGET.DELAY = SOURCE.DELAY,
		TARGET.ENABLED = SOURCE.ENABLED,
		TARGET.Parameter1 = SOURCE.Parameter1,
		TARGET.Parameter1Val = SOURCE.Parameter1Val,
		TARGET.Parameter2 = SOURCE.Parameter2,
		TARGET.Parameter2Val = SOURCE.Parameter2Val		
	WHEN NOT MATCHED BY TARGET THEN 					
		INSERT (Alarm,Delay,Parameter1,Parameter1Val,Parameter2,Parameter2Val,Enabled) 
		VALUES (Source.Alarm,Source.Delay,Source.Parameter1,Source.Parameter1Val,Source.Parameter2,Source.Parameter2Val,Enabled)
   OUTPUT
   $action AS ActionType,
   inserted.*,
   deleted.*
INTO @archive_digital;

SELECT 
CASE WHEN 
		ActionType = 'INSERT' 
	THEN 
		'Missing' 
	ELSE 
		'Different' 
	END 
		AS Action,   	
	TemplateAlarm,
	SiteAlarm,
	TemplateDelay,
	SiteDelay,
	TemplateParameter1,
	SiteParameter1,	
	TemplateParameter1Val,
	SiteParameter1Val,
	TemplateParameter2,
	SiteParameter2,
	TemplateParameter2Val,
	SiteParameter2Val,
	TemplateEnabled,
	SiteEnabled
 FROM @archive_digital 
 ORDER BY ActionType, TemplateAlarm 
 

DROP TABLE #TempTarget_Digital

END
go

