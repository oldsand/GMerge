-- Procedure to return change information of an object. 
-- The object should be checked out when this SP is called.

-- EntityChangeType:
--
--	EntityInitialized	= 0,
--	EntityNoChange	    = 1,
--	EntityPartialDirty	= 2,
--	EntityDirty	        = 3
--  

create proc dbo.internal_get_object_change_type
    @gobject_id int,
    -- Whether the object is valid 
    @object_is_valid bit output,
    -- If entity_change_type is EntityDirty. Other output parameter is 
    -- not significant.
    @entity_change_type smallint output,     
    -- Graphic portion is changed or not
    @graphic_changed bit output,
    -- Automation portion is changed or not
    @automation_changed bit output,
    -- Automation portion other than UDA and Script is changed
    @automation_other_than_lockedscript_and_uda_changed bit output,
    -- UDA portion is changed. It is significant only when
    -- @automation_other_than_lockedscript_and_uda_changed is false
    @uda_changed bit output,
    -- LockedScript portion is changed. It is significant only when
    -- @automation_other_than_lockedscript_and_uda_changed is false
    @lockedscript_changed bit output
as
begin

    set @object_is_valid = 0
    set @entity_change_type = 3
    set @graphic_changed = 0
    set @automation_changed = 0
    set @automation_other_than_lockedscript_and_uda_changed = 0 
    set @uda_changed = 0 
    set @lockedscript_changed = 0         


	declare @operation_mask int
    declare @checked_out_package_id int
    
    set @operation_mask = 0

    select  @checked_out_package_id = checked_out_package_id
    from    gobject
    where   gobject_id = @gobject_id
    
    if (@checked_out_package_id > 0)
    begin
	--- Find out for any child object in down derived hierarchy.
	--  if child's checked_in_package's derived_from_package_id is not equal to its immediate parent's checked_in_package_id than
	--- Go for normal checkin
		declare @descendents_objects table
		(
			gobject_id int default 0,			
			is_template bit,
			is_immediate_child bit			
		)       

		insert @descendents_objects
		(
			gobject_id, 
			is_template, 
			is_immediate_child
		)
		exec internal_get_gobject_descendants @gobject_id
    
		if exists(
		
			select childgobj.gobject_id
			from @descendents_objects	descids
			inner join gobject childgobj
			on 	
				childgobj.gobject_id = descids.gobject_id
			inner join gobject parentgobj
			on 
				parentgobj.gobject_id = childgobj.derived_from_gobject_id
			inner join package childpack
			on 
				childpack.gobject_id = childgobj.gobject_id
			and childpack.package_id = childgobj.checked_in_package_id
			where 
				childpack.derived_from_package_id <> parentgobj.checked_in_package_id
		)
		begin 
			--go for normal checkin
			set @automation_other_than_lockedscript_and_uda_changed = 1
		end
        set @object_is_valid = 1
        
        if (exists(
            select  1
            from    primitive_instance
            where   gobject_id = @gobject_id 
            and     package_id = @checked_out_package_id
            and     entity_change_type = 3))
        begin
            set @entity_change_type = 3
        end
        else
        begin
            select  @entity_change_type = max(entity_change_type)
            from    primitive_instance
            where   gobject_id = @gobject_id 
                and package_id = @checked_out_package_id

            if (exists(
                select  1   
                from    primitive_instance
                where   gobject_id = @gobject_id
                    and package_id = @checked_out_package_id
                    and extension_type = N'SymbolExtension'
                    and entity_change_type > 1))
            begin
                set @graphic_changed = 1
            end


            if (exists(
                select  1   
                from    primitive_instance
                where   gobject_id = @gobject_id
                    and package_id = @checked_out_package_id
                    and entity_change_type > 1
                    and extension_type <> N'SymbolExtension'))
            begin
                set @automation_changed = 1
            end
       
		    if (@automation_changed = 1)
		    begin
		        declare @other_changed  bit
		        set @other_changed = 0
		        
		        -- Check whether there is change other than
		        -- lockedscript and uda		        
		        -- We need to apply different rules here.
		        
		        -- 1. If there is change not in Common Primitive and 
		        -- not script extension
			    if (exists(
				    select  1   
				    from    primitive_instance
				    where   gobject_id = @gobject_id
					    and package_id = @checked_out_package_id
					    and mx_primitive_id <> 2
					    and entity_change_type > 1
					    and extension_type <> N'ScriptExtension'
						and extension_type <> N'SymbolExtension'))
			    begin
			        set @other_changed = 1
			    end

			    -- 2. If there is operation on UDA other than just setting value
			    if (@other_changed = 0)
			    begin			    
				    select	@operation_mask = operation_on_primitive_mask
				    from	primitive_instance
				    where	gobject_id = @gobject_id
					    and	package_id = @checked_out_package_id
					    and	mx_primitive_id = 2

				    if (@operation_mask | 4  <> 4)   -- UdaChanged bitmask is 0x04
				    begin
					    set @other_changed = 1
				    end
				    else
				    begin				    
				        if (@operation_mask & 4  = 4)   -- Uda is changed 
				        begin
					        set @uda_changed = 1
				        end
				    end
			    end
			    
			    -- 3. If the changed script primitive has unlocked attribute
			    if (@other_changed = 0)
			    begin
                    declare	@locked_attribute_id smallint

                    set @locked_attribute_id = 101      -- Attribute _Binary of script extension

                    if (exists(
                        select	1
                        from	template_attribute ta
                        inner join
		                        primitive_instance pri
                        on
		                        ta.gobject_id = pri.gobject_id
                        and		ta.package_id = pri.package_id
                        and		ta.mx_primitive_id = pri.mx_primitive_id

                        where	
								pri.operation_on_primitive_mask <> 0
                        and     pri.extension_type = N'ScriptExtension'
                        and		pri.gobject_id = @gobject_id
                        and		pri.package_id = @checked_out_package_id
                        and		ta.mx_attribute_id = @locked_attribute_id
                        and		ta.lock_type = 0
                    ))    
                    begin
					    set @other_changed = 1
                    end
                    else
                    begin
                        if (exists(
                            select	1
                            from	template_attribute ta
                            inner join
		                            primitive_instance pri
                            on
		                            ta.gobject_id = pri.gobject_id
                            and		ta.package_id = pri.package_id
                            and		ta.mx_primitive_id = pri.mx_primitive_id

                            where	pri.operation_on_primitive_mask <> 0
                            and     pri.extension_type = N'ScriptExtension'
                            and		pri.gobject_id = @gobject_id
                            and		pri.package_id = @checked_out_package_id
                            and		ta.mx_attribute_id = @locked_attribute_id
                            and		ta.lock_type > 0     
                        ))
                        begin
                            set @lockedscript_changed = 1
                        end               
                    end			    
			    end

				if (@other_changed = 1)
				begin
					set @automation_other_than_lockedscript_and_uda_changed = 1
				end
		    end
        end
    end    
end

go

