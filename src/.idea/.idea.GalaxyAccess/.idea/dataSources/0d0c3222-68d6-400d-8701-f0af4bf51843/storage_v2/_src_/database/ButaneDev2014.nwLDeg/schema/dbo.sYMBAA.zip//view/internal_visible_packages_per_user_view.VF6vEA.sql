-- This view returns package versions visible to each
-- user.
--
-- It is designed to be added to joins to select packages for
-- a given user.
--
-- For example, to get the visual element versions to use for 'Administrator'
-- user given by @user_guid:
--
--    declare @user_guid uniqueidentifier
--    select @user_guid = user_guid from user_profile 
--        where user_profile_name = 'Administrator'
--
--    select * from visual_element_version vev
--    inner join internal_visible_packages_per_user_view vp
--        on vev.gobject_id = vp.gobject_id
--        and vev.package_id = vp.package_id
--        and vp.user_guid = @user_guid


create  view dbo.internal_visible_packages_per_user_view
as
select 
    p.gobject_id, 
    p.package_id, 
    up.user_guid 

from package p 
inner join gobject g on g.gobject_id = p.gobject_id
inner join user_profile up
   on g.checked_out_by_user_guid is null and p.package_id = g.checked_in_package_id
   or (g.checked_out_by_user_guid  = up.user_guid and p.package_type = 'O')
   or (g.checked_out_by_user_guid  <> up.user_guid and p.package_id = g.checked_in_package_id)
go

