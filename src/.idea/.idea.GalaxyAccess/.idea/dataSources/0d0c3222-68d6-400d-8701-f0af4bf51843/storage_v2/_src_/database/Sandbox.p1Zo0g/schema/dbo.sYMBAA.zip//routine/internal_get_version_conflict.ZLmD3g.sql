-- 
-- return       1   when the name does not exists in the database
--              5   when name exists but the object is checked out ( applies for derived objects )
--              2   if object with same code base does not exists in the galaxy
--              3   if the minor version of the objects are different even if code base is same
--              4   if object exists with all the conditions satisfied.
--              7   if base template is going to mark protected
create proc dbo.internal_get_version_conflict
@tagname nvarchar(329),
@codebase nvarchar(322),
@codebaseminorversion int,
@returnval int out,
@gobject_id int out
as
begin
set @gobject_id = 0

declare @countobj int
set @countobj = 0
set @countobj = (select count(*) from gobject where tag_name = @tagname and namespace_id in (1,3))  -- Automation Object

if @countobj = 1  -- name exists in the database
  begin
  set @gobject_id = (select gobject_id from gobject where tag_name = @tagname and namespace_id in (1,3)) -- Automation Object
  declare @check_out_id int
  set @check_out_id = 0 
  set @check_out_id = (select checked_out_package_id from gobject where tag_name = @tagname and namespace_id in (1,3)) -- Automation Object
  if ( @check_out_id = 0 )
    begin
    -- find out if the codebase are same
    declare @countcodebase int
    set @countcodebase = 0
    set @countcodebase = (select count(*) from template_definition td
						 where td.template_definition_id = (select tempd.template_definition_id 
										from gobject g,template_definition tempd 
										where g.tag_name = @tagname 
										and g.template_definition_id = tempd.template_definition_id
										and namespace_id in (1,3) and tempd.codebase = @codebase   -- Namespace_ID 1 = Automation Object
										) )
	--Get is protected or not
	declare @is_gobject_protected int
	set @is_gobject_protected = 0
	if exists (select '*' from gobject_protected where gobject_id = @gobject_id)
	begin
			set @is_gobject_protected = 1
	end
	--END

    if @countcodebase > 0 and @countcodebase is not null -- the @tagname object's codebase is same as input codebase
      begin
        declare @dbconfigversion int
        set @dbconfigversion = 0
        set @dbconfigversion = (select codebase_minor_version from template_definition td where td.codebase =  @codebase )

        if @dbconfigversion > 0 and @dbconfigversion is not null -- the configuration version of tagname object is same as input config version
          begin
		    if ( @codebaseminorversion = @dbconfigversion )
			  begin
				if (@is_gobject_protected <> 1)
					set @returnval = 7
				else
                set @returnval = 4
              end
			else
			  set @returnval = 3	  
          end
        else
          set @returnval = 3 --When it will return 3????
      end
    else
	begin
		--Coment out to allow import of base template even it is protected in galaxy
		--if (@is_gobject_protected = 1)
		--	set @returnval = 9 --Code base diff and target is protected
		--else
			set @returnval = 2
	end
    end
  else
    set @returnval = 5
  end
else
  set @returnval = 1
end
go

