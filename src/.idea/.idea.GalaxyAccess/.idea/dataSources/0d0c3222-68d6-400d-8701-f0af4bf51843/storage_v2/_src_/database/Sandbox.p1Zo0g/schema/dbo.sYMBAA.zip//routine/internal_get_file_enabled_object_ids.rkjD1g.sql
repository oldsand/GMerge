--Get FileEnabled Object Ids from Give object Ids. 
--IntouchViewApp Template Object Ids only support File enable.
CREATE  procedure dbo.internal_get_file_enabled_object_ids
-- send list of object ids to sql as XMLDoc
@FileNameOfIds nvarchar (265)
AS
SET NOCOUNT ON
begin

	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #results_table ( gobject_id int)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')'

	EXEC sp_executesql @SQL


	--return file enable objects, IntouchViewApp objects only
	select 
           rt.gobject_id            
    from #results_table rt
    inner join gobject g 
		on rt.gobject_id = g.gobject_id
	inner join template_definition td 
		on td.template_definition_id = g.template_definition_id
    where td.category_id = 26 and g.is_template = 1

	drop table #results_table

end

go

