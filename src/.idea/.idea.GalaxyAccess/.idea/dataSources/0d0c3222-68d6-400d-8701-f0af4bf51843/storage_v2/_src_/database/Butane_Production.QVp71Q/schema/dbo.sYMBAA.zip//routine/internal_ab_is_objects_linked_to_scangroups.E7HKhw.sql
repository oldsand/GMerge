CREATE PROCEDURE dbo.internal_ab_is_objects_linked_to_scangroups
    @dio_name nvarchar(329),
    @sg_names_file nvarchar(329),
    @result int output
as
begin
  set nocount on

  DECLARE @gSQL nvarchar(2000)
  DECLARE @dio_id as int
  
  SET @dio_id = 0

  CREATE TABLE #sgnames(sg_name nvarchar(329))
  
  DECLARE @ResultSet TABLE( 
				gobject_id int, 
				gobject_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
				derived_from_gobject_id int, 
				derived_from_gobject_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
				istemplate bit, 
				nLevel int)
  
  SET @gSQL = 'BULK INSERT #sgnames  FROM ''' + @sg_names_file + ''' 
             WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
  EXEC sp_executesql @gSQL
  
  SELECT @dio_id = gobject_id FROM gobject WHERE tag_name = @dio_name and namespace_id = 1
  
  IF @dio_id <> 0
  BEGIN
  INSERT into @ResultSet
  EXEC internal_get_derivation_tree @dio_id
  
  SELECT pin.primitive_name,COUNT(*) AS LinkedInstances FROM @ResultSet rs
  INNER JOIN object_device_linkage odl
  ON rs.gobject_id = odl.dio_id
  INNER JOIN gobject dio
  ON dio.gobject_id = odl.dio_id
  INNER JOIN primitive_instance pin
  ON pin.gobject_id = odl.dio_id and pin.package_id = dio.checked_in_package_id and odl.sg_mx_primitive_id = pin.mx_primitive_id
  INNER JOIN #sgnames
  ON #sgnames.sg_name = pin.primitive_name
  GROUP BY pin.primitive_name
  END
  
  SET @result = 0  
end
go

