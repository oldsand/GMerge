/**************************************************
Object Name :  internal_list_object_name_info_by_category
Object Type :  Stored Proc. 
Purpose	    :  returns list of object' tag_name and namespace id 
Used By	    :  CDI uses it in ListObjectNameInfoByCategory call.
**************************************************/

CREATE PROCEDURE dbo.internal_list_object_name_info_by_category
	@category	int,
	@type		smallint
AS
BEGIN
SET NOCOUNT ON

IF	@type = 0	-- both template and instance
	BEGIN
		select	g.tag_name, g.namespace_id
		from	template_definition t inner join gobject g
		on		t.template_definition_id = g.template_definition_id
		where	t.category_id = @category
	END
ELSE
	IF @type = 1  -- template only
		BEGIN
			select	g.tag_name, g.namespace_id
			from	template_definition t inner join gobject g
			on		t.template_definition_id = g.template_definition_id
			where	t.category_id = @category and g.is_template = 1
		END
ELSE
	IF @type = 2  -- instance only
		BEGIN
			select	g.tag_name, g.namespace_id
			from	template_definition t inner join gobject g
			on		t.template_definition_id = g.template_definition_id
			where	t.category_id = @category and g.is_template = 0
		END


END
go

