/*
Object Name :  internal_getUniqueFolderName
Object Type :  Stored Proc.						
Purpose     :  Procedure to Get the Unique FolderName for a given base name
               and folder_type
Used By	    :  CDI()				
*/
create procedure dbo.internal_get_unique_folder_name
    @baseName nvarchar(64),
    @parent_folder_id int,
    @folder_type int,
    @uniqueName nvarchar(64) out 
AS
set nocount on  
begin
  declare @likeName nvarchar(128)
  set @baseName =  ( substring(@baseName,1, 60) )
  set @baseName = @baseName + '_'

  if ( substring(@baseName, len(@baseName), 1) = '_' )
    set @likeName = substring(@baseName, 1, len(@baseName)- 1) + '[_][0-9][0-9][0-9]'
  else
  	 set @likeName = @baseName + '[0-9][0-9][0-9]'

  declare @maxno integer
  set @maxno = ISNULL((select max(cast(rtrim (substring(folder_name,len(@baseName)+1,
                        len(folder_name))) as integer)) from folder where 
		                folder_name like @likeName and folder_type = @folder_type 
                        and parent_folder_id = @parent_folder_id),1)

  declare @whichname nvarchar(64)
  declare @howmanyzeros int
  declare @maxnolength int

  while 0 < 1
    begin
	set @maxnolength = len(cast(@maxno as nvarchar ))
	set @howmanyzeros = 3 - len(cast(@maxno as nvarchar ))
	
	if ( @howmanyzeros > 0 )
	  set @whichname = @baseName + (REPLICATE( '0',@howmanyzeros ) + cast(@maxno as nvarchar )   )
	else
		begin
			if ( len(@baseName) + @maxnolength ) > 64
				set @whichname = SUBSTRING(@baseName, 1, 64 - (@maxnolength + 1)) + '_' + cast(@maxno as nvarchar )
			else
				set @whichname = @baseName + cast(@maxno as nvarchar )
		end
	
	declare @isNameUnique int

	/* Find out if this name is a unique Name in the sub-folder list*/
	set @isNameUnique = (select count(*) from folder 
                        where folder_name = @whichname 
                        and  folder_type = @folder_type
                        and parent_folder_id = @parent_folder_id)
	
	if  @isNameUnique > 0 
	  set @maxno = @maxno + 1 
	else
	  begin
	    -- set the outgoing uniquename variable with which name	
 	    set @uniqueName = @whichname
	    break
	  end
  end

end
set nocount off

go

