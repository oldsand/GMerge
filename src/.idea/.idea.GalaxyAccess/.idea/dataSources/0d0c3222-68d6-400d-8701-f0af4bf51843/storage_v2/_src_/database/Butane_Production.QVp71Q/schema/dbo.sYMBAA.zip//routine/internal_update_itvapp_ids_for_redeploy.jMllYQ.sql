-- =============================================
-- Author:		<ABHAY Tembhare>
-- Create date: <7/19/2011>
-- Description:	<Insert the ITVAPP gobject ID into table 'intouchviewapptemplate_allsymbols'>
/*Object Name :  internal_update_itvapp_ids_for_redeploy						      */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To update gobject ID for ITVAPP when include all symbol is selected*/
/*Used By	  :  PackageServerNet												  */
/**********************************************************************/

create PROCEDURE dbo.internal_update_itvapp_ids_for_redeploy
(
    @gobjectID int,
    @bIsInsert bit,
    @bSuccess bit output
)
as
set nocount on
begin
begin tran

declare @bIsInstanceDeployed bit
set @bIsInstanceDeployed = 0
set @bSuccess = 0

if exists (select '*' from gobject where derived_from_gobject_id = @gobjectID and deployed_package_id <> 0)
begin
	set @bIsInstanceDeployed = 1
end

if (@bIsInstanceDeployed = 0)
begin
	if (@bIsInsert = 1)
	begin 
		if not exists (select gobject_id from intouchviewapptemplate_allsymbols where gobject_id = @gobjectID)
		begin 
			insert into intouchviewapptemplate_allsymbols values (@gobjectID)
		end
	end
	else
	begin
		delete from intouchviewapptemplate_allsymbols where gobject_id = @gobjectID
	end
	set @bSuccess = 1
end
commit

end
go

