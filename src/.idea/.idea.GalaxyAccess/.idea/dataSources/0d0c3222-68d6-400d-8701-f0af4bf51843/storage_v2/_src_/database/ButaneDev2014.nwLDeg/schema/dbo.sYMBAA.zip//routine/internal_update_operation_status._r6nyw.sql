create procedure dbo.internal_update_operation_status
@operation_id int,
@status int
as

update operation_status
set status =  @status
where operation_id =  @operation_id
go

