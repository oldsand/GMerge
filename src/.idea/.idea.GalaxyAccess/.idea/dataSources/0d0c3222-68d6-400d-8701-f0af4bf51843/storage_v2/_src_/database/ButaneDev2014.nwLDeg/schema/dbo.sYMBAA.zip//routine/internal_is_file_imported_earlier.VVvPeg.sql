
create proc dbo.internal_is_file_imported_earlier
@filename nvarchar(1000)
as
begin

declare @name nvarchar(1000)

set @name = substring(@filename, 0,charindex('.',@filename))
set @name = '%' + @name + '%'
--first check for client controls
declare @objectExists int
select @objectExists = COUNT(*) from well_known_client_controls 
where class_name like @name 

--if it it not a client control
--then it may be base template
if(@objectExists > 0)
begin
	select @objectExists
end
else
begin
	select count(*) from template_definition 
	where base_template_location like @name 
end

end


go

