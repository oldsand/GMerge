CREATE FUNCTION dbo.itvfabSplitAttrRef (@attr_io_ref nvarchar(329))
RETURNS TABLE
/*
** Function that accepts an attribute IO reference string with up to two separators (tank.pressure.inputsource or pressure.inputsource, or pressure), and returns
** - ao_tag_name (tank, or NULL, or NULL)
** - ao_attr (pressure)
** - io_attr_ref (inputsource, inputsource, or NULL)
**
** About the format of the passed reference string:
** - If it has only one token, it must be <UDA name>. 
** - If it has two tokens, it must be <UDA name>.<(InputSoure|OutputDest)>
** - If it has three tokens, it must be <tag-name>.<UDA name>.<(InputSoure|OutputDest)>
*/
AS
  RETURN (
    SELECT (CASE
              WHEN split_ref.first_split > 0 
                THEN RIGHT (@attr_io_ref, split_ref.length - CASE WHEN split_ref.second_split > 0 THEN split_ref.second_split ELSE split_ref.first_split END)
              ELSE
                NULL
            END) io_attr_ref
	     , SUBSTRING ( @attr_io_ref,
                       (CASE WHEN split_ref.second_split > 0 THEN split_ref.first_split ELSE 0 END) + 1,
                       (CASE 
                          WHEN split_ref.second_split > 0 
                            THEN split_ref.second_split - 1
                          WHEN split_ref.first_split > 0
                            THEN split_ref.first_split - 1
                          ELSE
                            split_ref.length
                        END)
                         - (CASE WHEN split_ref.second_split > 0 THEN split_ref.first_split ELSE 0 END)) ao_attr
         , (CASE WHEN split_ref.second_split > 0 THEN NULLIF (LEFT (@attr_io_ref, split_ref.first_split - 1), N'*') ELSE NULL END) ao_tag_name
      FROM itvfabFindSplit (@attr_io_ref) split_ref
  )
go

