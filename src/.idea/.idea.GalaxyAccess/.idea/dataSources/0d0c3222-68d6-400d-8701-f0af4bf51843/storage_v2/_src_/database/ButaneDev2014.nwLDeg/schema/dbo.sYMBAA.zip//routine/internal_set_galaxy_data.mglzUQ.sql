
/**************************************************/
/*Object Name :  internal_set_galaxy_data									*/
/*Object Type :  Stored Proc.												*/
/*Purpose :    Procedure to set galaxy wide data for given data type.	*/
/*Used By :    PackageServerNet												*/
/**************************************************/
create  proc dbo.internal_set_galaxy_data
@data_type nvarchar(256),
@data  image
as
begin

if ( select count(*) from galaxy_data 
	 where data_type = @data_type ) = 0
	
	insert into galaxy_data ( data_type, data)
	values( @data_type, @data)

else
	
	update galaxy_data set data = @data
	where data_type = @data_type	

end

go

