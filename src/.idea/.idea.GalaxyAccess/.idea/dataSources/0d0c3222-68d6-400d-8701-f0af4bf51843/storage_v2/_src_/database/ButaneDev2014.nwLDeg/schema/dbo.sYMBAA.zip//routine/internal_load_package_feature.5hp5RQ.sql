create proc dbo.internal_load_package_feature
	@gobject_id as int,
	@package_id as int
as begin
	set nocount on
	
	--load the primitive_instance features
	select 
		pifl.mx_primitive_id,
		pifl.feature_id,
		pifl.feature_name,
		pifl.feature_type
	from 
		primitive_instance_feature_link pifl
	where
	    pifl.gobject_id = @gobject_id
	and pifl.package_id = @package_id
end



go

