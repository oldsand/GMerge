/*Object Name :  internal_list_well_known_client_controls     */
/*Object Type :  Stored Proc.								   */
/*Purpose :    to get well known Client Controls data  */
/*Used By :    PackageServerNet									*/
/**************************************************/
CREATE  PROCEDURE dbo.internal_list_well_known_client_controls
AS
begin
set nocount on
--Create temp table to hold gObject Ids
create table #cc_class_link
(
	gobject_id int NULL,
	file_id int NULL,
	class_name nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
)

--insert one row per class/file name
insert into 
			#cc_class_link(file_id,class_name )
			(	select distinct 
					cccl.file_id, cccl.class_name 
				from 
					client_control_class_link cccl )

--insert one control(oldest) for each class/file in the table
update 
		#cc_class_link
set 
		gobject_id = (	select 
								min(cccl.gobject_id) 
						from 
								client_control_class_link as cccl
						where 
								#cc_class_link.file_id = cccl.file_id and
								#cc_class_link.class_name = cccl.class_name	)

--Use this to return the final information
select	c.gobject_id, 
		o.visual_element_id,
		g.tag_name,
		w.toolbox_info
from	
		well_known_client_controls w
inner join 
		#cc_class_link c
on
		w.file_id = c.file_id and
		w.class_name = c.class_name
inner join 
		owned_visual_element o
on		
		c.gobject_id = o.gobject_id
		and	o.mx_primitive_id = 101
inner join	
		gobject g
on		
		c.gobject_id = g.gobject_id and
		g.checked_in_package_id = o.package_id
order by
		c.gobject_id

drop table #cc_class_link


end
go

