-- Returns the parts of a visual element reference string
-- such as 'Symbol:o1.d1.x'
--
-- Example: 
--
--      Input:
--        @reference_string: Symbol:o1.d1.x 
--
--      Output:
--        @visual_element_type: Symbol
--        @tag_name: o1
--        @primitive_name: d1.x
--        @visual_element_name: o1.d1.x
--
-- If a particular part of the name is not found,
-- NULL will be returned for that part.
--

create proc dbo.internal_parse_visual_element_reference_string
    @reference_string nvarchar(3620),
    @visual_element_type nvarchar(329) output,
    @tag_name nvarchar(32) output,
    @primitive_name nvarchar(329) output,
    @visual_element_name nvarchar(3620) output,
    @is_relative_reference bit output,
    @relative_object_name nvarchar(329) output,
    @is_hierarchical_visual_element_name bit output
as    
begin
    set nocount on
    
    -- set output strings to blank so nulls never get returned
    set @visual_element_type  = ''
    set @tag_name = ''
    set @primitive_name = ''
    set @visual_element_name = ''
    set @relative_object_name = ''
    set @is_hierarchical_visual_element_name = 0

    -- part to the left of the colon is the visual_element_type
    set @visual_element_type = null
    declare @colonIndex int
    set @colonIndex = isnull(charindex(':',@reference_string),0)
    if @colonIndex = 0  begin
        set @visual_element_name = @reference_string
    end
    else begin
        set @visual_element_type = left( @reference_string, @colonIndex - 1 )
        set @visual_element_name = right( @reference_string, len(@reference_string)-@colonIndex)
    end

	-- US157622 (Apollo)
	-- As the syntax of the reference string evolves, we will expect additional meta-data to be specified as 
	-- colon-separated values. Until we know what these values are, and how they are to be used, we will
	-- account for them, and discard them.
	set @colonIndex = ISNULL(charindex(':',@visual_element_name), 0)
	if @colonIndex <> 0
	begin
		declare @leftover_refstr varchar(64)
        set @leftover_refstr = right( @visual_element_name, len(@visual_element_name)-@colonIndex)
		set @visual_element_name = LEFT(@visual_element_name, @colonIndex - 1)
	end -- US157622 (Apollo)

    declare @remaining_name nvarchar(329)

    -- check for relative reference and remove 'me.'
    if( left(UPPER(@visual_element_name),3) = 'ME.' )
    begin
        set @is_relative_reference = 1
        set @remaining_name = right(@visual_element_name,len(@visual_element_name)-3)
    end
    else
    begin
        set @is_relative_reference = 0
        set @remaining_name = @visual_element_name
    end
    

    -- next, locate primitive (if any) based on location of last period
    declare @last_period_index int
    set @last_period_index = len(@remaining_name)-isnull(charindex('.', reverse(@remaining_name)),0)
    if( @last_period_index = len(@remaining_name) )
        set @last_period_index = 0
    if( @is_relative_reference = 1 )
    begin
        if( @last_period_index = 0 )
        begin 
            set @primitive_name = @remaining_name
            set @relative_object_name = ''
        end else begin
                set @relative_object_name = left(@remaining_name,@last_period_index )
                set @primitive_name = right( 
                    @remaining_name, 
                    len(@remaining_name)-@last_period_index-1)
        end
    end
    else
    begin
        begin
            if( @last_period_index = 0 )
            begin
                set @tag_name = @remaining_name
                set @primitive_name = ''
            end else begin
                set @tag_name = left(@remaining_name,@last_period_index )
                set @primitive_name = right( 
                    @remaining_name, 
                    len(@remaining_name)-@last_period_index-1)
            end
        end
    end
    
    declare @number_of_periods_in_reference_string int
    set @number_of_periods_in_reference_string = (select dbo.get_char_count_in_string(@visual_element_name,'.'))

    if(@number_of_periods_in_reference_string > 1)
    begin 
        set @is_hierarchical_visual_element_name = 1
        -- remove 
    end
    

end

go

