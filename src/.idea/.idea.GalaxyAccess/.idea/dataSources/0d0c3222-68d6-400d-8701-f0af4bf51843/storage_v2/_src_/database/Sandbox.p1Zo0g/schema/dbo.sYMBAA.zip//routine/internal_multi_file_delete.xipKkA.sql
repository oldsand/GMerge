-- PLease Note that this stored-procedure will
-- update the deployed_file table and will mark flag need_to_delete = 1 
-- for all the files which DeleteBase Template going to remove for FR
-- so that when next time any client will ask for all the files then 
-- it will first remove it from respective Bin folders and then 
--it will do the clean up and installation

create PROCEDURE dbo.internal_multi_file_delete
	@FileNameOfIds nvarchar (400)
as
begin
	set nocount on

	-- Create temporary table for storing the file ids.
	CREATE TABLE  #results_table ( file_id int)
			
		begin tran

		-- call the stored procedure 'internal_construct_table_from_file'
		EXEC internal_construct_table_from_file @FileNameOfIds, '#results_table'


		SELECT     file_table.file_name, file_table.vendor_name, file_table.registration_type,file_table.subfolder
		FROM         deployed_file INNER JOIN
                file_table ON deployed_file.file_id = file_table.file_id INNER JOIN
                #results_table r ON file_table.file_id = r.file_id
		WHERE     (deployed_file.is_editor_deployed = 1)
		or (deployed_file.is_package_deployed = 1)
		or (deployed_file.is_runtime_deployed = 1)
		

		SELECT     file_table.file_name, file_table.vendor_name, file_table.registration_type, file_table.subfolder
		FROM  file_table INNER JOIN
			  #results_table r ON file_table.file_id = r.file_id
		
		--update need_to_delete = 1 only for remote-node not for GRNode
		update deployed_file 
        set  deployed_file.need_to_delete = case when deployed_file.node_name <> @@servername then 1  else 0 end,
				deployed_file.is_package_deployed = 0,
				deployed_file.is_editor_deployed = 0, 
				deployed_file.is_runtime_deployed = 0,
                deployed_file.is_browser_deployed = 0
		from deployed_file INNER JOIN #results_table r ON 
		deployed_file.file_id = r.file_id where  
		(
			deployed_file.is_package_deployed = 1 or
			deployed_file.is_editor_deployed = 1 or
            deployed_file.is_browser_deployed = 1
		)

		update deployed_file set deployed_file.is_runtime_deployed = 0
		from deployed_file INNER JOIN #results_table r ON 
		deployed_file.file_id = r.file_id where  
		(
			deployed_file.is_runtime_deployed = 1
		)


		commit tran

	DROP TABLE #results_table

	
end
go

