--
-- Returns the all visual elements referenced by
-- a given visual element whether or not they are valid
-- in the order they were added to the given visual element
--
-- Note: this differs from internal_get_referenced_visual_elements
--       because this proc returns valid and invalid references 
--       while internal_get_referenced_visual_elements returns only
--       valid references
--
-- Example:
--
--    exec internal_get_visual_element_references 20,'7F0312F4-0D1E-4D8D-84E2-1DEA26A65237'
--
-- returns table 
-- ( 
--   visual_element_id int not null, // zero for nulls
--   visual_element_name nvarchar not null,
--   visual_element_type nvarchar not null,
--   context_object nvarchar not null // tag_name of referring object
--  )
--
create proc dbo.internal_get_visual_element_references
(
    -- visual element that owns the references
    @visual_element_id int,
 
    -- user making request, results will include objects visible to that user
    -- passing null or guid_null causes checked in packages to be used
    @user_guid uniqueidentifier
)
as begin
    set nocount on

    -- get default user if none supplied
    if @user_guid is null or @user_guid = '00000000-0000-0000-0000-000000000000'
        select @user_guid = user_guid 
        from user_profile 
        where user_profile_name= 'SystemEngineer'

    -- find visual element version for this user
    declare @gobject_id int
    declare @package_id int
    declare @mx_primitive_id int
    select 
        @gobject_id = gobject_id, 
        @package_id = package_id,
        @mx_primitive_id = mx_primitive_id
    from visual_element_version 
    where 
        visual_element_id = @visual_element_id 
        and dbo.is_package_visible_to_user( gobject_id, package_id, @user_guid ) = 1

    -- optimization - return immediately if no references
    if not exists (
        select 1 
        from visual_element_reference 
        where 
            gobject_id = @gobject_id and 
            package_id = @package_id and 
            mx_primitive_id = @mx_primitive_id )
    begin
        return
    end

    select 
        isnull(ver.visual_element_id,0) visual_element_id, 
        isnull(ver.calculated_visual_element_name ,'') visual_element_name,
        isnull(ver.calculated_visual_element_type,'') visual_element_type,
        g.tag_name context_object_name
    from internal_visual_element_reference_per_user_view ver
    inner join gobject g on g.gobject_id = @gobject_id
    where
        ver.gobject_id = @gobject_id
        and ver.package_id = @package_id
        and ver.mx_primitive_id = @mx_primitive_id
        and ver.user_guid = @user_guid
    order by ver.visual_element_reference_index
end


go

