create proc dbo.internal_get_folder_changes
@last_known_change bigint,
@folder_type smallint,
@latestDBTS bigint out
as 
begin tran
    declare @last_known_change_ts timestamp
    set @last_known_change_ts = CAST ( @last_known_change  AS timestamp )     
    
--     select @latestDBTS = max_proxy_timestamp
--     from galaxy
     select @latestDBTS = @last_known_change


    -- step 1 : get folder changes from folder table table
    -- step 2 : get folder proxies        
    declare @work_table table 
    (
        folder_id int,
		timestamp_of_last_change bigint
    )

	declare @max_timestamp_from_changed bigint	
	set @max_timestamp_from_changed = 0
	declare @max_timestamp_from_deleted bigint	
	set @max_timestamp_from_deleted = 0

    insert into @work_table
    select
        f.folder_id,
		f.timestamp_of_last_change
    from folder f
    where 
        f.timestamp_of_last_change > @last_known_change_ts and
        f.folder_type = @folder_type
    union
    select 
        fl.folder_id,
		fl.timestamp_of_last_change 
    from
        folder_gobject_link fl
    inner join folder f on
        fl.folder_id = f.folder_id and f.folder_type = @folder_type
    where
        fl.timestamp_of_last_change > @last_known_change_ts

	if(@@rowcount > 0)
		select @max_timestamp_from_changed = max(timestamp_of_last_change)
		from @work_table
	


    select distinct
         f.folder_id, 
		 f.parent_folder_id,
         f.folder_name, 
         f.depth, 
         f.has_objects,
         f.has_folders
    from @work_table w
    inner join folder f on
        w.folder_id = f.folder_id
	
    -- get the deleted folders.....
    select d.deleted_id from  deleted_ids d
    inner join lookup_table_name l 
    on d.table_id = l.table_id 
    and l.table_name = 'folder'    
    where 
        d.deletion_timestamp > @last_known_change_ts 

	if(@@rowcount > 0)
		select @max_timestamp_from_deleted = max(deletion_timestamp)
		from deleted_ids

	if((@max_timestamp_from_changed = 0) and (@max_timestamp_from_deleted = 0))
	begin
		 set @latestDBTS = @last_known_change
	end
	else if(@max_timestamp_from_changed > @max_timestamp_from_deleted)
	begin
		set @latestDBTS = @max_timestamp_from_changed         
	end
	else
	begin
		set @latestDBTS = @max_timestamp_from_deleted         
	end


   

commit

go

