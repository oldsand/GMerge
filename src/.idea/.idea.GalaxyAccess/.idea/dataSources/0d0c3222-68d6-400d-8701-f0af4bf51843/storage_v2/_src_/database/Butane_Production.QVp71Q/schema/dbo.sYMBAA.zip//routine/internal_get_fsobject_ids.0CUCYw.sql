create procedure dbo.internal_get_fsobject_ids
@varwhere nvarchar(700),
@varwhichPkg int /*client's will pass 1 for the deployed package else 2 for checked in package*/,
@gobjectID int out,
@packageID int out,
@platformID  smallint out,
@engineID    smallint out,
@objectID    smallint out,
@backupPlatformID smallint out,
@backupEngineID   smallint out,
@catId			  smallint out
AS
set nocount on
set @platformID = 0
set @engineID   = 0
set @objectID   = 0
set @gobjectID  = 0
set @packageID  = 0
set @backupPlatformID = 0
set @backupEngineID = 0
set @catId = 0

begin
if ( @varwhichPkg != 2 )
	begin
	select 
	@gobjectID = g.gobject_id,
	@packageID = case when (g.deployed_package_id > 0) then g.deployed_package_id
	           	 else
	             	  case when (g.checked_in_package_id > 0) then g.checked_in_package_id
	               	  else
	                      g.checked_out_package_id
	                  end 
	             end ,
	@platformID = inst.mx_platform_id,
	@engineID = inst.mx_engine_id,
	@objectID = inst.mx_object_id,
	@backupPlatformID = isnull(backup_engine.mx_platform_id,0),
	@backupEngineID = isnull(backup_engine.mx_engine_id,0),
	@catId = td.category_id
	from gobject g 
	inner join instance inst on g.gobject_id = inst.gobject_id 
	inner join template_definition td on g.template_definition_id = td.template_definition_id
	left join instance engine on  engine.mx_platform_id = inst.mx_platform_id
				    and engine.mx_engine_id = inst.mx_engine_id  
				    and engine.mx_object_id = 1
	left join redundancy redun on	redun.primary_gobject_id = engine.gobject_id
	left join instance backup_engine on backup_engine.gobject_id = redun.backup_gobject_id
	where g.tag_name = @varwhere and g.namespace_id = 1
	end
else
	begin
	select 
	@gobjectID = g.gobject_id ,
	@packageID = case when (g.checked_in_package_id > 0) then g.checked_in_package_id
	           	 else
	             	  case when (g.checked_out_package_id  > 0) then g.checked_out_package_id 
	                  else
					      g.deployed_package_id				              	                       
	                  end 
	             end ,
	@platformID = inst.mx_platform_id,
	@engineID = inst.mx_engine_id,
	@objectID = inst.mx_object_id,
	@backupPlatformID = isnull(backup_engine.mx_platform_id,0),
	@backupEngineID = isnull(backup_engine.mx_engine_id,0),
	@catId = td.category_id
	from   gobject g
	inner join instance inst on g.gobject_id = inst.gobject_id 
	inner join template_definition td on g.template_definition_id = td.template_definition_id
	left join instance engine on  engine.mx_platform_id = inst.mx_platform_id
				    and engine.mx_engine_id = inst.mx_engine_id  
				    and engine.mx_object_id = 1
	left join redundancy redun on	redun.primary_gobject_id = engine.gobject_id
	left join instance backup_engine on backup_engine.gobject_id = redun.backup_gobject_id
	where  g.tag_name = @varwhere and g.namespace_id = 1
	end

	-- if object is un-assigned, set platform to -1 ( config time only )
	if ( @platformID = 0 and @packageID <> 0 ) set @platformID = -1


end
set nocount off
go

