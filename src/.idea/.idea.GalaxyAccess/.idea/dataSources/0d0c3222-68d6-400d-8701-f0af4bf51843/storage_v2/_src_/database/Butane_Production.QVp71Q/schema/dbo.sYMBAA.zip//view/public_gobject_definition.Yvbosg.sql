create view dbo.public_gobject_definition as

SELECT     gobject.tag_name, gobject.contained_name, primitive_definition.primitive_name, attribute_definition.attribute_name, attribute_definition.mx_attribute_id, attribute_definition.has_config_set_handler, attribute_definition.mx_data_type, 
                      attribute_definition.is_array, attribute_definition.security_classification, attribute_definition.mx_attribute_category, 
                      attribute_definition.is_frequently_accessed, attribute_definition.is_locked, attribute_definition.mx_value, gobject.gobject_id, 
                      gobject.derived_from_gobject_id, gobject.contained_by_gobject_id, gobject.area_gobject_id, gobject.hosted_by_gobject_id, 
                      gobject.default_symbol_gobject_id, gobject.default_display_gobject_id, gobject.checked_in_package_id, gobject.checked_out_package_id, 
                      gobject.deployed_package_id,   gobject.configuration_version, gobject.deployed_version, 
                      gobject.hosting_tree_level, primitive_definition.mx_primitive_id, primitive_definition.parent_mx_primitive_id, 
                      primitive_definition.execution_group, primitive_definition.is_virtual, primitive_definition.primitive_guid, 
                      primitive_definition.runtime_handler_clsid, primitive_definition.package_handler_clsid, 
                      primitive_definition.major_version, primitive_definition.supports_dynamic_attributes, template_definition.original_template_tagname, 
                      template_definition.required_features, template_definition.supported_features, template_definition.category_id, template_definition.category_clsid, 
                      template_definition.runtime_clsid
FROM         gobject INNER JOIN
                      template_definition ON gobject.template_definition_id = template_definition.template_definition_id INNER JOIN
                      primitive_definition INNER JOIN
                      attribute_definition ON primitive_definition.primitive_definition_id = attribute_definition.primitive_definition_id ON 
                      template_definition.template_definition_id = primitive_definition.template_definition_id
go

