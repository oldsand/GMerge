-- usage: exec loadgobject @gobject_id, @loggedin_user_id_guid, @nPackageType
-- @nPackageType 1:CheckedIn  2:CheckedOut  3:Deployed

create    proc dbo.internal_load_gobject
        @gobject_id int,
        @loggedin_user_id_guid nvarchar(38),
        @nPackageType int,       
        @is_association int,
        @association_temp_file nvarchar(329) = NULL
as
begin
    set nocount on    
         
    -- figure out the correct package_id for this user
    declare @loggedin_user_id int
    declare @gobject_package_id int
    declare @parent_package_id int
    declare @template_definition_id int
    declare @is_template bit
    declare @derived_from_gobject_id int
    declare @is_checked_in bit

    select  @derived_from_gobject_id = derived_from_gobject_id 
    from    gobject 
    where   gobject_id = @gobject_id
    
    select @gobject_package_id = 
            case when o.checked_out_by_user_guid = @loggedin_user_id_guid then
                case when @nPackageType = 2 then
                    o.checked_out_package_id                    
                when @nPackageType = 3 then
                    o.last_deployed_package_id                  
                else
                    o.checked_in_package_id                 
                end
            else                
                case when @nPackageType = 3 then
                    o.last_deployed_package_id                  
                else
                    o.checked_in_package_id                 
                end
            end,
        @is_checked_in = 
            case when o.checked_out_by_user_guid = @loggedin_user_id_guid then
                case when @nPackageType = 2 then                    
                    0
                else                    
                    1
                end
            else                
                1
            end,
        @template_definition_id = o.template_definition_id,
        @is_template = o.is_template
    from 
        gobject o
    where
        o.gobject_id = @gobject_id
    
    select  @parent_package_id = derived_from_package_id
    from    package
    where   gobject_id = @gobject_id and package_id = @gobject_package_id

    -- 1st RecordSet. Return template_definition_id, package_id, is_checked_in 
    -- For template, package_id is actually the package_id of itself.
    -- For instance, package_id is the derived_from_package_id.
    if (@is_template = 0)
    begin
        select  @template_definition_id as template_definition_id,
                @gobject_id as gobject_id,
                @derived_from_gobject_id as template_gobject_id,
                @parent_package_id as template_package_id,
                @is_checked_in as is_checked_in
    end
    else
    begin
        select  @template_definition_id as template_definition_id , 
                @gobject_id as gobject_id,
                @gobject_id as template_gobject_id,
                @gobject_package_id as template_package_id,
                @is_checked_in as is_checked_in
    end             
  
    -- Calculate the derivation level of this object.
    declare @derivationlevel smallint
    declare @objectId int

    set @derivationlevel = 0
    set @objectId = @gobject_id

    while (@objectId is not null)
    begin   
        select  @objectId = derived_from_gobject_id
        from    gobject
        where   gobject_id = @objectId

        if (@objectId = 0)
            break

        set @derivationlevel = @derivationlevel + 1

        -- raise error here
        if (@derivationlevel > 32)
        begin
            set @derivationlevel = -1
            break
        end
    end

    -- load gobject
    select  p.package_id,
            p.gobject_id,
            p.status_id,
            p.reference_status_id,
            p.security_group,
            p.derived_from_package_id,
            g.gobject_id,
            g.template_definition_id,
            g.derived_from_gobject_id,
            g.contained_by_gobject_id,
            g.area_gobject_id,
            g.hosted_by_gobject_id,
            g.checked_out_by_user_guid,
            g.default_symbol_gobject_id,
            g.default_display_gobject_id,
            g.checked_in_package_id,
            g.checked_out_package_id,
            g.deployed_package_id,
            g.last_deployed_package_id,
            g.tag_name,
            g.contained_name,
            g.identity_guid,
            g.configuration_guid,
            g.configuration_version,
            g.deployed_version,
            g.is_template,
            g.is_hidden,
            g.software_upgrade_needed,
            g.hosting_tree_level,
            g.hierarchical_name,
            instance.mx_platform_id,
            instance.mx_engine_id,
            instance.mx_object_id ,
            ghost.tag_name as host_name,
            gcontainer.tag_name as container_name,
            garea.tag_name as area_name,
            gderived.tag_name as derived_name,
            gbasedon.tag_name as basedon_name,
            gbeingeditedby.user_profile_name as beingeditedby_name,
            @derivationlevel as derivation_level,
            g.namespace_id,
            gderived.configuration_version as template_configuration_version
    from    package p
    inner join gobject g
        on p.gobject_id = g.gobject_id
        and g.gobject_id = @gobject_id
    left join instance
        on instance.gobject_id = g.gobject_id
    left join gobject ghost
        on g.hosted_by_gobject_id = ghost.gobject_id
    left join gobject gcontainer
        on g.contained_by_gobject_id = gcontainer.gobject_id
    left join gobject garea
        on g.area_gobject_id = garea.gobject_id
    left join gobject gderived
        on g.derived_from_gobject_id = gderived.gobject_id
    left join template_definition td
        on g.template_definition_id = td.template_definition_id
    left join gobject gbasedon
        on td.base_gobject_id = gbasedon.gobject_id
    left join user_profile gbeingeditedby
        on g.checked_out_by_user_guid = gbeingeditedby.user_guid
    where p.package_id = @gobject_package_id

    if( @is_template = 0 )
    begin
        -- For instance, load the InstancePackage
        exec internal_load_instance_package  @gobject_id,@gobject_package_id

        -- load the package features
        exec internal_load_package_feature @gobject_id, @gobject_package_id
        

		--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
		 --ITVAAPP POC START
        declare @gobject_id_prev int
        declare @gobject_package_id_prev int
        
		--Store the initial value that came as a part of processing
        set @gobject_id_prev = @gobject_id
        set @gobject_package_id_prev = @gobject_package_id
        
		declare @category_id int
			--store previous values
		select  @category_id = category_id 
				from gobject with (NOLOCK) 
				inner join template_definition on 
					gobject.template_definition_id = template_definition.template_definition_id
				where gobject_id = @derived_from_gobject_id
		--If ITVAPP type then only set the value otherwise NO
		--This is done becuase if ITVAPP POC is set need to populate the 
		--VER table (below) for the ITVAPP intance gobject ID but the information
		--will be from the ITVAPP template
		if(@category_id = 26)
		begin
			set @gobject_id = @derived_from_gobject_id
			set @gobject_package_id = @parent_package_id
		end
		--ITVAPP POC END


        -- load visual element refereneces
        if (@is_association = 0)
        begin
        select gobject_id = @gobject_id_prev,
            package_id = @gobject_package_id_prev,
            mx_primitive_id,
            visual_element_reference_index,
            reference_string,
            visual_element_bind_status
        from internal_visual_element_reference_per_user_view v
        where v.gobject_id = @gobject_id 
            and v.package_id = @gobject_package_id
            and v.user_guid = @loggedin_user_id_guid
        order by mx_primitive_id, visual_element_reference_index
        end
        else
        begin
			if (@association_temp_file is NULL or @association_temp_file = '')
			begin				
				select gobject_id = @gobject_id_prev,
				package_id = @gobject_package_id_prev,
				mx_primitive_id,
				visual_element_reference_index,
				reference_string,
				visual_element_bind_status
				from internal_visual_element_reference_per_user_view_association v
				where v.gobject_id = @gobject_id 
				and v.package_id = @gobject_package_id
				and v.user_guid = @loggedin_user_id_guid
				order by mx_primitive_id, visual_element_reference_index
			end				
			else
			begin -- Return visual element reference of the current object as well of associated objects
				create table #association
				(
					id int not null,
					tag_name nvarchar(128) not null
				)
				EXEC internal_create_and_populate_association_temp_table @association_temp_file
				
				select gobject_id = @gobject_id_prev,
					package_id = @gobject_package_id_prev,
					mx_primitive_id,
					visual_element_reference_index,
					reference_string,
					visual_element_bind_status,
					forAssociation = 0,
					N''					
				from internal_visual_element_reference_per_user_view_association v
				where v.gobject_id = @gobject_id 
					and v.package_id = @gobject_package_id
					and v.user_guid = @loggedin_user_id_guid			
				union all
				select gobject_id = aso.id,
					package_id = g.checked_in_package_id,
					mx_primitive_id,
					visual_element_reference_index,
					reference_string,
					visual_element_bind_status,					
					forAssociation = 1,
					g.tag_name				
				from internal_visual_element_reference_per_user_view v
				join #association aso on v.gobject_id = aso.id
				join gobject g on g.gobject_id = aso.id 
					and v.package_id = g.checked_in_package_id
				where v.user_guid = @loggedin_user_id_guid
				and visual_element_bind_status = 0
				order by mx_primitive_id, visual_element_reference_index
			end
        end

        --ITVAPP POC START
        --Reset the values for further use. the OLD values will be retained
        set @gobject_id = @gobject_id_prev
        set @gobject_package_id = @gobject_package_id_prev
        --ITVAPP POC END

        -- Load primitive_instance_file_table_link information
        select  mx_primitive_id,
                file_id,
                is_needed_for_package,
                is_needed_for_runtime,
                is_needed_for_editor
        from    primitive_instance_file_table_link
        where   gobject_id = @gobject_id
                and package_id = @gobject_package_id
    end            
end
go

