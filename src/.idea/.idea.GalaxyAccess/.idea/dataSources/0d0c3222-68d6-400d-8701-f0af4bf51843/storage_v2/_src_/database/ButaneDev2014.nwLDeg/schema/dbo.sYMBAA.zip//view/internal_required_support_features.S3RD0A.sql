/**************************************************/
/*Object Name :  internal_required_support_features			  */
/*Object Type :  View.					  */
/*Purpose	  :  To provide required_feature and supported feature of all the instances*/
/*Used By :    CDI								  */
/**************************************************/

create view dbo.internal_required_support_features as
select 
g.gobject_id,
g.tag_name,
td.required_features,
td.supported_features from 
template_definition td
inner join gobject g 
on g.template_definition_id = td.template_definition_id 
and g.is_template = 0
go

