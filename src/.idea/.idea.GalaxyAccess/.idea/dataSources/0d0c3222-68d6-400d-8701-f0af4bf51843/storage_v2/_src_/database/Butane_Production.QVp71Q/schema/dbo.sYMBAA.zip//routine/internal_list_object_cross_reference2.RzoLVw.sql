/*************************************************************************/
/*Object Name :  internal_list_object_cross_reference2                   */
/*Object Type :  Stored Procedure.                                       */
/*Purpose     :  To provide cross reference information for a given      */
/*               gobject similar to internal_list_object_cross_reference */
/*Used By     :  CDI                                                     */
/*************************************************************************/
create procedure dbo.internal_list_object_cross_reference2
    @namespace_id int,
    @tag_name nvarchar(32)
AS
begin
    select  referring_TagName,
            referringAttribute_full_name,
            reference_string,
            context_string,
            Referred_TagName,
            referredToAttributeName
    from    internal_reference_primitive_attribute v
    inner join gobject g 
        on  v.referredToGobjectID = g.gobject_id
    where 
            g.namespace_id = @namespace_id 
        and g.tag_name = @tag_name
end
go

