
/*
    Please Note: This proc is currently for
    IntouchViewapp templates.  It may easily be
    extended for other categories...
*/
create proc dbo.internal_has_deployed_instances
@template_id int,
@has_deployed_instances bit out
as
set @has_deployed_instances = 0
if exists(
select  1 
from deployed_intouch_viewapp div
inner join gobject g on
    div.gobject_id = g.gobject_id and
    g.derived_from_gobject_id = @template_id   
)
begin
    set @has_deployed_instances = 1
end
go

