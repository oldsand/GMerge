CREATE proc dbo.internal_load_instance_package
	@gobject_id as int,
    @package_id as int
as 
begin
    set nocount on
    
    /*
    ** CR L00115843: 
    ** Summary of changes:
    ** - Don't call scalar function get_visual_element_id()
    ** - Avoid in-lined selects
    */
    -- load the primitive_instance rows
    select
        primitive_definition_id,
        primitive_name,
        pri.mx_primitive_id,
		parent_mx_primitive_id,
		execution_group,
		execution_order,
		owned_by_gobject_id,
		extension_type,
		is_object_extension,
		checked_in_primitive_version,
        checked_out_primitive_version,
        ISNULL (vev.visual_element_id, 0),      
        case when owned_by_gobject_id > 0 then
          owning_object.tag_name
        else
          '' 
        end as inheritedfrom,
        entity_change_type,
        operation_on_primitive_mask,
		created_by_parent,
		status_id,
		ref_status_id,        
        primitive_attributes,
		mx_value_errors,
		mx_value_warnings,
		mx_value_reference_warnings        
    from
        primitive_instance pri
    inner join gobject owning_object on
        owning_object.gobject_id = 
        case when owned_by_gobject_id > 0 then owned_by_gobject_id else pri.gobject_id end
    left outer join
		visual_element_version vev
	on	vev.gobject_id = pri.gobject_id
	and vev.package_id = pri.package_id
	and vev.mx_primitive_id = pri.mx_primitive_id
    where
		pri.gobject_id = @gobject_id
    and pri.package_id = @package_id
    order by
        pri.mx_primitive_id

    -- load the dynamic_attribute rows
    select
		da.mx_primitive_id,
        da.mx_attribute_id,
		da.attribute_name,
		da.mx_data_type,
		da.is_array,
		da.security_classification,
		da.mx_attribute_category,
		da.lock_type,
        da.mx_value,
		da.owned_by_gobject_id,
        da.original_lock_type,
        da.dynamic_attribute_type,
        case when owned_by_gobject_id > 0 then
          owning_object.tag_name
        else
          '' 
        end as dainheritedfrom,
        da.bitvalues
    from
        dynamic_attribute da
    inner join gobject owning_object on
        owning_object.gobject_id = 
        case when owned_by_gobject_id > 0 then owned_by_gobject_id else da.gobject_id end
    where 
		da.gobject_id = @gobject_id
	and	da.package_id = @package_id

	-- load the reference data  from the attribute reference table
    select 
        a.referring_mx_primitive_id,
       a.referring_mx_attribute_id,
	   a.element_index,
	   isnull(inst.mx_platform_id,0) as platform_id,
       isnull(inst.mx_engine_id,0) as engine_id,
       isnull(inst.mx_object_id,0) as object_id,
       isnull(backup_engine.mx_platform_id,0) as redundant_engine_platform_id,
       isnull(backup_engine.mx_engine_id,0) as redundant_engine_engine_id,		
	   object_signature,
       reference_string,
	   context_string,
	   resolved_mx_primitive_id,
	   resolved_mx_attribute_id,
	   resolved_mx_property_id,
	   attribute_signature, 
	   lock_type,
	   attr_res_status,
	   is_valid,
	   isnull(g.tag_name,'') as tag_name,
	   a.attribute_index,
	   isnull(td.category_id,0) as cat_id
        
  from  attribute_reference a 
  left join instance inst 
   on   a.resolved_gobject_id = inst.gobject_id
  left join gobject g
   on   g.gobject_id = inst.gobject_id
  left join template_definition td 
   on	g.template_definition_id = td.template_definition_id   
  left join instance engine 
   on		inst.mx_platform_id = engine.mx_platform_id 
		and inst.mx_engine_id = engine.mx_engine_id
	    and engine.mx_object_id = 1
  left join redundancy redun 
   on		redun.primary_gobject_id = engine.gobject_id
  left join instance backup_engine 
  on		backup_engine.gobject_id = redun.backup_gobject_id
  where 
		a.gobject_id = @gobject_id 
	and a.package_id = @package_id
    
  order by a.referring_mx_primitive_id,a.referring_mx_attribute_id,a.element_index 


end
go

