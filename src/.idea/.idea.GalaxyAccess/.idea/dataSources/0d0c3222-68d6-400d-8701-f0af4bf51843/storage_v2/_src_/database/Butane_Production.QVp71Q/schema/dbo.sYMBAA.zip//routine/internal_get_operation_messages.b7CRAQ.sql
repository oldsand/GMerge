CREATE proc dbo.internal_get_operation_messages
@operation_id int
as
select 
    message_text "Operation Messages",
    message_time "Message Time"
    
from operation_message
where operation_id = @operation_id
order by message_id desc
go

