--***********************************************************************************************************************
--***	
--***	OBJECT NAME:	internal_get_failover_partner_id
--***	DESCRIPTION:	Procedure is used to obtain a gobject's failover parnter's gobject_id
--***	
--***	USAGE: 		dbo.internal_get_failover_partner_id(21) --(where 21 is the gobject_id of the object)
--***			Function is used by procedure: internal_set_area_association
--***	RETURNS :
--***	=========
--***	0 	   - if object does not have a failover partner
--***	gobject_id - if object has a failover partner
--***	
--***********************************************************************************************************************

CREATE procedure dbo.internal_get_failover_partner_id( 
	@gobject_id int, @failoverPartnerID int out
	)

as
begin
	
	declare @tag_name nvarchar(329)
	select @tag_name = tag_name  from gobject where gobject_id = @gobject_id

	select @failoverPartnerID = gobject.gobject_id
	from
	gobject,template_definition 
	where
	tag_name  = @tag_name  and template_definition.category_id = 3 and gobject.namespace_id in (1,2) and
	gobject.gobject_id <> @gobject_id and 
	gobject.template_definition_id = template_definition.template_definition_id
	
	if (@failoverPartnerID is null)
	set @failoverPartnerID  =  0
	
		
end


go

