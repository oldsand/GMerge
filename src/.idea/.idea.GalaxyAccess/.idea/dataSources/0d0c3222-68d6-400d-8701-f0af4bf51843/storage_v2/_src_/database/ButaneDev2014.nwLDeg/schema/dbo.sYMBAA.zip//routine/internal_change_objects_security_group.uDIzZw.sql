/********************************************************************/
/*Object Name	:  internal_change_objects_security_group              */
/*Object Type	:  Stored Proc.										*/
/*Purpose		:  to change the security groups of the objects		*/
/*Used By		:  CDI												*/
/********************************************************************/
CREATE   PROCEDURE dbo.internal_change_objects_security_group

@FileNameOfIds nvarchar (265)
 AS
begin
	set nocount on

 
	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #results_table 
	( 
		gobject_id int, 
		security_group nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS  , 
		checked_in_package_id int
	)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '

	EXEC sp_executesql @SQL

	update package set security_group = #results_table.security_group 
	FROM 
		package 
	INNER JOIN #results_table 
			ON 
			package.gobject_id = #results_table.gobject_id
		and #results_table.checked_in_package_id = package.package_id
		
	
	CREATE TABLE  #backupengines( gobject_id int, security_group nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS)
	
	insert into #backupengines
	select red.backup_gobject_id, r.security_group
	from redundancy red
	inner join #results_table r
	on r.gobject_id = red.primary_gobject_id	
		
	update  p 
    set     p.security_group = r.security_group
    from    package p
    inner   join #backupengines r
            on r.gobject_id = p.gobject_id    
    inner join gobject g
			on g.gobject_id = r.gobject_id					
	where   p.package_id = g.checked_in_package_id            

	drop table #backupengines
	
	drop table #results_table


	
end

go

