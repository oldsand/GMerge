

create   procedure dbo.internal_update_file_pending_update2
@file_name nvarchar(256),
@vendor_name nvarchar(256)
as
begin
    set nocount on
    declare @file_id int
    
    select @file_id = file_id 
    from file_table
    where vendor_name = @vendor_name and
          file_name = @file_name
    exec internal_update_file_pending_update @file_id

    /************************************************************
    *  return a list of all gobjects affected by this update...
    ************************************************************/
    
/*    -- get files per primitive definition....
    select g.gobject_id gobject_id
    from   file_table f
    inner join file_primitive_definition_link fpdl on 
              f.file_id = fpdl.file_id
    inner join primitive_definition pd on 
            fpdl.primitive_definition_id = pd.primitive_definition_id
    inner join template_definition td on 
            pd.template_definition_id = td.template_definition_id
    inner join gobject g on 
            g.template_definition_id = td.template_definition_id
    where f.file_id = @file_id
    
    union
    
    -- get files per feature....
    select pifl.gobject_id gobject_id
    from file_table f
    inner join feature_file_link ffl on
            f.file_id = ffl.file_id
    inner join feature fe on
            fe.feature_id = ffl.feature_id
    inner join primitive_instance_feature_link pifl on
            pifl.feature_id = fe.feature_id
    where f.file_id = @file_id
      
    union
    -- get files per client control....
    
    select vev.gobject_id gobject_id
    from file_table f
    inner join primitive_instance_file_table_link piftl on
            f.file_id = piftl.file_id
    inner join visual_element_version vev on
            piftl.gobject_id = vev.gobject_id and
            piftl.package_id = vev.package_id and
            piftl.mx_primitive_id = vev.mx_primitive_id
    where f.file_id = @file_id
    order by gobject_id    
*/        
end
go

