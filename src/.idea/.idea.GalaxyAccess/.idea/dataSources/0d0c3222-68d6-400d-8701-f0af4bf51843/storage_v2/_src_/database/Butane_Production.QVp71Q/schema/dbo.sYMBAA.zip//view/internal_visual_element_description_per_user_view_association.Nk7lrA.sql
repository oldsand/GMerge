
/*
***********************************************************************************************************************
***        
***        object name:     internal_visual_element_description_per_user_view
***        description:       view is used to object information about visual elements
***        
***        usage:              select * from internal_visual_element_description_view
***             where user_guid = 'FB2F7F08-69BC-43C5-AFE3-0CAC0129CADF'
***                                    
***        returns :
***        =========
***                    data set containing description, binary, name, etc.
***        
***        
***********************************************************************************************************************
*/
 
create view dbo.internal_visual_element_description_per_user_view_association
as
select 
    v.gobject_id,
    v.visual_element_id, 
    v.visual_element_type,
    v.visual_element_category,                   
    v.visual_element_name, 
    v.package_id, 
    v.mx_primitive_id,
    v.inheritance_status, 
    v.description,
    v.primitive_name, 
    v.tag_name tag_name,
    v.package_type,
    v.hierarchical_visual_element_name, 
    v.gobject_hierarchical_name,
    v.is_library_visual_element,
    ove.thumbnail,
    ove.visual_element_definition,
    up.user_guid,
    v.inherited_from_gobject_id,
	g.is_hidden,
    vev.inherited_from_visual_element_id,
    fgl.folder_id,
	v.is_thumbnail_dirty
from
internal_visual_element_description_view v (noexpand)
inner join visual_element_version vev on
	v.gobject_id = vev.gobject_id and
	v.package_id = vev.package_id and 
	v.mx_primitive_id = vev.mx_primitive_id
inner join owned_visual_element ove on
    vev.inherited_from_visual_element_id = ove.visual_element_id and
    vev.inherited_from_gobject_id = ove.gobject_id and
    vev.inherited_from_package_id = ove.package_id and 
    vev.inherited_from_mx_primitive_id = ove.mx_primitive_id
inner join gobject g on
	v.gobject_id = g.gobject_id
inner join dbo.user_profile up
    on g.checked_out_by_user_guid is null and v.package_id = g.checked_in_package_id
    or (g.checked_out_by_user_guid  = up.user_guid and v.package_type = 'O')
    or (g.checked_out_by_user_guid  <> up.user_guid and v.package_id = g.checked_in_package_id)
left outer join dbo.folder_gobject_link fgl on
    g.gobject_id = fgl.gobject_id
go

