--set the original galaxy identity_guid after the migration
create proc dbo.internal_set_galaxy_identity_guid
    @galaxy_identity_guid uniqueidentifier
as

begin	

	update gobject
	set	gobject.identity_guid = @galaxy_identity_guid	
	from	gobject 
	inner join template_definition
	on gobject.derived_from_gobject_id = template_definition.base_gobject_id
	where template_definition.original_template_tagname = '$Galaxy'

end

go

