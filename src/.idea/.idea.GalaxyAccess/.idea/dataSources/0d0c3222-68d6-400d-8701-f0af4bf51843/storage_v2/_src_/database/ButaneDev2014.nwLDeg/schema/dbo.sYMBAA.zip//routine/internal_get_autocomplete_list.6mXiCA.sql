create procedure dbo.internal_get_autocomplete_list(@starts_with nvarchar(max), @index int, @max_count int, @total_count int output)
as
begin
-- todo: set isolation level read uncommitted, set deadlock priority low, catch deadlocks
set nocount on

declare @pattern nvarchar(max)
set @pattern = replace(@starts_with, '_', '[_]') + '%'

if charindex('.', @starts_with) = 0 
begin
  -- @starts_with has no dot
  select @total_count = count(1) 
  from gobject 
  where 
    tag_name like @pattern and 
    namespace_id = 1 and 
    is_template = 0

  select name, 27 icon -- blue ball icon
  from 
  (
    select tag_name name, row_number() over (order by tag_name) as row
    from gobject
    where 
      tag_name like @pattern and 
      namespace_id = 1 and 
      is_template = 0
  ) as t
  where t.row between @index + 1 and @index + @max_count
  order by t.row
end

else

begin
  -- @starts_with has a dot
  declare @last_dot int;
  set @last_dot = dbo.get_last_dot(@starts_with)
  declare @base_name nvarchar(max)
  set @base_name = substring(@starts_with, 1, @last_dot - 1)
  declare @hierarchical_name nvarchar(max) 
  set @hierarchical_name = @base_name
  declare @results table (name nvarchar(max), icon int)
  declare @gobject_id int
  set @gobject_id = 0
  declare @checked_in_package_id int

  while 1 = 1
  begin
    -- get gobject id
    -- work backwards from final dot, trying longest possible object name, to shortest
    select @gobject_id = gobject_id, @checked_in_package_id = checked_in_package_id
    from gobject
    where
      namespace_id = 1 and
      (hierarchical_name = @hierarchical_name or tag_name = @hierarchical_name)

    if @gobject_id > 0 break -- longest possible object name found

    declare @last_hierarchical_dot int
    set @last_hierarchical_dot = dbo.get_last_dot(@hierarchical_name)

    if @last_hierarchical_dot = 0 break
    set @hierarchical_name = substring(@hierarchical_name, 1, @last_hierarchical_dot - 1)
  end

  if @gobject_id = 0
  begin
    -- return if user entered invalid name
    set @total_count = 0
    select * from @results
    
	return
  end

  declare @start int
  set @start = len(@hierarchical_name) + 2

  insert into @results(name, icon) 
  (
    -- user types Tank1. 
    -- Tank1.Valve and Tank1.Pump are hierarchical names in galaxy
    -- return Valve and Pump

    select distinct dbo.get_dotted_name(hierarchical_name, @start), 27 -- blue ball icon
    from gobject 
    where 
      namespace_id = 1 and
      is_hidden = 0 and
      substring(hierarchical_name, @start, 1) <> N'_' and
      hierarchical_name like @pattern
  )

  -- collect primitive names and ids in @primitives to be leveraged several places below
  declare @primitives table (id int, name nvarchar(max))

  insert into @primitives(id, name)
  (
    select pri.primitive_definition_id, pri.primitive_name
    from package pack
      inner join primitive_instance pri on pri.package_id = pack.package_id and pri.gobject_id = pack.gobject_id
      inner join primitive_definition pridef on pridef.primitive_definition_id = pri.primitive_definition_id
    where 
      pack.gobject_id = @gobject_id and
      pack.package_id = @checked_in_package_id and
      pridef.template_definition_id <> 1
  )

  insert into @results(name, icon) 
  (
    select name, min(icon)
    from
    (
      select 
        dbo.get_dotted_name(pa.name, @last_dot + 1) name,
        case pa.name when @base_name + N'.' + dbo.get_dotted_name(pa.name, @last_dot + 1) then pa.icon else 27 end icon
      from
      (
        -- add attribute name
        select 
          @hierarchical_name + N'.' + pri.name + case pri.name when N'' then N'' else N'.' end + attribute_name name,
          mx_data_type icon,
          mx_attribute_category
        from @primitives pri
          inner join attribute_definition on primitive_definition_id = pri.id
        where 
          attribute_name <> N''

        union all

        -- add dynamic attribute name
        select 
          @hierarchical_name + N'.' + attribute_name name,
          mx_data_type icon,
          mx_attribute_category
        from package pack
          inner join dynamic_attribute dyn on dyn.package_id = pack.package_id 
        where
          pack.package_id = @checked_in_package_id
      ) as pa
      where
        name like @pattern and
        mx_attribute_category not in (-1, 0, 1, 17, 18, 19)
    ) as t
    group by name
  )

  if substring(@starts_with, @last_dot + 1, 1) <> N'_'
  begin
    delete from @results where left(name, 1) = N'_'
  end

  declare @mx_data_type int
  set @mx_data_type = -1 -- -1 means attribute not yet found

  -- find attribute in order to determine data type

  select top 1 @mx_data_type = mx_data_type
  from @primitives pri
    inner join attribute_definition on primitive_definition_id = pri.id
  where 
    @hierarchical_name + N'.' + pri.name + case pri.name when N'' then N'' else N'.' end + attribute_name = @base_name

  if @mx_data_type < 0
  begin
    select top 1 @mx_data_type = mx_data_type
    from package pack
      inner join dynamic_attribute dyn on dyn.package_id = pack.package_id 
    where 
      pack.package_id = @checked_in_package_id and
      @hierarchical_name + N'.' + attribute_name = @base_name
  end

  if @mx_data_type > -1
  begin
    set @pattern = substring(@pattern, dbo.get_last_dot(@pattern) + 1, 9999);
    declare @properties table (name nvarchar(max), icon int)

    if 'Buffer' like @pattern insert into @properties values('Buffer', 27)
    if 'Category' like @pattern insert into @properties values('Category', 2)
    if 'Dimension1' like @pattern insert into @properties values('Dimension1', 2)
    if 'Locked' like @pattern insert into @properties values('Locked', 1)
    if 'Quality' like @pattern insert into @properties values('Quality', 12)
    if 'SecurityClassification' like @pattern insert into @properties values('SecurityClassification', 11)
    if 'Time' like @pattern insert into @properties values('Time', 6)
    if 'Type' like @pattern insert into @properties values('Type', 10)
    if 'Value' like @pattern insert into @properties values('Value', 27)

    insert into @results(name, icon)
    (
      select * from @properties where name not in (select name from @results)
    )

    if @mx_data_type = 2 -- integers require bit fields 00 to 31
    begin
      -- "sort" forces bit fields to bottom of autocomplete list
      declare @ordered table (sort int, name nvarchar(max), icon int)

      insert into @ordered(sort, name, icon)
      (
        select row_number() over (order by name), name, icon from @results
      )

      declare @bit int
      set @bit = 0
      while @bit < 32
      begin
        declare @bit_string nvarchar(2)
        if (@bit < 10) set @bit_string = '0' + str(@bit, 1) else set @bit_string = str(@bit, 2)
        if @bit_string like @pattern 
        begin
          insert into @ordered values(@bit + 10000, @bit_string, 1)
        end
        set @bit = @bit + 1
      end

      select @total_count  = count(1) from @ordered
      select name, icon
      from 
      (
        select name, icon, row_number() over (order by sort) as row
        from @ordered
      ) as t
      where t.row between @index + 1 and @index + @max_count
      order by t.row
      
      return
    end
  end

  select @total_count = count(1) from @results 
  
  select name, icon
  from 
  (
    select name, icon, row_number() over (order by name) as row
    from @results
  ) as t
  where t.row between @index + 1 and @index + @max_count
  order by t.row
end


end
go

