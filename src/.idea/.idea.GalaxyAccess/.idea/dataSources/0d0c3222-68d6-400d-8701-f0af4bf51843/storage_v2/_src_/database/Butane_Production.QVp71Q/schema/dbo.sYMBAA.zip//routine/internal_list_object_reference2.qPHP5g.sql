/**********************************************************************/
/*Object Name :  internal_list_object_reference2					  */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To provide reference information for a given		  */
/*               gobject similar to internal_list_object_reference    */
/*Used By	  :  CDI												  */
/**********************************************************************/
CREATE PROCEDURE dbo.internal_list_object_reference2
	@namespace_id int,
    @tag_name nvarchar(32)
AS
begin
    select  referring_TagName,
            case when referringPrimitiveName <> '' then
                referringPrimitiveName + '.' + referringAttributeName
            else
                referringAttributeName
            end
            as referringAttributeName,
            reference_string,
            context_string,
            Referred_TagName,
            referredAttribute_full_name
    from    internal_reference_primitive_attribute v
    inner join gobject g 
        on  v.referringGobjectID = g.gobject_id
    where 
            g.namespace_id = @namespace_id 
        and g.tag_name = @tag_name
end
go

