-- Adds a single unbound visual element reference to the given primitive
-- 
-- System will attempt to bind this reference at a later time
create proc dbo.internal_add_visual_element_reference
  @gobject_id int,
  @package_id int,
  @mx_primitive_id smallint,
  @visual_element_reference_index int,
  @reference_string nvarchar(395),
  @visual_element_id int
as
begin tran
    set nocount on
    declare @visual_element_name nvarchar(362)
    declare @visual_element_type nvarchar(329)
    declare @tag_name nvarchar(32)
    declare @primitive_name nvarchar(329)
    declare @is_relative_reference bit
    declare @relative_object_name nvarchar(329)
    declare @is_hierarchical_visual_element_name bit
    
    set @relative_object_name = ''
    -- break the reference down into its parts
    set @primitive_name = N'' -- initialize out param
    exec internal_parse_visual_element_reference_string
        @reference_string,
        @visual_element_type output,
        @tag_name output,
        @primitive_name output,
        @visual_element_name output,
        @is_relative_reference output,
        @relative_object_name output,
	@is_hierarchical_visual_element_name output

       
    if(@is_relative_reference = 1)  
    begin
        -- the tag_name is not relevant, so we will not store it..
        set @tag_name = null
	end


    -- add to visual_element_reference table
    insert into visual_element_reference 
    (
        gobject_id, 
        package_id, 
        mx_primitive_id,
        visual_element_reference_index,
        --visual_element_bind_status, -- this is now a calculated column....
        is_relative_reference,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id ,
        checked_out_bound_visual_element_gobject_id ,
        checked_out_bound_visual_element_package_id ,
        checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        checked_in_unbound_visual_element_name ,
        checked_in_unbound_visual_element_type ,
        checked_in_unbound_tag_name  ,
        checked_in_unbound_primitive_name ,
        checked_in_unbound_relative_object_name  ,
        checked_in_unbound_visual_element_id,
        checked_out_unbound_visual_element_name ,
        checked_out_unbound_visual_element_type ,
        checked_out_unbound_tag_name  ,
        checked_out_unbound_primitive_name,
        checked_out_unbound_relative_object_name  ,
        checked_out_unbound_visual_element_id,
        checked_out_to_user_guid
       

    ) 
    values
    (
        @gobject_id,
        @package_id,
        @mx_primitive_id,
        @visual_element_reference_index,
        --0, --visual_element_bind_status -- this is now a calculated column....
        @is_relative_reference,
        null,--checked_in_bound_visual_element_gobject_id ,
        null,--checked_in_bound_visual_element_package_id ,
        null,--checked_in_bound_visual_element_mx_primitive_id ,
        null,--checked_out_bound_visual_element_gobject_id ,
        null,--checked_out_bound_visual_element_package_id ,
        null,--checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        @visual_element_name,--checked_in_unbound_visual_element_name ,
        @visual_element_type,--checked_in_unbound_visual_element_type ,
        @tag_name,--checked_in_unbound_tag_name,
        @primitive_name,--checked_in_unbound_primitive_name not ,
        @relative_object_name,--checked_in_unbound_relative_object_name  ,
        @visual_element_id,--checked_in_unbound_visual_element_id,
        @visual_element_name,--checked_out_unbound_visual_element_name ,
        @visual_element_type,--checked_out_unbound_visual_element_type ,
        @tag_name,--checked_out_unbound_tag_name  ,
        @primitive_name,--checked_out_unbound_primitive_name ,
        @relative_object_name,--checked_out_unbound_relative_object_name  ,
        @visual_element_id,--checked_out_unbound_visual_element_id
        null--checked_out_to_user_guid
   
    )


commit

go

