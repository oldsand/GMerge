/*
This procedure will get called at the start of the deployment operation to check 
whether software_upgrade is needed for the list of Objects which are getting deployed

usage:
declare @P1 int
exec internal_private_software_upgrade_needed'
     <r><gobject id = 23 ></r>, @P1
*/
create procedure dbo.internal_private_software_upgrade_needed
@FileNameOfIds  nvarchar(400),
@sur_required int  output
 as
begin
set nocount on

	declare  @platformtable  table (platform_gobject_id int)
	declare  @sur int
	declare  @upgrade_required int
	declare  @all_platform_not_included_in_deployed_List int

	--Insert Data into #deployed_ids
	declare @iDoc int
	create table #deployed_ids (gobject_id int)
	-- call the stored procedure 'internal_construct_table_from_file'
	exec internal_construct_table_from_file @FileNameOfIds, '#deployed_ids'
	
	--@platformtable:: it contains the list of all the platforms on which the input objects are going to deploy....
	insert into @platformtable
	select distinct gobject_id
	from  instance
	where  ( (  mx_platform_id IN
	(select distinct mx_platform_id  from instance where gobject_id in(select gobject_id from #deployed_ids)) 
	and (mx_engine_id = 1) AND (mx_object_id = 1)))


	declare @platform_check_required int

	--CHECK WHETHER ANY PLATFORM HAS BEEN selectED OR NOT IN THE SEND DEPLOYED LIST...
	set @platform_check_required = (select count(gobject.gobject_id) from gobject,platform 
	where (gobject.gobject_id = platform.platform_gobject_id ) 
	and gobject.gobject_id in (select gobject_id from #deployed_ids))


	if(@platform_check_required <> 0)
	begin
		--if platform selected then check whether all the platforms has been selected or Not...for all the objects which are going to get deployed.,.,.
		set @all_platform_not_included_in_deployed_List = (select distinct count(platform_gobject_id)
		from @platformtable where platform_gobject_id not in
		(select gobject.gobject_id from gobject,platform 
		where (gobject.gobject_id = platform.platform_gobject_id ) 
		and gobject.gobject_id in (select gobject_id from #deployed_ids)))
	end

	---declare variable
	set @upgrade_required = 0 
	set @sur = 0 
	set @sur = (select count(gobject_id) from gobject where 
		(gobject_id in(select gobject_id from #deployed_ids) and  software_upgrade_needed = 1))

	--- 
	if ( @sur <> 0)
	begin
		if(@platform_check_required <> 0)
		begin
			if( @all_platform_not_included_in_deployed_List <> 0 ) 
				set @upgrade_required = 1 
		end
		else
			set @upgrade_required = 1 
	end
	else
	begin

		--FIND ALL THE OBJECTS WHICH ARE UNDER THIS PLATFORM IN WHICH THESE OBJECTS
		--ARE selectED AND IF ANY OBJECT REQUIRE SUR THEN MARK @sur=1
		set @sur = (select count(gobject_id) from gobject where (software_upgrade_needed = 1)
					and 
					(gobject_id in(select gobject_id from instance where mx_platform_id in 
						( select distinct mx_platform_id from instance where
						 gobject_id in		
						(select gobject_id from #deployed_ids)))))

		if(@sur<>0)
			set @upgrade_required = 1 
		else
		begin
			
				--This is a extra check there can be case that objects under none of them need sur but still they need
				--have some pending file so they still need to redeploy the platform				
				if(@platform_check_required <> 0)
				begin	
					if( @all_platform_not_included_in_deployed_List = 0 ) 
					set @upgrade_required = 0 
				end
				else
				begin	
					--get the list of gobjects which are assigned to the platform to which 
					--the Objects are getting deployed.
					declare @gobjects_ids table (gobject_id int )
					insert into @gobjects_ids select gobject_id
					from instance where mx_platform_id IN
					(
						select distinct mx_platform_id
						from instance
						where gobject_id in (select gobject_id from #deployed_ids)
					)
					
					--then get the list of the Objects which may require software_upgrade_needed
					--if it is > 0 then mark	@upgrade_required is true			
					--27 May 2009 Merged the fix for CR# L00092655 HF-1431 from L00093212 HF-1406					
					set @sur =  
					(
						select count(gobject.gobject_id) 
						from primitive_definition inner join
						file_primitive_definition_link on primitive_definition.primitive_definition_id = file_primitive_definition_link.primitive_definition_id AND 
						file_primitive_definition_link.is_needed_for_runtime = 1 inner join
						file_pending_update on file_primitive_definition_link.file_id = file_pending_update.file_id inner join
						gobject on primitive_definition.template_definition_id = gobject.template_definition_id
						inner join primitive_instance on
							primitive_instance.primitive_definition_id = primitive_definition.primitive_definition_id and
							primitive_instance.gobject_id = gobject.gobject_id

						where 
						(
							gobject.gobject_id IN 
								(
									select   gobject_id
									from @gobjects_ids)
								)
							AND 
								(
									file_pending_update.node_name in 
									(
										select	p.node_name 
										from	platform p
										inner join @gobjects_ids gids
										on		p.platform_gobject_id = gids.gobject_id
									)
								)
							AND
								gobject.deployed_package_id <> 0
						)
				

					if(@sur<>0)
						set @upgrade_required = 1 		
					else
					begin
						set @sur =  
						(
						select count(g.gobject_id) from gobject g 
						inner join @gobjects_ids gid
							on g.gobject_id = gid.gobject_id
						inner join primitive_instance_feature_link pfl on 
							pfl.gobject_id = g.gobject_id
						inner join feature_file_link fl on
							fl.feature_id = pfl.feature_id
						inner join file_pending_update fp on						 
							fl.file_id = fp.file_id 						
						where
								(
									fp.node_name in 
									(
										select node_name from platform p where 
										p.platform_gobject_id in 
										(	
											select   gobject_id	from @gobjects_ids	
										)
									)
									)
								AND
									g.deployed_package_id <> 0
							)
					

						if(@sur<>0)
							set @upgrade_required = 1 		
					end
						
				end
				
		
		end
	end

	--drop the table
	drop table #deployed_ids

	set  @sur_required = @upgrade_required


end



go

