/**************************************************/
/*Object Name :  internal_multi_list_proxy                            */
/*Object Type :  Stored Proc.								*/
/*Purpose :    to provide proxy data for a given fsobject */
/*Used By :    CDI									*/
/**************************************************/
create procedure dbo.internal_multi_list_proxy

@FileNameOfIds nvarchar (265)
 AS
begin
set nocount on


SET QUOTED_IDENTIFIER OFF

CREATE TABLE  #results_table ( gobject_id int)

DECLARE @SQL nvarchar(2000)

SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

EXEC (@SQL)

declare  @worktable table ( 
gobject_id int  NOT NULL ,
is_failover_enabled int )

insert @worktable
SELECT 
gobject.gobject_id, 
isnull((select distinct 1 from redundancy r with(nolock) where r.primary_gobject_id = gobject.gobject_id or r.backup_gobject_id = gobject.gobject_id),0)is_failover_enabled
from gobject with(nolock) inner join #results_table
on gobject.gobject_id = #results_table.gobject_id

---Add All Partner IDS also to broadcast proxy
declare @PartnerGIds table( gobject_id int NOT NULL)
insert @PartnerGIds 
select dbo.get_failover_partner_id(w.gobject_id) from @worktable w where is_failover_enabled = 1

insert @worktable
select p.gobject_id , 1 from @PartnerGIds p
---Add All Partner IDS also to broadcast proxy


		--Added to optimize the performance for IOB 
		--This is fro NON DI
		declare @worktable_nonDI table ( gobject_id int NOT NULL, -- primary key,
									dio_id int,
									sg_mx_primitive_id smallint,
									is_failover_enabled int, 
									MyDiName nvarchar(329))
		insert into @worktable_nonDI
		select g.gobject_id,
	odl.dio_id,
	odl.sg_mx_primitive_id,
		g.is_failover_enabled,
	(case when dio.tag_name is not null and sg_pi.primitive_name is not null
	then
		dio.tag_name + '.' + sg_pi.primitive_name 
	else
		null
			end)
		from @worktable g 
		inner join gobject with(nolock) on gobject.gobject_id = g.gobject_id
		inner join template_definition td on
		td.template_definition_id = gobject.template_definition_id 
		and td.category_id not in (11,12,24)
left outer join object_device_linkage odl on
		odl.gobject_id = g.gobject_id
left outer JOIN gobject dio
ON dio.gobject_id = odl.dio_id
left outer JOIN primitive_instance sg_pi
ON sg_pi.gobject_id = dio.gobject_id
AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
AND sg_pi.package_id = dio.checked_in_package_id
		
		--This is for DI
		--Added to optimize the performance for IOB : IO device
		declare @worktable_DI table ( gobject_id int NOT NULL, -- primary key,
								   cnt smallint,
								   is_failover_enabled int,
								   hasiolinkedobjects int )

		insert into @worktable_DI
		select g.gobject_id, scan_group.CNT, g.is_failover_enabled,
		case when exists(select odl.gobject_id from object_device_linkage odl where odl.dio_id = g.gobject_id)
		then 1
		else 0
		end as hasiolinkedobjects
		from @worktable g 
		inner join gobject  with(nolock) on gobject.gobject_id = g.gobject_id
		inner join template_definition td on
		td.template_definition_id = gobject.template_definition_id 
		and td.category_id in (11,12,24)
		CROSS APPLY (select     cast(COUNT(*) as smallint) as CNT from primitive_instance sg_pi
							 inner join primitive_definition pd
									 on pd.primitive_definition_id = sg_pi.primitive_definition_id
									and pd.primitive_name in (N'S', N'SG', N'ScanGroup1')
								  where sg_pi.gobject_id = gobject.gobject_id
									and sg_pi.package_id = gobject.checked_in_package_id
					) scan_group
		--Added to optimize the performance for IOB END

select   distinct worktable.gobject_id, 
		gobject.tag_name, 
		gobject.contained_name,
		gobject.hierarchical_name, 
		--package.status_id as status, 
		-- Fix for CRL00132704: Added logic to update the status of ITVA instance.
		CASE WHEN (package.status_id = 0 and gobject.is_template = 1) THEN
			CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0)--ver_warning_view.has_warning = 1 
				THEN 2 
			ELSE 0 
			END
		WHEN (package.status_id = 0 and gobject.is_template = 0 and template_definition.category_id = 26) THEN
			CASE WHEN exists(select 1 from gobject itvappgObject
					inner join visual_element_reference myver on
					itvappgObject.gobject_id = myver.gobject_id and
					myver.visual_element_bind_status = 0 and
					myver.checked_in_unbound_visual_element_name <> '---'
					where 
					itvappgObject.gobject_id = gobject.derived_from_gobject_id
					and itvappgObject.checked_in_package_id = myver.package_id
					)
				THEN 2 
				ELSE 0 
			END
		WHEN (package.status_id = 0 and gobject.is_template = 0 and template_definition.category_id <> 26)THEN
			CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0) 
				THEN 2 
			ELSE 0 
			END
		ELSE package.status_id
		END as status, 
		package.reference_status_id as refStatus,
		gobject.hosted_by_gobject_id,
		gobject.derived_from_gobject_id as derived_from_id,
		template_definition.base_gobject_id as base_type,  
		isnull((select user_profile_name from user_profile where user_guid = gobject.checked_out_by_user_guid),'') as checkoutbyname, 
		gobject.checked_out_by_user_guid as checkedout_by,
		folder_gobject_link.folder_id AS toolset_id, 
		gobject.checked_in_package_id,
		gobject.template_definition_id,		
		gobject.contained_by_gobject_id as container_id,	
		gobject.area_gobject_id as area_id, 
		--package_checked_out.status_id as checked_out_package_status,
		CASE WHEN package_checked_out.status_id = 0 THEN
			CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
				THEN 2 
			ELSE 0 
			END
		ELSE package_checked_out.status_id 
		END as checked_out_package_status,
		(gobject.is_template * 1) +
		  	(gobject.is_hidden * 2 ) +
		 	((CASE WHEN gobject.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
		  	((CASE WHEN gobject.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +		 	
		 	((CASE WHEN (gobject.deployed_package_id <> 0) and ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
			THEN 1	ELSE 0 	END) * 16 ) +
		  	((CASE WHEN (gobject.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
		  	((CASE WHEN (gobject.namespace_id = 1 and template_definition.category_id = 3 and gobject.is_template = 0 and worktable.is_failover_enabled >0 ) THEN 1 ELSE 0 END) * 64) +
		 	((CASE WHEN (gobject.namespace_id = 2 and template_definition.category_id = 3 and gobject.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
		 	((CASE WHEN (worktable.is_failover_enabled >0) THEN 1 ELSE 0 END) * 256) + 
		 	((CASE WHEN ((worktable.is_failover_enabled >0) and 
	((gobject.deployed_package_id <> 0) and (dbo.is_partner_deployed(gobject.gobject_id) =  0))) then 1 else 0 end) * 512) +
		 	((CASE WHEN ((worktable.is_failover_enabled >0) and 
	((gobject.deployed_package_id = 0) and (dbo.is_partner_deployed(worktable.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
			case when exists(select gobject_id from gobject where derived_from_gobject_id = worktable.gobject_id) --Hasderived_obj
                 then 2048	 else 0	 end +
			case when exists(select gobject_id from gobject where hosted_by_gobject_id = worktable.gobject_id) --Hasassigned_obj
                 then 4096   else 0  end + 
			case when exists(select gobject_id from gobject where contained_by_gobject_id =worktable.gobject_id) --HasContained_obj
				 then 8192	 else 0	 end +
			case when exists(select gobject_id from gobject where area_gobject_id = worktable.gobject_id) --HasBelongTo_obj
				 then 16384  else 0  end +
			( (CASE WHEN (gobject.is_template = 0 and template_definition.category_id = 1) then
 					dbo.is_gr_platform_id(gobject.gobject_id)	
 				else 
 					cast(0 as bit) end) * 32768) +
 			ISNULL(deployed_intouch_viewapp.deploy_file_transfering,0) * 65536 +
					CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = worktable.gobject_id )
					then  131072 else 0 end                       					 								
		 as 'gObjectStatus',
     CAST ( pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
     gobject.namespace_id,
	folder_gobject_link.folder_id,
	--IO Binding changes
	worktable.dio_id,
	worktable.sg_mx_primitive_id,
	worktable.MyDiName as 'MyDiName'
	--IO Binding changes end
from @worktable_nonDI worktable 
join gobject with(nolock)
    on worktable.gobject_id = gobject.gobject_id
join package with(nolock)
    on gobject.gobject_id = package.gobject_id 
    and gobject.checked_in_package_id = package.package_id
join template_definition with(nolock) on
    gobject.template_definition_id = template_definition.template_definition_id 
inner join proxy_timestamp pt with(nolock)  on
    gobject.gobject_id = pt.gobject_id
    
left outer join visual_element_reference ver_warning_view on
	gobject.gobject_id = ver_warning_view.gobject_id and
	package.package_id = ver_warning_view.package_id and
	ver_warning_view.visual_element_bind_status = 0 and
	ver_warning_view.checked_in_unbound_visual_element_name <> '---'
	    
--inner join internal_visual_element_reference_warning_status_view ver_warning_view on
--	gobject.gobject_id = ver_warning_view.gobject_id and
--	package.package_id = ver_warning_view.package_id

left join package  package_checked_out with(nolock) on
    gobject.gobject_id = package_checked_out.gobject_id 
    and gobject.checked_out_package_id = package_checked_out.package_id

left outer join visual_element_reference ver_warning_view_checked_out on
	package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
	package_checked_out.package_id = ver_warning_view_checked_out.package_id and
	ver_warning_view_checked_out.visual_element_bind_status = 0 and
	ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
	
--left outer join internal_visual_element_reference_warning_status_view ver_warning_view_checked_out on
--	package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
--	package_checked_out.package_id = ver_warning_view_checked_out.package_id

left join template  with(nolock) on
    template.gobject_id = gobject.gobject_id
left join folder_gobject_link  with(nolock) on
	folder_gobject_link.gobject_id = gobject.gobject_id 
left outer join package checked_in_package  with(nolock) on 
	gobject.gobject_id = checked_in_package.gobject_id and 
    gobject.checked_in_package_id = checked_in_package.package_id
left outer join package deployed_package  with(nolock) on 
	gobject.gobject_id = deployed_package.gobject_id and 
    gobject.deployed_package_id = deployed_package.package_id
left outer join deployed_intouch_viewapp on
		worktable.gobject_id = deployed_intouch_viewapp.gobject_id
----for device
union

select   distinct worktable.gobject_id, 
		gobject.tag_name, 
		gobject.contained_name,
		gobject.hierarchical_name, 
		--package.status_id as status, 
		CASE WHEN package.status_id = 0 THEN
			CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0) --ver_warning_view.has_warning = 1 
				THEN 2 
			ELSE 0 
			END
		ELSE package.status_id
		END as status, 
		package.reference_status_id as refStatus,
		gobject.hosted_by_gobject_id,
		gobject.derived_from_gobject_id as derived_from_id,
		template_definition.base_gobject_id as base_type,  
		isnull((select user_profile_name from user_profile where user_guid = gobject.checked_out_by_user_guid),'') as checkoutbyname, 
		gobject.checked_out_by_user_guid as checkedout_by,
		folder_gobject_link.folder_id AS toolset_id, 
		gobject.checked_in_package_id,
		gobject.template_definition_id,		
		gobject.contained_by_gobject_id as container_id,	
		gobject.area_gobject_id as area_id, 
		--package_checked_out.status_id as checked_out_package_status,
		CASE WHEN package_checked_out.status_id = 0 THEN
			CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
				THEN 2 
			ELSE 0 
			END
		ELSE package_checked_out.status_id 
		END as checked_out_package_status,
		(gobject.is_template * 1) +
		  	(gobject.is_hidden * 2 ) +
		 	((CASE WHEN gobject.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
		  	((CASE WHEN gobject.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +		 	
		 	((CASE WHEN (gobject.deployed_package_id <> 0) and ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
			THEN 1	ELSE 0 	END) * 16 ) +
		  	((CASE WHEN (gobject.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
		  	((CASE WHEN (gobject.namespace_id = 1 and template_definition.category_id = 3 and gobject.is_template = 0 and worktable.is_failover_enabled >0 ) THEN 1 ELSE 0 END) * 64) +
		 	((CASE WHEN (gobject.namespace_id = 2 and template_definition.category_id = 3 and gobject.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
		 	((CASE WHEN (worktable.is_failover_enabled >0) THEN 1 ELSE 0 END) * 256) + 
		 	((CASE WHEN ((worktable.is_failover_enabled >0) and 
	((gobject.deployed_package_id <> 0) and (dbo.is_partner_deployed(gobject.gobject_id) =  0))) then 1 else 0 end) * 512) +
		 	((CASE WHEN ((worktable.is_failover_enabled >0) and 
	((gobject.deployed_package_id = 0) and (dbo.is_partner_deployed(worktable.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
			case when exists(select gobject_id from gobject where derived_from_gobject_id = worktable.gobject_id) --Hasderived_obj
                 then 2048	 else 0	 end +
			case when exists(select gobject_id from gobject where hosted_by_gobject_id = worktable.gobject_id) --Hasassigned_obj
                 then 4096   else 0  end + 
			case when exists(select gobject_id from gobject where contained_by_gobject_id =worktable.gobject_id) --HasContained_obj
				 then 8192	 else 0	 end +
			case when exists(select gobject_id from gobject where area_gobject_id = worktable.gobject_id) --HasBelongTo_obj
				 then 16384  else 0  end +
			( (CASE WHEN (gobject.is_template = 0 and template_definition.category_id = 1) then
 					dbo.is_gr_platform_id(gobject.gobject_id)	
 				else 
 					cast(0 as bit) end) * 32768) +
 			ISNULL(deployed_intouch_viewapp.deploy_file_transfering,0) * 65536 +
					CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = worktable.gobject_id )
					then  131072 else 0 end +
                    CASE WHEN (worktable.hasiolinkedobjects = 1) --hasiolinkedobjects for IO device only
                    then  262144 else 0 end
		 as 'gObjectStatus',
     CAST ( pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
     gobject.namespace_id,
	folder_gobject_link.folder_id,
	-- >> IO Binding changes
				0 as dio_id,
	worktable.cnt as sg_mx_primitive_id, -- Return the number of scan-groups created for the object as the sg_mx_primitive_id (something of a necessary hack)
				null as 'MyDiName'
	-- << IO Binding changes end
from @worktable_DI worktable 
join gobject with(nolock)
    on worktable.gobject_id = gobject.gobject_id
join package with(nolock)
    on gobject.gobject_id = package.gobject_id 
    and gobject.checked_in_package_id = package.package_id
join template_definition with(nolock) on
    gobject.template_definition_id = template_definition.template_definition_id 
inner join proxy_timestamp pt with(nolock)  on
    gobject.gobject_id = pt.gobject_id
    
left outer join visual_element_reference ver_warning_view on
	gobject.gobject_id = ver_warning_view.gobject_id and
	package.package_id = ver_warning_view.package_id and
	ver_warning_view.visual_element_bind_status = 0 and
	ver_warning_view.checked_in_unbound_visual_element_name <> '---'
	    
--inner join internal_visual_element_reference_warning_status_view ver_warning_view on
--	gobject.gobject_id = ver_warning_view.gobject_id and
--	package.package_id = ver_warning_view.package_id

left join package  package_checked_out with(nolock) on
    gobject.gobject_id = package_checked_out.gobject_id 
    and gobject.checked_out_package_id = package_checked_out.package_id

left outer join visual_element_reference ver_warning_view_checked_out on
	package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
	package_checked_out.package_id = ver_warning_view_checked_out.package_id and
	ver_warning_view_checked_out.visual_element_bind_status = 0 and
	ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
	
--left outer join internal_visual_element_reference_warning_status_view ver_warning_view_checked_out on
--	package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
--	package_checked_out.package_id = ver_warning_view_checked_out.package_id

left join template  with(nolock) on
    template.gobject_id = gobject.gobject_id
left join folder_gobject_link  with(nolock) on
	folder_gobject_link.gobject_id = gobject.gobject_id 
left outer join package checked_in_package  with(nolock) on 
	gobject.gobject_id = checked_in_package.gobject_id and 
    gobject.checked_in_package_id = checked_in_package.package_id
left outer join package deployed_package  with(nolock) on 
	gobject.gobject_id = deployed_package.gobject_id and 
    gobject.deployed_package_id = deployed_package.package_id
left outer join deployed_intouch_viewapp on
		worktable.gobject_id = deployed_intouch_viewapp.gobject_id

drop table #results_table

end
go

