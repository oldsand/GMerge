CREATE proc dbo.internal_get_library_element_thumbnails
    -- comma separated list of gobject ids or file of ids
    @ids_or_file_of_ids nvarchar(4000),
    -- user making request, will affect results returned
    @user_guid uniqueidentifier
as
begin
    -- put object ids into table
    create  table #gobject_ids_for_thumbnails(gobject_id int primary key)
    
    insert #gobject_ids_for_thumbnails(gobject_id)
        exec internal_select_ids @ids_or_file_of_ids

	select 
		ved.thumbnail,
		ved.gobject_id,
		ved.is_thumbnail_dirty
	from internal_visual_element_description_per_user_view ved with(nolock)--Important
	inner join #gobject_ids_for_thumbnails gids on
		ved.gobject_id = gids.gobject_id
	where ved.user_guid = @user_guid and
			ved.is_library_visual_element=1			
end
go

