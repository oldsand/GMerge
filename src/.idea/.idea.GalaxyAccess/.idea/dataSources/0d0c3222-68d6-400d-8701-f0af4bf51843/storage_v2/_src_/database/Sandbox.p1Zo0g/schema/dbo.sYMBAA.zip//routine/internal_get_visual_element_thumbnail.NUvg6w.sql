create proc dbo.internal_get_visual_element_thumbnail
    @visual_element_id int,
	@user_guid nvarchar(64)
as
begin

	select	
            is_thumbnail_dirty,
            thumbnail
	from internal_visual_element_description_per_user_view 
	where	visual_element_id = @visual_element_id and
			user_guid = @user_guid

end


go

