/************************************************************************/
/*Object Name :  internal_get_referenced_ids_for_deleted_dynamic_attributes	*/
/*Object Type :  Stored Proc.											*/
/*Purpose	  :  Proc. to Provide the invalid object references list.	*/
/*Used By	  :  CDI													*/
/************************************************************************/
create PROCEDURE dbo.internal_get_referenced_ids_for_deleted_dynamic_attributes
@FileNameOfIds nvarchar (265)
 AS
BEGIN
	SET NOCOUNT ON
	
	CREATE TABLE  #objects_table ( gobject_id int not null)
	/* CR L00115843: Use table variables instead of temp tables */
    DECLARE @results_table table ( gobject_id int, 
								   package_id int, 
									referring_mx_primitive_id smallint,
									referring_mx_attribute_id smallint,
								   element_index smallint,
								   PRIMARY KEY (gobject_id, package_id, referring_mx_primitive_id, referring_mx_attribute_id, element_index))

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #objects_table  FROM ''' + @FileNameOfIds+ ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '

	EXEC (@SQL)

	-- 1st inner join returns all rows whose checked_in_package 
	-- is same as package_id.
	-- 2nd inner join returns all rows which are referring to 
	-- the object that has deleted dynamic attributes.
	-- 3rd inner join returns all rows whose resolved_gobject_id 
	-- is same as gobject_id. This is used for retrieving tag name 
	-- of the referenced object.
	-- 4th left join returns all rows whose attributes are removed 
	-- from the referenced object.
	-- CR L00115843: Protect the PRIMARY KEY of @results_table from collisions by selecting DISTINCT rows.
	INSERT INTO @results_table
	SELECT DISTINCT
		ar.gobject_id, 
		ar.package_id,
		ar.referring_mx_primitive_id, 
		ar.referring_mx_attribute_id,
		ar.element_index
	FROM attribute_reference ar		
	INNER JOIN gobject g on
		g.gobject_id = ar.gobject_id and
		g.checked_in_package_id = ar.package_id
	INNER JOIN #objects_table o on
		ar.resolved_gobject_id = o.gobject_id and
		ar.gobject_id <> o.gobject_id
	INNER JOIN gobject resolved on
		resolved.gobject_id = ar.resolved_gobject_id
	-- This will invalidate all the references on the reffering objects 
		-- This was need to avoid stale references if the Primitives are deleted CR L00085637
		
		
	--inner join dynamic_attribute da on		
	--	da.gobject_id = ar.resolved_gobject_id and
	--	dbo.get_attribute_name_from_reference_string(ar.reference_string,ar.resolved_gobject_id) = da.attribute_name
	--inner join packages_to_be_deleted d on
	--	da.gobject_id = d.gobject_id and
	--	da.package_id = d.package_id
	--WHERE 
	--	ar.resolved_mx_primitive_id = 2 and 
	--	ar.resolved_mx_attribute_id > 131


	-- This table is populated by internal_multi_object_checkin for this proc to use.
	-- After the preceeding query, the rows are no longer needed.
	truncate table packages_to_be_deleted
	
	-- Update the attribute reference table whose referenced dynamic attributes are removed.
	update attribute_reference 
	set resolved_gobject_id = 0, 
		object_signature = 0,
		resolved_mx_primitive_id = 0,
		resolved_mx_attribute_id = 0,
		resolved_mx_property_id = 0,
		attribute_signature = 0,
		attribute_index = 0,
		is_valid = 1,
		attr_res_status = 0
	FROM attribute_reference att
	INNER JOIN @results_table r
	ON r.gobject_id = att.gobject_id
	and r.package_id = att.package_id
	and r.referring_mx_primitive_id = att.referring_mx_primitive_id
	and r.referring_mx_attribute_id = att.referring_mx_attribute_id
	and r.element_index = att.element_index
	

	-- Update the object's packages whose referenced attributes are not available.
	-- SHARON Changed this line to use aliases
	UPDATE p  
	SET reference_status_id = 2 
	FROM package p
  	INNER JOIN gobject g
	ON p.package_id = g.checked_in_package_id
	INNER JOIN @results_table obj 
	ON g.gobject_id = obj.gobject_id
	
	SELECT distinct gobject_id from @results_table	
	
	DROP TABLE #objects_table

	
END
go

