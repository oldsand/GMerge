/*
This procedure will get called at the start of the deployment operation to check 
whether software_upgrade is needed for the list of Objects which are getting deployed

usage:
declare @gobject_id int
set @gobject_id = 1
exec internal_get_ref_object_details @gobject id

*/
CREATE PROCEDURE dbo.internal_get_ref_object_details
@gobject_id int
 AS
begin
	
	SET NOCOUNT ON

	select g.tag_name, 
		   g.is_template,
		   g.derived_from_gobject_id,
		   g.checked_out_by_user_guid,
		   td.codebase, 
		   g.configuration_version, 
		   p.security_group as sec_group,
		   ghost.tag_name as host_name,
		   garea.tag_name as area_name,
		   gcontain.tag_name  as contain_name,
		   toolset_name = dbo.get_folder_path(g.gobject_id,1),
		    g.is_hidden, 
            td.category_id     
	from gobject g 
	left join template_definition td on td.template_definition_id = g.template_definition_id 
	left join package p 
		on p.package_id = g.checked_in_package_id 
	left join gobject ghost 
		on ghost.gobject_id = g.hosted_by_gobject_id 
	left join gobject garea 
		on garea.gobject_id = g.area_gobject_id
	left join gobject gcontain 
		on gcontain.gobject_id = g.contained_by_gobject_id 
	where g.gobject_id = @gobject_id
    and g.derived_from_gobject_id is not null 
	and g.derived_from_gobject_id <> 0 


	SET NOCOUNT OFF
end
go

