create proc dbo.internal_get_folder_depth
(
	@folder_id int,
	@depth int out
)
as
begin
    set @depth = 0

	if (@folder_id = 0) 
		set @depth = 0
	else 
	begin
		select @depth = depth 
		from folder 
		where folder_id = @folder_id
	end
end


go

