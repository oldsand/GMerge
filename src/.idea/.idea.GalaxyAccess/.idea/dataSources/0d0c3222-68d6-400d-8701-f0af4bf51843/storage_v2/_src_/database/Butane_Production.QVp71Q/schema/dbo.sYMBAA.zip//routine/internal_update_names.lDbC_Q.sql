create procedure dbo.internal_update_names
  @tagname nvarchar(329),
  @containname nvarchar(32),
  @hierarchicalname nvarchar(329),
  @gobjectid int,
  @containedby int
as
begin tran

if( len(@containname) = 0 )
BEGIN
update gobject
set
  tag_name = @tagname,
  hierarchical_name = @hierarchicalname
  from gobject 
  where gobject_id = @gobjectid
END
else
BEGIN
update gobject
set
  tag_name = @tagname,
  contained_name = @containname,
  hierarchical_name = @hierarchicalname,
  contained_by_gobject_id = @containedby
from gobject 
where gobject_id = @gobjectid
END

commit
go

