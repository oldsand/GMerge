create function dbo.get_hosted_objects(
	@host_id int )
returns @retTable table(objectId int, nLevel int)
As 
begin
	declare @nLevel int
	set @nLevel = 1

	insert into @retTable 
	select gobject_id, @nLevel from gobject where hosted_by_gobject_id = @host_id
	if @@rowcount = 0 return

	while 1 > 0
	begin
		insert into @retTable
		select gobject_id, @nLevel + 1 from gobject G inner join @retTable R
		on G.hosted_by_gobject_id = R.objectId and R.nLevel = @nLevel

		if @@rowcount = 0 break
		set @nLevel = @nLevel + 1
	end
	
	return
end
go

