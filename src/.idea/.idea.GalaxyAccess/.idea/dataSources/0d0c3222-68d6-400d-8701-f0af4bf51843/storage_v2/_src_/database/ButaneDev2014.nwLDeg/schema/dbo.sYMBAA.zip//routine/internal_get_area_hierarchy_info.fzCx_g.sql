create proc dbo.internal_get_area_hierarchy_info
@FileNameOfids nvarchar (265),
@primitive_type varchar(64)
as
begin
set nocount on
begin tran
	CREATE TABLE  #results_table ( gobject_id int)
	DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
	EXEC sp_executesql @SQL

	declare @objCount integer
	declare @nLevel integer
	declare @area_tree_ids table(obj_id int,nLevel smallint)
	insert  into  @area_tree_ids(obj_id,nLevel) 
	select gobject_id,1 from #results_table

	select @objCount = count(*) from @area_tree_ids
	
	IF @objCount > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN			
			insert into @area_tree_ids
			select area_gobject_id, @nLevel + 1
			from gobject g inner join @area_tree_ids aid 
			on g.gobject_id = aid.obj_id
			where nLevel = @nLevel
	
			if @@rowcount = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END


	select distinct gobj1.tag_name as objectname,isnull(gobj2.tag_name,'') as areaname,
       instance1.mx_platform_id as platformID,instance1.mx_engine_id as engineID,
       instance1.mx_object_id as objectID,
	   case
		   when gobj1.deployed_package_id = 0 then dbo.is_partner_deployed(gobj1.gobject_id)
		   else gobj1.deployed_package_id 
	   end as deployedPkg,				
       case
           when ISNULL(gobj1.contained_name, '') = gobj1.tag_name then ''
           else gobj1.contained_name 
       end as contained_name,
       case
           when ISNULL(gobj1.hierarchical_name, '') = gobj1.tag_name then ''
           else gobj1.hierarchical_name 
       end as hierarchical_name,
       td.category_id  as Category
	from @area_tree_ids as ar
	inner join  gobject as gobj1 on gobj1.gobject_id = ar.obj_id
 inner join instance as instance1 on gobj1.gobject_id = instance1.gobject_id
 left join gobject as gobj2 on gobj1.area_gobject_id = gobj2.gobject_id
inner join primitive_definition pd on gobj1.template_definition_id = pd.template_definition_id
inner join template_definition td on td.template_definition_id = pd.template_definition_id
	 where pd.primitive_guid = @primitive_type 
    and pd.primitive_guid = @primitive_type

    
	drop table #results_table
commit

end

go

