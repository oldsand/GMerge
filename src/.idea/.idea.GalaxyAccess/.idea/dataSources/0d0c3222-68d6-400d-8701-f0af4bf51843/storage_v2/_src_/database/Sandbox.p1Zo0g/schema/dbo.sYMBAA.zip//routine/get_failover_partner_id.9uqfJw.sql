--***********************************************************************************************************************
--***	
--***	OBJECT NAME:	get_failover_partner_id
--***	DESCRIPTION:		Function is used to obtain a gobject's failover parnter's gobject_id
--***	
--***	USAGE: 		dbo.get_failover_partner_id(21) --(where 21 is the gobject_id of the object)
--***	
--***	RETURNS :
--***	=========
--***	0		- If object does not have a failover partner
--***	gobject_id	- If object has a failover partner
--***	
--***********************************************************************************************************************

Create function dbo.get_failover_partner_id( 
	@gobject_id int
	)
returns int

as
begin
	
	declare @failOverPartnerID int

	
	select @failOverPartnerID = ((primary_gobject_id + backup_gobject_id) - @gobject_id) from 
	redundancy
	where backup_gobject_id = @gobject_id or primary_gobject_id = @gobject_id		

	select @failOverPartnerID = isnull(@failOverPartnerID,0)
	
	return @failOverPartnerID
	
end


go

