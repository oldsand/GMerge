create  procedure dbo.internal_has_gobject_deployment_config_version_changed
@gobject_id int,
@bChanged bit output
as

declare @checked_in_deployment_version int
declare @checked_out_deployment_version int

select 
    @checked_in_deployment_version = p.deployable_configuration_version 
from package p
inner join gobject g on
    p.gobject_id = @gobject_id and p.gobject_id = g.gobject_id
    and p.package_id = g.checked_in_package_id

select 
    @checked_out_deployment_version = deployable_configuration_version
from package p
inner join gobject g on
    p.gobject_id = @gobject_id and p.gobject_id = g.gobject_id
    and p.package_id = g.checked_out_package_id 

set @bChanged = 0
if (@checked_in_deployment_version <> @checked_out_deployment_version)
begin 
set @bChanged = 1
end



go

