create proc dbo.internal_add_visual_elements_from_parent
@gobject_id int,
@package_id int
as

declare @derived_from_gobject_id int
declare @derived_from_package_id int

select @derived_from_gobject_id = derived_from_gobject_id 
from gobject
where gobject_id = @gobject_id

select @derived_from_package_id = derived_from_package_id
from package
where gobject_id = @gobject_id and
	package_id = @package_id

-- Return if there the parent has no visual elements....
if not exists(
	select '*'
	from visual_element_version with(nolock)
	where gobject_id = @derived_from_gobject_id and
		package_id = @derived_from_package_id 
	)
begin
	return
end

begin tran

	declare @visual_element_version table  (
		gobject_id int NOT NULL ,
		package_id int NOT NULL ,
		mx_primitive_id smallint NOT NULL ,
		visual_element_id int NOT NULL ,
		inherited_from_gobject_id int NOT NULL ,
		inherited_from_package_id int NOT NULL ,
		inherited_from_mx_primitive_id smallint NOT NULL ,
		inherited_from_visual_element_id int NULL ,
		child_visual_element_id int
	) 


	declare @tag_name nvarchar(329) 
	declare @visual_element_name nvarchar(329) 
	declare @inherited_from_mx_primitive_id smallint
	declare @inherited_from_gobject_id int
	declare @inherited_from_visual_element_id int
	declare @visual_element_type nvarchar(32)
	declare @primitive_name nvarchar(329) 
	declare @mx_primitive_id smallint
	declare @inherited_from_package_id int -- this can be removed and replace with @derived_from_package_id 
	declare @parent_visual_element_id int
	declare @child_visual_element_id int
	declare @is_new_visual_element bit



	-- copy inherited visual_elements from parentpackage
	-- 
	insert into 
		@visual_element_version 
	select 
		pv.gobject_id,
		pv.package_id,
		pv.mx_primitive_id ,
		pv.visual_element_id ,
		pv.inherited_from_gobject_id ,
		pv.inherited_from_package_id ,
		pv.inherited_from_mx_primitive_id ,
		pv.inherited_from_visual_element_id ,
		isnull(mv.visual_element_id,0)
	from 
		visual_element_version pv -- pv=parent version
	left outer join visual_element_version mv on -- mv=my version
		((pv.inherited_from_visual_element_id = mv.inherited_from_visual_element_id) and ( mv.inherited_from_visual_element_id <> mv.visual_element_id))and 
		 mv.gobject_id = @gobject_id 
		-- need to get ids from at most one package, we can have multiple packages
		-- such as previously deployed packages that we DONT want to inherit from
	where pv.package_id = @derived_from_package_id 

	-- create two temp tables to be used to bind at the end of the proc...

	declare @visual_element_to_bind_by_id table
	(
		visual_element_id int,
		visual_element_type nvarchar(32),
		mx_primitive_id smallint
	)
	declare @visual_element_to_bind_by_name table
	(
		visual_element_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS null,
		visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS null,
		mx_primitive_id smallint
	)

		

	while exists(select '1' from @visual_element_version)
	begin

		 select top 1          
				   @inherited_from_gobject_id = tvev.inherited_from_gobject_id,
				   @inherited_from_package_id = tvev.inherited_from_package_id,
				   @inherited_from_mx_primitive_id = tvev.inherited_from_mx_primitive_id,
				   @inherited_from_visual_element_id = tvev.inherited_from_visual_element_id,
				   @parent_visual_element_id = tvev.visual_element_id,
				   @primitive_name = p.primitive_name,
				   @child_visual_element_id = tvev.child_visual_element_id
		from @visual_element_version tvev
		inner join primitive_instance p on tvev.gobject_id = p.gobject_id and
				tvev.mx_primitive_id = p.mx_primitive_id and
				p.package_id = @derived_from_package_id

		-- if this is a new element, get a new visual_element id..    
		if (@child_visual_element_id = 0)
		begin
			set @is_new_visual_element = 1
			exec internal_get_new_visual_element_id @child_visual_element_id out

		end
		else
		begin
			set @is_new_visual_element = 0        
		end
		-- obtain the tag_name and the visual_elment name....
		--(this can be removed when delete triggers replace cascading deletes..)
	    
		select @tag_name = g.tag_name,
			   @visual_element_name = g.tag_name + '.' + @primitive_name
		from gobject g
		where gobject_id = @gobject_id

		if (@is_new_visual_element = 1)
		begin
			-- create row in visual_element        
			insert into visual_element
				(visual_element_id, 
				 visual_element_type,
				 inheritance_status,
				 visual_element_category)
			select 
				@child_visual_element_id,
				visual_element_type,
				'I',
				visual_element_category
			from visual_element 
			where visual_element_id = @inherited_from_visual_element_id                
		end
	    
		-- create row in visual_element_version
		insert into visual_element_version 
		(
			gobject_id, 
		package_id ,
		mx_primitive_id ,
		visual_element_id ,
		inherited_from_gobject_id ,
		inherited_from_package_id ,
		inherited_from_mx_primitive_id ,
		inherited_from_visual_element_id) 
	    
		select
		@gobject_id, 
		@package_id ,
		@inherited_from_mx_primitive_id,
		@child_visual_element_id ,
		@inherited_from_gobject_id ,
		@inherited_from_package_id ,
		@inherited_from_mx_primitive_id ,
		@inherited_from_visual_element_id
		


		delete from @visual_element_version
		where package_id = @derived_from_package_id and
			  visual_element_id = @parent_visual_element_id


		select @visual_element_type = visual_element_type 
		from visual_element 
		where visual_element_id = @child_visual_element_id
	/*    if(@@rowcount > 0)
		begin
	  -- bind the visual_element if necessary...
		 exec internal_bind_visual_element
		 @child_visual_element_id,
		 @visual_element_type,
		 @visual_element_name,
		 null
		end
	*/

		insert into @visual_element_to_bind_by_id
		select @child_visual_element_id, @visual_element_type,@inherited_from_mx_primitive_id

		insert into @visual_element_to_bind_by_name
		select @visual_element_name, @visual_element_type,@inherited_from_mx_primitive_id
	end

	-- bind here...
	declare @visual_element_id int
	--declare @mx_primitive_id smallint
	-- bind by id first...
	while exists(select 1 from @visual_element_to_bind_by_id)
	begin 	
		select top 1
			@visual_element_id = visual_element_id,
			@visual_element_type = visual_element_type,
			@mx_primitive_id = mx_primitive_id
		from @visual_element_to_bind_by_id

		exec internal_bind_visual_element_by_id_or_name
			@gobject_id, 
			@package_id ,
			@mx_primitive_id,
			@visual_element_id,
			@visual_element_type,
			N'',--@visual_element_name nvarchar(362),
			1 --@bind_by_id bit

		delete from @visual_element_to_bind_by_id
		where visual_element_id = @visual_element_id

	end 


	while exists (select 1 from @visual_element_to_bind_by_name)
	begin 
		select top 1
			@visual_element_name = visual_element_name,
			@visual_element_type = visual_element_type,
			@mx_primitive_id = mx_primitive_id
		from @visual_element_to_bind_by_name

		exec internal_bind_visual_element_by_id_or_name
			@gobject_id, 
			@package_id ,
			@mx_primitive_id,
			0,--@visual_element_id,
			@visual_element_type,
			@visual_element_name,
			0 --@bind_by_id bit

		delete from @visual_element_to_bind_by_name
		where visual_element_name = @visual_element_name
		

	end 

commit
go

