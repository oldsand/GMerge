/*
This procedure will get called at the start of the deployment operation to check 
whether software_upgrade is needed for the list of Objects which are getting deployed

usage:
declare @P1 int
exec internal_software_upgrade_needed'
     <r><gobject id = 23 ></r>, @P1
*/
CREATE PROCEDURE dbo.internal_software_upgrade_needed
	@FileNameOfIds  nvarchar(400),
	@sur_required int  OUTPUT
AS
begin
SET NOCOUNT ON       
	set	@sur_required	 = 0	
	IF(exists ( select gobject_id from gobject where (deployed_package_id > 0) and (software_upgrade_needed  = 1) )) 
	begin
		exec internal_private_software_upgrade_needed @FileNameOfIds,@sur_required out
	end
	else
	begin
		IF (exists ( select f.file_id from file_pending_update f inner join file_primitive_definition_link fp
		on f.file_id = fp.file_id where fp.is_needed_for_runtime = 1 ))
		begin
			exec internal_private_software_upgrade_needed @FileNameOfIds,@sur_required out    		
		end
	end

end
go

