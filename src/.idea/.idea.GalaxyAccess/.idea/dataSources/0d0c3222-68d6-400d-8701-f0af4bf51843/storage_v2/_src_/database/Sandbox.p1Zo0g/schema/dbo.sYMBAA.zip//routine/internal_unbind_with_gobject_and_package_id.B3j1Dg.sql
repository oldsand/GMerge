
--This will use     (#unbind_vereferences uve) table created by his client
--Unbind all ve references whose 
--            checked_in_bound_visual_element_gobject_id = uve.gobject_id
--            and ver.checked_in_bound_visual_element_package_id = uve.package_id

create  proc dbo.internal_unbind_with_gobject_and_package_id
as 
    if not exists (select 1 from #unbind_vereferences)
    begin    
        return
    end
begin tran

-- unbind visual elements...

    declare @affected_checked_in_bound_elements table(
    gobject_id int not null,
    package_id int not null,
    mx_primitive_id smallint not null,    
    visual_element_reference_index int not null,

    --visual_element_bind_status char (1) not null,-- now a calculated column..

    is_relative_reference bit not null,
    checked_in_unbound_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    checked_in_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
    checked_in_unbound_tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    checked_in_unbound_primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS null,
    checked_in_unbound_relative_object_name nvarchar (329) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    checked_in_unbound_visual_element_id int null)

    declare @affected_checked_out_bound_elements table
    (

		gobject_id int not null,
		package_id int not null,
		mx_primitive_id smallint not null,    
		visual_element_reference_index int not null,

		--visual_element_bind_status char (1) not null,-- now a calculated column..

		is_relative_reference bit not null,
		checked_out_unbound_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_out_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_out_unbound_tag_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_out_unbound_primitive_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS null,
		checked_out_unbound_relative_object_name nvarchar (329)  COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		checked_out_unbound_visual_element_id int null
	)

	-- first, unbind any checked-in visual_elements...


	insert into @affected_checked_in_bound_elements
    (gobject_id,
    package_id,
    mx_primitive_id,
    visual_element_reference_index,
    --visual_element_bind_status,-- now a calculated column..
    is_relative_reference,
    checked_in_unbound_visual_element_name ,
    checked_in_unbound_visual_element_type ,
    checked_in_unbound_tag_name  ,
    checked_in_unbound_primitive_name ,
    checked_in_unbound_relative_object_name,
    checked_in_unbound_visual_element_id)
    select 
    b.gobject_id,
    b.package_id,
    b.mx_primitive_id,
    b.visual_element_reference_index,
--    0,
    b.is_relative_reference,
    case when ver.is_relative_reference = 0 then    
        case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name 
        else g.tag_name 
        end
    else
           'me'+ right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name)) )  +   '.' + pri.primitive_name
    end,
    v.visual_element_type,
    g.tag_name,
    pri.primitive_name,
    case when ver.is_relative_reference = 1 then    
            case when(len(g.hierarchical_name) > len(gme.hierarchical_name)) then
            right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name) -1))
                else
            null
                end
    else 
        null
    end,
    d.visual_element_id
    from visual_element_version d 
    inner join visual_element_reference b on     
        b.checked_in_bound_visual_element_gobject_id = d.gobject_id and
        b.checked_in_bound_visual_element_package_id = d.package_id and
        b.checked_in_bound_visual_element_mx_primitive_id = d.mx_primitive_id and
        b.checked_in_bound_visual_element_package_id = d.package_id 
    inner join visual_element v on d.visual_element_id = v.visual_element_id 
    inner join primitive_instance pri on pri.gobject_id = d.gobject_id and
        pri.package_id = d.package_id and 
        pri.mx_primitive_id = d.mx_primitive_id
    inner join gobject g on 
        g.gobject_id = d.gobject_id 
    inner join visual_element_reference ver on 
        b.gobject_id = ver.gobject_id and
        b.package_id = ver.package_id and
        b.mx_primitive_id = ver.mx_primitive_id and
        b.visual_element_reference_index = ver.visual_element_reference_index
    inner join gobject gme on ver.gobject_id = gme.gobject_id      
    inner join #unbind_vereferences uve on    
            ver.checked_in_bound_visual_element_gobject_id = uve.gobject_id
            and ver.checked_in_bound_visual_element_package_id = uve.package_id

    --update the checked_in_unbound ver columns....

    update  ver
    set -- unbound columns...
        ver.checked_in_unbound_visual_element_name = wt.checked_in_unbound_visual_element_name,
        ver.checked_in_unbound_visual_element_type = wt.checked_in_unbound_visual_element_type,
        ver.checked_in_unbound_tag_name = wt.checked_in_unbound_tag_name,
        ver.checked_in_unbound_primitive_name = wt.checked_in_unbound_primitive_name,
        ver.checked_in_unbound_relative_object_name = wt.checked_in_unbound_relative_object_name,
        --ver.visual_element_bind_status = 0,-- now a calculated column..
	    ver.checked_in_unbound_visual_element_id = wt.checked_in_unbound_visual_element_id,
        -- bound columns....
        ver.checked_in_bound_visual_element_gobject_id = null,
        ver.checked_in_bound_visual_element_package_id = null,
        ver.checked_in_bound_visual_element_mx_primitive_id = null
    from visual_element_reference ver 
    inner join @affected_checked_in_bound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index

-- next, unbind any checked_out visual_elements...

insert into @affected_checked_out_bound_elements
    (gobject_id,
    package_id,
    mx_primitive_id,
    visual_element_reference_index,
    --visual_element_bind_status,-- now a calculated column..
    is_relative_reference,
    checked_out_unbound_visual_element_name ,
    checked_out_unbound_visual_element_type ,
    checked_out_unbound_tag_name  ,
    checked_out_unbound_primitive_name ,
    checked_out_unbound_relative_object_name,
    checked_out_unbound_visual_element_id)
    select 
    b.gobject_id,
    b.package_id,
    b.mx_primitive_id,
    b.visual_element_reference_index,
--    0,
    b.is_relative_reference,
    case when ver.is_relative_reference = 0 then    
        case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name 
        else g.tag_name 
        end
    else
           'me'+ right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name)) )  +   '.' + pri.primitive_name
    end,
    v.visual_element_type,
    g.tag_name,
    pri.primitive_name,
    case when ver.is_relative_reference = 1 then    
            case when(len(g.hierarchical_name) > len(gme.hierarchical_name)) then
            right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name) -1))
                else
            null
                end
    else 
        null
    end,
    d.visual_element_id
    from visual_element_version d 
    inner join visual_element_reference b on     
        b.checked_out_bound_visual_element_gobject_id = d.gobject_id and
        b.checked_out_bound_visual_element_package_id = d.package_id and
        b.checked_out_bound_visual_element_mx_primitive_id = d.mx_primitive_id 
    inner join visual_element v on d.visual_element_id = v.visual_element_id
    inner join primitive_instance pri on pri.gobject_id = d.gobject_id and
        pri.package_id = d.package_id and 
        pri.mx_primitive_id = d.mx_primitive_id
    inner join gobject g on 
        g.gobject_id = d.gobject_id and
        g.checked_out_package_id = d.package_id
    inner join visual_element_reference ver on 
        b.gobject_id = ver.gobject_id and
        b.package_id = ver.package_id and
        b.mx_primitive_id = ver.mx_primitive_id and
        b.visual_element_reference_index = ver.visual_element_reference_index
    inner join gobject gme on ver.gobject_id = gme.gobject_id         
    inner join #unbind_vereferences uve on    
            ver.checked_in_bound_visual_element_gobject_id = uve.gobject_id
            and ver.checked_in_bound_visual_element_package_id = uve.package_id

    --update the checked_out_unbound ver columns....

    update  ver
    set -- unbound columns...
        ver.checked_out_unbound_visual_element_name = wt.checked_out_unbound_visual_element_name,
        ver.checked_out_unbound_visual_element_type = wt.checked_out_unbound_visual_element_type,
        ver.checked_out_unbound_tag_name = wt.checked_out_unbound_tag_name,
        ver.checked_out_unbound_primitive_name = wt.checked_out_unbound_primitive_name,
        ver.checked_out_unbound_relative_object_name = wt.checked_out_unbound_relative_object_name,
        --ver.visual_element_bind_status = 0,-- now a calculated column..
        ver.checked_out_unbound_visual_element_id = wt.checked_out_unbound_visual_element_id,
        -- bound columns....
        ver.checked_out_bound_visual_element_gobject_id = null,
        ver.checked_out_bound_visual_element_package_id = null,
        ver.checked_out_bound_visual_element_mx_primitive_id = null
    from visual_element_reference ver 
    inner join @affected_checked_out_bound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index

commit



go

