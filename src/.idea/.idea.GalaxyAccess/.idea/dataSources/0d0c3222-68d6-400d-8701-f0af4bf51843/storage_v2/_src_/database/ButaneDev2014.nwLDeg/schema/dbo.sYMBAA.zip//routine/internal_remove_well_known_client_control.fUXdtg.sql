-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*Object Name :  internal_remove_well_known_client_control						      */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To remove the info for all well known client controls in a given assembly*/
/*Used By	  :  WWCDI											  */
/**********************************************************************/

create PROCEDURE dbo.internal_remove_well_known_client_control
(
    @FileNameOfIds nvarchar (400)
)
as
begin
set nocount  on
-- Create temporary table for storing the file ids.
CREATE TABLE  #file_id_table ( file_id int)

-- call the stored procedure 'internal_construct_table_from_file'
EXEC internal_construct_table_from_file @FileNameOfIds, '#file_id_table'

delete from 
	well_known_client_controls
where 
	file_id 
in 
	(select file_id from #file_id_table)	


end
go

