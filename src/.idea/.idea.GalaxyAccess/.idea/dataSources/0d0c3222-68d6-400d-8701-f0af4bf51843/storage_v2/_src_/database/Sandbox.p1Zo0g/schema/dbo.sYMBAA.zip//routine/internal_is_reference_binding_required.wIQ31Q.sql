/************************************************************************************/
/*Object Name :  internal_is_reference_binding_required											*/
/*Object Type :  Stored Proc.														*/
/*Purpose	  :  returns the boolean value depending on the last ConfigTime and last reference time.	*/
/*Used By	  :  CDI																*/
/************************************************************************************/
CREATE PROCEDURE dbo.internal_is_reference_binding_required
@Result int out,
@lastConfigChange nvarchar(50) out
 AS
begin
SET NOCOUNT ON

SELECT @Result = CASE 
		WHEN time_of_last_config_change > ISNULL(time_of_last_reference_binding , 0)
			THEN 1 
			ELSE 0
		END
FROM galaxy

SELECT @lastConfigChange = convert(nvarchar(50), time_of_last_config_change, 121)
FROM galaxy


end
go

