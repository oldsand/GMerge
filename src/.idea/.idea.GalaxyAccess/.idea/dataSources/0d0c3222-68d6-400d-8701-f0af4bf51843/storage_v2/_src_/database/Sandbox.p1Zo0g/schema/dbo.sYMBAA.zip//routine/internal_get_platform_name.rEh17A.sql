create proc dbo.internal_get_platform_name
  @gobjectid int,
  @platformname nvarchar(32) out
as
begin
set nocount on
set @platformname = (select isnull(objname.tag_name,'') from instance inst
	left join instance inst1 on inst.mx_platform_id = inst1.mx_platform_id
		  and inst1.mx_engine_id = 1
	left join gobject objname on inst1.gobject_id = objname.gobject_id
	where inst.gobject_id = @gobjectid)

end
go

