create proc dbo.internal_get_next_timestamp
@timestamp bigint output
as
begin
/* 
insert a row into the timestamp_record 
table to get a new timestamp
*/
insert into timestamp_record (ts)
select null

/* 
read the timestamp value into the
out param                      
*/
select @timestamp = @@dbts

 
end
go

