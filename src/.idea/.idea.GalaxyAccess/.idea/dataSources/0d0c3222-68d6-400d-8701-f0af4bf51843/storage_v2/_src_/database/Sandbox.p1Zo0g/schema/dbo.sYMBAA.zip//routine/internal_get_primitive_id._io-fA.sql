-- Procedure to get the Primitive ID
create procedure dbo.internal_get_primitive_id
@varpkgID int,
@vargobjectId int,
@varPrimName nvarchar(700)
AS
begin
set nocount on
	select 
	   prim_inst.mx_primitive_id 
	from 
       primitive_instance prim_inst
	where 
	    prim_inst.primitive_name = @varPrimName 
    and prim_inst.package_id = @varpkgID
	and prim_inst.gobject_id = @vargobjectId


end
go

