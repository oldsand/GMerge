/*
	This view is used by the WWCDI:QueryObject.h

*/

create view dbo.internal_package_status_view
as 
	select
		g.gobject_id, 
		p.package_id,
		CASE WHEN (p.status_id = 0 and p.reference_status_id = 0) THEN
			CASE WHEN ver_warning_view.has_warning = 1 
				THEN 2 
			ELSE 0 
		END
		ELSE 
			CASE WHEN p.status_id <> 0 THEN
				p.status_id
			ELSE
				CASE WHEN (p.status_id = 0 and p.reference_status_id <> 0) THEN
					p.reference_status_id
				ELSE 0 
				END
			END
		END as status_id
	from gobject g with (nolock)
	inner join package p with (nolock) on
		(g.gobject_id = p.gobject_id and
		g.checked_in_package_id = p.package_id) or
		(g.gobject_id = p.gobject_id and
		g.checked_out_package_id = p.package_id) or
		(g.gobject_id = p.gobject_id and
		g.deployed_package_id = p.package_id) 
	inner join internal_visual_element_reference_warning_status_view ver_warning_view on
		ver_warning_view.gobject_id = p.gobject_id and
		ver_warning_view.package_id = p.package_id
go

