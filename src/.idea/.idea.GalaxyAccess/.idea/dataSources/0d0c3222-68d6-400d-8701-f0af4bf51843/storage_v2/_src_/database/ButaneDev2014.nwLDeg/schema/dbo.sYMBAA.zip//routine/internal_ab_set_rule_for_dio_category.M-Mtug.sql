CREATE PROCEDURE dbo.internal_ab_set_rule_for_dio_category
	  @dio		int
    , @rule_id  int = NULL
	, @force	bit = 0
as
begin
    set nocount on

	declare @set_cat_id int
	declare @abd_cat_id int
	declare @abd_cat_rule_id int

	select @set_cat_id = lcat.category_id, @abd_cat_id = ab_cat.category_id, @abd_cat_rule_id = ab_cat.rule_id
	FROM gobject dio
	INNER JOIN template_definition td
	  ON td.template_definition_id = dio.template_definition_id
	INNER JOIN lookup_category lcat
	  ON lcat.category_id = td.category_id
	 AND lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
	LEFT OUTER JOIN autobind_device_category ab_cat
	  ON ab_cat.category_id = lcat.category_id

	if @@ROWCOUNT = 0
		return -1

	if @abd_cat_id IS NULL
		INSERT INTO autobind_device_category (category_id, rule_id) VALUES (@set_cat_id, @rule_id)
	else if @abd_cat_rule_id IS NULL OR @force = 1
		UPDATE autobind_device_category SET rule_id = @rule_id WHERE category_id = @abd_cat_id
	else
		return 1

   -- EXECUTE internal_ab_refresh_attribute_aliases 0, 0, 0, 0, @abd_cat_id

    return 0
end
go

