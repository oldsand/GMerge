/*
** Procedure [internal_ab_override_topic_name_rule]
** This sproc asserts a naming-rule at the scan-group-level scope.
*/
CREATE PROCEDURE dbo.internal_ab_set_rule_for_dio_topic
    @dio_id		int
    , @sg_name	nvarchar(329)
    , @rule_id	int = NULL
    , @force	bit = 0
as
begin
    set nocount on
	declare @sg_rule_id int
	declare @sg_mx_primitive_id smallint

    SELECT @sg_rule_id = topic.overridden_naming_rule_id, @sg_mx_primitive_id = topic.sg_mx_primitive_id
      FROM autobind_device_topic topic
	  INNER JOIN gobject dio
	      ON dio.gobject_id = topic.dio_id
	     AND dio.is_template = 0
    INNER JOIN primitive_instance p
        ON p.gobject_id = topic.dio_id
       AND p.package_id = dio.checked_in_package_id
	     AND p.mx_primitive_id = topic.sg_mx_primitive_id
       AND p.primitive_name = @sg_name
    INNER JOIN primitive_definition pd
        ON pd.primitive_definition_id = p.primitive_definition_id
       AND pd.primitive_name in ('S', 'SG', 'ScanGroup1')
     WHERE topic.dio_id = @dio_id

    if @@ROWCOUNT = 0
        RETURN -1    -- Return -1 to indicate that bad dio|scan-group was specified.

	if @sg_rule_id IS NULL OR @force = 1
		UPDATE autobind_device_topic 
		   SET overridden_naming_rule_id = @rule_id 
		 WHERE dio_id = @dio_id
		   AND sg_mx_primitive_id = @sg_mx_primitive_id
	else
		return 1



    EXECUTE internal_ab_refresh_attribute_aliases 0, @dio_id, @sg_mx_primitive_id

    RETURN 0
end
go

