-- Returns the derivation level for an gObject template 
-- or instance.  
-- Returns -1 for invalid object id.
-- Returns 0 for base template, 1 for first level 
-- template or instance, etc.
-- 
create proc dbo.internal_get_object_derivation_level
	@varObjectName nvarchar(329),
	@varDerivationLevel smallint out
as

SET NOCOUNT ON

set @varDerivationLevel = -1
BEGIN
	declare	@objectId		int
	declare	@level			int

	select	@objectId = gobject_id 
	from	gobject
	where	tag_name = @varObjectName and namespace_id = 1  -- Automation Object

	if (@objectId is null)
		return

	select	@level = 0

	while (@objectId is not null)
	begin	
		select	@objectId = derived_from_gobject_id
		from	gobject
		where	gobject_id = @objectId

		if (@objectId = 0)
			break

		set @level = @level + 1

		-- raise error here
		if (@level > 32)
		begin
			set @level = -1
			RAISERROR('Can not find the derivation level of %s. Database maybe corrupted.',
				16, 1, @varObjectName)
			break
		end
	end

	set @varDerivationLevel = @level
END

go

