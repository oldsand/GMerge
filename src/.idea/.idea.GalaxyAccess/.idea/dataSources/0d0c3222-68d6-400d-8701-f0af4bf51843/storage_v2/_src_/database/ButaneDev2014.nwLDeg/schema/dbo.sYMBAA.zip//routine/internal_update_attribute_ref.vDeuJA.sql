/********************************************************************/
/*Object Name	:  internal_update_attribute_ref			            */
/*Object Type	:  Stored Proc.										*/
/*Purpose		:  to update the attribute reference table			*/
/*Used By		:  CDI												*/
/********************************************************************/
CREATE   PROCEDURE dbo.internal_update_attribute_ref
@FileNameOfdata nvarchar (265)
 AS
begin
	set nocount on


	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #results_table ( 
					gobject_id int,
					package_id int,
					ref_prim_id int,
					ref_attr_id int,
				    element_index int, 
				    res_gobject_id int,
				    dest_obj_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
				    obj_sign int,
				    attr_sign int, 
				    res_mx_prim_id int,
				    res_mx_attr_id int,
				    res_mx_prop_id int,
				    attr_res_st int,
                    attr_idx int)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfdata + ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '

	EXEC (@SQL)

	update #results_table set res_gobject_id = ISNULL(( select case when gobj.gobject_id = NULL then 0
														 else gobj.gobject_id
														 end
													from gobject gobj
													where gobj.namespace_id = 1 and gobj.tag_name = #results_table.dest_obj_name ), 0)  -- Namespace_id 1 =Automation Object
	from #results_table 

	update attribute_reference 
	set resolved_gobject_id = #results_table.res_gobject_id, 
		object_signature = #results_table.obj_sign,
		resolved_mx_primitive_id = #results_table.res_mx_prim_id,
		resolved_mx_attribute_id = #results_table.res_mx_attr_id,
		resolved_mx_property_id = #results_table.res_mx_prop_id,
		attribute_signature = #results_table.attr_sign,
		attribute_index = #results_table.attr_idx,
		is_valid = 0
	FROM attribute_reference 
	INNER JOIN #results_table ON #results_table.gobject_id = attribute_reference.gobject_id
	and #results_table.package_id = attribute_reference.package_id
	and #results_table.ref_prim_id = attribute_reference.referring_mx_primitive_id
	and #results_table.ref_attr_id = attribute_reference.referring_mx_attribute_id
	and #results_table.element_index = attribute_reference.element_index
		
	drop table #results_table


	
end

go

