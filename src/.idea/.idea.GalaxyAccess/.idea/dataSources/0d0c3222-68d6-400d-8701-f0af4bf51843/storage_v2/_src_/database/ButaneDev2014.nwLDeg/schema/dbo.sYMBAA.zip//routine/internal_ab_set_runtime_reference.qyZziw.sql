/*
** Return: 0: Successfully asserted override; 1: Invalid @attr_name; 2: Invalid @override_str,
** Algorithm:
** 
*/
CREATE PROCEDURE dbo.internal_ab_set_runtime_reference
    @attr_name nvarchar(329) -- Attribute reference being sought (e.g.: UDO_001.uda1.InputSource)
  , @override_str nvarchar(329)
  , @gobject_id  int = 0
  , @returnCode int output
as
begin
  set nocount on
  declare @attr_ref nvarchar(329) = NULL
  declare @dio_name nvarchar(329)
  declare @sg_name  nvarchar(329)
  declare @dio_id   int = 0
  declare @sg_mx_primitive_id smallint = 0
  declare @ao_name  nvarchar(329)
  declare @uda_name nvarchar(329)
  declare @io_attr  nvarchar(329)  -- 'InputSource'|'OutputDest'
  declare @ov_type  nvarchar(329) = ''
  declare @prim_id  int
  declare @attr_id  int

  --added to check spaces and two ..
  if (CHARINDEX(' ',@override_str) <> 0 OR CHARINDEX('..',@override_str)<> 0 OR SUBSTRING(@override_str,LEN(@override_str),1) = '.')
  begin
	set @returnCode = 2
	return
  end

  set @returnCode = 0 --set it to success by default

  -- Split the passed @attr_name into its components
  SELECT @io_attr  = io_attr_ref
       , @uda_name = ao_attr
       , @ao_name  = ao_tag_name 
    FROM itvfabSplitAttrRef (@attr_name)

  if @gobject_id = 0
  begin
    -- If @gobject_id == 0, @attr_name will contain the following information: "gobject_id.uda_primitive_id.uda_attribute_id"
    -- The call to itvfabSplitAttrRef will have split @attr_name into the three IDs
    -- The conversion of char to int in the following assignments is implicit
    set @gobject_id = @ao_name
    set @prim_id    = @uda_name
    set @attr_id    = @io_attr

    SELECT @ao_name                               = lo.tag_name
         , @uda_name                              = lo_pi.primitive_name
         , @io_attr                               = lo_attr_def.attribute_name
         , @dio_id                                = odl.dio_id
         , @sg_mx_primitive_id                    = odl.sg_mx_primitive_id
      FROM object_device_linkage odl
    INNER JOIN gobject lo
        ON lo.gobject_id                          = odl.gobject_id
    INNER JOIN attribute_reference lo_attr_ref
        ON lo_attr_ref.gobject_id                 = lo.gobject_id
       AND lo_attr_ref.package_id                 = lo.checked_in_package_id
       AND lo_attr_ref.referring_mx_primitive_id  = @prim_id
       AND lo_attr_ref.referring_mx_attribute_id  = @attr_id
       AND lo_attr_ref.element_index              = 0                                      -- No arrays for now.
       AND lo_attr_ref.reference_string           = N'---Auto---'
    INNER JOIN primitive_instance lo_pi
        ON lo_pi.package_id                       = lo_attr_ref.package_id
       AND lo_pi.gobject_id                       = lo_attr_ref.gobject_id
       AND lo_pi.mx_primitive_id                  = lo_attr_ref.referring_mx_primitive_id
    INNER JOIN attribute_definition lo_attr_def
        ON lo_attr_def.primitive_definition_id    = lo_pi.primitive_definition_id
       AND lo_attr_def.mx_attribute_id            = lo_attr_ref.referring_mx_attribute_id
     WHERE odl.gobject_id                         = @gobject_id
  end
  else
    SELECT @dio_id = dio_id
         , @sg_mx_primitive_id = sg_mx_primitive_id
      FROM object_device_linkage
     WHERE gobject_id = @gobject_id

  if (@dio_id = 0 OR @sg_mx_primitive_id = 0 OR @gobject_id = 0)
  begin
    set @returnCode =  1
    return
  end

  SELECT  @dio_name = dio_tag_name
        , @sg_name  = dio_scan_group_name
        , @attr_ref = default_attr_reference
        , @prim_id  = lo_prim_id
        , @attr_id  = lo_attr_id
    FROM  itvfGetAutobindInfoForDIO (@dio_id, @sg_mx_primitive_id, @gobject_id, @uda_name, @io_attr) bind_info

  if @@ROWCOUNT = 0
  begin
    set @returnCode =  1
    return
  end

  -- Look for ASB like references
  if (@override_str = '---' OR @override_str = '---.---')
    set @ov_type = N'Radical_Override'
  else if (CHARINDEX (':', @override_str) <> 0)
    set @ov_type = N'ASB_Reference'
  else
  begin
    declare @attr_match  bit = 0
    declare @dio_match bit = 0
    declare @dot1 int
    declare @dot2 int = 0
    declare @dev_override nvarchar(65)
    declare @sg_override nvarchar(32) = ''

    if (RIGHT (@override_str, LEN (@attr_ref) + 1) = '.' + @attr_ref)
    begin
      set @override_str = LEFT (@override_str, LEN (@override_str) - LEN (@attr_ref) - 1)
      if (@override_str <> '')
        set @attr_match = 1
      else
        set @override_str = @attr_ref -- no device override: The attribute reference cannot be deemed a match. Restore @override_str.
    end

    -- Now see if the device-override matches with what the auto-bound reference is already set to
    set @dot1 = CHARINDEX ('.', @override_str)
    if (@dot1 = 0)
    begin
      if (@attr_match = 0)
      begin
        set @returnCode =  2 -- Invalid override str: Need at least device.attr.
        return
      end
      else
      begin
        set @dev_override = @override_str   -- Possibly a Device_Override (default scan-group).
        set @override_str = ''
      end
    end
    else
    begin
      set @dev_override = LEFT (@override_str, @dot1 - 1)
      if (@dev_override = '' OR CHARINDEX (' ', @dev_override) <> 0) -- Leading '.', or spaces in device override: Invalid device override.
      begin
        set @returnCode =  2
        return
      end

      set @dot2 = CHARINDEX ('.', @override_str, @dot1 + 1)
      if (@dot2 = 0)
      begin
        if (@attr_match = 1)
        begin
          set @sg_override = SUBSTRING (@override_str, @dot1 + 1, 329)
          set @override_str = ''
        end
	else --Added for demo issue
        begin
		set @sg_override = ''
		set @override_str = SUBSTRING(@override_str,@dot1 + 1,329)
        end --end
      end
      else
      begin
        set @sg_override = SUBSTRING (@override_str, @dot1 + 1, @dot2 - @dot1 - 1)
		if (@sg_override <> '')
			set @dot2 = @dot2 + 1
        set @override_str = SUBSTRING (@override_str, @dot2, 329)
        if (@attr_match = 1)
        begin
          set @attr_match = 0  -- The presence of a second '.' breaks the @attr_match = 1 condition
          set @override_str = @override_str + '.' + @attr_ref -- restore the @attr_ref portion we'd stripped from @override_str
        end
      end
    end

    -- We have enough information to determine if the device portion of the override matches the default
    if (@dev_override = @dio_name AND @sg_override = @sg_name)
      set @dio_match = 1

    if (@dio_match = 1 AND @attr_match = 1)
      set @ov_type = N'None'
    else if (@dio_match = 1)
    begin
      set @ov_type = N'Simple_Override'
    end
    else if @sg_override = ''
    begin
      if (@attr_match = 1)
      begin
        set @ov_type = N'Device_Override'
        set @override_str = @dev_override
      end
      else
	  begin
	    set @override_str = @dev_override + '.' + @override_str
		set @ov_type = N'Radical_Override_Default_SG'
	  end
    end
    else  -- Neither parts of the override match with the default reference
    begin
      -- This (@override_str) is a radical override, we just need to verify the type.
      -- We'll simply verify if @sg_override is a valid scan-group under @dev_override. 
      -- If it isn't we'll assume that it's a part the attribute reference (default scan-group).
      SELECT @ov_type = CASE WHEN @attr_match = 1 THEN N'Device_and_SG_Override' ELSE N'Radical_Override' END
        FROM gobject g
      INNER JOIN primitive_instance p
          ON p.gobject_id = g.gobject_id
         AND p.package_id = g.checked_in_package_id
         AND p.primitive_name = @sg_override
      INNER JOIN primitive_definition pd
          ON pd.primitive_definition_id = p.primitive_definition_id
         AND pd.primitive_name IN (N'S', N'SG', N'ScanGroup1')
      INNER JOIN template_definition t
          ON t.template_definition_id = g.template_definition_id
         AND t.category_id IN (11,12,24)
       WHERE g.tag_name = @dev_override

      if @@ROWCOUNT = 0
      begin
        set @ov_type = N'Radical_Override_Default_SG'
        set @override_str = @dev_override + '.' + @sg_override + '.' + CASE WHEN @attr_match = 1 THEN @attr_ref ELSE @override_str END
      end
      else if (@attr_match = 0)
        set @override_str = @dev_override + '.' + @sg_override + '.' + @override_str
      else
        set @override_str = @dev_override + '.' + @sg_override
    end
  end

  if (@ov_type <> '')
  begin
    UPDATE autobound_attribute
       SET attr_alias = @override_str
         , xlate_rule_id = (SELECT xlate_rule_id FROM autobind_translation_rule WHERE xlate_rule_name = @ov_type)
     WHERE gobject_id = @gobject_id
       AND mx_primitive_id = @prim_id
       AND mx_attribute_id = @attr_id
       AND element_index = 0
  end

end

go

