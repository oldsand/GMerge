--*************************************************
--Object Name :  internal_get_gobject_id_from_tag_name3
--Object Type :  Stored Proc. 
--Purpose	  :  This procedure retrieves a gobject_id 
--		     for a given tag_name from template_definition table. 
--
--
--				This was written for CR 'L00087123'.
--				To cover the scenarios where in when the user re-names the 
--				original base template name and then when we patch this base template
--				with a newer version, minor version change, then that original tag-name
--				is not present in the gObject table. Hence we look for the same in the 
--				template_definition table.
--				This is during scenario when Galaxy Patcher is called which updates the
--				base template in question.
--**************************************************/

CREATE PROCEDURE dbo.internal_get_gobject_id_from_tag_name3
	@namespace_id smallint,
	@tag_name nvarchar(329),
	@gobject_d int  OUTPUT
AS
begin
SET NOCOUNT ON

begin

	select @gobject_d = max(base_gobject_id)
	from template_definition 
	where original_template_tagname = @tag_name

end 


end

go

