-- resolves a user supplied visual element reference.
-- See interface IVisualElementReference
--
-- If user_guid is supplied, that users view will determine
-- what gets resolved
-- resolves a user supplied visual element reference.
-- See interface IVisualElementReference
--
-- If user_guid is supplied, that users view will determine
-- what gets resolved
-- resolves a user supplied visual element reference.
-- See interface IVisualElementReference
--
-- If user_guid is supplied, that users view will determine
-- what gets resolved
create proc dbo.internal_resolve_visual_element_reference2 (
    @visual_element_name nvarchar(395) = N'',
    @visual_element_type nvarchar(32) = N'',
    @visual_element_id  int = 0,
    @user_guid uniqueidentifier,
    @reference_object_tagname nvarchar(329) = N'',
    @resolved_visual_element_name nvarchar(329) out,
    @resolved_visual_element_type nvarchar(32) out,
    @resolved_visual_element_id int out )
as
begin
    -- initialize out params..
    set @resolved_visual_element_name = N''
    set @resolved_visual_element_type = N''
    set @resolved_visual_element_id = 0
 
    -- pull apart the different parts of the reference string
    declare @p_visual_element_type nvarchar(329) -- unused
    declare @tag_name nvarchar(32)
    declare @primitive_name nvarchar(329)
    declare @p_visual_element_name nvarchar(329) -- unused
    declare @is_relative_reference bit
    declare @relative_object_name nvarchar(329)
    declare @is_hierarchical_visual_element_name bit

    -- Set parameter values
    exec internal_parse_visual_element_reference_string
        @visual_element_name, 
        @p_visual_element_type output, 
        @tag_name output,
        @primitive_name output,
        @p_visual_element_name output,
        @is_relative_reference output,
        @relative_object_name output,
        @is_hierarchical_visual_element_name output

    -- get default user if none supplied
    if @user_guid is null or @user_guid = '00000000-0000-0000-0000-000000000000'
        select @user_guid = user_guid 
        from user_profile 
        where user_profile_name= 'SystemEngineer'
 
    -- try to bind by id
    select 
        @resolved_visual_element_name = visual_element_name,
        @resolved_visual_element_type = visual_element_type,
        @resolved_visual_element_id = visual_element_id
    from 
        internal_visual_element_description_per_user_view 
    where 
        visual_element_id = @visual_element_id
        and user_guid = @user_guid

	if( @@rowcount <> 0 )
        return
  
    if( @is_relative_reference = 1)
    begin

        declare @reference_object_hierarchical_name nvarchar(329)
        select @reference_object_hierarchical_name  = hierarchical_name 
		from gobject 
		where tag_name = @reference_object_tagname
		and namespace_id = 1

  
        declare @target_gobject_hierarchical_name nvarchar(329)
        if( len(@relative_object_name) > 0 )
            set @target_gobject_hierarchical_name = @reference_object_hierarchical_name + '.' + @relative_object_name
        else
            set @target_gobject_hierarchical_name = @reference_object_hierarchical_name
 
        select 
            @resolved_visual_element_name = visual_element_name,
            @resolved_visual_element_type = visual_element_type,
            @resolved_visual_element_id = visual_element_id
        from 
            internal_visual_element_description_per_user_view 
        where 
            gobject_hierarchical_name = @target_gobject_hierarchical_name
            and primitive_name = @primitive_name
            and user_guid = @user_guid

    end
    else if(@is_hierarchical_visual_element_name = 0)
    begin
  

    -- if type passed in, bind by name and type, otherwise by name only
        -- try to bind by name
        select 
            @resolved_visual_element_name = visual_element_name,
            @resolved_visual_element_type = visual_element_type,
            @resolved_visual_element_id = visual_element_id
        from 
            internal_visual_element_description_per_user_view 
        where 
            tag_name = @tag_name
            and primitive_name = @primitive_name
            and user_guid = @user_guid
    end
    else
    begin  -- a hierachical visual element name was passed in...
    -- if type passed in, bind by name and type, otherwise by name only
        -- try to bind by name
        select 
            @resolved_visual_element_name = visual_element_name,
            @resolved_visual_element_type = visual_element_type,
            @resolved_visual_element_id = visual_element_id
        from 
            internal_visual_element_description_per_user_view 
        where 
            hierarchical_visual_element_name = @p_visual_element_name
            and user_guid = @user_guid
    end

    
 
     if isnull(@visual_element_type,'') = '' or @visual_element_type = @resolved_visual_element_type
        return
 
    -- couldn't bind, return the names passed in and visual_element_id of 0
    set @resolved_visual_element_name = @visual_element_name
    set @resolved_visual_element_type = @visual_element_type
    set @resolved_visual_element_id = 0
 
    return
end
go

