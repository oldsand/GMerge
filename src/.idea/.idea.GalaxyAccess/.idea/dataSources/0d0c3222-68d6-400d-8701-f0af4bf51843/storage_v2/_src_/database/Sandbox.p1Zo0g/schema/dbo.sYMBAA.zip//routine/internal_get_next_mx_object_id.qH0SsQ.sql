/*
  This stored procedure is used to find a hole in the mx_object_ids for a given mx_platform_id and 
  mx_engine_id. It does a left join with itself and finds out where the nulls are.
  Called by internal_set_host_and_mx_ids
*/

create proc dbo.internal_get_next_mx_object_id 
	@my_platform_id smallint,
	@my_engine_id smallint,
	@my_object_id smallint out
as
begin
set @my_object_id = (select min(i.mx_object_id) from instance i 
left join (select mx_object_id from instance where mx_platform_id = @my_platform_id and mx_engine_id = @my_engine_id)
  r on i.mx_object_id + 1 = r.mx_object_id
		where r.mx_object_id is null 
                and i.mx_platform_id = @my_platform_id and i.mx_engine_id = @my_engine_id )

set @my_object_id = @my_object_id + 1				
  
end
go

