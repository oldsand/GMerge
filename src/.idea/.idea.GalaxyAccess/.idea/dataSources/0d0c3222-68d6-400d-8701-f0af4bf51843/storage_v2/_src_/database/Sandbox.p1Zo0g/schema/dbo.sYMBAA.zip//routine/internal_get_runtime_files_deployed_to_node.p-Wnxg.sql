/*
This procedure outputs the list of all the 
runtime files which are deployed to target node 
usage: exec internal_getRuntimeFilesDeployedToNode 'Nodename'
*/
CREATE  proc dbo.internal_get_runtime_files_deployed_to_node
    @nodename nvarchar(256)
as
set nocount on
begin
		 
	select file_name, vendor_name, registration_type, subfolder from file_table ft
	inner join deployed_file 
		on ft.file_id = deployed_file.file_id and
			   deployed_file.is_package_deployed = 0 and
			   deployed_file.is_editor_deployed = 0 and
			   deployed_file.is_runtime_deployed = 1 and		
			   deployed_file.node_name = @nodename
end
set nocount off
go

