create procedure dbo.internal_add_visual_element_references_from_parent
@gobject_id int,
@package_id int,
@package_type nchar,
@parent_package_id int = 0, -- CR L00123287 cloned from HF CR# CR L00123250
@use_parent_vers_tbl bit = 0

as
begin tran

--get the derived_from_gobject_id from the DB...
declare @derived_from_gobject_id int
select @derived_from_gobject_id = derived_from_gobject_id
from gobject 
where gobject_id = @gobject_id

if exists(select '*'
            from internal_visual_element_reference_view with(nolock)
            where gobject_id = @derived_from_gobject_id and
              package_type = @package_type

           )
begin
    /*
    ** CR L00115843: 
    ** Summary of changes:
    ** Don't invoke internal_add_visual_reference. Instead, call internal_parse_internal_visual_element_reference_string direcrly,
    ** populate a temp table (the @my_parents_ve_reference table variable, actually), and perform a bulk insert into the
    ** visual_element_reference_table.
    */
    
    create table #ver_view
	(
	   mx_primitive_id smallint,
	   visual_element_reference_index int,
	   reference_string nvarchar(3620)
	)
	
	declare @mx_primitive_id smallint
	declare @visual_element_reference_index int
	declare @reference_string nvarchar(3620)
	declare @visual_element_id int
 	declare @visual_element_name nvarchar(362)
	declare @visual_element_type nvarchar(329)
	declare @tag_name nvarchar(32)
	declare @primitive_name nvarchar(329)
	declare @is_relative_reference bit
	declare @relative_object_name nvarchar(329)
	declare @is_hierarchical_visual_element_name bit
			
	if (@use_parent_vers_tbl = 0)
	begin
		-- create temp table to store parents info...
		 declare @my_parents_ve_references table
		 (
			gobject_id							int not null,
			package_id							int not null,
			mx_primitive_id smallint,
		  visual_element_reference_index int,
			visual_element_id					int default 0,
			visual_element_name					nvarchar(362),
			visual_element_type					nvarchar(329),
			tag_name							nvarchar(32),
			primitive_name						nvarchar(329),
			is_relative_reference				bit,
			relative_object_name				nvarchar(329),
			is_hierarchical_visual_element_name bit
		)
	      
		-- add each reference from temp table
		--Start CR L00123287 cloned from HF CR# L00123250 there can be many packages of type X during import 
		--so get the visual element references from the parent package child is referring to
		
		if( @package_type = 'X')
		begin
		  insert into #ver_view 
		  select distinct
			mx_primitive_id,
			visual_element_reference_index,
			reference_string
		  from internal_visual_element_reference_view
		  where gobject_id = @derived_from_gobject_id and
				package_id = @parent_package_id
		end
		else
		begin
		insert into #ver_view
		select distinct
			mx_primitive_id,
			visual_element_reference_index,
			reference_string
		from internal_visual_element_reference_view
		where gobject_id = @derived_from_gobject_id and
			  package_type = @package_type
		end
	          
		declare visual_element_reference_cursor cursor fast_forward for
		 select
			mx_primitive_id,
			visual_element_reference_index,
			reference_string
		from #ver_view
		--End CR L00123287

		open visual_element_reference_cursor
		while( 1=1 )
		begin
			set @mx_primitive_id = NULL
			set @visual_element_reference_index = NULL
			set @reference_string = NULL
			set @visual_element_id = 0
 			set @visual_element_name = NULL
			set @visual_element_type = NULL
			set @tag_name = NULL
			set @primitive_name = N''
			set @is_relative_reference = NULL
			set @relative_object_name = ''
			set @is_hierarchical_visual_element_name = NULL
		    
			fetch next from visual_element_reference_cursor into
				@mx_primitive_id,
				@visual_element_reference_index,
				@reference_string
	 
			if( @@fetch_status <> 0 ) break

			if not exists(
				select '1' from visual_element_reference 
				where gobject_id = @gobject_id
				  and package_id = @package_id
				  and mx_primitive_id = @mx_primitive_id
				  and visual_element_reference_index = @visual_element_reference_index
				)
			begin
				--set @relative_object_name = ''
				--set @visual_element_id = 0
			
				-- break the reference down into its parts
				--set @primitive_name = N'' -- initialize out param
				exec internal_parse_visual_element_reference_string
					@reference_string,
					@visual_element_type output,
					@tag_name output,
					@primitive_name output,
					@visual_element_name output,
					@is_relative_reference output,
					@relative_object_name output,
					@is_hierarchical_visual_element_name output

	       
				if(@is_relative_reference = 1)  
				begin
					-- the tag_name is not relevant, so we will not store it..
					set @tag_name = null
				end
	    
	    		INSERT INTO @my_parents_ve_references
	    			VALUES (
						@gobject_id,
						@package_id,
						@mx_primitive_id,
						@visual_element_reference_index,
						@visual_element_id,
						@visual_element_name,
						@visual_element_type,
						@tag_name,
						@primitive_name,
						@is_relative_reference,
						@relative_object_name,
						@is_hierarchical_visual_element_name
					)
			end		

		end
		close visual_element_reference_cursor
		deallocate visual_element_reference_cursor
		drop table #ver_view -- CR L00123287 cloned from HF CR# L00123250 

		-- add to visual_element_reference table
		INSERT INTO visual_element_reference 
		(
			gobject_id, 
			package_id, 
			mx_primitive_id,
			visual_element_reference_index,
			--visual_element_bind_status, -- this is now a calculated column....
			is_relative_reference,
			checked_in_bound_visual_element_gobject_id ,
			checked_in_bound_visual_element_package_id ,
			checked_in_bound_visual_element_mx_primitive_id ,
			checked_out_bound_visual_element_gobject_id ,
			checked_out_bound_visual_element_package_id ,
			checked_out_bound_visual_element_mx_primitive_id ,
	    
			-- unbound section
			checked_in_unbound_visual_element_name ,
			checked_in_unbound_visual_element_type ,
			checked_in_unbound_tag_name  ,
			checked_in_unbound_primitive_name ,
			checked_in_unbound_relative_object_name  ,
			checked_in_unbound_visual_element_id,
			checked_out_unbound_visual_element_name ,
			checked_out_unbound_visual_element_type ,
			checked_out_unbound_tag_name  ,
			checked_out_unbound_primitive_name,
			checked_out_unbound_relative_object_name  ,
			checked_out_unbound_visual_element_id,
			checked_out_to_user_guid
		) 
		SELECT
			gobject_id,
			package_id,
			mx_primitive_id,
			visual_element_reference_index,
			--0, --visual_element_bind_status -- this is now a calculated column....
			is_relative_reference,
			null,--checked_in_bound_visual_element_gobject_id ,
			null,--checked_in_bound_visual_element_package_id ,
			null,--checked_in_bound_visual_element_mx_primitive_id ,
			null,--checked_out_bound_visual_element_gobject_id ,
			null,--checked_out_bound_visual_element_package_id ,
			null,--checked_out_bound_visual_element_mx_primitive_id ,

			-- unbound section
			visual_element_name,--checked_in_unbound_visual_element_name ,
			visual_element_type,--checked_in_unbound_visual_element_type ,
			tag_name,--checked_in_unbound_tag_name,
			primitive_name,--checked_in_unbound_primitive_name not ,
			relative_object_name,--checked_in_unbound_relative_object_name  ,
			visual_element_id,--checked_in_unbound_visual_element_id,
			visual_element_name,--checked_out_unbound_visual_element_name ,
			visual_element_type,--checked_out_unbound_visual_element_type ,
			tag_name,--checked_out_unbound_tag_name  ,
			primitive_name,--checked_out_unbound_primitive_name ,
			relative_object_name,--checked_out_unbound_relative_object_name  ,
			visual_element_id,--checked_out_unbound_visual_element_id
			null--checked_out_to_user_guid
		FROM
			@my_parents_ve_references 
		
		--delete from  @my_parents_ve_references
	end
	else
	begin
	
		--Parent template's VER will be fetched only once and stored in a #parents_ve_references_table table while processing its first instance.
		-- For the remaining instance of the same teplate, #parents_ve_references_table table table will be refered.
		IF NOT EXISTS (select '1' from #parents_ve_references_table where derived_from_gobject_id = @derived_from_gobject_id and package_type = @package_type)
		begin

				-- add each reference from temp table
				--Start CR L00123287 cloned from HF CR# L00123250 there can be many packages of type X during import 
				--so get the visual element references from the parent package child is referring to
				
				if( @package_type = 'X')
				begin
				  insert into #ver_view 
				  select distinct
					mx_primitive_id,
					visual_element_reference_index,
					reference_string
				  from internal_visual_element_reference_view
				  where gobject_id = @derived_from_gobject_id and
						package_id = @parent_package_id
				end
				else
				begin
				insert into #ver_view
				select distinct
					mx_primitive_id,
					visual_element_reference_index,
					reference_string
				from internal_visual_element_reference_view
				where gobject_id = @derived_from_gobject_id and
					  package_type = @package_type
				end

				declare visual_element_reference_cursor cursor fast_forward for
				 select
					mx_primitive_id,
					visual_element_reference_index,
					reference_string
				from #ver_view
				--End CR L00123287

				open visual_element_reference_cursor
				while( 1=1 )
				begin
					set @mx_primitive_id = NULL
					set @visual_element_reference_index = NULL
					set @reference_string = NULL
					set @visual_element_id = 0
 					set @visual_element_name = NULL
					set @visual_element_type = NULL
					set @tag_name = NULL
					set @primitive_name = N''
					set @is_relative_reference = NULL
					set @relative_object_name = ''
					set @is_hierarchical_visual_element_name = NULL
		    
					fetch next from visual_element_reference_cursor into
						@mx_primitive_id,
						@visual_element_reference_index,
						@reference_string
	 
					if( @@fetch_status <> 0 ) break

						--set @relative_object_name = ''
						--set @visual_element_id = 0
			
						-- break the reference down into its parts
						--set @primitive_name = N'' -- initialize out param
						exec internal_parse_visual_element_reference_string
							@reference_string,
							@visual_element_type output,
							@tag_name output,
							@primitive_name output,
							@visual_element_name output,
							@is_relative_reference output,
							@relative_object_name output,
							@is_hierarchical_visual_element_name output

	       
						if(@is_relative_reference = 1)  
						begin
							-- the tag_name is not relevant, so we will not store it..
							set @tag_name = null
						end
	    
	    				INSERT INTO #parents_ve_references_table
	    					VALUES (
								@derived_from_gobject_id,
								@package_type,
								@mx_primitive_id,
								@visual_element_reference_index,
								@visual_element_id,
								@visual_element_name,
								@visual_element_type,
								@tag_name,
								@primitive_name,
								@is_relative_reference,
								@relative_object_name,
								@is_hierarchical_visual_element_name
							)
				end
				close visual_element_reference_cursor
				deallocate visual_element_reference_cursor
				drop table #ver_view -- CR L00123287 cloned from HF CR# L00123250 
		end

		declare parents_ve_references_table_cursor cursor fast_forward for
		Select * FROM #parents_ve_references_table
				where derived_from_gobject_id = @derived_from_gobject_id and package_type = @package_type
		open parents_ve_references_table_cursor
		while( 1=1 )
		begin
			declare @derived_from_gobject_id1		int
			declare @package_type1				nchar
			fetch next from parents_ve_references_table_cursor into
						@derived_from_gobject_id1, @package_type1,
						@mx_primitive_id, @visual_element_reference_index, @visual_element_id, 
						@visual_element_name, @visual_element_type, @tag_name, @primitive_name, 
						@is_relative_reference,	@relative_object_name, @is_hierarchical_visual_element_name
	 
			if( @@fetch_status <> 0 ) break

			if not exists(
						select '1' from visual_element_reference 
						where gobject_id = @gobject_id
						  and package_id = @package_id
						  and mx_primitive_id = @mx_primitive_id
						  and visual_element_reference_index = @visual_element_reference_index
						)
					begin		
						-- add to visual_element_reference table
						INSERT INTO visual_element_reference 
						(
							gobject_id,
							package_id, 
							mx_primitive_id,
							visual_element_reference_index,
							--visual_element_bind_status, -- this is now a calculated column....
							is_relative_reference,
							checked_in_bound_visual_element_gobject_id ,
							checked_in_bound_visual_element_package_id ,
							checked_in_bound_visual_element_mx_primitive_id ,
							checked_out_bound_visual_element_gobject_id ,
							checked_out_bound_visual_element_package_id ,
							checked_out_bound_visual_element_mx_primitive_id ,
	    
							-- unbound section
							checked_in_unbound_visual_element_name ,
							checked_in_unbound_visual_element_type ,
							checked_in_unbound_tag_name  ,
							checked_in_unbound_primitive_name ,
							checked_in_unbound_relative_object_name  ,
							checked_in_unbound_visual_element_id,
							checked_out_unbound_visual_element_name ,
							checked_out_unbound_visual_element_type ,
							checked_out_unbound_tag_name  ,
							checked_out_unbound_primitive_name,
							checked_out_unbound_relative_object_name  ,
							checked_out_unbound_visual_element_id,
							checked_out_to_user_guid
						) 
						Values(
							@gobject_id,
							@package_id,
							@mx_primitive_id,
							@visual_element_reference_index,
							--0, --visual_element_bind_status -- this is now a calculated column....
							@is_relative_reference,
							null,--checked_in_bound_visual_element_gobject_id ,
							null,--checked_in_bound_visual_element_package_id ,
							null,--checked_in_bound_visual_element_mx_primitive_id ,
							null,--checked_out_bound_visual_element_gobject_id ,
							null,--checked_out_bound_visual_element_package_id ,
							null,--checked_out_bound_visual_element_mx_primitive_id ,

							-- unbound section
							@visual_element_name,--checked_in_unbound_visual_element_name ,
							@visual_element_type,--checked_in_unbound_visual_element_type ,
							@tag_name,--checked_in_unbound_tag_name,
							@primitive_name,--checked_in_unbound_primitive_name not ,
							@relative_object_name,--checked_in_unbound_relative_object_name  ,
							@visual_element_id,--checked_in_unbound_visual_element_id,
							@visual_element_name,--checked_out_unbound_visual_element_name ,
							@visual_element_type,--checked_out_unbound_visual_element_type ,
							@tag_name,--checked_out_unbound_tag_name  ,
							@primitive_name,--checked_out_unbound_primitive_name ,
							@relative_object_name,--checked_out_unbound_relative_object_name  ,
							@visual_element_id,--checked_out_unbound_visual_element_id
							null--checked_out_to_user_guid
							)

					end		

		end
		close parents_ve_references_table_cursor
		deallocate parents_ve_references_table_cursor
	
	end
    -- bind the newly added references.....
	exec internal_bind_relative_visual_elements_for_gobject @gobject_id,@package_id
    -- exec internal_bind_visual_element_references -- CR 117307
end    
commit
go

