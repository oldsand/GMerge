/*
Object Name :  internal_get_unique_name
Object Type :  Stored Proc.						
Purpose     :  Procedure to Get the Unique TagName for a given base name
               and namespace
Used By	    :  CDI()				
*/
create procedure dbo.internal_get_unique_name
@baseName nvarchar(32),
    @namespace_id int,
@uniqueName nvarchar(32) out 
AS
set nocount on  
begin
  declare @likeName nvarchar(64)

  if ( substring(@baseName, len(@baseName), 1) = '_' )
     set @likeName = substring(@baseName, 1, len(@baseName)- 1) + '[_][0-9][0-9][0-9]'
  else
  	 set @likeName = @baseName + '[0-9][0-9][0-9]'

  declare @galaxy_gobject_id integer
  select @galaxy_gobject_id =  gobject_id from gobject g
	inner join template_definition td 
	on g.template_definition_id = td.template_definition_id
	and td.category_id = 23
	where g.is_template = 0

  declare @maxno integer
  set @maxno = ISNULL(
	(	select max(cast(rtrim (substring(tag_name,
		len(@baseName)+1,len(tag_name))) as integer))
		 from gobject where 
		(tag_name like @likeName and namespace_id = @namespace_id)
		or
		(tag_name = @likeName and gobject_id = @galaxy_gobject_id)
	),1)
  

  declare @whichname nvarchar(32)
  declare @howmanyzeros int
  declare @maxnolength int

  while 0 < 1
    begin
	set @maxnolength = len(cast(@maxno as nvarchar ))
	set @howmanyzeros = 3 - len(cast(@maxno as nvarchar ))
	
	if ( @howmanyzeros > 0 )
	  set @whichname = @baseName + (REPLICATE( '0',@howmanyzeros ) + cast(@maxno as nvarchar )   )
	else
		begin
			if ( len(@baseName) + @maxnolength ) > 32
				set @whichname = SUBSTRING(@baseName, 1, 32 - (@maxnolength + 1)) + '_' + cast(@maxno as nvarchar )
			else
				set @whichname = @baseName + cast(@maxno as nvarchar )
		end
	
	declare @isNameUnique int

	/* Find out if this name is a unique Name*/
	set @isNameUnique = (select count(*) from gobject where 
			(tag_name = @whichname and namespace_id = @namespace_id)
			or (tag_name = @whichname and gobject_id = @galaxy_gobject_id)
			)
	
	if  @isNameUnique > 0 
	  set @maxno = @maxno + 1 
	else
	  begin
	    -- 6set the outgoing uniquename variable with which name	
 	    set @uniqueName = @whichname
	    break
	  end
  end
end
go

