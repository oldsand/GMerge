-- Returns TimeofLastDeploy from GalaxyTable
create  procedure dbo.internal_get_time_of_last_deploy
    @time datetime  OUTPUT
as 
set nocount on
begin
    select @time = time_of_last_deploy from galaxy
end
set nocount off



go

