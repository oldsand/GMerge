/*
	Proc will return an instance's errors and warnings
	for the checked-in package.

*/
create procedure dbo.internal_get_objects_errors_and_warnings
@file_name_of_ids nvarchar (265)
as
begin
set nocount on


SET QUOTED_IDENTIFIER OFF

create table  #input_table ( gobject_id int)

declare @SQL nvarchar(2000)

set @SQL = 'BULK INSERT #input_table  FROM ''' + @file_name_of_ids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

exec (@SQL)

	declare @final_output table
	(
		gobject_id int primary key,
		warnings text,
		errors text	
	)
	
	insert into @final_output
		(gobject_id)
	select 
		gobject_id
	from #input_table
	
	-- handle instances:
	-- set warnings info
	update fo
	set  warnings = mx_value
	from @final_output fo
	inner join gobject g on
		g.gobject_id = fo.gobject_id
	inner join instance_attribute ia on	
		ia.gobject_id = g.gobject_id and
		ia.package_id = g.checked_in_package_id and
		g.is_template = 0 and
		ia.mx_attribute_id = 126	and 
		ia.mx_primitive_id = 2

	-- set errors info
	update fo
	set  errors = mx_value
	from @final_output fo
	inner join gobject g on
		g.gobject_id = fo.gobject_id
	inner join instance_attribute ia on	
		ia.gobject_id = g.gobject_id and
		ia.package_id = g.checked_in_package_id and
		g.is_template = 0 and
		ia.mx_attribute_id = 107	and 
		ia.mx_primitive_id = 2


	-- handle templates:
	-- set warnings info
	update fo
	set  warnings = mx_value
	from @final_output fo
	inner join gobject g on
		g.gobject_id = fo.gobject_id
	inner join template_attribute ia on	
		ia.gobject_id = g.gobject_id and
		ia.package_id = g.checked_in_package_id and
		g.is_template = 1 and
		ia.mx_attribute_id = 126	and 
		ia.mx_primitive_id = 2

	-- set errors info
	update fo
	set  errors = mx_value
	from @final_output fo
	inner join gobject g on
		g.gobject_id = fo.gobject_id
	inner join template_attribute ia on	
		ia.gobject_id = g.gobject_id and
		ia.package_id = g.checked_in_package_id and
		g.is_template = 1 and
		ia.mx_attribute_id = 107	and 
		ia.mx_primitive_id = 2


	select 
		gobject_id,
		warnings,
		errors
	from @final_output




end
go

