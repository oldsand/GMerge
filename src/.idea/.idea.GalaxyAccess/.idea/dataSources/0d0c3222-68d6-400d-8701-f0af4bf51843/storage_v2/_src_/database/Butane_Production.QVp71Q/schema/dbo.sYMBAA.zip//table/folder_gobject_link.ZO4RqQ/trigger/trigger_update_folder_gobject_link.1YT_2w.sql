create     trigger trigger_update_folder_gobject_link
on folder_gobject_link
for update
as
begin tran

    begin
        update f 
        set f.has_objects = 1
        from folder f
        inner join inserted i on
        f.folder_id = i.folder_id and 
        f.folder_type = i.folder_type

		--update timestamp for updated gobject
		update g 
        set g.is_template = g.is_template
        from gobject g
        inner join inserted i on
        g.gobject_id = i.gobject_id

        update folder 
        set has_objects = 0
        from folder f
        inner join deleted d on
            f.folder_id = d.folder_id and
            f.folder_id not in  
        (select fg.folder_id from folder_gobject_link fg 
         inner join deleted d on 
            fg.folder_type = d.folder_type and fg.folder_id = d.folder_id  )

    end
       
commit
go

