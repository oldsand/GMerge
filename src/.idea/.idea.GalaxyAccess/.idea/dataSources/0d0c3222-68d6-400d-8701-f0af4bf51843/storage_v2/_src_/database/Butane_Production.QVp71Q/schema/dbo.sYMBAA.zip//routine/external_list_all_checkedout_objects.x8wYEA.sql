-- This is not a supported function. Data returned from this function may be incorrect.
--drop proc external_list_all_checkedout_objects
--go
--exec external_list_all_checkedout_objects
create proc dbo.external_list_all_checkedout_objects
as
begin
	select  g.tag_name as 'Object Name',
		gderived.tag_name as 'Immediate Parent Name', 
		td.original_template_tagname as 'Base Object Name'
	from   gobject g 
	inner join template_definition td 
		on     g.template_definition_id = td.template_definition_id
		and    g.checked_out_package_id > 0
	inner join gobject gderived
		on gderived.gobject_id = g.derived_from_gobject_id
end

go

