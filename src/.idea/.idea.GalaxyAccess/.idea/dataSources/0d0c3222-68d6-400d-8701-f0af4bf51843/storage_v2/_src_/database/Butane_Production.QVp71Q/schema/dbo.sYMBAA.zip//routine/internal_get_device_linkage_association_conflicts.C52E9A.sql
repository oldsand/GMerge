create proc dbo.internal_get_device_linkage_association_conflicts(
    @childIdList nvarchar(255),
    @parentId int,
    @sg_mx_primitive_id smallint,
    @assocType smallint,
    @pre_device_linkage_conflict_count int out,  -- Applicable if area objects are selected
    @post_device_linkage_conflict_count int out) -- Applicable if objects are selected without the areas that host them.
AS 
BEGIN
  -- TO DO: Account for redundant objects (they need to point to the same DIO as their primary counterparts)
  -- Arguments that require some explanation:
  -- @force_area_device_linkage: If true, all objects hosted by an area are forced to be linked to the 
  --    same device to which the area is being [re]assigned, regardless of whether or not such congruence exists
  --    in the first place.
  -- @ignore_area_device_linkage: If true, individual objects (whose hosting areas haven't been selected for device assignment)
  --    may be assigned to devices other than those to which their hosting areas are assigned.
	if @parentId = 0 return	-- UNASSIGNMENT, should call internal_unset_association

	if @assocType <> 4 return --This only applicable for the IO assignement

  begin tran
  set nocount on

  declare @to_device bigint = @parentId * 1000000 + @sg_mx_primitive_id

  -- ASSIGNMENT
      
  declare @parentCategory nvarchar(329) 
  declare @is_template bit    

  select @parentCategory = category_name, @is_template = is_template
  from gobject inner join template_definition
  on gobject.template_definition_id = template_definition.template_definition_id
  inner join lookup_category lc on lc.category_id = template_definition.category_id
  where gobject_id = @parentId

  if(@parentCategory NOT IN (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO') OR @is_template = 1) -- if host is not a valid DIO then return
  begin
      return 0
  end

  create table  #childList (gid int primary key)
  DECLARE @gSQL nvarchar(2000)
  SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
              WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
  EXEC sp_executesql @gSQL

  -- exec internal_filter_deployed_objects_from_input_list
  -- Filter out objects that are ineligible for assignment:
  -- DIO objects
  delete #childList
    from #childList cl
  inner join gobject g
      on cl.gid = g.gobject_id
  inner join template_definition
      on template_definition.template_definition_id = g.template_definition_id
  inner join lookup_category lc
      on lc.category_id = template_definition.category_id
     and lc.category_name IN (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
  --truncate table CurrentSessionContainedName 

  declare @Stage table (
      obj_id  int primary key
    , area_id int
    , cat_id  int
    , device  bigint
  )

  -- Stage all objects: Determine their current device linkages.
  insert into @Stage
  select c.gid, g.area_gobject_id, t.category_id, ISNULL (d.dio_id, 0) * 1000000 + ISNULL (d.sg_mx_primitive_id, 0)
    from #childList c
  inner join gobject g
      on g.gobject_id = c.gid
   and g.is_template = 0
  inner join template_definition t 
      on t.template_definition_id = g.template_definition_id
  left outer join object_device_linkage d
      on d.gobject_id = g.gobject_id

  -- Delete objects in #childList that are hosted by areas that are also included in #childList:
  -- They will be processed with the parent area anyway.
  delete ds
    from @Stage ds
  inner join @Stage ia 
      on ia.obj_id = ds.area_id


  -- Look for the first variety of conflict: Area objects to be reassigned that host
  -- objects that are linked to different devices than that to which they themselves are.
  select @pre_device_linkage_conflict_count = count(*)
    from gobject g
  inner join template_definition t
     on t.template_definition_id = g.template_definition_id
  inner join @Stage area_id
      on area_id.obj_id = g.area_gobject_id
     and area_id.cat_id = 13 
  left outer join object_device_linkage d
      on d.gobject_id = g.gobject_id
   where ISNULL (d.dio_id, 0) * 1000000 + ISNULL (d.sg_mx_primitive_id, 0) <> @to_device
     and ISNULL (d.dio_id, 0) * 1000000 + ISNULL (d.sg_mx_primitive_id, 0) = area_id.device


  -- Now, look for the second form of conflict: Unaccompanied objects (objects without area)
  -- that are currently linked to their area's device, that are being reassigned.
  select @post_device_linkage_conflict_count = count(*) 
    from @Stage st
  inner join gobject area                             -- Outer join because @ObjInfo currently only contains areas that are not to be processed
      on area.gobject_id = st.area_id
  left outer join object_device_linkage area_device
      on area_device.gobject_id = area.gobject_id
   where st.device <> @to_device
     and st.cat_id <> 13
     and st.device = ISNULL (area_device.gobject_id, 0) * 1000000 + ISNULL (area_device.sg_mx_primitive_id, 0)
     and ISNULL (area_device.gobject_id, 0) * 1000000 + ISNULL (area_device.sg_mx_primitive_id, 0) <> @to_device


  return 1
end
go

