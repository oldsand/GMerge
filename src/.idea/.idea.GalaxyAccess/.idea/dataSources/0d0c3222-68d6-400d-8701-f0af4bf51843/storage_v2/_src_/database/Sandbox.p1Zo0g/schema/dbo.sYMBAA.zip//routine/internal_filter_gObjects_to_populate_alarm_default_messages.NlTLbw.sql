CREATE PROCEDURE dbo.internal_filter_gObjects_to_populate_alarm_default_messages
(	
	@filepath_of_gobject_ids nvarchar(265) 
	-- A file with one gObject Id per line
)
AS
BEGIN
	-- Returns a dataset of gObject Ids filtered from the ones passed in 
	-- that actually have alarms, and whose alarm_message records are potentially 
	-- out of date and need to be reextracted from the fsObject.
	-- 
	-- An alarm is potentially out of date if the object it belongs to has changed since
	-- the last time the the method populate_alarm_message_defaults was called for that object

	set nocount on
	
	CREATE TABLE  #candidateIds (gobject_id int primary key)
	DECLARE @SQL nvarchar(2000)	
	SET @SQL = 'BULK INSERT #candidateIds  FROM ''' + @filepath_of_gobject_ids + ''' WITH (
			    FIELDTERMINATOR = '','',
				TABLOCK,
				DATAFILETYPE  = ''widechar''       
				)'
	EXEC sp_executesql @SQL

	select distinct cids.gobject_id from #candidateIds cids
    inner join proxy_timestamp pt on pt.gobject_id = cids.gobject_id 
	inner join internal_all_alarms_view aav on aav.gobject_id = cids.gobject_id
    left join alarm_message_timestamps amts on amts.gobject_id = pt.gobject_id 
		where amts.timestamp_of_populate is null or 
			  amts.timestamp_of_populate < pt.timestamp_of_last_change
	
	drop table #candidateIds

	
END
go

