-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*Object Name :  internal_update_control_class_link						      */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To update the link table entries for a client control*/
/*Used By	  :  WWFSObject												  */
/**********************************************************************/

create PROCEDURE dbo.internal_update_control_class_link
(
    @gobject_id int,
	@primary_file_name nvarchar(256),
    @vendor_name nvarchar(256),
    @class_name nvarchar(1024)
)
as
begin
set nocount  on
--First drop the row if any
delete
		client_control_class_link
where
		gobject_id = @gobject_id

--Insert the entry with the latest information
declare @file_id as int
select 
		@file_id = file_id 
from 
		file_table 
where 
		vendor_name = @vendor_name and
		file_name = @primary_file_name

insert
		client_control_class_link
values
		(@gobject_id, @file_id,@class_name)


end
go

