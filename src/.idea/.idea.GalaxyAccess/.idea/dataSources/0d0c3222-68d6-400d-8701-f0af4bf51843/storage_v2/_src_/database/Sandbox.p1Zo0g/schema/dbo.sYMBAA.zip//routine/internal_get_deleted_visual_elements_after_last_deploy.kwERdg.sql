create procedure dbo.internal_get_deleted_visual_elements_after_last_deploy
@intouchviewapp_name nvarchar(329)
as
begin tran

declare @gobject_id int
declare @derived_gobject_id int

select @gobject_id = gobject_id,
@derived_gobject_id = derived_from_gobject_id
from gobject
where 
    tag_name = @intouchviewapp_name and
    namespace_id = 1 -- automation object
    

if exists(select gobject_id from intouchviewapptemplate_allsymbols where gobject_id = @derived_gobject_id)
begin
--return all deleted since deployed time
	declare @deployed_time bigint
	set @deployed_time = 0
	select @deployed_time = timestamp_of_deploy from deployed_intouch_viewapp where gobject_id = @gobject_id
	if(@deployed_time = 0)
	begin
		select distinct gobject_id, visual_element_name from deleted_visual_element_version 
		where 1=0 -- force an empty result set
	end	
	else
	begin
		--Deleted symbols and Clientcontrols
		select distinct gobject_id, visual_element_name from deleted_visual_element_version 
		where timestamp_of_delete > @deployed_time
		union 
		--Unreferenced ClientControls from Symbol
		select distinct vedv.gobject_id, isnull(vedv.visual_element_name, '') as visual_element_name
		from internal_visual_element_description_view vedv
		left join visual_element_reference veref
		on vedv.gobject_id = veref.checked_in_bound_visual_element_gobject_id
		and vedv.checked_in_package_id = veref.checked_in_bound_visual_element_package_id
		and vedv.mx_primitive_id = veref.checked_in_bound_visual_element_mx_primitive_id  				
		where vedv.checked_in_package_id = vedv.package_id
		and vedv.visual_element_type = 'ClientControl' 		
		and veref.gobject_id is null
		
		--Following logic is another way to get Unreferenced ClientControls from Symbol
		--select distinct gobject_id, isnull(visual_element_name, '') as visual_element_name
		--from internal_visual_element_description_view where checked_in_package_id = package_id
		--and visual_element_type = 'ClientControl' 
		--and checked_in_package_id 
		--not in (select checked_in_bound_visual_element_package_id from visual_element_reference)
	end
commit
return	
end

	create table #temp
	(
		visual_element_id int,
		visual_element_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS  ,
		visual_element_reference_index int
	)
	
	--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
	--ITVAPP START START
	insert into #temp
	exec internal_get_visual_elements_for_view_app_deploy @intouchviewapp_name, 0
	--ITVAPP START END
	
create table #currentDependency
(
	visual_element_name nvarchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS 
)

insert into #currentDependency
select 
	v.visual_element_name
from #temp t
inner join internal_visual_element_description_view v (noexpand)
	on t.visual_element_id = v.visual_element_id

select distinct gobject_id,
	visual_element_name
from deployed_intouch_viewapp_visual_element_dependency dvd
where dvd.gobject_id = @gobject_id and
	dvd.visual_element_name not in
	(
		select visual_element_name
		from #currentDependency
	)

drop table #temp
drop table #currentDependency

commit

go

