/*
This procedure calculates which runtime files are 
required for deployment of the objects.

usage:
exec internal_get_runtime_files_for_packages_to_deploy.sql '
    <r>
        <package id=''8''/>
        <package id=''1186''/>
    </r>
', 1, 'Nodename'
*/
create proc dbo.internal_get_runtime_files_for_packages_to_deploy
    @FileNameOfIds nvarchar(400),
    @mx_platform_id int,
    @nodename nvarchar(256)
as
set nocount on
begin
begin tran
	create table #deploy_file_ids( file_id int )
	create table #package_ids( package_id int )

	-- populate #package_ids
	insert into #package_ids
		exec internal_select_ids @FileNameOfIds

	-- special case for Failover
	-- Platform deployment should ignore if any of the runtime files is already deployed
	declare @isPlatformSelected int
	set	@isPlatformSelected = 0	
	select @isPlatformSelected = gobject_id from platform pt inner join
	package p on pt.platform_gobject_id = p.gobject_id inner join #package_ids pid
	on p.package_id = pid.package_id

	-- Mark as undeploy for all the runtime files for the selected platform
	if(@isPlatformSelected > 0)
	BEGIN
		update	deployed_file 
		set is_runtime_deployed = 0
		where node_name = @nodename
		create table #file_ids( file_id int )

		exec internal_get_runtime_files_for_packages

		insert into #deploy_file_ids 
			select file_id from #file_ids	
	END
	else
	BEGIN	
		-- populate #deploy_file_ids
		-- in:  @PackageIdsAsXml, @mx_platform_id
		-- out: #deploy_file_ids
		exec internal_get_runtime_files_for_packages_needed_on_platform @mx_platform_id, @nodename
	END

	drop table #package_ids

	-- Get list of files in #deploy_file_ids that's already deployed
	declare @already_deployed_file_ids table( file_id int, is_runtime_deployed bit )
	insert into @already_deployed_file_ids
		select distinct deployed_file.file_id, is_runtime_deployed
		from deployed_file
		inner join #deploy_file_ids ufi
		on ufi.file_id = deployed_file.file_id and
		   deployed_file.node_name = @nodename and (deployed_file.is_runtime_deployed = 1 )

	-- Remove files already deployed from #deploy_file_ids
	delete from #deploy_file_ids
		where file_id in ( select file_id from @already_deployed_file_ids )

	---select  * from #deploy_file_ids
	declare @insert_new_deployed_file_ids table( file_id int)

	insert into @insert_new_deployed_file_ids (file_id)((select file_id from #deploy_file_ids where file_id 
	not in (select file_id from deployed_file where node_name = @nodename )))

	-- insert record into deployed_file table for each file not already deployed
	-- (in #deploy_file_ids).
	insert into deployed_file
	(
		file_id,
		node_name,
		need_to_delete,
		is_package_deployed,
		is_editor_deployed,
		is_runtime_deployed,
        is_browser_deployed
	)
	select
		file_id,
		UPPER(@nodename),
		0,
		0,
		0,
		0,
        0
	from @insert_new_deployed_file_ids 

	-- output
	select ft.file_id,file_name, vendor_name, registration_type , subfolder from file_table ft
		inner join #deploy_file_ids dfi
		on ft.file_id = dfi.file_id

	delete from file_pending_update where node_name = @nodename and 
					file_id in ( select file_id from #deploy_file_ids)

	--delete from #deploy_file_ids
	drop table #deploy_file_ids

commit tran
end
set nocount off
go

