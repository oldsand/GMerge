create proc dbo.internal_cascade_checkin
@parent_template_gobject_id int,
@user_guid nvarchar(64)
as
set nocount on
	
	-- get the user_profile_name for use with the change log...
	declare @user_profile_name nvarchar(256)
    select @user_profile_name  = user_profile_name 
	from user_profile 
	where user_guid = @user_guid

	if @user_profile_name is NULL
		set @user_profile_name = N'DefaultUser'

	declare @parent_template_checked_in_package_id int

	select @parent_template_checked_in_package_id = checked_in_package_id 
	from gobject
	where gobject_id = @parent_template_gobject_id


    -- create a table based on input parameter
    
    declare @previous table 
	(
        gobject_id  int,
		parent_checked_out_package_id int,
        primary key (gobject_id)
    )

    declare @next table 
	(
        gobject_id  int,
		parent_checked_out_package_id int,
        primary key (gobject_id)
    )
	
	declare @affected_objects table
	(
		gobject_id int,
		message_text nvarchar(4000)
	)
	
	declare @derivation_level int
	

	-- table to be used in internal_multi_gobjects_checkout
	create table #results_table ( gobject_id int)


	/*
		Steps:
		1) Find all objects directly derived from the passed-in object	
		2) Check these objects out
		3) Overwrite the inherited dynamic attributes with the ones in the parent's
		   checked-out package
		4) Go to the next level and do the same thing...(until the last level is complete)		
		5) Return a list of affected objects

	*/

	--1) Find all objects directly derived from the passed-in object	
    insert  @next
		(gobject_id,
		 parent_checked_out_package_id)
    select  
		gobject_children.gobject_id,
		gobject_parent.checked_out_package_id
	from gobject gobject_children
	inner join gobject gobject_parent on
		gobject_parent.gobject_id = @parent_template_gobject_id and
		gobject_parent.checked_out_package_id > 0
	where gobject_children.derived_from_gobject_id = @parent_template_gobject_id

	set @derivation_level = 1

    while exists (select '1' from @next )
    begin

		--2) Check these objects out

		truncate table #results_table

		insert into #results_table
			(gobject_id)
		select 
			gobject_id
		from @next
		
		insert into @affected_objects
		exec internal_multi_gobjects_checkout @user_guid, N'', 1

		insert into gobject_change_log
		( 
			gobject_id, 
			change_date, 
			operation_id, 
			user_comment, 
			configuration_version,
			user_profile_name 
		)
		select
			r.gobject_id,
			GetDATE(),
			2,
			N'System checked out object for cascade check-in of parent',
			g.configuration_version,
			@user_profile_name
		from #results_table r 
		inner join gobject g on
			r.gobject_id = g.gobject_id

			
		--3) Overwrite the inherited dynamic attributes with the ones in the parent's
		--   checked-out package
		exec internal_set_uda_info_from_parents_checked_out_package 
			@derivation_level, 
			@parent_template_checked_in_package_id

		insert into gobject_change_log
		( 
			gobject_id, 
			change_date, 
			operation_id, 
			user_comment, 
			configuration_version,
			user_profile_name 
		)
		select
			r.gobject_id,
			GetDATE(),
			37,
			N'System updated configuration for cascade check-in of parent',
			g.configuration_version,
			@user_profile_name
		from #results_table r
		inner join gobject g on
			r.gobject_id = g.gobject_id


		
		
		-- update the children's derived_from_package_id to point to their
		-- parent's checked_out_package_id

		-- bump up the deployable_configuration_version of the children.  
		-- This will trigger a pending update if they are deployed...
		update p
		set 
			p.deployable_configuration_version = p.deployable_configuration_version + 1,
			p.derived_from_package_id = n.parent_checked_out_package_id
		from @next n
		inner join gobject g on
			n.gobject_id = g.gobject_id
		inner join package p on
			p.gobject_id = g.gobject_id and
			p.package_id = g.checked_out_package_id
			

		--4) Go to the next level and do the same thing...(until the last level is complete)
		insert into @previous 
			(gobject_id,
			parent_checked_out_package_id)
		select
			gobject_id,
			parent_checked_out_package_id
		from @next

		delete
		from @next

		insert into @next
			(gobject_id,
			 parent_checked_out_package_id)
		select 
			g.gobject_id,
			gobject_parent.checked_out_package_id
		from @previous p -- parent table...
		inner join gobject g on
			g.derived_from_gobject_id = p.gobject_id
		inner join gobject gobject_parent on 
			gobject_parent.gobject_id =  g.derived_from_gobject_id

		delete
		from @previous
		
		set @derivation_level = @derivation_level + 1
		

	end
		

	/*

	--5) Check in all of the objects that we checked out...
	delete 
	from #results_table

	insert into #results_table
		(gobject_id)
	select gobject_id
	from @affected_objects

	exec internal_multi_object_checkin N'',1
	*/

	--6) Return a list of affected objects
	-- return all affected_objects...

	select 
		gobject_id,
		message_text
	from @affected_objects

	drop table #results_table


go

