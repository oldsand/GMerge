CREATE VIEW [dbo].[internal_all_alarms_view]
AS
select g.tag_name + '.' + p.primitive_name 'name', p.gobject_id, p.package_id, p.mx_primitive_id from gobject g
inner join primitive_instance p on p.gobject_id = g.gobject_id and p.execution_group = 19
inner join primitive_definition pd on p.primitive_definition_id = pd.primitive_definition_id and pd.primitive_name <> ''
inner join package pkg on p.gobject_id = pkg.gobject_id and p.package_id = pkg.package_id and pkg.package_id = g.checked_in_package_id 
where g.is_template = 0 and g.namespace_id = 1
go

