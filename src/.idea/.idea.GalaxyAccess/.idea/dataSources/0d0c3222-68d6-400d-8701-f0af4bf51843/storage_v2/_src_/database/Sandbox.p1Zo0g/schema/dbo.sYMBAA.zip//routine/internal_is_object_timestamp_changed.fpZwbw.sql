/**************************************************/
/*Object Name :  internal_is_object_timestamp_changed				*/
/*Object Type :  Stored Proc.						*/
/*Purpose	  :  stored procedure to check is object is modified in galaxy */
/*Used By	  :  CDI								*/
/*Return Values: */
/**************************************************/
create  procedure dbo.internal_is_object_timestamp_changed
@varwhere int,
@lastRefreshed bigint,
@result bit out
 AS
begin
set nocount on

set @result = 0
declare @timestamp bigint

select @timestamp = (CAST (pt.timestamp_of_last_change as bigint))
from proxy_timestamp pt where pt.gobject_id = @varwhere 

if @timestamp <> @lastRefreshed
begin
	set @result = 1
end    


end
go

