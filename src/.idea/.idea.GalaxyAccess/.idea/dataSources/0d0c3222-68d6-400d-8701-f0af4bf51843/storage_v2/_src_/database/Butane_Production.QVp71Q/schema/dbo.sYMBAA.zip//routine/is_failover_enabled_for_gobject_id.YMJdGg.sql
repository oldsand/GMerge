
--***********************************************************************************************************************
--***	
--***	OBJECT NAME:	is_failover_enabled_for_gobject_id
--***	DESCRIPTION:	Function is used to find out if a gobject is failover enabled or not
--***	
--***	USAGE: 		dbo.is_failover_enabled('AppEngine001') --(where 'AppEngine001' is the tag name)
--***			Function is used by view: internal_proxyobj
--***	RETURNS :
--***	=========
--***	1 - If object is failover enabled
--***	0 - If object is not failover enabled
--***	
--***********************************************************************************************************************

Create FUNCTION dbo.is_failover_enabled_for_gobject_id( 
	@gobject_id int
	)
returns int

as
begin
	declare @is_failover_enabled int	

	select @is_failover_enabled = count(*) 
	from
	redundancy r 
	where
	@gobject_id = primary_gobject_id or @gobject_id = backup_gobject_id
 
	return @is_failover_enabled
		
end
go

