-- This procedure is for checking whether it is allowed to move objects to an folder
-- Result is returned in a recordset and here is the reason_code
-- 0:Success  
-- 1:Invalid object  
-- 2:Invalid folder  
-- 3:Graphics object can not be moved to automation object folder.
-- 4:Automation object can not be moved to graphics object folder.
-- 5:Object can not be moved to its current folder


create proc dbo.internal_can_move_objects_to_folder
	@FileNameOfIds nvarchar(265),
	@target_folder_Id int
AS
begin
	set nocount on

	declare @ErrorCode int

    CREATE TABLE  #input_object_ids (gobject_id int)
    DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #input_object_ids  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'',ROWTERMINATOR = '','')'
    EXEC sp_executesql @SQL
    
    declare @results table(
        gobject_id int primary key, 
        can_be_moved bit, 	-- 1:Yes  0:No
        reason_code int)    

	-- Assume all objects are invalid first
    insert  into  @results(gobject_id, can_be_moved, reason_code)
        select  gobject_id, 0, 1	
        from    #input_object_ids

	-- Set those valid objects to true. 
	update	r
	set		r.can_be_moved = 1,
			r.reason_code = 0
	from	@results r 
	inner join gobject g on r.gobject_id = g.gobject_id
		
	-- make sure the target folder is valid
	if ((not exists(
		select 	folder_id 
		from 	folder 
		where 	folder_id = @target_folder_Id
	)) and (@target_folder_Id <> 0))
	begin
		update	@results
		set		can_be_moved = 0,
				reason_code = 2
	end
	else
	begin
		declare @folder_type int
		if (@target_folder_Id > 0)
		begin
		    select 	@folder_type = folder_type 
			from 	folder 
			where 	folder_id = @target_folder_Id
		end
		else
		begin
		    set @folder_type = 2
		end

		if (@folder_type = 1)
		begin
			-- The target folder is for automation object. 
			-- Graphics object can not be assigned to it.
			update	r
			set		r.can_be_moved = 0,
					r.reason_code = 3
			from	@results r
			inner join gobject g on r.gobject_id = g.gobject_id
			where	g.namespace_id = 3
		end
		
		if (@folder_type = 2)
		begin
			-- The target folder is for graphic object. 
			-- Automation object can not be assigned to it.
			update	r
			set		r.can_be_moved = 0,
					r.reason_code = 3
			from	@results r
			inner join gobject g on r.gobject_id = g.gobject_id
			where	g.namespace_id = 1 or g.namespace_id = 2
		end

		-- Object can not be assigned to its current folder
		update	r
		set		r.can_be_moved = 0,
				r.reason_code = 4
		from	@results r
		inner join folder_gobject_link fg on r.gobject_id = fg.gobject_id
		inner join gobject g on r.gobject_id = g.gobject_id
		where	fg.folder_id = @target_folder_Id
		and g.contained_by_gobject_id = 0

	end

	select	gobject_id, can_be_moved, reason_code
	from	@results

	drop table #input_object_ids
end

go

