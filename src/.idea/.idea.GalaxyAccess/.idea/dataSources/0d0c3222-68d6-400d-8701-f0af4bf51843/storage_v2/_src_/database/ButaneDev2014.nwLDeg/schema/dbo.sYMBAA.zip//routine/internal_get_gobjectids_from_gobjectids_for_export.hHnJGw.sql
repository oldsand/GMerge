CREATE PROCEDURE dbo.internal_get_gobjectids_from_gobjectids_for_export
            @FileNameOfIds nvarchar (265)
AS
BEGIN

set nocount on

            SET QUOTED_IDENTIFIER OFF
            CREATE TABLE  #input_table ( gobject_id int)
            DECLARE @SQL nvarchar(2000)

            SET @SQL = 'BULK INSERT #input_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
            EXEC (@SQL)
           
			insert into #input_table
				select dbo.get_failover_partner_id(t.gobject_id)
				from #input_table t
			
						

			select distinct g.gobject_id,  g.namespace_id
				from #input_table 
					inner join gobject g on g.gobject_id = #input_table.gobject_id
				where #input_table.gobject_id > 0
				order by g.namespace_id asc, g.gobject_id asc

			drop table #input_table
END
go

