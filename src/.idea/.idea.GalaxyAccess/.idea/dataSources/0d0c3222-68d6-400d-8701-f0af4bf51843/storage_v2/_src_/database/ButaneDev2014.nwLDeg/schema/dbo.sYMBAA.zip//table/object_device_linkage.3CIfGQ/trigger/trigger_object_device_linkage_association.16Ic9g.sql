/*
** It's probably best not to rely on triggers to do this: Bulk-assignment at an elemental level needs to be supported.
**
*/
CREATE  TRIGGER trigger_object_device_linkage_association
ON  [object_device_linkage]
FOR INSERT, UPDATE
AS  
BEGIN
  DECLARE @gobject_id             int = 0
  DECLARE @dio_id                 int
  DECLARE @sg_mx_primitive_id     smallint
  DECLARE @old_dio_id             int
  DECLARE @old_sg_mx_primitive_id smallint


  WHILE (1 = 1)
  BEGIN
  
    SELECT   TOP 1 
             @gobject_id              = i.gobject_id
           , @dio_id                  = i.dio_id
           , @sg_mx_primitive_id      = i.sg_mx_primitive_id
           , @old_dio_id              = ISNULL (d.dio_id, 0)
           , @old_sg_mx_primitive_id  = ISNULL (d.sg_mx_primitive_id, 0)
        FROM inserted i
    LEFT OUTER JOIN deleted d
          ON d.gobject_id = i.gobject_id
       WHERE i.gobject_id > @gobject_id
    ORDER BY i.gobject_id ASC

    IF @@ROWCOUNT = 0
      BREAK
      
    EXECUTE internal_ab_set_device_linkage @gobject_id, @dio_id, @sg_mx_primitive_id, @old_sg_mx_primitive_id, @old_dio_id

  END

END
go

