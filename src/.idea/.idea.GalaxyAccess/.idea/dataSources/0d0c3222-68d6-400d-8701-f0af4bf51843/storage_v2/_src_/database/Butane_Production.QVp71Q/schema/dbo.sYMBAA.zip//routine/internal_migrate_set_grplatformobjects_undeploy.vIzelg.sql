create proc dbo.internal_migrate_set_grplatformobjects_undeploy
As
begin 
begin tran
update gobject
set     gobject.deployed_package_id  = 0,
	gobject.last_deployed_package_id = 0,
	gobject.deployment_pending_status = 0
from    gobject inner join
        instance on gobject.gobject_id = instance.gobject_id
	where gobject.deployed_package_id <> 0 

--clean up the platform related files in deploy_file table


declare @strgrnode as char(15)
select @strgrnode = platform.node_name from platform 
inner join instance on 
platform.platform_gobject_id = instance.gobject_id 
where instance.mx_platform_id = 1

delete from deployed_file where node_name = @strgrnode
commit tran
end
go

