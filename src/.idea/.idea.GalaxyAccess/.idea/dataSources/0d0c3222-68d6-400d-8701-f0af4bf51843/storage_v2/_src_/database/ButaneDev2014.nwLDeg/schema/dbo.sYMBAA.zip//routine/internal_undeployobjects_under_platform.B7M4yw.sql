--This stored procedure does the following functions
--1. Marks the Undeploy status for the hosted objects under all the Engines for the given platform
--   (The Engine is neither Primary nor Redundant)
--2. Marks the Undeploy status for the hosted objects under the Redundant engine
--   for the partial deployed redundant engine case
--3. Marks the Undeploy status for the Primary Engine and does not change the object status 
--   for the hosted objects for the fully deployed primary engine case

create proc dbo.internal_undeployobjects_under_platform
(
    @Platform_Tag_name nvarchar(64)
)
as
BEGIN
begin tran

declare @changed_gobject_id table (
    gobject_id int
)

--get the platform gobject_id
declare @Platform_gobject_id as int
select @Platform_gobject_id = gobject_id 
from gobject 
where tag_name = @Platform_Tag_name

--get the node_name and mx_platform_id
--------------------------------------------------
declare @nodeName nvarchar(64)
declare @mx_platform_id as int

select @nodeName = p.node_name,@mx_platform_id = i.mx_platform_id 
from dbo.platform as p
    inner join instance i on p.platform_gobject_id = i.gobject_id
where (p.platform_gobject_id = @Platform_gobject_id )
--------------------------------------------------

---GetAlltheRedundantEngines

create table #redundant_engines( re_id  int )
-- insert all the backup engines
insert into #redundant_engines
select i.gobject_id from instance i 
where ( i.mx_platform_id = @mx_platform_id
and i.mx_engine_id <> 1 and i.mx_object_id = 1 )
and
 (dbo.is_failover_enabled(i.gobject_id) = 1 )

insert into #redundant_engines
select dbo.get_failover_partner_id(re_id) from #redundant_engines

-----------------------------------------------
--Get partial deployed backup engines hosted by platform
create table #temp_appengines( counter int identity(1,1),temp_gobject_id  int )
insert into #temp_appengines
select gobject_id from gobject g
    inner join template_definition td
    on g.template_definition_id = td.template_definition_id
    where td.category_id = 3
    and g.hosted_by_gobject_id = @Platform_gobject_id
    and g.namespace_id = 2
    and dbo.is_partner_deployed(gobject_id) = 0
    and deployed_package_id <> 0

declare @enginecount int
select @enginecount = count(*) from #temp_appengines

IF ( @enginecount > 0 )
BEGIN
    declare @RowNum int
    declare @gobject_id as int

    set @RowNum = 1 

    WHILE ( @RowNum <= @enginecount )
    BEGIN
        set @gobject_id = 0

        SELECT @gobject_id = temp_gobject_id FROM #temp_appengines tapp
        WHERE  tapp.counter = @RowNum
                
        declare @partner_engine_gobject_id as int
        set @partner_engine_gobject_id = dbo.get_failover_partner_id( @gobject_id )

        declare @hosted_children table (gobject_id int primary key )

        insert into @hosted_children(gobject_id)
        select objectId 
        from dbo.get_hosted_objects( @partner_engine_gobject_id )   
        
        insert @changed_gobject_id(gobject_id)
        (
            select  g.gobject_id        
            from    gobject as g 
            inner join 
                    @hosted_children as HC 
                on  g.gobject_id = HC.gobject_id
        )

        update gobject 
        set deployed_package_id = 0 , last_deployed_package_id = 0 ,software_upgrade_needed = 0, deployment_pending_status = 0
        from gobject as g inner join @hosted_children as HC on g.gobject_id = HC.gobject_id

        
        delete  attributes_translation_table
        from attributes_translation_table  as att inner join
        @hosted_children as HC on att.gobject_id = HC.gobject_id

        update pt
        set pt.gobject_id = pt.gobject_id
        from @hosted_children hc
        inner join proxy_timestamp pt on
            hc.gobject_id = pt.gobject_id

        
        set @RowNum = @RowNum + 1
                
    END 
END
    
-------------------------------------------------------------------
--****************************************************************
-- Start Fix for US 275309 
-------------------------------------------------------------------
--Get list of Primary REs hosted by platform whose Backup Engines are deployed
create table #temp_REs( counter int identity(1,1),temp_gobject_id  int )
insert into #temp_REs
select g.gobject_id
from    instance i 
inner join gobject g
on      g.gobject_id = i.gobject_id 
inner join template_definition td
    on g.template_definition_id = td.template_definition_id
    where td.category_id = 3
and i.mx_platform_id = @mx_platform_id
and g.namespace_id = 1
and dbo.is_partner_deployed(g.gobject_id) = 1

-- Create table for Hosted Children of the Primary REs available in #temp_REs table
create table #temp_REs_HC( counter int identity(1,1),temp_gobject_id  int )

declare @RECount int
select @RECount = count(*) from #temp_REs

IF ( @RECount > 0 )
BEGIN
    
    set @RowNum = 1 

	declare @hosted_children_RE table (gobject_id int primary key )

    WHILE ( @RowNum <= @RECount )
    BEGIN
        set @gobject_id = 0
		
        SELECT @gobject_id = temp_gobject_id FROM #temp_REs tapp
        WHERE  tapp.counter = @RowNum
		
        insert into @hosted_children_RE(gobject_id)
        select objectId 
        from dbo.get_hosted_objects( @gobject_id ) 
        
        set @RowNum = @RowNum + 1
                
    END 
    
   -- Insert the hosted deployed children for Primary REs which are in latest version
   Insert into #temp_REs_HC	
	Select g.gobject_id from gobject g where  g.gobject_id IN (
		Select gobject_id from @hosted_children_RE ) and g.software_upgrade_needed = 0	

END
-- End Fix for US 275309 
-------------------------------------------------------------------


--mark the all the other the above objects hosted under platform(including platform, engine and hosted objects)
--These objects are hosted under engines which are neither a primary nor redundant  

insert @changed_gobject_id(gobject_id)
(
    select  g.gobject_id
    from    gobject g
    inner join instance i
    on      g.gobject_id = i.gobject_id
    where   i.mx_platform_id = @mx_platform_id
)

update gobject      
set deployed_package_id = 0, last_deployed_package_id = 0 , software_upgrade_needed = 0 
from gobject g
inner join instance i
on g.gobject_id = i.gobject_id
where i.mx_platform_id = @mx_platform_id
--US 275309 Dont mark undeployed status for Hosted Children on Backup Engines with Latest version
and g.gobject_id NOT IN (Select HC.temp_gobject_id from #temp_REs_HC HC ) 

delete  attributes_translation_table
from attributes_translation_table  as att inner join
gobject g on att.gobject_id = g.gobject_id
inner join instance i
on g.gobject_id = i.gobject_id
where i.mx_platform_id = @mx_platform_id

update pt
set pt.gobject_id = pt.gobject_id
from proxy_timestamp pt             
inner join gobject g            
on g.gobject_id = pt.gobject_id
inner join instance i
on g.gobject_id = i.gobject_id      
where i.mx_platform_id = @mx_platform_id
and g.gobject_id NOT IN (Select HC.temp_gobject_id from #temp_REs_HC HC ) --US 275309

update pt
set pt.gobject_id = pt.gobject_id
from proxy_timestamp pt
inner join #redundant_engines re            
on re.re_id = pt.gobject_id

--------------------------------------------------
delete deployed_file where node_name = @nodeName
------------update time stamp------------------

declare @max_proxy_timestamp bigint
select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

update galaxy
set max_proxy_timestamp = @max_proxy_timestamp

drop table #temp_REs_HC
drop table #temp_REs

drop table #redundant_engines
drop table #temp_appengines

select  distinct gobject_id
from    @changed_gobject_id

commit tran
END
go

