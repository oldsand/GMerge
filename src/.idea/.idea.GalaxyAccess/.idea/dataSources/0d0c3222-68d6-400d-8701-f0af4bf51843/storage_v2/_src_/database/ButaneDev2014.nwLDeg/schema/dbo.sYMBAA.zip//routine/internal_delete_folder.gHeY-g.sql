
/***********************************************************************************************************************************
If you change this you need to check w/ Foxboro. This is used by Foxboro objects in their MigratePrimitive methods -- HF1467 CR93406
************************************************************************************************************************************/

--Delete subtree of the folder of sub folders doesnt have any objects..

create proc dbo.internal_delete_folder
(
	@folder_id int
)
AS
begin

declare @ErrorCode int

    begin tran
    
if not exists(select '*' from folder where folder_id = @folder_id)
begin
	set @ErrorCode = 1000    
    rollback
    return @ErrorCode
end

    declare @parentId int
    set @parentId = 0
    select   @parentId = parent_folder_id from folder where folder_id = @folder_id

    declare @childfolders table(folderid int,myparent int,nLevel smallint)
    insert  into  @childfolders(folderid,myparent,nLevel) values(@folder_id,@parentId,1)

    declare @objCount integer
	declare @nLevel integer
    select @objCount = count(*) from @childfolders

    declare @rowInserted int

	IF @objCount > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN	
            set @rowInserted = 0
            insert into @childfolders
			select f.folder_id, f.parent_folder_id, @nLevel + 1
			from folder f inner join @childfolders fs on f.parent_folder_id = fs.folderid
			where nLevel = @nLevel

            set @rowInserted = @@rowcount

            if(exists(select ('*') from folder f inner join @childfolders fc
            on f.folder_id = fc.folderid where
			has_objects = 1))
            begin
                set @ErrorCode = 999
                rollback
                return @ErrorCode
            end

			if @rowInserted = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END       
  
    if(not exists(select ('*') from folder f inner join @childfolders fc
        on f.folder_id = fc.folderid where
			has_objects = 1))
    begin
        delete from folder where folder_id in 
        (select folderid from @childfolders)
	end
    else
    begin
        set @ErrorCode = 999
        rollback
        return @ErrorCode
    end

    set @ErrorCode = @@error
    if @ErrorCode <> 0 begin
        rollback
        return @ErrorCode
    end

    commit
	return @ErrorCode
end
go

