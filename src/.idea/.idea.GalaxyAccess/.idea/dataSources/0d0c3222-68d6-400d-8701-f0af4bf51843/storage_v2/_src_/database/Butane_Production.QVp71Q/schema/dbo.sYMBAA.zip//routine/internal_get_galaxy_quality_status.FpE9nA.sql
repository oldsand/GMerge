
/**************************************************/
/*Object Name :  internal_get_galaxy_quality_status			*/
/*Object Type :  Stored Proc.								*/
/*Purpose :    Procedure to get galaxy quality status		*/
/*Used By :    PackageServerNet								*/
/**************************************************/
create  proc dbo.internal_get_galaxy_quality_status
@breturndefault bit
as
begin
--set @quality_status = N''
    select 
        CASE WHEN @breturndefault = 1 THEN 
		    default_qs_data
        ELSE 
		    current_qs_data
    	END 
	    AS qs_data
    from galaxy_settings 
		
end
go

