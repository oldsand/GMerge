/**************************************************/
/*Object Name :  internal_list_all_objects_in_folder                            */
/*Object Type :  Stored Proc.								*/
/*Purpose :    to provide proxy data for a all the objects inside the folder*/
/*Used By :    CDI									*/
/**************************************************/
create proc [dbo].[internal_list_all_objects_in_folder]
@FileNameOfIds nvarchar (265),
@depth int 
AS
begin
set nocount on

SET QUOTED_IDENTIFIER OFF

    if(@depth = 0) return 
	
	CREATE TABLE  #folder_table ( folder_id int)
  
    DECLARE @SQL nvarchar(2000)
    SET @SQL = 'BULK INSERT #folder_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'',ROWTERMINATOR = '','')'
    EXEC (@SQL)

    declare @folders table(folderid int,myparent int,nLevel smallint)
    insert  into  @folders
        select f.folder_id,f.parent_folder_id,1
        from folder f 
        inner join #folder_table ft    
        on f.folder_id = ft.folder_id

    declare @object_count integer
	declare @nLevel integer
    declare @row_inserted int
	select  @object_count = count(*) from @folders


	IF @object_count > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN	
            set @row_inserted = 0
            insert into @folders
			select f.folder_id, f.parent_folder_id, @nLevel + 1
			from folder f inner join @folders fs on f.parent_folder_id = fs.folderid
			where nLevel = @nLevel


            set @row_inserted = @@rowcount
            
			if @row_inserted = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END


select distinct fg.gobject_id 
from folder_gobject_link fg 
inner join @folders fs on fs.folderid = fg.folder_id
	


end

go

