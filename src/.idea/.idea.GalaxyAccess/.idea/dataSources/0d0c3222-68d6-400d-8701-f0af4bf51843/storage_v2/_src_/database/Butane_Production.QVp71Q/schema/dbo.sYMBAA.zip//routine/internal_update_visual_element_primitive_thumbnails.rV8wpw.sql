create procedure dbo.internal_update_visual_element_primitive_thumbnails
@gobject_id int,
@thumbnail_file_name nvarchar(256)
as
begin tran
--Create temp table and bulk insert the values from file
create table  #primitive_thumbnail (mx_primitive_id smallint,thumbnail image)

DECLARE @gSQL nvarchar(2000)
SET @gSQL = 'BULK INSERT #primitive_thumbnail  FROM ''' + @thumbnail_file_name+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
EXEC (@gSQL)
---Update the graphic primitives that are dirty
	update ove
	set 
		thumbnail = pt.thumbnail,
		is_thumbnail_dirty = 0
	from 
		owned_visual_element ove
	inner join
		gobject g
	on
		g.gobject_id = ove.gobject_id and
		g.checked_in_package_id = ove.package_id
	inner join 
		#primitive_thumbnail pt
	on
		pt.mx_primitive_id = ove.mx_primitive_id
	where 
		ove.gobject_id = @gobject_id		

if @@rowcount > 0
begin
	--Generate proxy change if toolbox symbol
	declare @namespace as int
	select 
		@namespace = namespace_id 
	from 
		gobject 
	where
		gobject_id = @gobject_id

	if @namespace = 3 -- VisualElement
	begin	
		exec internal_update_gobject_timestamp @gobject_id,0
	end
end	
commit
go

