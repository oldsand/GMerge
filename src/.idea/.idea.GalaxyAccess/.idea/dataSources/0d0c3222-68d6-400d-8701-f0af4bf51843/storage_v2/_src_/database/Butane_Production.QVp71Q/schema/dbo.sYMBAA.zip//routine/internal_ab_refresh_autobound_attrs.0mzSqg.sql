/*
** Procedure [internal_ab_refresh_autobound_attrs]
** This is typically invoked by internal_ab_assign_app_object_to_device. It also needs to be invoked when an app object is checked in
** It refreshes autobound_attributes from attribute_reference, sets up alias entries, and returns the number of attributes processed.
*/
CREATE PROCEDURE dbo.internal_ab_refresh_autobound_attrs
    @gobject_id           int 
    , @dio_id             int
    , @sg_mx_primitive_id smallint
as
begin
  set nocount on

	IF NOT EXISTS (SELECT * FROM autobind_device WHERE dio_id = @dio_id)
		RETURN 1

  declare @bkup_attrs TABLE (gobject_id      int
                           , mx_primitive_id smallint
                           , mx_attribute_id smallint
                           , element_index   smallint
                           , default_ref     nvarchar(329)
                           , xlate_rule_id   int
                           , attr_alias      nvarchar(329)
                             , match_by_id          bit
                           , PRIMARY KEY (gobject_id, mx_primitive_id, mx_attribute_id, element_index))

  -- If called from multi-object-checkin, previously established manual overrides (if any) for this object 
  -- may be found in the temp table #autobound_attribute_transient.
  IF OBJECT_ID ('tempdb..#autobound_attribute_transient') IS NOT NULL
    INSERT INTO @bkup_attrs
    SELECT gobject_id
         , mx_primitive_id
         , mx_attribute_id
         , element_index
         , default_ref
         , xlate_rule_id
         , attr_alias
         , match_by_id
      FROM #autobound_attribute_transient 
     WHERE gobject_id = @gobject_id
       AND xlate_rule_id <> 0
  ELSE  -- Not called as a part of the save gobject|check-in|rename workflow.
    INSERT INTO @bkup_attrs
    SELECT lo_id, lo_prim_id, lo_attr_id, lo_element_index
         , app_object_attr_name + '.' + app_object_io_attr
         , xlate_rule_id, overridden_attr_reference
         , 1
      FROM itvfGetAutobindInfoForDIO (@dio_id, @sg_mx_primitive_id, @gobject_id, DEFAULT, DEFAULT)
     WHERE xlate_rule_id <> 0

   -- First, delete all autobound attributes defined for the passed @gobject_id...
  DELETE autobound_attribute
   WHERE dio_id = @dio_id
     AND sg_mx_primitive_id = @sg_mx_primitive_id
     AND gobject_id = @gobject_id

  -- ...and create a new set from attributes defined for the gobject being checked-in
  INSERT INTO autobound_attribute (dio_id, sg_mx_primitive_id, gobject_id, mx_primitive_id, mx_attribute_id, element_index)
  SELECT  @dio_id
        , @sg_mx_primitive_id
        , lo.gobject_id
        , lo_attr_ref.referring_mx_primitive_id
        , lo_attr_ref.referring_mx_attribute_id
        , lo_attr_ref.element_index
  FROM  gobject lo
  INNER JOIN attribute_reference lo_attr_ref
     ON lo_attr_ref.gobject_id = lo.gobject_id
    AND lo_attr_ref.package_id = lo.checked_in_package_id 
    AND lo_attr_ref.reference_string = N'---Auto---'
    AND lo_attr_ref.element_index = 0
  WHERE lo.is_template = 0
    AND lo.gobject_id = @gobject_id

  -- Restore overrides
  UPDATE ab_attr
     SET ab_attr.xlate_rule_id = bkup.xlate_rule_id
       , ab_attr.attr_alias    = bkup.attr_alias
    FROM autobound_attribute ab_attr
  CROSS APPLY itvfGetAutobindInfoForDIO (@dio_id, @sg_mx_primitive_id, @gobject_id, DEFAULT, DEFAULT) itvf
  INNER JOIN @bkup_attrs bkup
      ON bkup.gobject_id = itvf.lo_id
     AND (bkup.default_ref = itvf.app_object_attr_name + '.' + itvf.app_object_io_attr
		  OR    (bkup.match_by_id = 1
             AND bkup.mx_primitive_id = itvf.lo_prim_id
             AND bkup.mx_attribute_id = itvf.lo_attr_id
             AND bkup.element_index = itvf.lo_element_index))
   WHERE ab_attr.dio_id = itvf.dio_id
     AND ab_attr.sg_mx_primitive_id = itvf.sg_mx_primitive_id
     AND ab_attr.gobject_id = itvf.lo_id
     AND ab_attr.mx_primitive_id = itvf.lo_prim_id
     AND ab_attr.mx_attribute_id = itvf.lo_attr_id
   OPTION (FORCE ORDER)    --L00136670

  -- Next, we need to refresh the alias (attr_name) for all entries in autobound_attribute that were renamed.
  EXECUTE internal_ab_refresh_overrides @dio_id, @sg_mx_primitive_id

  RETURN 0
end
go

