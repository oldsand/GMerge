/***************************************************************************************/
/*Object Name :  internal_get_attribute_references_from_checked_out_checked_in_package */
/*Object Type :  Stored Proc.                                                          */
/*Purpose     :  Proc. to retrieve attribute reference from                            */
/*               checked_out_package and checked_in_package of a template              */
/*               Object should be in checkout state when this SP is called.            */
/*Used By     :  PackageServer                                                         */
/***************************************************************************************/

create proc dbo.internal_get_attribute_references_from_checked_out_checked_in_package
    @gobject_id int,
    @primitive_names nvarchar(329),
    @attribute_name nvarchar(32)
as
begin

    set nocount on

    declare @checked_out_package_id int
    declare @checked_in_package_id int

    set @checked_out_package_id = 0
    set @checked_in_package_id = 0
    
    select  @checked_out_package_id = checked_out_package_id,
            @checked_in_package_id = checked_in_package_id
    from    gobject
    where   gobject_id = @gobject_id

    if ( (@checked_out_package_id = 0) or 
         (@checked_in_package_id = 0) )
        return
        
    -- checked_out_package
    select  
        pri.gobject_id,
        pri.package_id,
        pri.mx_primitive_id,
        pri.entity_change_type,
        ta.mx_attribute_id,
        ta.mx_value
    from    
        template_attribute ta
    inner join 
        primitive_instance pri
    on  ta.gobject_id = pri.gobject_id
    and ta.package_id = pri.package_id
    and ta.mx_primitive_id = pri.mx_primitive_id
    inner join
        primitive_definition pd
    on  pri.primitive_definition_id = pd.primitive_definition_id
    inner join
        attribute_definition ad
    on  pd.primitive_definition_id = ad.primitive_definition_id
    and ad.mx_attribute_id = ta.mx_attribute_id
    where   
        pri.gobject_id = @gobject_id
    and pri.package_id = @checked_out_package_id
    and ad.attribute_name = @attribute_name
    and pd.primitive_name in (@primitive_names)
    and datalength(ta.mx_value) > 4
    order by pri.mx_primitive_id -- CR L00117428


    -- checked_in_package
    select  
        pri.gobject_id,
        pri.package_id,
        pri.mx_primitive_id,
        pri.entity_change_type,
        ta.mx_attribute_id,
        ta.mx_value
    from    
        template_attribute ta
    inner join 
        primitive_instance pri
    on  ta.gobject_id = pri.gobject_id
    and ta.package_id = pri.package_id
    and ta.mx_primitive_id = pri.mx_primitive_id
    inner join
        primitive_definition pd
    on  pri.primitive_definition_id = pd.primitive_definition_id
    inner join
        attribute_definition ad
    on  pd.primitive_definition_id = ad.primitive_definition_id
    and ad.mx_attribute_id = ta.mx_attribute_id
    where   
        pri.gobject_id = @gobject_id
    and pri.package_id = @checked_in_package_id
    and ad.attribute_name = @attribute_name
    and pd.primitive_name in (@primitive_names)
    and datalength(ta.mx_value) > 4
    order by pri.mx_primitive_id -- CR L00117428


    
end
go

