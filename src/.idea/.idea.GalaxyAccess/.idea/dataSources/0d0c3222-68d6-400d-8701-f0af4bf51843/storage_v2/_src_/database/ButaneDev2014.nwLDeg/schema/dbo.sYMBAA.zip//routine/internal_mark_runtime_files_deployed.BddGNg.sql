/*
This stored procedure gets called by internal_multi_save_for_setdeploystatus just after
deployment of objects occurs.

After a set of gobjects gets deployed from a single platform, this proc will mark 
the runtime files as deployed. 

exec internal_mark_runtime_files_deployed
     1, 'Nodename'
  1, 'Nodename'
*/
CREATE proc dbo.internal_mark_runtime_files_deployed
    @FileIdsFileName nvarchar(256),
	@node_name nvarchar(256)
as
begin
set nocount on
begin tran
	CREATE TABLE  #fileids_table ( file_id int)
	DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #fileids_table   FROM ''' + @FileIdsFileName+ ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')' 
	EXEC (@SQL)
	
	update deployed_file
	set
		is_runtime_deployed = 1 
		from deployed_file df inner join #fileids_table ft
		on df.file_id = ft.file_id 
		where
		df.node_name = @node_name
commit tran

end

go

