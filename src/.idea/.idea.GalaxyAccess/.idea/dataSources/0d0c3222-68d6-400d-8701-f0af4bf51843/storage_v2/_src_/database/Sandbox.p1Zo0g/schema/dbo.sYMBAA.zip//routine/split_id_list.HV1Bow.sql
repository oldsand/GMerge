--
-- Returns a table filled with integers from a csv list (no spaces)
--
-- Example:
--
--   select * from dbo.split_id_list('34,35,36')
create function dbo.split_id_list
(
	@id_list varchar(8000)
)
returns 
    @split table
    (
    	split_id int
    )
as
begin
	declare @id varchar(10), @pos int, @start int

	set @id_list = @id_list+ ','
    set @start = 0
	set @pos = charindex(',',@id_list)

	while @pos > 0
	begin
		set @id = substring(@id_list, @start, @pos - @start)
		if @id <> ''
		begin
			insert into @split (split_id) 
			values (cast(@id as int))
		end
        set @start = @pos+1
		set @pos = charindex(',', @id_list, @start)
	end
	return
end
go

