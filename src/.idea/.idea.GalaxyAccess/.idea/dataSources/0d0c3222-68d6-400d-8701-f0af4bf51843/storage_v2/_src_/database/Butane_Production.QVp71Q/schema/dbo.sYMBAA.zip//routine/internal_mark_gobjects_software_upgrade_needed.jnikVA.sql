--	This stored procedure will update the gobject table for all the 
--	the gobjects which are deployed and are using the input runtime file_id
--  and return the table of affected gobject_ids 

create procedure dbo.internal_mark_gobjects_software_upgrade_needed
@file_id int
AS
SET NOCOUNT ON
begin
   create table #affected_gobjects(gobject_id int)

	--// select gobject
    insert into #affected_gobjects(gobject_id)
	    select distinct  gobject.gobject_id
	    from primitive_definition INNER JOIN 
	    file_primitive_definition_link ON 
	    primitive_definition.primitive_definition_id = file_primitive_definition_link.primitive_definition_id 
	    INNER JOIN 
	    gobject	 ON 
	    primitive_definition.template_definition_id = gobject.template_definition_id 
    	WHERE ---(primitive_definition.runtime_handler_clsid <> '{00000000-0000-0000-0000-000000000000}') AND 
	    (file_primitive_definition_link.file_id = @file_id)

  --  //1. Get all the visual elements using these files
     declare visual_element_cursor cursor for
         select distinct vev.visual_element_id from
         visual_element_version vev INNER JOIN
         primitive_instance pi ON
 	vev.mx_primitive_id = pi.mx_primitive_id AND
 	vev.gobject_id = pi.gobject_id AND
 	vev.package_id = pi.package_id INNER JOIN
 	primitive_instance_file_table_link pif ON
         pif.mx_primitive_id = pi.parent_mx_primitive_id AND
 	pif.gobject_id = pi.gobject_id AND
         pif.package_id = pi.package_id 
    WHERE
         pif.file_id = @file_id
     
     open visual_element_cursor
     
     declare @visual_element_id int
     set @visual_element_id = 0
 
     fetch next from visual_element_cursor into @visual_element_id
     while @@fetch_status = 0
     begin
         --//2. Get all view apps using this visual element
         insert #affected_gobjects(gobject_id)
             execute internal_get_referring_visual_elements @visual_element_id,0,1
         fetch next from visual_element_cursor into @visual_element_id
     end
     
     close visual_element_cursor
     
     deallocate visual_element_cursor
     
     --add viewapps which are configured for "include all"
     if(@visual_element_id <>0)
     begin
     insert #affected_gobjects(gobject_id)
		select gobject_id from gobject where derived_from_gobject_id in 
		(select gobject_id from intouchviewapptemplate_allsymbols)
     end
     
 --   remove undeployed objects from the table
    delete #affected_gobjects FROM 
    #affected_gobjects a INNER JOIN gobject g ON  g.gobject_id = a.gobject_id 
                                              AND g.deployed_package_id = 0
    
    --Mark these objects as SUR
    update gobject 
        set software_upgrade_needed = 1 
        FROM #affected_gobjects a where a.gobject_id = gobject.gobject_id

    update pt
    set pt.gobject_id = pt.gobject_id
    from proxy_timestamp pt
    inner join #affected_gobjects gi on
        pt.gobject_id = gi.gobject_id

    update gfit
    set gfit.gobject_id = gfit.gobject_id
    from gobject_filter_info_timestamp gfit
    inner join #affected_gobjects gi on
        gfit.gobject_id = gi.gobject_id


	update galaxy
    set max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 


    
    --Return these object ids
    select distinct gobject_id from #affected_gobjects
	
    drop table #affected_gobjects

	-- clean the deployed file table for runtime files
	update deployed_file set is_runtime_deployed = 0 where file_id in ( select file_id from file_pending_update )


end

go

