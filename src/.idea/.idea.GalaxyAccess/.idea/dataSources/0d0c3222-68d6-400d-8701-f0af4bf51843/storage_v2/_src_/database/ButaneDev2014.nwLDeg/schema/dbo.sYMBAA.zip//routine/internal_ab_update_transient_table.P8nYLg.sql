CREATE PROCEDURE dbo.internal_ab_update_transient_table
                 @list_of_ids nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @gobject table (id INT PRIMARY KEY)

    INSERT INTO @gobject
    EXEC  internal_select_ids @list_of_ids

    -- Debug:
    --insert into ab_dump
    --select gobject_id       
    --     , mx_primitive_id  
    --     , mx_attribute_id  
    --     , default_ref 
    --     , xlate_rule_id    
    --     , attr_alias       
    --     , match_by_id  
    --  from #autobound_attribute_transient

    /*
    ** The information in #autobound_attribute_transient is enough to restore overrides to instances even if attributes were renamed or deleted.
    ** If, however, change is being cascaded from the parent template to the instance, the addition, or deletion, of IO extension primitives in 
    ** an ancestor could cause the mx_primitive_ids in the instance to be reassigned, resulting in overrides being incorrectly assigned at the
    ** conclusion of the check-in operation. The cascade check-in workflow therefore needs some additional work.
    ** We determine the need to handle the cascade check-in case by comparing the number of inherited primitives in the checked-in package
    ** against those in the checked-out package. 
    ** If the two are the same, we know that either this is not a cascade check-in, or even if it is, we don't need to account for reassignment of
    ** mx_primitive_ids in the instance. We will, however, need to account for renamed template primitives in this case.
    ** If, on the other hand, the two counts differ, we know for certain that this is a cascade check-in, and that we need to account for the
    ** reassignment of mx_primitive_ids in the instance.
    */
    DECLARE @cascade_checkin_targets TABLE (gobject_id INT PRIMARY KEY, processing_order INT)
    INSERT INTO @cascade_checkin_targets
    SELECT DISTINCT g.gobject_id, (CI.cnt - CO.cnt) as processing_order FROM @gobject gobj
    INNER JOIN gobject g
        ON g.gobject_id = gobj.id
       AND g.is_template = 0
    CROSS APPLY (SELECT COUNT(*) AS cnt 
                   FROM primitive_instance pini
                  WHERE pini.gobject_id = g.gobject_id
                    AND pini.package_id = g.checked_in_package_id
                    AND pini.created_by_parent <> 0) CI
    CROSS APPLY (SELECT COUNT(*) AS cnt 
                   FROM primitive_instance pino
                  WHERE pino.gobject_id = g.gobject_id
                    AND pino.package_id = g.checked_out_package_id
                    AND pino.created_by_parent <> 0) CO

    /*
    ** @cascade_checkin_targets now contains all instance gobject_ids whose individual mx_primitive_ids may have changed due to the addition or deletion
    ** of primitives in the parent template (if processing_order != 0). We now need to know which entries in the #transient table we need to update.
    ** We look at all primitive_instance and attribute_reference records in the checked-in package that were _not_ inherited from the parent [template]. 
    ** We then retrieve the mx_primitive_ids and mx_attribute_ids from the checked out package for attributes that do not belong to inherited primitives. 
    ** These represent the values that will replace what's in the autobound_attributes table after it is refreshed. The two result sets should have the 
    ** same size (count) if this is a cascade check-in. All we have to do is to update the mx_primitive_id and mx_attribute_id in the #transient table 
    ** with the new ones. 
    ** Rather than to write a loop to do this, we're invoking the following flattening query to convert what are 3-columned tables with the same key (gobject_id),
    ** but different values of mx_primitive_id (checked-in and checked-out), into one 3-columned result-set that contains:
    ** {gobject_id, checked_in_mx_primitive_id, checked_out_mx_primitive_id}.
    ** In other words, if 
    ** the checked-in package had  {gobject_id, mx_primitive_id}      := {{615, 122}, {615, 123}}; and
    ** the checked-out package had {gobject_id, mx_primitive_id}      := {{615, 132}, {615, 133}};
    ** the output of the following select would be two rows containing:= {{615, 122, 132}, {615, 123, 133}}.
    ** In other words, the schema: {gobject_id, old_mx_primitive_id, new_mx_primitive_id}
    */
    DECLARE @filtered_primitives TABLE (gobject_id INT
                                      , old_mx_primitive_id SMALLINT
                                      , new_mx_primitive_id SMALLINT)

    INSERT INTO @filtered_primitives
    SELECT DISTINCT CI.gobject_id, CI.mx_primitive_id, CO.mx_primitive_id
    FROM (
        SELECT ROW_NUMBER() OVER(ORDER by ar.gobject_id, ar.referring_mx_primitive_id) rid
             , pin.gobject_id as gobject_id
             , pin.mx_primitive_id as mx_primitive_id
          FROM @cascade_checkin_targets ci
        INNER JOIN gobject g
            ON g.gobject_id = ci.gobject_id
        INNER JOIN primitive_instance pin
            ON pin.gobject_id = g.gobject_id
           AND pin.package_id = g.checked_in_package_id
           AND pin.created_by_parent = 0                    -- instance primitives only: Not inherited from ancestor
        INNER JOIN attribute_reference ar
            ON ar.gobject_id = pin.gobject_id
           AND ar.package_id = pin.package_id
           AND ar.referring_mx_primitive_id = pin.mx_primitive_id
           AND ar.reference_string = '---Auto---'
         WHERE ci.processing_order <> 0                     -- Cascade check-in case only
    ) CI
    CROSS APPLY (
        SELECT ROW_NUMBER() OVER(ORDER by ar.gobject_id, ar.referring_mx_primitive_id) rid
             , pout.gobject_id as gobject_id
             , pout.mx_primitive_id as mx_primitive_id
          FROM @cascade_checkin_targets ci
        INNER JOIN gobject g
            ON g.gobject_id = ci.gobject_id
        INNER JOIN primitive_instance pout
            ON pout.gobject_id = g.gobject_id
           AND pout.package_id = g.checked_out_package_id
           AND pout.created_by_parent = 0                    -- instance primitives only: Not inherited from ancestor
        INNER JOIN attribute_reference ar
            ON ar.gobject_id = pout.gobject_id
           AND ar.package_id = pout.package_id
           AND ar.referring_mx_primitive_id = pout.mx_primitive_id
           AND ar.reference_string = '---Auto---'
         WHERE ci.processing_order <> 0                     -- Cascade check-in case only
    ) CO
    WHERE CI.rid = CO.rid

    /*
    ** Now, simply update the mx_primitive_ids in the #transient table.
    ** To avoid the risk of primary key violations, we do it in two steps.
    ** Step 1:
    */
    UPDATE transient 
       SET transient.mx_primitive_id = -filter.new_mx_primitive_id
         , match_by_id = 0
      FROM #autobound_attribute_transient transient
    INNER JOIN @filtered_primitives filter
        ON filter.gobject_id = transient.gobject_id
       AND filter.old_mx_primitive_id = transient.mx_primitive_id

    -- And, step 2:
    UPDATE transient 
       SET transient.mx_primitive_id = -transient.mx_primitive_id
      FROM #autobound_attribute_transient transient
    INNER JOIN @filtered_primitives filter
        ON filter.gobject_id = transient.gobject_id
       AND filter.new_mx_primitive_id = -transient.mx_primitive_id
     WHERE match_by_id = 0

    -- Debug:
    --insert into ab_dump
    --select gobject_id       
    --     , mx_primitive_id  
    --     , mx_attribute_id 
    --     , default_ref 
    --     , xlate_rule_id    
    --     , attr_alias       
    --     , match_by_id  
    -- from #autobound_attribute_transient


    /*
    ** We need to handle deleted|renamed primitives. Compare the check-in and check-out packages for I/O primitives and their attributes
    ** by name. Disable 'match by ID' for all entries in the transient table that exist with the same default_ref in the checked-out and 
    ** checked-in packages (i.e., have the same primitive name and attribute name).
    */
    UPDATE transient
       SET match_by_id = 0
      FROM #autobound_attribute_transient transient         
    INNER JOIN @cascade_checkin_targets cct
        ON cct.gobject_id = transient.gobject_id            
    INNER JOIN gobject g
        ON g.gobject_id = cct.gobject_id                    
    INNER JOIN primitive_instance pin
        ON pin.gobject_id = g.gobject_id
       AND pin.package_id = g.checked_in_package_id
    INNER JOIN attribute_reference ain
        ON ain.gobject_id = pin.gobject_id
       AND ain.package_id = pin.package_id
       AND ain.referring_mx_primitive_id = pin.mx_primitive_id
    INNER JOIN attribute_definition adin
        ON adin.primitive_definition_id = pin.primitive_definition_id
       AND adin.mx_attribute_id = ain.referring_mx_attribute_id
    INNER JOIN primitive_instance pout
        ON pout.gobject_id = g.gobject_id
       AND pout.package_id = g.checked_out_package_id
    INNER JOIN attribute_reference aout
        ON aout.gobject_id = pout.gobject_id
       AND aout.package_id = pout.package_id
       AND aout.referring_mx_primitive_id = pout.mx_primitive_id
    INNER JOIN attribute_definition adout
        ON adout.primitive_definition_id = pout.primitive_definition_id
       AND adout.mx_attribute_id = aout.referring_mx_attribute_id
     WHERE (pout.created_by_parent <> 0 OR cct.processing_order = 0)
       AND ain.reference_string = aout.reference_string
       AND pin.primitive_name = pout.primitive_name
       AND adin.attribute_name = adout.attribute_name
       AND ain.referring_mx_primitive_id = transient.mx_primitive_id
       AND ain.referring_mx_attribute_id = transient.mx_attribute_id
       AND match_by_id = 1

    -- Debug:
    --insert into ab_dump
    --select gobject_id       
    --     , mx_primitive_id  
    --     , mx_attribute_id 
    --     , default_ref 
    --     , xlate_rule_id    
    --     , attr_alias       
    --     , match_by_id  
    --  from #autobound_attribute_transient
END

go

