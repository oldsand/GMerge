--
-- Returns a Visual element ID for given gobject_id,package_id, mx_primitive_id
-- If not found then return 0 (ZERO)
create function dbo.get_visual_element_id
(
	@gobject_id int,
	@package_id int,
	@mx_primitive_id smallint
)
returns int
as
begin
	declare @visual_elemnt_id int
	set @visual_elemnt_id = 0

	select @visual_elemnt_id = visual_element_id 
	from visual_element_version
	where gobject_id = @gobject_id and 
		  package_id = @package_id and
		  mx_primitive_id = @mx_primitive_id
	
	return @visual_elemnt_id 
end
go

