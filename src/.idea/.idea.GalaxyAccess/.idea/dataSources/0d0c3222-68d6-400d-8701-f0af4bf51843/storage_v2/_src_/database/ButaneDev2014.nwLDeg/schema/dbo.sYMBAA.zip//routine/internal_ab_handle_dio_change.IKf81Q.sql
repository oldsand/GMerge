create proc dbo.internal_ab_handle_dio_change
    @dio_id int
as 
begin
  set nocount on

  IF OBJECT_ID ('tempdb..#autobound_attribute_transient') IS NOT NULL
  BEGIN
    -- Called from a sproc that is required to handle the effects of renaming a DIO on auto-binding.
    DECLARE @updPxy TABLE (gobject_id int PRIMARY KEY)
    /*
    ** What we need to do now is to mark objects that make auto-bound references to a device [or scan-group] that's been renamed as pending redeployment.
    ** We need to exclude auto-bound references that haven't endured device [.scan-group] overrides (itvf.xlate_rule_id >= -1).
    */
    UPDATE g 
       SET deployment_pending_status = 1
    OUTPUT inserted.gobject_id INTO @updPxy
      FROM gobject g
    CROSS APPLY (SELECT * FROM itvfGetAutobindInfoForDIO (@dio_id, DEFAULT, DEFAULT, DEFAULT, DEFAULT) WHERE xlate_rule_id >= -1) itvf
    INNER JOIN #autobound_attribute_transient oldattr
        ON oldattr.gobject_id = itvf.lo_id
       AND oldattr.mx_primitive_id = itvf.lo_prim_id
       AND oldattr.mx_attribute_id = itvf.lo_attr_id
       AND oldattr.element_index = itvf.lo_element_index
       AND oldattr.linked_device <> itvf.dio_tag_name + '.' + itvf.dio_scan_group_name
     WHERE g.gobject_id = oldattr.gobject_id
       AND g.deployed_package_id != 0 
       AND g.deployment_pending_status = 0

    IF @@ROWCOUNT <> 0
    BEGIN
      -- Update proxy timestamp for affected objects: We don't want duplicate gobject_ids here.
      -- This is why the updated gobject_ids were OUTPUT to @updPxy in the previous update.
      UPDATE pt
         SET pt.gobject_id = up.gobject_id
        FROM proxy_timestamp pt 
      INNER JOIN @updPxy up
          ON up.gobject_id = pt.gobject_id

      RETURN 1
    END
  END

  RETURN 0
end
go

