CREATE proc dbo.internal_add_file
(
    @file_name nvarchar(256),
    @subfolder nvarchar(256),
    @vendor_name nvarchar(256),
    @registration_type int,
	@file_version nvarchar(50),
	@file_modified_time nvarchar(50),
    @file_id int out
)
as
begin
	if exists (select '*' from file_table where file_name = @file_name and subfolder = @subfolder and vendor_name = @vendor_name)
		begin	
			update file_table
				set file_version = @file_version,
					file_modified_time = @file_modified_time where file_name = @file_name and subfolder = @subfolder and vendor_name = @vendor_name
		end
	else
		begin

			insert into file_table(file_name,subfolder,vendor_name,registration_type,file_version,file_modified_time ) 
			values(@file_name,@subfolder,@vendor_name,@registration_type,@file_version,@file_modified_time )
			
			set @file_id = @@identity
		end
end
go

