create proc dbo.internal_resolve_visual_element_references_from_file
    @gobject_id int,
    @package_id int,
    @visual_element_reference_file_path nvarchar(255),
    @is_association int
as
begin
set nocount on
   	
	
    CREATE TABLE #visual_element_reference
    (
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        reference_string nvarchar(3620) COLLATE SQL_Latin1_General_CP1_CI_AS,
        is_relative_reference bit not null
    ) 
    create table #visual_element_reference_string
    (
	gobject_id int not null,
	package_id int not null,
	mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        reference_string nvarchar(3620) COLLATE SQL_Latin1_General_CP1_CI_AS,
        visual_element_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS null,
        tag_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS null,
        primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS default N'',
	visual_element_name nvarchar(3260)  COLLATE SQL_Latin1_General_CP1_CI_AS null,
        hierarchical_visual_element_name nvarchar(3620)  COLLATE SQL_Latin1_General_CP1_CI_AS null,
        is_relative_reference bit not null,
        relative_object_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS default '',
        is_hierarchical_visual_element_name bit null
    )  
    create index reference_string_index on #visual_element_reference_string (reference_string)  

    create table #visual_element_reference_info
    (
	-- reference owner info...
	gobject_id int not null,
	package_id int not null,
	mx_primitive_id smallint not null,    
	visual_element_reference_index int not null,
	is_relative_reference bit not null,
     
	-- unbound section
	visual_element_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS null, 
	hierarchical_visual_element_name nvarchar(3620)  COLLATE SQL_Latin1_General_CP1_CI_AS null, 
	visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS  null, 
	tag_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS null, 
	primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS  null, 
	relative_object_name nvarchar (329) COLLATE SQL_Latin1_General_CP1_CI_AS  null, 
	visual_element_id int NULL
    ) 



	declare @commandText nvarchar(2000)
	set @commandText = 'bulk insert #visual_element_reference  from ''' 
	+ @visual_element_reference_file_path + ''' 
		with (fieldterminator = '','', tablock, datafiletype  = ''widechar'') '
	exec( @commandText )

	-- add each reference from temp table

	insert into #visual_element_reference_string
		select @gobject_id, @package_id, mx_primitive_id,  visual_element_reference_index, reference_string, null, null, N'',null, null, is_relative_reference, '',null 			from #visual_element_reference
        
	exec internal_resolve_visual_element_reference3 @is_association
	

	-- now, try to resolve the ids....

    
	declare @resolved_visual_element table
	(
		gobject_id int,
		package_id int,
		mx_primitive_id smallint,
		visual_element_reference_index int,
		visual_element_id int null
	)


	/* we must make multiple passes*/
    
	-- try to bind non-relative checked-in visual_elements......    
	insert into @resolved_visual_element
	(gobject_id,
	package_id,
	mx_primitive_id,
	visual_element_reference_index,
	visual_element_id)
	select     
	distinct    
	u.gobject_id,
	u.package_id,
	u.mx_primitive_id ,
	u.visual_element_reference_index,
    	vev.visual_element_id
	from visual_element_version vev
	inner join gobject g on
        	vev.gobject_id = g.gobject_id
	inner join primitive_instance pri on           
        	vev.gobject_id = vev.gobject_id and
 	        vev.package_id = pri.package_id and 
		vev.mx_primitive_id = pri.mx_primitive_id
	inner join owned_visual_element ove on
        	vev.inherited_from_visual_element_id = ove.visual_element_id and
	        vev.inherited_from_gobject_id = ove.gobject_id and
        	vev.inherited_from_package_id = ove.package_id and 
	        vev.inherited_from_mx_primitive_id = ove.mx_primitive_id
	inner join visual_element ve on 
        	vev.visual_element_id = ve.visual_element_id
	inner join #visual_element_reference_info u on 
        	u.tag_name = g.tag_name  and
	        u.primitive_name = pri.primitive_name  and
        	((ve.visual_element_type = u.visual_element_type  ) or u.visual_element_type is null )
	inner join #visual_element_reference_info ver on
        	u.gobject_id = ver.gobject_id and
	        u.package_id = ver.package_id and
        	u.mx_primitive_id = ver.mx_primitive_id and
	        u.visual_element_reference_index = ver.visual_element_reference_index and
        	(ver.is_relative_reference = 0 or @is_association = 1)  and
	        u.hierarchical_visual_element_name is null        


	--update the checked_in_bound ver columns....
	update  ver
	set 
        ver.visual_element_id = wt.visual_element_id
	from #visual_element_reference_info ver 
	inner join @resolved_visual_element wt on
        	wt.gobject_id = ver.gobject_id and
	        wt.package_id = ver.package_id and
        	wt.mx_primitive_id = ver.mx_primitive_id and
	        wt.visual_element_reference_index = ver.visual_element_reference_index


	delete from @resolved_visual_element


	--  Finished binding non-relative references.....

	-- try to bind relative visual_elements....
	  insert into @resolved_visual_element
	    (gobject_id,
	    package_id,
	    mx_primitive_id,
	    visual_element_reference_index,
	    visual_element_id)
	    select
	    distinct     
	    u.gobject_id,
	    u.package_id,
	    u.mx_primitive_id ,
	    u.visual_element_reference_index,
	    vev.visual_element_id
	    from #visual_element_reference_info u
	    inner join gobject referer on
        	referer.gobject_id = u.gobject_id
	    inner join #visual_element_reference_info ver on
        	ver.gobject_id = u.gobject_id
	        and ver.package_id = u.package_id
        	and ver.mx_primitive_id = u.mx_primitive_id
	        and ver.visual_element_reference_index = u.visual_element_reference_index
        	and ver.is_relative_reference = 1
	        and ver.hierarchical_visual_element_name is null        
	    inner join visual_element_version vev  on
		vev.gobject_id = u.gobject_id
		and vev.package_id = u.package_id
	    inner join gobject g on 
	        g.hierarchical_name = 
        	CASE WHEN u.relative_object_name is null OR len(u.relative_object_name) = 0 THEN
			referer.hierarchical_name
		ELSE
			referer.hierarchical_name + '.' +  u.relative_object_name
		END 
	    inner join	primitive_instance pri on                  
		pri.gobject_id = vev.gobject_id
		and pri.package_id = vev.package_id 
		and pri.mx_primitive_id = vev.mx_primitive_id  
		and pri.primitive_name = u.primitive_name
	    inner join  owned_visual_element ove on      
		vev.inherited_from_visual_element_id = ove.visual_element_id
		and vev.inherited_from_gobject_id = ove.gobject_id 
		and vev.inherited_from_package_id = ove.package_id
		and vev.inherited_from_mx_primitive_id = ove.mx_primitive_id  
	    inner join  visual_element ve on       
		ve.visual_element_id = vev.visual_element_id    
		and ve.visual_element_type = isnull (u.visual_element_type, ve.visual_element_type) 


	--update the checked_in_bound ver columns....
	update  ver
	set 
        	ver.visual_element_id = wt.visual_element_id
	from #visual_element_reference_info ver 
	inner join @resolved_visual_element wt on
        	wt.gobject_id = ver.gobject_id and
	        wt.package_id = ver.package_id and
        	wt.mx_primitive_id = ver.mx_primitive_id and
	        wt.visual_element_reference_index = ver.visual_element_reference_index


	delete from @resolved_visual_element


	-- try to bind visual_elements that were stored by hierarchical name
	insert into @resolved_visual_element
	(gobject_id,
	package_id,
	mx_primitive_id,
	visual_element_reference_index,
	visual_element_id)
	select
	distinct     
	u.gobject_id,
	u.package_id,
	u.mx_primitive_id ,
	u.visual_element_reference_index,
	vev.visual_element_id
	from #visual_element_reference_info u
	inner join	dbo.visual_element_version vev  on
			vev.gobject_id = u.gobject_id  
	inner join	dbo.primitive_instance pri on                  
			vev.gobject_id = pri.gobject_id 
			and vev.package_id = pri.package_id 
			and vev.mx_primitive_id = pri.mx_primitive_id  
	inner join	dbo.owned_visual_element ove on      
			vev.inherited_from_visual_element_id = ove.visual_element_id 
			and vev.inherited_from_gobject_id = ove.gobject_id 
			and vev.inherited_from_package_id = ove.package_id 
			and vev.inherited_from_mx_primitive_id = ove.mx_primitive_id  
	inner join	dbo.visual_element ve on       
			vev.visual_element_id = ve.visual_element_id  
	inner join  gobject g on
			g.gobject_id = pri.gobject_id
			and u.hierarchical_visual_element_name = 
			CASE WHEN pri.primitive_name is null OR len (pri.primitive_name) = 0 
				THEN g.hierarchical_name 				
				ELSE g.hierarchical_name + '.' + LEFT (pri.primitive_name, 32) 
			END



	--update the checked_in_bound ver columns....
	update  ver
	set 
        	ver.visual_element_id = wt.visual_element_id
	from #visual_element_reference_info ver 
	inner join @resolved_visual_element wt on
        	wt.gobject_id = ver.gobject_id and
	        wt.package_id = ver.package_id and
        	wt.mx_primitive_id = ver.mx_primitive_id and
	        wt.visual_element_reference_index = ver.visual_element_reference_index



    	select isnull(visual_element_id,0) 
	    from #visual_element_reference_info
	    order by gobject_id, mx_primitive_id,visual_element_reference_index
	
	drop table #visual_element_reference_string	    
	drop table #visual_element_reference
	drop table #visual_element_reference_info
	    
    
end



go

