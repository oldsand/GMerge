/**************************************************/
/*Object Name :  internal_get_gr_node_platform_info   */
/*Object Type :  Stored Proc.					  */
/*Purpose	  :  If return 1 record and           */
/*               deployed_package_id != 0 then GR */
/*               Node's Platform is deployed,     */
/*               else is not deployed. Before     */
/*               calling, all Mx Encoded ID's     */
/*               must be decoded first.           */
/*Used By	  :  CDI()                            */
/**************************************************/

create procedure dbo.internal_get_gr_node_platform_info
as
SET NOCOUNT ON
begin
	SELECT     gobject.deployed_package_id, gobject.gobject_id, platform.node_name,
	case gobject.deployed_package_id when 0 then 0 else 1 end as is_deployed
	FROM         gobject INNER JOIN
	instance ON 
	instance.mx_platform_id = 1 AND 
	instance.mx_engine_id = 1 AND 
	instance.gobject_id = gobject.gobject_id 
	INNER JOIN
	platform ON 
	gobject.gobject_id = platform.platform_gobject_id
end



go

