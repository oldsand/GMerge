create function dbo.get_char_count_in_string ( 
            @string_to_search nvarchar(2000),
            @char_to_find char(1)
            )
returns int
as
begin
    declare @position_char_was_found_in int
    declare @number_of_times_char_exists_in_search_string int
    declare @startingPosition int
    
    set @startingPosition = 1
    set @number_of_times_char_exists_in_search_string = 0
    while 1=1
    begin
        set @position_char_was_found_in = isnull(charindex(@char_to_find,@string_to_search,@startingPosition),0)
        if(@position_char_was_found_in > 0)
        begin
            set @number_of_times_char_exists_in_search_string = @number_of_times_char_exists_in_search_string + 1
            set @startingPosition = @position_char_was_found_in + 1
        end
        else
        begin
            break
            
        end
        set @position_char_was_found_in = isnull(charindex(@char_to_find,@string_to_search,@startingPosition),0)
    
    end
    
    return @number_of_times_char_exists_in_search_string
end
go

