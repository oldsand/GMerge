/*
** Procedure: [internal_ab_set_device_linkage]:
** Fulfills the device assignment (drag-drop) logic
** ------------------------------------------------------------------------------------------------------------------------------------------------
** 
*/
CREATE PROCEDURE dbo.internal_ab_set_device_linkage
    @gobject_id               int 
    , @dio_id                 int
    , @sg_mx_primitive_id     smallint
    , @old_sg_mx_primitive_id smallint = 0
    , @old_dio_id             int = 0
    , @apply_naming_rule      int = NULL
as
begin

  set nocount on

  declare @result int
  set @result = 0

  /*
  ** First: Create entries in autobind_device and autobind_device_topic if they don't exist. 
  ** It doesn't matter if this "set-device-linkage" terminates in the middle due to an invalid parameter:
  ** This step of primimg the dop for autobinding is not a wasted effort.
  */
  execute @result = internal_ab_prime_dio_for_autobind @dio_id

  if (@result = 0)
  begin
    /*
    ** autobind_device and autobind_device_topic will have been populated with information pertaining to DIO and its scan-groups.
    ** Effect a topic-level name-rule if called upon to do so (and if not the default topic)--this might change in a later sprint.
    */
    if (@apply_naming_rule IS NOT NULL) 
    begin
      UPDATE autobind_device_topic
         SET overridden_naming_rule_id = @apply_naming_rule
       WHERE
             dio_id = @dio_id
         AND sg_mx_primitive_id = @sg_mx_primitive_id
	       AND overridden_naming_rule_id IS NULL
    end


    /*
    ** Next, on confirmation that @sg_mx_primitive_id refers to a valid scan-group under the passed DIO, 
    ** create entries in autobound_attribute for all of the passed AO's '---Auto---' attributes.
    */
    EXECUTE @result = internal_ab_assign_app_object_to_device @gobject_id, @dio_id, @sg_mx_primitive_id, @old_sg_mx_primitive_id, @old_dio_id
  end

  -- update gobject set assigned_to_device = @dio_id where gobject_id = @ao_id
  -- Don't perform this update here: The SetAssociation IDE workflow should handle this 

  RETURN @result
end
go

