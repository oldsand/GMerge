create trigger trigger_delete_package
    on package
    instead of delete
as
    set nocount on
if not exists(select 1 from deleted)
begin
    return
end
begin tran
    -- delete children
--    delete instance_attribute
--    from instance_attribute, deleted
--    where instance_attribute.gobject_id = deleted.gobject_id
--    and   instance_attribute.package_id = deleted.package_id
    
    delete primitive_instance_feature_link 
    from primitive_instance_feature_link, deleted
    where primitive_instance_feature_link.gobject_id = deleted.gobject_id
    and   primitive_instance_feature_link.package_id = deleted.package_id

    delete template_attribute 
    from template_attribute, deleted
    where template_attribute.gobject_id = deleted.gobject_id
    and   template_attribute.package_id = deleted.package_id

    delete dynamic_attribute 
    from dynamic_attribute, deleted
    where dynamic_attribute.gobject_id = deleted.gobject_id
    and   dynamic_attribute.package_id = deleted.package_id

    delete primitive_instance 
    from primitive_instance, deleted
    where primitive_instance.gobject_id = deleted.gobject_id
    and   primitive_instance.package_id = deleted.package_id

    delete attribute_reference
    from attribute_reference, deleted
    where attribute_reference.gobject_id = deleted.gobject_id
    and   attribute_reference.package_id = deleted.package_id

    --delete rows in target table
    delete package
    from package, deleted
    where package.gobject_id = deleted.gobject_id 
    and    package.package_id = deleted.package_id

commit
go

