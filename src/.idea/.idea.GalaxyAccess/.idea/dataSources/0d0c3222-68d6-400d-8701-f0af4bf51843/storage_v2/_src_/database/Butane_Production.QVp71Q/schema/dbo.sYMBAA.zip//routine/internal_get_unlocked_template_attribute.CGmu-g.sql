create proc dbo.internal_get_unlocked_template_attribute
@packageid  int,
@gobjectid  int
as
begin
  select ta.mx_primitive_id,
         ta.mx_attribute_id,
	 ta.mx_value
  from   template_attribute ta
  where  ta.package_id = @packageid
    and  ta.gobject_id = @gobjectid
    and  ta.lock_type  = 0
  order by mx_primitive_id
end
go

