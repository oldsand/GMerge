--***********************************************************************************************************************
--***      
--***      OBJECT NAME:            is_partner_in_pending_update_state
--***      DESCRIPTION:  Function is used to find out if a gobject's failover partner is in pending update state or not
--***      
--***      USAGE:                  dbo.is_partner_in_pending_update_state(23) --(where 23 is the gobject's id)
--***      RETURNS :
--***      =========
--***      0 - if failover partner is not in pending update
--***      1 - if failover partner is in pending update
--***      
--***********************************************************************************************************************
create   function dbo.is_partner_in_pending_update_state( 
            @gobject_id int
            )
returns smallint
as
begin
            declare @isPartnerPendingUpdate smallint       
            select  @isPartnerPendingUpdate =
			(case when (gobject.deployed_package_id <> 0) 
			and ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version
			<> deployed_package.deployable_configuration_version)
				then '1' else '0' 	end )
			from gobject 
			left join package checked_in_package   on 
					gobject.gobject_id = checked_in_package.gobject_id and 
					gobject.checked_in_package_id = checked_in_package.package_id
			left join package deployed_package  on 
					gobject.gobject_id = deployed_package.gobject_id and 
					gobject.deployed_package_id = deployed_package.package_id
			where 
					gobject.gobject_id = dbo.get_failover_partner_id(@gobject_id) 
			

            select @isPartnerPendingUpdate = isnull(@isPartnerPendingUpdate,0)

            return @isPartnerPendingUpdate
                       

end
go

