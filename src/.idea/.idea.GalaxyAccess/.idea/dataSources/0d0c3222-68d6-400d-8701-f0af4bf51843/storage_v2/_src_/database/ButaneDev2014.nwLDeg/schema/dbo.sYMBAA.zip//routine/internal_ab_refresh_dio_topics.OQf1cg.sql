/*
** Procedure [internal_ab_refresh_dio_topics]
** This is invoked by internal_ab_prime_dio_for_autobind. It should also be invoked when a DIO is checked in.
** NOTE: This sproc does not need to be exposed to the Package Framework (i.e., wwCDI does not need to make this accessible to wwPackageServer).
*/
CREATE PROCEDURE [dbo].[internal_ab_refresh_dio_topics]
	@dio_id int 
as
begin
    set nocount on

    IF NOT EXISTS (SELECT * FROM autobind_device WHERE dio_id = @dio_id)
        RETURN 1

    /*
    ** Delete rows from topic that no longer exist in primitive_instance:
    ** i.e., account for scan-groups that were deleted from the DIO.
    */
    DECLARE @redeploy   TABLE (gobject_id int PRIMARY KEY)    
    DECLARE @updPxy     TABLE (gobject_id int PRIMARY KEY)
    DECLARE @refreshPxy int = 0

    -- |<-- CR L00139143
	-- and start HF CR L00137941 Remove the deleted/renamed scan groups entries from object_device_linkage and autobound_attribute tables
    IF OBJECT_ID ('tempdb..#scan_groups_deleted') IS NOT NULL
       AND OBJECT_ID ('tempdb..#scan_groups_common') IS NOT NULL
    BEGIN
        /*
        ** Save (locally) entries for this dio, and delete them from the temp tables so that
        ** they aren't found when the trigger invokes this sproc.
        */
        DECLARE @deleted_sg TABLE (dio_id int, mx_primitive_id smallint)
        INSERT INTO @deleted_sg SELECT dio_id, mx_primitive_id FROM #scan_groups_deleted WHERE dio_id = @dio_id

        DECLARE @changed_sg TABLE (dio_id int, old_mx_primitive_id smallint, new_mx_primitive_id smallint)
        INSERT INTO @changed_sg
        SELECT DISTINCT dio_id, old_mx_primitive_id, new_mx_primitive_id from #scan_groups_common WHERE dio_id = @dio_id
        
        DELETE #scan_groups_deleted WHERE dio_id = @dio_id
        DELETE #scan_groups_common WHERE dio_id = @dio_id

        -- First, delete object-device linkages
        DELETE odl 
        OUTPUT deleted.gobject_id INTO @redeploy
          FROM object_device_linkage AS odl
        INNER JOIN @deleted_sg sgd
        	ON sgd.dio_id = odl.dio_id
           AND sgd.mx_primitive_id = odl.sg_mx_primitive_id

        /*
        ** Delete the autobound topics: 
        ** There's no 'on-delete' trigger defined for object_device_linkage, so we need to do this manually.
        ** Referential integrity (CASCADE DELETE) will delete linked attributes [from autobound_reference].
        */
        DELETE topic 
          FROM autobind_device_topic AS topic
        INNER JOIN @deleted_sg sgd
        	ON sgd.dio_id = topic.dio_id
           AND sgd.mx_primitive_id = topic.sg_mx_primitive_id

        /*
        ** Next, process the changes to the autobind_device_topic table
        ** The mx_primitive_ids of scan-groups may have changed due to the addition of a new primitive
        ** (new scan groups, dynamic attribute, or other primitives) in the DIO or its ancestor.
        ** To avoid the risk of running into primary key violations, do so in two stages:
        ** First update the sg_mx_primitive_id to -(new_sg_mx_primitive_id).
        ** Next, negate the negative sg_mx_primitive_ids.
        ** But to account for the firing of the trigger when we update object_device_linkage,
        ** we perform the second negation after we update the object-device linkages.
        */		
        UPDATE topic
           SET sg_mx_primitive_id = -csg.new_mx_primitive_id
          FROM autobind_device_topic AS topic
        INNER JOIN @changed_sg csg
            ON csg.dio_id = topic.dio_id
           AND csg.old_mx_primitive_id = topic.sg_mx_primitive_id


    		/*
    		** We have to delete topics whose 'sg_mx_primitive_id's clash with those just negated.
    		** But, before we do so, we need to move their 'autobound_attribute's to the topics
    		** with negated 'sg_mx_primitive_id's that correspond to theirs.
    		*/
    		UPDATE attr
    		   SET sg_mx_primitive_id = changed_topic.sg_mx_primitive_id
    		  FROM autobound_attribute attr
    		INNER JOIN autobind_device_topic topic
    		    ON topic.dio_id = attr.dio_id
    		   AND topic.sg_mx_primitive_id = attr.sg_mx_primitive_id
    		INNER JOIN autobind_device_topic changed_topic
    		    ON changed_topic.dio_id = topic.dio_id
    		   AND changed_topic.sg_mx_primitive_id = -topic.sg_mx_primitive_id
    		 WHERE changed_topic.dio_id = @dio_id
    		   AND changed_topic.sg_mx_primitive_id < 0

    		DELETE topic
    		  FROM autobind_device_topic topic
    		INNER JOIN autobind_device_topic changed_topic
    		    ON changed_topic.dio_id = topic.dio_id
    		   AND changed_topic.sg_mx_primitive_id = -topic.sg_mx_primitive_id
    		 WHERE changed_topic.dio_id = @dio_id
    		   AND changed_topic.sg_mx_primitive_id < 0

        --Updating object_device_linkage with changed modified scan group primitive ids
        UPDATE odl 
           SET odl.sg_mx_primitive_id = sgs.new_mx_primitive_id
          FROM object_device_linkage odl
        INNER JOIN @changed_sg sgs
            ON odl.dio_id = sgs.dio_id 
           AND odl.sg_mx_primitive_id = sgs.old_mx_primitive_id
         WHERE sgs.old_mx_primitive_id != sgs.new_mx_primitive_id

        -- Correct sg_mx_primitive_id in autobind_device_topic.
        UPDATE topic
           SET sg_mx_primitive_id = -sg_mx_primitive_id
          FROM autobind_device_topic AS topic
        INNER JOIN @changed_sg csg
            ON csg.dio_id = topic.dio_id
         WHERE topic.sg_mx_primitive_id < 0


        /*
        ** Add rows to topic that were newly added to the DIO: 
        ** This sproc is not passed the scan-groups that were newly added. 
        */
        INSERT INTO autobind_device_topic
        SELECT g.gobject_id, p.mx_primitive_id, NULL, 0
          FROM gobject g
        INNER JOIN primitive_instance p
            ON p.gobject_id = g.gobject_id
           AND p.package_id = g.checked_in_package_id
        INNER JOIN primitive_definition pd
            ON pd.primitive_definition_id = p.primitive_definition_id
           AND pd.primitive_name in ('S', 'SG', 'ScanGroup1')
        INNER JOIN template_definition t
            ON t.template_definition_id = g.template_definition_id
        INNER JOIN lookup_category lcat
            ON lcat.category_id = t.category_id
           AND lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
         WHERE g.is_template = 0
           AND g.gobject_id = @dio_id
        EXCEPT
        SELECT dio_id, ABS(sg_mx_primitive_id), NULL, 0 
          FROM autobind_device_topic 
         WHERE dio_id = @dio_id
    END
    --End HF CR L00137941, and
    -- CR L00139143 -->|
    ELSE
    BEGIN
        /*
        ** The case where this sproc isn't being called by internal_multi_object_checkin.
        */
        declare @scan_groups TABLE (dio_id int, mx_primitive_id smallint)

        -- Get the scan-groups assigned to @dio_id into our table variable
        INSERT INTO @scan_groups
        SELECT g.gobject_id, p.mx_primitive_id
          FROM gobject g
        INNER JOIN primitive_instance p
            ON p.gobject_id = g.gobject_id
           AND p.package_id = g.checked_in_package_id
        INNER JOIN primitive_definition pd
            ON pd.primitive_definition_id = p.primitive_definition_id
           AND pd.primitive_name in ('S', 'SG', 'ScanGroup1')
        INNER JOIN template_definition t
            ON t.template_definition_id = g.template_definition_id
        INNER JOIN lookup_category lcat
            ON lcat.category_id = t.category_id
           AND lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
         WHERE g.is_template = 0
           AND g.gobject_id = @dio_id

        DECLARE @not_in_pi  TABLE (dio_id int, mx_primitive_id smallint)

        -- Identify scan-groups that are in autobind_device_topic that aren't in primitive_instance.
        INSERT INTO @not_in_pi
        SELECT dio_id, sg_mx_primitive_id 
          FROM autobind_device_topic 
         WHERE dio_id = @dio_id
        EXCEPT
        SELECT dio_id, mx_primitive_id FROM @scan_groups

        -- Delete from object_device_linkage
        DELETE odl 
        OUTPUT deleted.gobject_id INTO @redeploy
          FROM object_device_linkage AS odl
        INNER JOIN @not_in_pi pin
            ON pin.dio_id = odl.dio_id
           AND pin.mx_primitive_id = odl.sg_mx_primitive_id
         WHERE odl.dio_id = @dio_id

        DELETE topic 
          FROM autobind_device_topic AS topic
        INNER JOIN @not_in_pi pin
            ON pin.dio_id = topic.dio_id
           AND pin.mx_primitive_id = topic.sg_mx_primitive_id 
         WHERE topic.dio_id = @dio_id

        -- Add rows to topic that were newly added to the DIO.
        INSERT INTO autobind_device_topic
        SELECT dio_id, mx_primitive_id, NULL, 0 FROM @scan_groups
        EXCEPT
        SELECT dio_id, sg_mx_primitive_id, NULL, 0 FROM autobind_device_topic WHERE dio_id = @dio_id
	END

    -- Mark affected objects that are deployed
    UPDATE g 
       SET deployment_pending_status = 1
    OUTPUT inserted.gobject_id INTO @updPxy
      FROM gobject g
    INNER JOIN @redeploy red
        ON red.gobject_id = g.gobject_id
     WHERE g.deployed_package_id != 0 
       AND g.deployment_pending_status = 0

    IF @@ROWCOUNT <> 0
    BEGIN
      -- Update proxy timestamp for affected objects: We don't want duplicate gobject_ids here.
      -- This is why the updated gobject_ids were OUTPUT to @updPxy in the previous update.
      UPDATE pt
         SET pt.gobject_id = up.gobject_id
    	FROM proxy_timestamp pt 
      INNER JOIN @updPxy up
          ON up.gobject_id = pt.gobject_id

      IF @@ROWCOUNT > 0
    	SET @refreshPxy = 1
    END

    RETURN @refreshPxy
end
go

