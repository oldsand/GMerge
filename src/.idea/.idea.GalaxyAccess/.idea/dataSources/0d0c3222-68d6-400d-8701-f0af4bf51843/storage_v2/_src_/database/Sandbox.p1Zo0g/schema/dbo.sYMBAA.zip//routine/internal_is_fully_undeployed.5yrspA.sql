
/*
This procedure will verify that input gobject_id = IsFullyUndeployed or not
usage:
declare @P1 int
exec internal_is_fully_undeployed
     gobject_id = 23, @P1
*/
CREATE  PROCEDURE dbo.internal_is_fully_undeployed
@gobject_id  int,
@isFullyUndeployed int  OUTPUT
 AS
begin
SET NOCOUNT ON
	set @isFullyUndeployed = 0

	select @isFullyUndeployed = count(gobject_id) from gobject 
	where (deployed_package_id = 0 and dbo.is_partner_deployed(gobject_id)= 0) 
	and gobject_id = @gobject_id


end

go

