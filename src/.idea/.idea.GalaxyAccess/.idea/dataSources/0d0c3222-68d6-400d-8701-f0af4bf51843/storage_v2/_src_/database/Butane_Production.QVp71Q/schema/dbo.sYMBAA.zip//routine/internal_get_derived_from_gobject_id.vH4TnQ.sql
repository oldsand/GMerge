create proc [dbo].[internal_get_derived_from_gobject_id]
@gobject_id int, 
@derived_from_gobject_id int OUTPUT

AS 
begin

set nocount on

	set @derived_from_gobject_id = -1

	select @derived_from_gobject_id = derived_from_gobject_id
	from gobject
	where  gobject_id = @gobject_id


end
go

