-- Set the migration in progress flag in the galaxy
--
create proc dbo.internal_set_galaxy_migrating_status
    @migrating bit
as
begin
    update  galaxy
    set     is_migration_in_progress = @migrating
    
    if (@migrating = 0)
    begin
        exec internal_bind_visual_element_references
    end
end



go

