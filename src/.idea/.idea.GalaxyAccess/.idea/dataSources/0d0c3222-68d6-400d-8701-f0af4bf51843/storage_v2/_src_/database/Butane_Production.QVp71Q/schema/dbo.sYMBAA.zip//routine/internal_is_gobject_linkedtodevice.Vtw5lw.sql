/**************************************************
Object Name :  internal_is_gobject_linkedtodevice
Object Type :  Stored Proc. 
Purpose	    :  This procedure tells wheter object is linked to any device or not.
Used By	    :  package server net
**************************************************/

CREATE PROCEDURE dbo.internal_is_gobject_linkedtodevice
(
	@gobject_d int,
	@islinkedtodevice int  OUTPUT
)
AS

begin
	SET NOCOUNT ON
	set @islinkedtodevice = 0
		
	if exists (select 1 from object_device_linkage where gobject_id = @gobject_d)
	begin
		set @islinkedtodevice = 1
	end
	
end
go

