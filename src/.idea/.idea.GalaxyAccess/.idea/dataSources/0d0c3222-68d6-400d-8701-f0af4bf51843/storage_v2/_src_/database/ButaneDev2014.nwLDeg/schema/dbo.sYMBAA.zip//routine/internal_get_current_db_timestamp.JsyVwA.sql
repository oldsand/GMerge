create procedure dbo.internal_get_current_db_timestamp
@current_proxy_timestamp bigint out,
@current_visual_element_timestamp bigint out,
@current_folder__timestamp bigint out
as
begin
	select 
		@current_proxy_timestamp = max_proxy_timestamp,
		@current_visual_element_timestamp = max_visual_element_timestamp,
		@current_folder__timestamp = max_proxy_timestamp
	from galaxy
end

go

