/**************************************************/
/*Object Name :  internal_get_deploy_info			  */
/*Object Type :  Stored Proc.					  */
/*Purpose	  :  Proc. to get list of Object Info */
/*               for deploying/undeploying a list */
/*				 of objects in a defined order of */
/*				-- Platform,FailoverEnableEngines,Other Engine,*/
/*				-- DINet,DIDevices,Area,Application Objects */
/*Used By	  :  CDI() */
/**************************************************/

create procedure dbo.internal_get_deploy_info
-- send list of object ids to sql as XMLDoc
@FileNameOfIds nvarchar(400)
AS
SET NOCOUNT ON
begin

    CREATE TABLE #gobject_ids (gobject_id int)    
    -- call the stored procedure 'internal_construct_table_from_file'
    EXEC internal_construct_table_from_file @FileNameOfIds, '#gobject_ids'
    --create this table where sorted list of gobjects will be stored


    declare @deploymentOrder_gobject_ids table (order_id int identity(1,1),gobject_id int)
    --FIRST Platform(Nodes)
    insert into @deploymentOrder_gobject_ids
        select
        gobject.gobject_id
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
            left join instance
        on instance.gobject_id = gobject.gobject_id
        where gobject.hosting_tree_level = 0 or gobject.hosting_tree_level = 1
        order by 
            gobject.hosting_tree_level asc, 
        	instance.mx_platform_id asc,
    	    instance.mx_engine_id asc,
			gobject.tag_name asc

    -- SORT NON-FAILOVER ENABLED ENGINES		
	insert into @deploymentOrder_gobject_ids
        select
        gobject.gobject_id
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
        left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id
	left join instance
	on instance.gobject_id = gobject.gobject_id
	where (gobject.hosting_tree_level = 2)	and (is_template = 0) and (gobject.namespace_id = 1) and (dbo.is_failover_enabled(gobject.tag_name) < 2) and not (template_definition.category_id = 25)
	order by 
	gobject.hosting_tree_level asc, 
	instance.mx_platform_id asc,
	gobject.tag_name asc


    --DEPLOY FAILOVER ENABLED ENGINES(GROUP THEM)
	insert into @deploymentOrder_gobject_ids
        select
        gobject.gobject_id
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
        left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id
	left join instance
	on instance.gobject_id = gobject.gobject_id
	where (gobject.hosting_tree_level = 2) and (is_template = 0) and (dbo.is_failover_enabled(gobject.tag_name)>1) and not (template_definition.category_id = 25)
	order by 
	gobject.hosting_tree_level asc, 
	gobject.tag_name asc,	
	gobject.namespace_id asc
	

	--THEN DI[IO]NETWORK AND DI[IO]DEVICE OBJECTS...
    insert into @deploymentOrder_gobject_ids
        select
            gobject.gobject_id
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
        left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id
        left join instance
            on instance.gobject_id = gobject.gobject_id
        where (template_definition.category_id = 11 or  
               template_definition.category_id = 12 )
        order by 
			instance.mx_platform_id asc,
            gobject.hosting_tree_level asc,         	
        	instance.mx_engine_id asc,
    	    gobject.tag_name asc


    --THEN REDUNDANT DI OR POST IO
    insert into @deploymentOrder_gobject_ids
        select
            gobject.gobject_id
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
        left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id
        left join instance
            on instance.gobject_id = gobject.gobject_id
        where (template_definition.category_id = 24)
        order by 
			instance.mx_platform_id asc,
            gobject.hosting_tree_level asc,         	
        	instance.mx_engine_id asc,
    	    gobject.tag_name asc

     ---THEN AREA 
    insert into @deploymentOrder_gobject_ids
        select
            gobject.gobject_id
        from #gobject_ids ids
        left join gobject
            on gobject.gobject_id = ids.gobject_id 
        left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id
        left join instance
            on instance.gobject_id = gobject.gobject_id
        where (template_definition.category_id = 13) 
        order by 
			instance.mx_platform_id asc,
            gobject.hosting_tree_level asc,         	
           	instance.mx_engine_id asc,            
        	gobject.tag_name asc 
    ---Then OTHER Application OBJECTS
    -- For application Objects we need the order based on Platform->Engine->Area-> Objects contained in Area 
    -- Create temporary table to get all the application Objects and there hosted_by_tag_name ..
    declare @applicationObj_gobject_ids table 
    (
		gobject_id int,
		hosted_by_gobject_id int, 
		hosted_by_tag_name nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS
	)   
    --- insert gobject and hosted_by_tag_name
    insert into @applicationObj_gobject_ids
        select gobject.gobject_id,gobject.hosted_by_gobject_id,N''  
        from #gobject_ids ids
        left join gobject
        on gobject.gobject_id = ids.gobject_id 
         left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id        
        where (template_definition.category_id = 10 or  template_definition.category_id = 17 or  template_definition.category_id = 26)
    --update hosted_by_tag_name	                   
    update @applicationObj_gobject_ids set hosted_by_tag_name = g.tag_name
    from @applicationObj_gobject_ids a inner join gobject g 
    on a.hosted_by_gobject_id = g.gobject_id
    -----------------------------------insert applicationObjects in @deploymentOrder_gobject_ids..
    insert into @deploymentOrder_gobject_ids
    select
        gobject.gobject_id
    from @applicationObj_gobject_ids ids
    left join gobject
        on gobject.gobject_id = ids.gobject_id 
    left join template_definition
        on template_definition.template_definition_id = gobject.template_definition_id
    left join instance
        on instance.gobject_id = gobject.gobject_id
    where (template_definition.category_id = 10 or  template_definition.category_id = 17 or  template_definition.category_id = 26 )
    order by 
		instance.mx_platform_id asc,
        gobject.hosting_tree_level asc,         	
    	instance.mx_engine_id asc,
        ids.hosted_by_tag_name asc,         	
    	gobject.tag_name asc    

    -- Create temporary table to get all the custom Objects and there hosted_by_tag_name ..
   declare @customObj_gobject_ids table 
   (
		gobject_id int,
		hosted_by_gobject_id int, 
		hosted_by_tag_name nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS
	)   
    --- insert gobject and hosted_by_tag_name
    insert into @customObj_gobject_ids
        select gobject.gobject_id,gobject.hosted_by_gobject_id,N''  
        from #gobject_ids ids
        left join gobject
        on gobject.gobject_id = ids.gobject_id 
         left join template_definition
            on template_definition.template_definition_id = gobject.template_definition_id        
        where (template_definition.category_id = 25)        
    --update hosted_by_tag_name	                   
    update @customObj_gobject_ids set hosted_by_tag_name = g.tag_name
    from @customObj_gobject_ids a inner join gobject g 
    on a.hosted_by_gobject_id = g.gobject_id

    -----------------------------------insert customObjects in @deploymentOrder_gobject_ids..
    insert into @deploymentOrder_gobject_ids
    select
        gobject.gobject_id
    from @customObj_gobject_ids ids
    left join gobject
        on gobject.gobject_id = ids.gobject_id 
    left join template_definition
        on template_definition.template_definition_id = gobject.template_definition_id
    left join instance
        on instance.gobject_id = gobject.gobject_id
    where (template_definition.category_id = 25 )
    order by 
		instance.mx_platform_id asc,
        gobject.hosting_tree_level asc,         	
    	instance.mx_engine_id asc,
        ids.hosted_by_tag_name asc,         	
    	gobject.tag_name asc 

    --Get the ObjectInfo of all the above sorted Objects
    select
        gobject.gobject_id,
        gobject.tag_name,
        gobject.hosting_tree_level,
        template_definition.category_clsid category_clsid,
        gobject.hosted_by_gobject_id hosted_by_gobject_id,
        case gobject.deployed_package_id when 0 then 0 else 1 end as is_deployed,
        case host.deployed_package_id when 0 then 0 else 1 end as host_deployed,
		case when (gobject.deployed_package_id <> 0) 
			and ((gobject.deployment_pending_status <> 0) or (checked_in_package.deployable_configuration_version 
			<> deployed_package.deployable_configuration_version))
				then 1	else 0 	end as has_pending_updates,		        
        gobject.checked_in_package_id checked_in_package_id,
        gobject.checked_out_package_id checked_out_package_id,
        instance.mx_platform_id,
        instance.mx_engine_id,
        instance.mx_object_id,
        template_definition.category_id,
        gobject.deployed_package_id,
        gobject.last_deployed_package_id,
        package.status_id,
    	gobject.software_upgrade_needed,
		dbo.can_deploy_object_delta(gobject.gobject_id)
		
    from @deploymentOrder_gobject_ids ids 
    left join gobject
        on gobject.gobject_id = ids.gobject_id
    left join gobject host
        on gobject.hosted_by_gobject_id = host.gobject_id
    left join template_definition
        on template_definition.template_definition_id = gobject.template_definition_id
    left join instance
        on instance.gobject_id = gobject.gobject_id
    left join package
        on package.gobject_id = gobject.gobject_id and package.package_id = gobject.checked_in_package_id
	left join package checked_in_package   on 
		gobject.gobject_id = checked_in_package.gobject_id and 
		gobject.checked_in_package_id = checked_in_package.package_id
	left join package deployed_package  on 
		gobject.gobject_id = deployed_package.gobject_id and 
		gobject.deployed_package_id = deployed_package.package_id
	order by order_id asc
	---drop the table 
	DROP TABLE #gobject_ids

end



go

