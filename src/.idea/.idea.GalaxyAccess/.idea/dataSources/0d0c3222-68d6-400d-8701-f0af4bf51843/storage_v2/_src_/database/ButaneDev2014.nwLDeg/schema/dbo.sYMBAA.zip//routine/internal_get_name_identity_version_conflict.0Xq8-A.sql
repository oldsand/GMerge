-- 
-- return       1   when the name does not exists in the database
--              5   when name exists but the object is checked out ( applies for derived objects )
--              2   if object with same code base does not exists in the galaxy
--              3   if the minor version of the objects are different even if code base is same
--              4   if object exists with all the conditions satisfied.
create proc dbo.internal_get_name_identity_version_conflict
@tagname nvarchar(329),
@codebase nvarchar(322),
@configversion  int,
@namespaceid int,
@is_protected int,
@returnval int out,
@gobject_id int out
as
begin
set @gobject_id = 0

declare @gobjid int
set @gobjid = 0
set @gobjid = (select gobject_id from gobject where tag_name = @tagname and namespace_id = @namespaceid)  


if @gobjid > 0  and @gobjid is not null-- name exists in the database
begin
  set @gobject_id = @gobjid
  declare @check_out_id int
  set @check_out_id = 0
  set @check_out_id = (select checked_out_package_id from gobject where gobject_id = @gobjid)
  if ( @check_out_id = 0 )
    begin
    -- find out if the codebase are same
    declare @countcodebase int
    set @countcodebase = 0
    set @countcodebase = (select count(*) from template_definition td
						 where td.template_definition_id = (select tempd.template_definition_id 
										from gobject g,template_definition tempd 
										where g.gobject_id = @gobjid 
										and g.template_definition_id = tempd.template_definition_id
										and tempd.codebase = @codebase ) )

    --START
	--Check whether the object is protected or not
	declare @is_gobject_protected int
	set @is_gobject_protected = 0
	if exists (select '*' from gobject_protected where gobject_id = @gobjid)
	begin
			set @is_gobject_protected = 1
	end
    -- the existing object's codebase is same as input codebase 
    if (@countcodebase = 1)  
      begin
        --If Its ClientControl always return 2 so it get renamed
        if (charindex(N'.ClientControl.',@codebase) > 0) 
		begin
			if(@is_protected = 1 and @is_gobject_protected = 1)
				set @returnval = 10 --Code base diff and both Source and Target are protected
			else if (@is_gobject_protected = 1)
				set @returnval = 9 --Code base diff and target is protected
			else if (@is_protected = 1)
				set @returnval = 8 --Code base diff and source is protected
			else
				set @returnval = 2
		end
        else
		begin
			declare @dbconfigversion int
			set @dbconfigversion = 0
			set @dbconfigversion = (select configuration_version from gobject where gobject_id = @gobjid)		
			
			if ( @is_gobject_protected <> @is_protected and @is_protected = 1 )
				begin
					if (@dbconfigversion >= @configversion)
					begin
						set @returnval = 12 -- Here source is protected and target is unprotected   //CR125564: modified for
					end
					--else 
					--if (@dbconfigversion = @configversion)
					--	set @returnval = 7 --Mark protected
					else
						set @returnval = 6 --protected overwrite
				end
			else if (@is_gobject_protected = @is_protected)
				begin
					if @dbconfigversion >= @configversion -- the configuration version of tagname object is same as input config version
					begin
							set @returnval = 4 -- same object skip it
					end
					else
						set @returnval = 3 -- simple return
				end
			else if  @is_gobject_protected = 1
				begin
					 set @returnval = 11  --protected in galaxy
				end
			else
				set @returnval = 4  -- same object skip it
			--END
			
			--if @dbconfigversion >= @configversion -- the configuration version of tagname object is same as input config version
			--begin
			--	set @returnval = 4
			--end
			--else
			--	set @returnval = 3
		end
      end
	else
		begin
			if(@is_protected = 1 and @is_gobject_protected = 1)
				set @returnval = 10 --Code base diff and both Source and Target are protected
			else if (@is_gobject_protected = 1)
				set @returnval = 9 --Code base diff and target is protected
			else if (@is_protected = 1)
				set @returnval = 8 --Code base diff and source is protected
			else
				set @returnval = 2
		end
    end
	else
		set @returnval = 5
end
else
begin
    declare @galaxy_gobject_id integer
    select @galaxy_gobject_id =  gobject_id from gobject g
    inner join template_definition td 
    on g.template_definition_id = td.template_definition_id
    and td.category_id = 23
    where g.is_template = 0

    if exists(select tag_name from gobject where 
        tag_name = @tagname and gobject_id = @galaxy_gobject_id)
    begin
        set @returnval = 4
    end
    else
    begin
		set @returnval = 1
        set @gobject_id = 0
    end
end
end
/*
-- Test code below if required to test for any object
declare @tagname nvarchar(32)
set @tagname = 'SystemArea'
declare @codebase as nvarchar(320)
set @codebase = 'ArchestrA.Area.1'
declare @cv int
set @cv = 3
declare @returnval int
set @returnval = 0
declare @gobjectid int
set @gobjectid = 0
exec internal_get_name_identity_version_conflict @tagname,@codebase,@cv,@returnval output,@gobjectid output
print @gobjectid
print @returnval
*/
go

