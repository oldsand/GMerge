
-- Checks whether embedding a given visual element references in 
-- another visaul element will cause a circular reference.
--
-- Reference checking is done relative visual elements visible
-- to the user that the destination visual element is checked out to.
--
-- If embedding into a template, instance references to the exact visual
-- element being referenced are checked.
create proc dbo.internal_will_embed_cause_circular_reference
	@visual_element_container int,
	@visual_element_to_embed int,    
    @can_cause_circular_reference bit output
as 
begin
    begin tran

    -- initialize output to false
    set @can_cause_circular_reference = 0

    -- get user that the object is checked out to
    declare @user_guid uniqueidentifier
    select @user_guid = g.checked_out_by_user_guid
    from visual_element_version vev 
    inner join gobject g on
        g.checked_out_package_id = vev.package_id
    where vev.visual_element_id = @visual_element_container

    -- if not checked out, it will revert to system engineer    
    if @user_guid is null
    begin
        select @user_guid = user_guid 
        from user_profile 
        where user_profile_name = 'SystemEngineer'
    end
    
    declare @input table
    ( 
        visual_element_id int primary key 
    )

    insert @input (visual_element_id) values (@visual_element_to_embed)

    declare @all table
    (
        visual_element_id int primary key
    )
    
    insert @all select * from @input

    declare @next table
    (
        visual_element_id int primary key
    )

    declare @prev table
    (
        visual_element_id int primary key
    )

    insert @prev select * from @input

    while @@rowcount > 0 -- note, rowcount initially from insert @prev, then from delete @next
    begin
        -- exit if we found a circular reference on the last pass
        if exists (
            -- check in self and all derived visual elements
            select 1 from @prev where visual_element_id in ( 
                select visual_element_id 
                from visual_element_version 
                where inherited_from_visual_element_id = @visual_element_container ) )
        begin
            set @can_cause_circular_reference = 1
            break
        end

        insert into @next
        select distinct( bound_vev.visual_element_id ) from @prev p
        inner join visual_element_version vev on 
            p.visual_element_id = vev.visual_element_id
        inner join internal_visible_packages_per_user_view vp on
            vp.package_id = vev.package_id 
            and vp.user_guid = @user_guid
        inner join visual_element_reference bver on
            bver.gobject_id = vev.gobject_id
            and bver.package_id = vev.package_id
            and bver.mx_primitive_id = vev.mx_primitive_id
        inner join visual_element_version bound_vev on
             bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
              bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
              bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
        inner join visual_element ve on
            bound_vev.visual_element_id = ve.visual_element_id
            and ve.visual_element_category = 'E' -- only check embedding type references
        where bound_vev.visual_element_id not in (select visual_element_id from @all )
        union
        select distinct( bound_vev.visual_element_id ) from @prev p
        inner join visual_element_version vev on 
            p.visual_element_id = vev.visual_element_id
        inner join internal_visible_packages_per_user_view vp on
            vp.package_id = vev.package_id 
            and vp.user_guid = @user_guid
        inner join visual_element_reference bver on
            bver.gobject_id = vev.gobject_id
            and bver.package_id = vev.package_id
            and bver.mx_primitive_id = vev.mx_primitive_id
        inner join visual_element_version bound_vev on
             bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
              bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
              bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
        inner join visual_element ve on
            bound_vev.visual_element_id = ve.visual_element_id
            and ve.visual_element_category = 'E' -- only check embedding type references
        where bound_vev.visual_element_id not in (select visual_element_id from @all )


        insert into @all select * from @next
        delete from @prev
        insert into @prev select * from @next
        delete from @next
    end

    commit tran
end
go

