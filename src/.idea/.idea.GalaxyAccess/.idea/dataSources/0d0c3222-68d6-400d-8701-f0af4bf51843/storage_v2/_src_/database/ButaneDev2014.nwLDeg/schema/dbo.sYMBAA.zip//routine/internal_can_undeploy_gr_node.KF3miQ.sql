/**************************************************/
/*Object Name :  internal_can_undeploy_gr_node			  */
/*Object Type :  Stored Proc.					  */
/*Purpose	  :  Proc. to verify that whether GRNode can be undeployed or not*/
/*Used By	  :  CDI() */
/**************************************************/

CREATE  procedure dbo.internal_can_undeploy_gr_node
@CanDeploy int out
AS
SET NOCOUNT ON
begin

Declare @DeployedPlatformCount  int
select @DeployedPlatformCount = count(*) from 
 	gobject INNER JOIN
	platform ON gobject.gobject_id = platform.platform_gobject_id
WHERE  (gobject.deployed_package_id <> 0)

if(@DeployedPlatformCount > 1)
	set @CanDeploy = 0
else
	set @CanDeploy = 1


end


go

