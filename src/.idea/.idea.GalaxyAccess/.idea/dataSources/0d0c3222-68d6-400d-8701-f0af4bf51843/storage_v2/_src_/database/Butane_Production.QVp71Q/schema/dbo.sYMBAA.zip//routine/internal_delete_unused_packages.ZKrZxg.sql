-- Removes all packages that are no longer referred to
-- directly or indirectly by any gobject
--
-- This exists because template packages are currently 
-- not deleted when a new template package is checked in.
create proc dbo.internal_delete_unused_packages 
@all_finished int output
as
begin
  set nocount on
      declare @num_rows int
	  declare @package_to_be_deleted table (gobject_id int, package_id int, rec_no int IDENTITY (1,1) not null)
	  
	  /* CR L00115843: Query rewritten so as to be invoked just once. */
	  insert into @package_to_be_deleted (gobject_id, package_id)
	  select top(2)package.gobject_id, package.package_id
	  from package
      where not exists (
        select * from gobject
          where gobject.checked_in_package_id = package.package_id
            or gobject.checked_out_package_id = package.package_id
            or gobject.deployed_package_id = package.package_id
            or gobject.last_deployed_package_id = package.package_id )
        and not exists (
          select * from package p2 where p2.derived_from_package_id = package.package_id )

		set @num_rows = @@ROWCOUNT
		if(@num_rows >0)
		begin
		begin tran
		delete p	
		from @package_to_be_deleted t
		inner join package p on
			t.gobject_id = p.gobject_id and
			t.package_id = p.package_id
		where
			t.rec_no = 1
		commit
		end

			
		if @num_rows > 1
		begin
			set @all_finished = 1
		end
		else
		begin 
			set @all_finished = 0
		end
				
end
go

