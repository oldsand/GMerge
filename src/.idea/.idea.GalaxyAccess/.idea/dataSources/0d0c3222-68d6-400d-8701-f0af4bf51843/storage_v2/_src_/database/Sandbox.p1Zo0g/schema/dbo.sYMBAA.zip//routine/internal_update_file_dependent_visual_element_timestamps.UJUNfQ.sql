create procedure dbo.internal_update_file_dependent_visual_element_timestamps
@file_id int
as
begin tran

	-- Find all client controls using this file
	-- Find all visual elements using the client controls
	-- update the visual elements' timestamps

	create  table #input_table1
	(
		gobject_id int,
		package_id int,
		mx_primitive_id smallint,
		visual_element_id int
	)   
    

	insert into #input_table1 
    select  distinct
			vev.gobject_id,
			vev.package_id,
			vev.mx_primitive_id,
			vev.visual_element_id
    from primitive_instance_file_table_link piftl 
    inner join primitive_instance pri on
            piftl.gobject_id = pri.gobject_id and
            piftl.package_id = pri.package_id and
            piftl.mx_primitive_id = pri.parent_mx_primitive_id 
    inner join visual_element_version vev on
            pri.gobject_id = vev.gobject_id and
            pri.package_id = vev.package_id and
            pri.mx_primitive_id = vev.mx_primitive_id 
	where piftl.file_id = @file_id


    create table #output_table1 
		(
     gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_id int
    )
	create table #next_selection1 
    (
     gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_id int
    )
	
	insert into #output_table1
		select * from #input_table1 
 
    while( 1 = 1 )
    begin   

        insert into #next_selection1    
	select distinct
			parent.gobject_id,
			parent.package_id,
			parent.mx_primitive_id,
			vev.visual_element_id
		from #input_table1 it
		inner join visual_element_reference b on
			 (b.checked_in_bound_visual_element_gobject_id = it.gobject_id and
			  b.checked_in_bound_visual_element_package_id = it.package_id and
			  b.checked_in_bound_visual_element_mx_primitive_id = it.mx_primitive_id) 
		inner join primitive_instance parent on 
			  parent.gobject_id = b.gobject_id and
			  parent.package_id = b.package_id and
			  parent.mx_primitive_id = b.mx_primitive_id	
		inner join visual_element_version vev on
			  vev.gobject_id = b.gobject_id and
			  vev.package_id = b.package_id and
			  vev.mx_primitive_id = b.mx_primitive_id
        left outer join #output_table1 ot on
			 ot.visual_element_id = vev.visual_element_id
             where	ot.visual_element_id is NULL
        
		truncate table #input_table1 		

        insert into #input_table1(gobject_id,package_id,mx_primitive_id,visual_element_id)
	        select gobject_id,package_id,mx_primitive_id,visual_element_id from #next_selection1 
		
        insert into #output_table1
	         select * from #next_selection1 

        truncate table #next_selection1
 
        
		if(@@ROWCOUNT = 0)
			break
    end
    
	insert into visual_element_timestamp
	( 
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_id,
		change_type
	)
	select 
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_id,
		1
	from #output_table1


	
	update galaxy 
	set max_visual_element_timestamp = cast(@@dbts as bigint)

	drop table #input_table1
	drop table #next_selection1
	drop table #output_table1
	
	
commit
go

