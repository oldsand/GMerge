
--***********************************************************************************************************************
--***      
--***      OBJECT NAME:            is_partner_deployed
--***      DESCRIPTION:  Function is used to find out if a gobject's failover partner is deployed or not
--***      
--***      USAGE:                        dbo.is_partner_deployed(23) --(where 23 is the gobject's id)
--***                              Function is used by view: internal_proxyobj
--***      RETURNS :
--***      =========
--***      0 - if failover partner is not deployed
--***      1 - if failover partner is deployed
--***      
--***********************************************************************************************************************

create function dbo.is_partner_deployed( 
            @gobject_id int
            )
returns smallint

as
begin

            declare @is_partner_deployed smallint       

            select  @is_partner_deployed =
			(case when  (deployed_package_id = 0) 
				then '0' 
			else '1' end) 
			from gobject where gobject_id = dbo.get_failover_partner_id(@gobject_id) 

            select @is_partner_deployed = isnull(@is_partner_deployed,0)

            return @is_partner_deployed

                       
end
go

