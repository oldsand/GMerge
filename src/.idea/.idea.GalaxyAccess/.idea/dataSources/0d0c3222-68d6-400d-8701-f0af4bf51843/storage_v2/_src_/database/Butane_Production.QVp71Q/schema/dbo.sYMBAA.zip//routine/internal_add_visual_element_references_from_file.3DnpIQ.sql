create proc dbo.internal_add_visual_element_references_from_file
    @gobject_id int,
    @package_id int,
    @visual_element_reference_file_path nvarchar(255),
	@is_association int
as
begin
 
    begin tran

    -- load from file into temp table
    delete from visual_element_reference
    where gobject_id = @gobject_id and  
          package_id = @package_id
    
    CREATE TABLE #visual_element_reference
    (
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        reference_string nvarchar(3620) COLLATE SQL_Latin1_General_CP1_CI_AS  ,
        is_relative_reference bit not null,
        visual_element_id int default 0
    ) 

    /* CR L00115843: Start */
    DECLARE @visual_element_reference_parsed TABLE
    (
		gobject_id							int not null,
		package_id							int not null,
		mx_primitive_id						smallint not null,
		visual_element_reference_index		int,
        visual_element_id					int default 0,
		visual_element_name					nvarchar(362),
		visual_element_type					nvarchar(329),
		tag_name							nvarchar(32),
		primitive_name						nvarchar(329),
		is_relative_reference				bit,
		relative_object_name				nvarchar(329),
		is_hierarchical_visual_element_name bit
    )
    /* CR L00115843: End */
    
    declare @commandText nvarchar(2000)
    set @commandText = 'bulk insert #visual_element_reference  from ''' 
        + @visual_element_reference_file_path + ''' 
                        with (fieldterminator = '','', tablock, datafiletype  = ''widechar'') '
    exec sp_executesql @commandText

    -- add each reference from temp table
    declare visual_element_reference_cursor cursor fast_forward for
            select 
            mx_primitive_id,
            visual_element_reference_index,
            reference_string,
            is_relative_reference,
            visual_element_id
        from #visual_element_reference
 
    open visual_element_reference_cursor
    while( 1=1 )
    begin
        declare @mx_primitive_id smallint
        declare @visual_element_reference_index int
        declare @reference_string nvarchar(3620)
        declare @visual_element_id int
 
		/* CR L00115843: Start */
		declare @visual_element_name nvarchar(362)
		declare @visual_element_type nvarchar(329)
		declare @tag_name nvarchar(32)
		declare @primitive_name nvarchar(329)
		declare @is_relative_reference bit
		declare @is_relative_reference_orig bit		
		declare @relative_object_name nvarchar(329)
		declare @is_hierarchical_visual_element_name bit
        /* CR L00115843: End */
        
        fetch next from visual_element_reference_cursor into
            @mx_primitive_id,
            @visual_element_reference_index,
            @reference_string,
            @is_relative_reference_orig,
            @visual_element_id
 
        if( @@fetch_status <> 0 ) break
		/* CR L00115843: Start */
        --exec internal_add_visual_element_reference 
        --    @gobject_id, 
        --    @package_id, 
        --    @mx_primitive_id, 
        --    @visual_element_reference_index,
        --    @reference_string,
        --    @visual_element_id
        
		set @relative_object_name = ''
		-- break the reference down into its parts
		set @primitive_name = N'' -- initialize out param
		exec internal_parse_visual_element_reference_string
			@reference_string,
			@visual_element_type output,
			@tag_name output,
			@primitive_name output,
			@visual_element_name output,
			@is_relative_reference output,
			@relative_object_name output,
			@is_hierarchical_visual_element_name output

       
		if(@is_relative_reference = 1)  
		begin
			-- the tag_name is not relevant, so we will not store it..
			set @tag_name = null
		end
		
		INSERT INTO @visual_element_reference_parsed
		VALUES (
            @gobject_id, 
            @package_id, 
            @mx_primitive_id, 
            @visual_element_reference_index,
			@visual_element_id,
			@visual_element_name,
			@visual_element_type,
			@tag_name,
			@primitive_name,
	  	    case when @is_association = 1
			then @is_relative_reference_orig
		    else @is_relative_reference
			end,
			@relative_object_name,
			@is_hierarchical_visual_element_name
		)
		/* CR L00115843: End */
    end
    close visual_element_reference_cursor
    deallocate visual_element_reference_cursor
 
    drop table #visual_element_reference
	/* CR L00115843: Start */
    -- add to visual_element_reference table
	if (@is_association = 0)
    begin
    INSERT INTO visual_element_reference 
    (
        gobject_id, 
        package_id, 
        mx_primitive_id,
        visual_element_reference_index,
        --visual_element_bind_status, -- this is now a calculated column....
        is_relative_reference,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id ,
        checked_out_bound_visual_element_gobject_id ,
        checked_out_bound_visual_element_package_id ,
        checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        checked_in_unbound_visual_element_name ,
        checked_in_unbound_visual_element_type ,
        checked_in_unbound_tag_name  ,
        checked_in_unbound_primitive_name ,
        checked_in_unbound_relative_object_name  ,
        checked_in_unbound_visual_element_id,
        checked_out_unbound_visual_element_name ,
        checked_out_unbound_visual_element_type ,
        checked_out_unbound_tag_name  ,
        checked_out_unbound_primitive_name,
        checked_out_unbound_relative_object_name  ,
        checked_out_unbound_visual_element_id,
        checked_out_to_user_guid
       

    ) 
    SELECT
        gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        --0, --visual_element_bind_status -- this is now a calculated column....
        is_relative_reference,
        null,--checked_in_bound_visual_element_gobject_id ,
        null,--checked_in_bound_visual_element_package_id ,
        null,--checked_in_bound_visual_element_mx_primitive_id ,
        null,--checked_out_bound_visual_element_gobject_id ,
        null,--checked_out_bound_visual_element_package_id ,
        null,--checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        visual_element_name,--checked_in_unbound_visual_element_name ,
        visual_element_type,--checked_in_unbound_visual_element_type ,
        tag_name,--checked_in_unbound_tag_name,
        primitive_name,--checked_in_unbound_primitive_name not ,
        relative_object_name,--checked_in_unbound_relative_object_name  ,
        visual_element_id,--checked_in_unbound_visual_element_id,
        visual_element_name,--checked_out_unbound_visual_element_name ,
        visual_element_type,--checked_out_unbound_visual_element_type ,
        tag_name,--checked_out_unbound_tag_name  ,
        primitive_name,--checked_out_unbound_primitive_name ,
        relative_object_name,--checked_out_unbound_relative_object_name  ,
        visual_element_id,--checked_out_unbound_visual_element_id
        null--checked_out_to_user_guid
    FROM
		@visual_element_reference_parsed
    end
	else
	begin
    INSERT INTO visual_element_reference 
    (
        gobject_id, 
        package_id, 
        mx_primitive_id,
        visual_element_reference_index,
        --visual_element_bind_status, -- this is now a calculated column....
        is_relative_reference,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id ,
        checked_out_bound_visual_element_gobject_id ,
        checked_out_bound_visual_element_package_id ,
        checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        checked_in_unbound_visual_element_name ,
        checked_in_unbound_visual_element_type ,
        checked_in_unbound_tag_name  ,
        checked_in_unbound_primitive_name ,
        checked_in_unbound_relative_object_name  ,
        checked_in_unbound_visual_element_id,
        checked_out_unbound_visual_element_name ,
        checked_out_unbound_visual_element_type ,
        checked_out_unbound_tag_name  ,
        checked_out_unbound_primitive_name,
        checked_out_unbound_relative_object_name  ,
        checked_out_unbound_visual_element_id,
        checked_out_to_user_guid
       

    ) 
    SELECT
        gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        --0, --visual_element_bind_status -- this is now a calculated column....
        is_relative_reference,
        null,--checked_in_bound_visual_element_gobject_id ,
        null,--checked_in_bound_visual_element_package_id ,
        null,--checked_in_bound_visual_element_mx_primitive_id ,
        null,--checked_out_bound_visual_element_gobject_id ,
        null,--checked_out_bound_visual_element_package_id ,
        null,--checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        visual_element_name,--checked_in_unbound_visual_element_name ,
        visual_element_type,--checked_in_unbound_visual_element_type ,
        tag_name,--checked_in_unbound_tag_name,
        primitive_name,--checked_in_unbound_primitive_name not ,
        relative_object_name,--checked_in_unbound_relative_object_name  ,
        visual_element_id,--checked_in_unbound_visual_element_id,
        visual_element_name,--checked_out_unbound_visual_element_name ,
        visual_element_type,--checked_out_unbound_visual_element_type ,
        tag_name,--checked_out_unbound_tag_name  ,
        primitive_name,--checked_out_unbound_primitive_name ,
        relative_object_name,--checked_out_unbound_relative_object_name  ,
        visual_element_id,--checked_out_unbound_visual_element_id
        null--checked_out_to_user_guid
    FROM
		@visual_element_reference_parsed
	where is_relative_reference = 0

    INSERT INTO visual_element_reference 
    (
        gobject_id, 
        package_id, 
        mx_primitive_id,
        visual_element_reference_index,
        --visual_element_bind_status, -- this is now a calculated column....
        is_relative_reference,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id ,
        checked_out_bound_visual_element_gobject_id ,
        checked_out_bound_visual_element_package_id ,
        checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        checked_in_unbound_visual_element_name ,
        checked_in_unbound_visual_element_type ,
        checked_in_unbound_tag_name  ,
        checked_in_unbound_primitive_name ,
        checked_in_unbound_relative_object_name  ,
        checked_in_unbound_visual_element_id,
        checked_out_unbound_visual_element_name ,
        checked_out_unbound_visual_element_type ,
        checked_out_unbound_tag_name  ,
        checked_out_unbound_primitive_name,
        checked_out_unbound_relative_object_name  ,
        checked_out_unbound_visual_element_id,
        checked_out_to_user_guid
       

    ) 
    SELECT
        v.gobject_id,
        v.package_id,
        v.mx_primitive_id,
        v.visual_element_reference_index,
        --0, --visual_element_bind_status -- this is now a calculated column....
        v.is_relative_reference,
        g.gobject_id,--checked_in_bound_visual_element_gobject_id ,
        g.checked_in_package_id,--checked_in_bound_visual_element_package_id ,
        101,--checked_in_bound_visual_element_mx_primitive_id ,
        null,--checked_out_bound_visual_element_gobject_id ,
        null,--checked_out_bound_visual_element_package_id ,
        null,--checked_out_bound_visual_element_mx_primitive_id ,
    
        -- unbound section
        null,--checked_in_unbound_visual_element_name ,
        null,--checked_in_unbound_visual_element_type ,
        null,--checked_in_unbound_tag_name,
        null,--checked_in_unbound_primitive_name not ,
        null,--checked_in_unbound_relative_object_name  ,
        null,--checked_in_unbound_visual_element_id,
        null,--checked_out_unbound_visual_element_name ,
        null,--checked_out_unbound_visual_element_type ,
        null,--checked_out_unbound_tag_name  ,
        null,--checked_out_unbound_primitive_name ,
        null,--checked_out_unbound_relative_object_name  ,
        null,--checked_out_unbound_visual_element_id
        null--checked_out_to_user_guid
    FROM
		@visual_element_reference_parsed v
	inner join gobject g on
		g.tag_name = v.tag_name
	where is_relative_reference = 1
    end

	/* CR L00115843: End */
 
    -- drop table #visual_element_reference_parsed
 
 
    declare @parent_package_type nchar
    declare @parent_package_id int -- CR L00123287 cloned from HF CR# L00123250 
 
    select  @parent_package_type = parent_package.package_type,
            @parent_package_id = parent_package.package_id
    from package parent_package
    inner join package own_package on
        parent_package.package_id = own_package.derived_from_package_id and
        own_package.package_id = @package_id and
        own_package.gobject_id = @gobject_id
        
 
 
    exec internal_add_visual_element_references_from_parent
        @gobject_id,
        @package_id,
        @parent_package_type,
        @parent_package_id -- CR L00123287 cloned from HF CR# L00123250 
 
    -- bind the references....
    exec internal_bind_relative_visual_elements_for_gobject
            @gobject_id ,
            @package_id
    
    exec internal_bind_visual_element_references
 
    commit tran
    
end
go

