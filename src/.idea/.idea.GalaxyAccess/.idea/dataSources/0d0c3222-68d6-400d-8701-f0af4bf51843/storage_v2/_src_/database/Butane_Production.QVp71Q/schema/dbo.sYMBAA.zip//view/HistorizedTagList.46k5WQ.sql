create view [dbo].[HistorizedTagList] as
select Prefix SitePrefix,
		_go.gobject_id,
		_go.tag_name ObjectName,
		_pi.primitive_name AttributeName,
		concat( _go.tag_name, '.', _pi.primitive_name) TagName
from [SXLButane_Tables].dbo.SiteList
join gobject _go on tag_name LIKE concat(Prefix, '%') and is_template = 0
join primitive_instance _pi on _go.gobject_id = _pi.gobject_id and _go.deployed_package_id = _pi.package_id and _pi.execution_group = 18
go

