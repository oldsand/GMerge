-- Unassigns gobject @gobject_id from its host.
create proc dbo.internal_unassign_host
    @gobject_id int
as
begin

declare @host_tree_level	int
declare @mx_platform_id		int
declare @mx_engine_id		int

set @host_tree_level = (select hosting_tree_level from gobject where gobject_id = @gobject_id)

-- reset host in gobject table
update gobject set hosted_by_gobject_id = 0, hosting_tree_level = 0
where gobject_id = @gobject_id

if @host_tree_level = 2  -- the child is an engine
	begin
		-- get the current mx_platform_id and mx_engine_id of this object
		select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id
		from instance where gobject_id = @gobject_id

		-- zero out mx_ids of this engine and all hosted objects ( on this engine )
		update instance set mx_platform_id = 0, mx_engine_id = 0,  mx_object_id = 0
		where mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id

		-- zero out the hosting tree level
		update gobject set hosting_tree_level = 0 
		where hosted_by_gobject_id = @gobject_id OR gobject_id = @gobject_id
	end
else if @host_tree_level = 3  -- the child is an area
	begin
		-- get the current mx_platform_id and mx_engine_id of this object
		select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id
		from instance where gobject_id = @gobject_id

		-- zero out mx_ids of this object and its hosted objects
		update instance set mx_platform_id = 0, mx_engine_id = 0,  mx_object_id = 0
		where mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id and
		gobject_id in ( select g.gobject_id from gobject g 
						inner join instance i on g.gobject_id = i.gobject_id 
						where hosted_by_gobject_id = @gobject_id OR g.gobject_id = @gobject_id )

		-- zero out the hosting tree level
		update gobject set hosting_tree_level = 0 
		where hosted_by_gobject_id = @gobject_id OR gobject_id = @gobject_id
	end
else if @host_tree_level = 4  -- the child is AppObject, etc...
	begin
		-- get the ids of this object and all its descendants ( in the container )
		declare @contain_level int
		declare @descendant table( objectId int, depth int )
		set @contain_level = 0

		insert into @descendant values(@gobject_id, @contain_level)

		while (select COUNT(*) from  @descendant where depth = @contain_level) > 0 
		begin

			-- get the children of the next level
			insert into @descendant  (objectId, depth)	
   			select gobject_id, @contain_level + 1
   			from gobject where contained_by_gobject_id in (select objectId from @descendant where depth = @contain_level)

			-- increment the depth for each level
			set @contain_level = @contain_level + 1
		end

		-- zero out mx_ids all objects under this container
		update instance set mx_platform_id = 0, mx_engine_id = 0,  mx_object_id = 0
		where gobject_id in ( select objectId from @descendant )

		-- zero out all hosting_tree_level under this container
		update gobject set hosting_tree_level = 0 
		where gobject_id in ( select objectId from @descendant )

	end

end -- store-proc
go

