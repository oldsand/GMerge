
-- ***
-- ***    Returns a list of all visual elements that
-- ***    an InTouchViewapp needs to deploy.
-- ***
-- **************************************************
create proc dbo.internal_get_visual_elements_for_view_app_deploy
(
    @intouch_viewapp_name nvarchar(329) = '',
    @return_only_delta bit = 1
)
as begin tran
    declare @intouch_viewapp_gobject_id int

    select @intouch_viewapp_gobject_id = gobject_id
    from gobject 
    where 
        tag_name = @intouch_viewapp_name and
        namespace_id = 1
    -- put visual_element_ids into table
    -- This will act as our seed table... #input_table
    --create  table #visual_element_ids_for_referenced_elements
  create  table #input_table
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)

  declare @referenced_ve_that_have_changed_since_deploy table 
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)

	--ITVAPP POC START
	--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
   
    declare @intouch_viewapp_gobject_id_temp int
   
	--ITVAPP POC END
    
    --ITVAPP POC START
	set  @intouch_viewapp_gobject_id_temp = @intouch_viewapp_gobject_id
	declare @category_id int
		--store previous values
	select  @category_id = category_id 
			from gobject with (NOLOCK) 
			inner join template_definition on 
				gobject.template_definition_id = template_definition.template_definition_id
			where gobject_id = @intouch_viewapp_gobject_id
		
	if(@category_id = 26)
	begin
		--if category is OF ITVAPP (no need to check but doing it: get the derived from gobject id
		select @intouch_viewapp_gobject_id_temp = g.derived_from_gobject_id from gobject g 
		where g.gobject_id = @intouch_viewapp_gobject_id AND g.is_template = 0 --Fix for CR#L00132272: Added condition to retrieve only instances
	end
--ITVAPP POC END
    
    if(@return_only_delta = 1)
    begin
        insert #input_table
    	(
    		visual_element_id,
    		gobject_id,
    		package_id,
			mx_primitive_id,
    		visual_element_reference_index
    	)
        select 
    		vev.visual_element_id,
    		ver.checked_in_bound_visual_element_gobject_id,
    		ver.checked_in_bound_visual_element_package_id,
			ver.checked_in_bound_visual_element_mx_primitive_id,
    		ver.visual_element_reference_index
        from visual_element_reference ver
        inner join visual_element_version vev on
            ver.checked_in_bound_visual_element_gobject_id = vev.gobject_id and
            ver.checked_in_bound_visual_element_package_id = vev.package_id and 
            ver.checked_in_bound_visual_element_mx_primitive_id = vev.mx_primitive_id
        where ver.gobject_id = @intouch_viewapp_gobject_id_temp
    end    
    else
    begin
    -- Only use the references for the checked in package...
        insert #input_table
    	(
    		visual_element_id,
    		gobject_id,
    		package_id,
			mx_primitive_id,
    		visual_element_reference_index
    	)
        select 
    		vev.visual_element_id,
    		ver.checked_in_bound_visual_element_gobject_id,
    		ver.checked_in_bound_visual_element_package_id,
			ver.checked_in_bound_visual_element_mx_primitive_id,
    		ver.visual_element_reference_index
        from visual_element_reference ver
        inner join visual_element_version vev on
            ver.checked_in_bound_visual_element_gobject_id = vev.gobject_id and
            ver.checked_in_bound_visual_element_package_id = vev.package_id and 
            ver.checked_in_bound_visual_element_mx_primitive_id = vev.mx_primitive_id and
            ver.visual_element_bind_status = 1
        inner join gobject g on
            g.gobject_id = ver.gobject_id and
            g.checked_in_package_id = ver.package_id
        where ver.gobject_id = @intouch_viewapp_gobject_id_temp
    end    

 
    create table  #final_selection 
    (
        visual_element_id int,
        gobject_id int,
    	package_id int,
		mx_primitive_id smallint,
		visual_element_reference_index int
    )

    create table  #final_output 
    (
        visual_element_id int,
        visual_element_reference_index int
    )


    create index final_selection_index on #final_selection (visual_element_id, gobject_id, package_id)

    create table  #output_table 
    (
        visual_element_id int,
        gobject_id int,
	    package_id int,
	    mx_primitive_id smallint,
		visual_element_reference_index int
    )

    create index final_selection_index on #output_table (visual_element_id, gobject_id, package_id, mx_primitive_id)

	exec internal_get_recursively_referenced_visual_elements
	
	truncate table #input_table
	
	insert into #final_selection
		(
			visual_element_id,
			gobject_id,
			package_id,
			mx_primitive_id,
			visual_element_reference_index
		)
	select 
		visual_element_id,
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_reference_index
	from #output_table

	truncate table #output_table
	


    if not exists
        (
            select 1 
            from deployed_intouch_viewapp
            where gobject_id = @intouch_viewapp_gobject_id
        )
    begin
	-- the view app that was passed in does not apply...
        select visual_element_id , 
       'Symbol' visual_element_type,-- Symbols are the only supported VE type...
        visual_element_reference_index
        from #final_selection 
        group by visual_element_id,visual_element_reference_index
        order by visual_element_reference_index

	commit
	return
    end
    else
    begin
        if(@return_only_delta = 1) -- fileter results with timestamp...
        begin
        -- Filter the result set for visual elements that
        -- were modified since last deploy...
        declare @after_timestamp timestamp
        select @after_timestamp = timestamp_of_deploy
        from deployed_intouch_viewapp
        where gobject_id = @intouch_viewapp_gobject_id

        -- room for optimization here...
        -- mx_primitive_id can be added to #final_selection to
        -- avoid a join with visual_element_version...
		insert into @referenced_ve_that_have_changed_since_deploy
 		 (visual_element_id ,
		 gobject_id ,
		 package_id ,
		 visual_element_reference_index )	
            select 
                u.visual_element_id ,
                u.gobject_id,
				u.package_id,
                u.visual_element_reference_index 
            from #final_selection u
            inner join visual_element_version vev on
              u.visual_element_id = vev.visual_element_id
            inner join primitive_instance pri on
              vev.gobject_id = pri.gobject_id and
              vev.package_id = pri.package_id and
              vev.mx_primitive_id = pri.mx_primitive_id and
              pri.timestamp_of_last_change > @after_timestamp
            group by 
                u.visual_element_id,
				u.gobject_id,
				u.package_id,
                u.visual_element_reference_index
            order by u.visual_element_reference_index
	
		-- now, get all of the nested elements for these new references...
        insert #input_table
    	(
    		visual_element_id,
    		gobject_id,
    		package_id,
			mx_primitive_id,
    		visual_element_reference_index
    	)
        select 
    		r.visual_element_id,
    		r.gobject_id,
    		r.package_id,
			r.mx_primitive_id,
    		r.visual_element_reference_index
		from @referenced_ve_that_have_changed_since_deploy r

		exec internal_get_recursively_referenced_visual_elements

		-- add the new or modified visual elements to the staging table...
		insert into #final_output 
			(visual_element_id ,
			 visual_element_reference_index)
        select 
			o.visual_element_id ,
			o.visual_element_reference_index
		from #output_table o 

			-- now add any new visual element references and the associated
			-- visual element ids that are not already in #final_selection
			exec internal_get_referenced_visual_elements_after_last_deploy @intouch_viewapp_gobject_id
        end
        else
        begin
			insert into #final_output 
			(visual_element_id ,
			visual_element_reference_index)
            select 
                u.visual_element_id ,
                u.visual_element_reference_index
            from #final_selection u
            inner join visual_element_version vev on
              u.visual_element_id = vev.visual_element_id
            inner join primitive_instance pri on
              vev.gobject_id = pri.gobject_id and
              vev.package_id = pri.package_id and
              vev.mx_primitive_id = pri.mx_primitive_id 
            group by 
                u.visual_element_id,
                u.visual_element_reference_index
            order by u.visual_element_reference_index            
        end

		
    end

    drop table #final_selection

 --CR L00078769 commented this block out.
 --CR L00088291 uncommented this block:
	-- add all immediate parents of visual elements to be returned...
	insert into #final_output 
		(visual_element_id ,
		visual_element_reference_index)
    select 
        vev_parent.visual_element_id ,
        ver_parent.visual_element_reference_index
	from #final_output fo
	inner join visual_element_version vev_child on
		fo.visual_element_id = vev_child.visual_element_id
	inner join visual_element_reference ver_parent on
        ver_parent.checked_in_bound_visual_element_gobject_id = vev_child.gobject_id and
        ver_parent.checked_in_bound_visual_element_package_id = vev_child.package_id and 
        ver_parent.checked_in_bound_visual_element_mx_primitive_id = vev_child.mx_primitive_id
	inner join visual_element_version vev_parent on
		vev_parent.gobject_id = ver_parent.gobject_id and
		vev_parent.package_id = ver_parent.package_id and
		vev_parent.mx_primitive_id = ver_parent.mx_primitive_id
	where vev_parent.visual_element_id not in
		(
			select visual_element_id
			from #final_output
		)


	
	select 
		visual_element_id ,
		'Symbol'visual_element_type,
		visual_element_reference_index
	from #final_output
    group by 
        visual_element_id,
        visual_element_reference_index
    order by visual_element_reference_index

	drop table #final_output
	
	

    
commit
go

