create procedure dbo.internal_get_gobjectids_categoryids_tagnames_from_gobjectids
            @filenameofids nvarchar (265)
as
begin
	set nocount on

    SET QUOTED_IDENTIFIER OFF
    create table #input_table ( gobject_id int primary key)
    declare @SQL nvarchar(2000)

    SET @SQL = 'BULK INSERT #input_table  FROM ''' + @filenameofids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
    EXEC (@SQL)  

	select	
		g.gobject_id,
		g.tag_name,
		t.category_id
	from	gobject g 
	inner join template_definition t on 
		t.template_definition_id = g.template_definition_id
	inner join #input_table intab on 
		intab.gobject_id = g.gobject_id			

end
go

