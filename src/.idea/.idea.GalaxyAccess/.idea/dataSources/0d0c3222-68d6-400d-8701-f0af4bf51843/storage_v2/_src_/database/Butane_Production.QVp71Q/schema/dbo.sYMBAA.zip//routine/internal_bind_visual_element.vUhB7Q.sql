/*
***********************************************************************************************************************
***	
***	object name:	internal_bind_visual_element
***	description:	procedure attempts to bind VisualElements based
***	                on 
***                    1)visual_element_type and visual_element_id or visual_element_name
***                 or
***                    2)@tag_name_in (in the case of renaming an object..)
***	usage: 		    proc is used in internal_rename_fsobject and 
***                    internal_add_owned_visual_element
***			    
***	returns :
***	=========
***	            nothing
***	
***	
***********************************************************************************************************************
*/

create procedure dbo.internal_bind_visual_element
@visual_element_id int,
@visual_element_type nvarchar(32),
@visual_element_name nvarchar(362),
@tag_name nvarchar(329)
as

if exists(select 1 from galaxy where is_migration_in_progress = 1)
    return
    
begin tran

    -- create a temp table to store all affected object for polling purposes...
    declare @all_affected_objects table(gobject_id int)


    declare @affected_checked_in_unbound_elements table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        checked_in_bound_visual_element_gobject_id int not null,
        checked_in_bound_visual_element_package_id int not null,
        checked_in_bound_visual_element_mx_primitive_id smallint not null,
        primary key
        (
            gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )
    
    declare @affected_checked_out_unbound_elements table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        checked_out_bound_visual_element_gobject_id int not null,
        checked_out_bound_visual_element_package_id int not null,
        checked_out_bound_visual_element_mx_primitive_id smallint  not null
        primary key
        (
            gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )
    
    if (@tag_name is null) -- try to bind VisualElement based on scenario #1 (add_visual_element)
    begin

        declare @checked_in_gobject_id int
        declare @checked_in_package_id int
        declare @checked_in_mx_primitive_id int
        
        select 
            @checked_in_gobject_id  = vev.gobject_id,
            @checked_in_package_id = vev.package_id,
            @checked_in_mx_primitive_id  = vev.mx_primitive_id 
        from visual_element_version vev
        inner join gobject g
            on vev.gobject_id = g.gobject_id
            and vev.package_id = g.checked_in_package_id
        where vev.visual_element_id = @visual_element_id

        if( @checked_in_package_id is not null )
        begin
            -- first try to bind any checked-in VEs....
            insert into @affected_checked_in_unbound_elements
            (gobject_id,
            package_id,
            mx_primitive_id ,
            visual_element_reference_index ,
            checked_in_bound_visual_element_gobject_id ,
            checked_in_bound_visual_element_package_id ,
            checked_in_bound_visual_element_mx_primitive_id )    
            select 
                u.gobject_id,
                u.package_id,
                u.mx_primitive_id,
                u.visual_element_reference_index,
                @checked_in_gobject_id,
                @checked_in_package_id,
                @checked_in_mx_primitive_id
            from visual_element_reference u 
            where 
                (u.checked_in_unbound_visual_element_type = @visual_element_type and
                 u.checked_in_unbound_visual_element_name = @visual_element_name)
                 or u.checked_in_unbound_visual_element_id = @visual_element_id

            if exists( select 1 from @affected_checked_in_unbound_elements )
            begin
                --update the checked_in_bound ver columns....
                update  ver
                set 
                    -- bound columns...
                    ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
                    ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
                    ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
                    --ver.visual_element_bind_status = 1,-- now a calculated column..
                    -- unbound columns...
                    ver.checked_in_unbound_visual_element_name = null,
                    ver.checked_in_unbound_visual_element_type = null,
                    ver.checked_in_unbound_tag_name = null,
                    ver.checked_in_unbound_primitive_name = null,
                    ver.checked_in_unbound_relative_object_name = null,
                    ver.checked_in_unbound_visual_element_id = null
				output inserted.gobject_id
				into @all_affected_objects
                from visual_element_reference ver 
                inner join @affected_checked_in_unbound_elements wt on
                    wt.gobject_id = ver.gobject_id and
                    wt.package_id = ver.package_id and
                    wt.mx_primitive_id = ver.mx_primitive_id and
                    wt.visual_element_reference_index = ver.visual_element_reference_index
            end
        end

        -- bind checked out elements
        declare @checked_out_gobject_id int
        declare @checked_out_package_id int
        declare @checked_out_mx_primitive_id int

        select 
            @checked_out_gobject_id  = vev.gobject_id,
            @checked_out_package_id = vev.package_id,
            @checked_out_mx_primitive_id  = vev.mx_primitive_id 
        from visual_element_version vev
        inner join gobject g
            on vev.gobject_id = g.gobject_id
            and vev.package_id = g.checked_out_package_id
        where vev.visual_element_id = @visual_element_id

        if( @checked_out_package_id is not null )
        begin

            -- next, try to bind any checked-out VEs....
            insert into @affected_checked_out_unbound_elements
            (gobject_id,
            package_id,
            mx_primitive_id ,
            visual_element_reference_index ,
            checked_out_bound_visual_element_gobject_id ,
            checked_out_bound_visual_element_package_id ,
            checked_out_bound_visual_element_mx_primitive_id )    
            select 
                ver.gobject_id,
                ver.package_id,
                ver.mx_primitive_id,
                ver.visual_element_reference_index,
                @checked_out_gobject_id,
                @checked_out_package_id,
                @checked_out_mx_primitive_id
            from visual_element_reference ver
            where 
                (ver.checked_out_unbound_visual_element_type = @visual_element_type and
                 ver.checked_out_unbound_visual_element_name = @visual_element_name)
                 or ver.checked_out_unbound_visual_element_id = @visual_element_id

            if exists ( select 1 from @affected_checked_out_unbound_elements )
            begin
                --update the checked_out_bound ver columns....
                update  ver
                set 
                    -- bound columns...
                    ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
                    ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
                    ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
                    --ver.visual_element_bind_status = 1, -- now a calculated column..
                    -- unbound columns...
                    ver.checked_out_unbound_visual_element_name = null,
                    ver.checked_out_unbound_visual_element_type = null,
                    ver.checked_out_unbound_tag_name = null,
                    ver.checked_out_unbound_primitive_name = null,
                    ver.checked_out_unbound_relative_object_name = null,
                    ver.checked_out_unbound_visual_element_id = null
				output inserted.gobject_id
				into @all_affected_objects
                from visual_element_reference ver 
                inner join @affected_checked_out_unbound_elements wt on
                    wt.gobject_id = ver.gobject_id and
                    wt.package_id = ver.package_id and
                    wt.mx_primitive_id = ver.mx_primitive_id and
                    wt.visual_element_reference_index = ver.visual_element_reference_index
            end
        end
        
    end
    else-- rename fs object 
    begin
        -- first, try to bind the checked-in VEs..
        insert into @affected_checked_in_unbound_elements
        (gobject_id,
        package_id,
        mx_primitive_id ,
        visual_element_reference_index ,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id )    
        select 
            distinct
            u.gobject_id,
            u.package_id,
            u.mx_primitive_id,
            u.visual_element_reference_index,
            vev.gobject_id,
            vev.package_id,
            vev.mx_primitive_id
        from visual_element_reference u 
        inner join primitive_instance pri on pri.primitive_name = u.checked_in_unbound_primitive_name
        inner join gobject g on u.checked_in_unbound_tag_name = g.tag_name and 
                   g.gobject_id = pri.gobject_id
        inner join visual_element_version vev on vev.gobject_id = pri.gobject_id and
                vev.package_id = pri.package_id and 
                vev.mx_primitive_id = pri.mx_primitive_id
        inner join visual_element v on vev.visual_element_id = v.visual_element_id and
                u.checked_in_unbound_visual_element_type = v.visual_element_type
        inner join gobject visual_element_gobject on
                vev.package_id = visual_element_gobject.checked_in_package_id
        where
            u.checked_in_unbound_tag_name = @tag_name
 
        --update the checked_in_bound ver columns....
        update  ver
        set -- bound columns....
            ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
            ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
            ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
            --ver.visual_element_bind_status = 1,-- now a calculated column..
            -- unbound columns...
            ver.checked_in_unbound_visual_element_name = null,
            ver.checked_in_unbound_visual_element_type = null,
            ver.checked_in_unbound_tag_name = null,
            ver.checked_in_unbound_primitive_name = null,
            ver.checked_in_unbound_relative_object_name = null
		output inserted.gobject_id
		into @all_affected_objects
        from visual_element_reference ver 
        inner join @affected_checked_in_unbound_elements wt on
            wt.gobject_id = ver.gobject_id and
            wt.package_id = ver.package_id and
            wt.mx_primitive_id = ver.mx_primitive_id and
            wt.visual_element_reference_index = ver.visual_element_reference_index
        

        -- next, try to bind any checked_out VEs..
        insert into @affected_checked_out_unbound_elements
        (gobject_id,
        package_id,
        mx_primitive_id ,
        visual_element_reference_index ,
        checked_out_bound_visual_element_gobject_id ,
        checked_out_bound_visual_element_package_id ,
        checked_out_bound_visual_element_mx_primitive_id )    
        select 
            distinct
            u.gobject_id,
            u.package_id,
            u.mx_primitive_id,
            u.visual_element_reference_index,
            vev.gobject_id,
            vev.package_id,
            vev.mx_primitive_id
        from visual_element_reference u 
        inner join primitive_instance pri on pri.primitive_name = u.checked_out_unbound_primitive_name
        inner join gobject g on u.checked_out_unbound_tag_name = g.tag_name and 
                   g.gobject_id = pri.gobject_id
        inner join visual_element_version vev on vev.gobject_id = pri.gobject_id and
                vev.package_id = pri.package_id and 
                vev.mx_primitive_id = pri.mx_primitive_id
        inner join visual_element v on vev.visual_element_id = v.visual_element_id and
                u.checked_out_unbound_visual_element_type = v.visual_element_type
        inner join gobject visual_element_gobject on
                vev.package_id = visual_element_gobject.checked_out_package_id
        where
            u.checked_out_unbound_tag_name = @tag_name
 
        --update the checked_out_bound ver columns....
        update  ver
        set -- bound columns...
            ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
            ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
            ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
            --ver.visual_element_bind_status = 1,-- now a calculated column..
            -- unbound columns...
            ver.checked_out_unbound_visual_element_name = null,
            ver.checked_out_unbound_visual_element_type = null,
            ver.checked_out_unbound_tag_name = null,
            ver.checked_out_unbound_primitive_name = null,
            ver.checked_out_unbound_relative_object_name = null
		output inserted.gobject_id
		into @all_affected_objects
        from visual_element_reference ver 
        inner join @affected_checked_out_unbound_elements wt on
            wt.gobject_id = ver.gobject_id and
            wt.package_id = ver.package_id and
            wt.mx_primitive_id = ver.mx_primitive_id and
            wt.visual_element_reference_index = ver.visual_element_reference_index
        

    end

	if exists(select '1' from @all_affected_objects)
	begin
			declare @distinct_affected_objects table(gobject_id int primary key)

			insert into @distinct_affected_objects
			select distinct gobject_id
			from @all_affected_objects

			update pt
			set pt.gobject_id = pt.gobject_id
			from proxy_timestamp pt
			inner join @distinct_affected_objects dao on
				pt.gobject_id = dao.gobject_id 

			update gfi
			set gfi.gobject_id = gfi.gobject_id
			from gobject_filter_info_timestamp gfi
			inner join @distinct_affected_objects dao on
				gfi.gobject_id = dao.gobject_id 


			declare @max_proxy_timestamp bigint
			select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

			update galaxy
			set max_proxy_timestamp = @max_proxy_timestamp
	end
    


commit
go

