create proc dbo.internal_list_objects_for_device
@varwhere int,  -- DIO_gobject_id * 1000 + SG_mx_primtive_id
@maxResultCount int = 0,
@startingAfterTagname nvarchar(329) = ''
AS
BEGIN
    SET NOCOUNT ON

	if @varwhere = -1
	begin
		set @varwhere = 0 
		declare @worktable table ( gobject_id int primary key,
		hasiolinkedobjects int)

		insert into @worktable
		select gobject_id,
		case when exists(select odl.gobject_id from object_device_linkage odl where odl.dio_id = g.gobject_id)
		 then 1
		 else 0
		 end as hasiolinkedobjects
		from gobject g
		inner join template_definition td
		    on td.template_definition_id = g.template_definition_id
		 where g.is_hidden = 0
		   and g.is_template = 0
		   and g.namespace_id = 1
		   and td.category_id in (11, 12, 24) -- Restrict to DI Objects
        
        if @maxResultCount <> 0
            SET ROWCOUNT @maxResultCount

		select distinct g.gobject_id, 
			g.tag_name, 
			g.contained_name,
			g.hierarchical_name, 
	--      package.status_id as status, 
			CASE WHEN package.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0)--ver_warning_view.has_warning = 1 
					THEN 2 
				ELSE 0 
				END
			ELSE package.status_id
			END as status, 
			package.reference_status_id as refStatus,
			g.hosted_by_gobject_id,
			g.derived_from_gobject_id as derived_from_id,
			template_definition.base_gobject_id as base_type,  
			isnull((select user_profile_name from user_profile where user_guid = g.checked_out_by_user_guid),'') as checkoutbyname, 
			g.checked_out_by_user_guid as checkedout_by,
			folder_gobject_link.folder_id AS toolset_id, 
			g.checked_in_package_id,
			g.template_definition_id,       
			g.contained_by_gobject_id as container_id,  
			g.area_gobject_id as area_id, 
	--      package_checked_out.status_id as checked_out_package_status,
			CASE WHEN package_checked_out.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
					THEN 2 
				ELSE 0 
				END
			ELSE package_checked_out.status_id 
			END as checked_out_package_status,
			(g.is_template * 1) +
			(g.is_hidden * 2 ) +
			((CASE WHEN g.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
			((CASE WHEN g.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +
			((CASE WHEN (g.deployed_package_id <> 0) and ((g.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
			THEN 1  ELSE 0  END) * 16 ) +
			((CASE WHEN (g.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
			((CASE WHEN (g.namespace_id = 1 and template_definition.category_id = 3 and g.is_template = 0 and dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1 ) THEN 1 ELSE 0 END) * 64) +
			((CASE WHEN (g.namespace_id = 2 and template_definition.category_id = 3 and g.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
			((CASE WHEN (dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) THEN 1 ELSE 0 END) * 256) + 
			((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
						((g.deployed_package_id <> 0) and (dbo.is_partner_deployed(g.gobject_id) =  0))) then 1 else 0 end) * 512) +
			((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
						((g.deployed_package_id = 0) and (dbo.is_partner_deployed(g.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
			case when exists(select gobject_id from gobject where derived_from_gobject_id = g.gobject_id) --Hasderived_obj
				 then 2048   else 0  end +
			case when exists(select gobject_id from gobject where hosted_by_gobject_id = g.gobject_id) --Hasassigned_obj
				 then 4096   else 0  end + 
			case when exists(select gobject_id from gobject where contained_by_gobject_id =g.gobject_id) --HasContained_obj
				 then 8192   else 0  end +
			case when exists(select gobject_id from gobject where area_gobject_id = g.gobject_id) --HasBelongTo_obj
				 then 16384  else 0  end +
			((CASE WHEN (g.is_template = 0 and template_definition.category_id = 1) then
					dbo.is_gr_platform_id(g.gobject_id) 
				else 
					cast(0 as bit) end) * 32768) +
			ISNULL(deployed_intouch_viewapp.deploy_file_transfering,0) * 65536  +
			CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = g.gobject_id )
					then  131072 else 0 end +
            CASE WHEN (wt.hasiolinkedobjects = 1) --hasiolinkedobjects for IO device only
                    then  262144 else 0 end
			as 'gObjectStatus',
			CAST (pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
			g.namespace_id,
			folder_gobject_link.folder_id,
			-- >> IO Binding changes
			0 as dio_id,
			scan_group.cnt as sg_mx_primitive_id, -- Return the number of scan-groups created for the object as the sg_mx_primitive_id (something of a necessary hack)
			null as 'MyDiName'
			-- << IO Binding changes end
		from  @worktable wt 
		inner join gobject g
		    on wt.gobject_id = g.gobject_id
		inner join package 
			on g.gobject_id = package.gobject_id 
			and g.checked_in_package_id = package.package_id
		inner join template_definition on
			g.template_definition_id = template_definition.template_definition_id 
		inner join proxy_timestamp pt on
			g.gobject_id = pt.gobject_id
		left join package package_checked_out 
			on g.gobject_id = package_checked_out.gobject_id and
			g.checked_out_package_id = package_checked_out.package_id
		left outer join visual_element_reference ver_warning_view on
			g.gobject_id = ver_warning_view.gobject_id and
			package.package_id = ver_warning_view.package_id and
			ver_warning_view.visual_element_bind_status = 0 and
			ver_warning_view.checked_in_unbound_visual_element_name <> '---'

		left outer join visual_element_reference ver_warning_view_checked_out on
			package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
			package_checked_out.package_id = ver_warning_view_checked_out.package_id and
			ver_warning_view_checked_out.visual_element_bind_status = 0 and
			ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
		left join folder_gobject_link on
			folder_gobject_link.gobject_id = g.gobject_id
		left outer join package checked_in_package on 
			g.gobject_id = checked_in_package.gobject_id and 
			g.checked_in_package_id = checked_in_package.package_id
		left outer join package deployed_package on 
			g.gobject_id = deployed_package.gobject_id and
			g.deployed_package_id = deployed_package.package_id
		left outer join deployed_intouch_viewapp on
				g.gobject_id = deployed_intouch_viewapp.gobject_id
		-- >> I/O Binding
		--CROSS APPLY (select cast (count(*) as smallint) as cnt from itvfGetScanGroupsForDIO (g.gobject_id)) scan_groups
		CROSS APPLY (select     cast(COUNT(*) as smallint) as CNT from primitive_instance sg_pi
					 inner join primitive_definition pd
							 on pd.primitive_definition_id = sg_pi.primitive_definition_id
							and pd.primitive_name in (N'S', N'SG', N'ScanGroup1')
						  where sg_pi.gobject_id = g.gobject_id
							and sg_pi.package_id = g.checked_in_package_id
			) scan_group
		-- << I/O Binding
		 where scan_group.CNT <> 0
		   and g.tag_name > @startingAfterTagname
		order by    g.tag_name
	end
	else if @varwhere <> 0
	begin
		declare @dio_id int = @varwhere / 1000
		declare @sg_prim smallint = @varwhere % 1000

		--Added to optimize the performance for IOB : no IO device
		declare @worktable_noDI table ( gobject_id int NOT NULL primary key,
									dio_id int,
									sg_mx_primitive_id smallint,
									MyDiName nvarchar(329))

		insert into @worktable_noDI
		select g.gobject_id,
		odl.dio_id,
		odl.sg_mx_primitive_id,
		(case when dio.tag_name is not null and sg_pi.primitive_name is not null
			then
				dio.tag_name + '.' + sg_pi.primitive_name 
			else
				null
			end)
		from gobject g 
		inner join template_definition td
		on td.template_definition_id = g.template_definition_id
		and td.category_id not in (11,12,24)
		left outer join object_device_linkage odl on
		odl.gobject_id = g.gobject_id
		left outer JOIN gobject dio
		ON dio.gobject_id = odl.dio_id
		left outer JOIN primitive_instance sg_pi
		ON sg_pi.gobject_id = dio.gobject_id
		AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
		AND sg_pi.package_id = dio.checked_in_package_id
		where g.is_hidden = 0
		   and g.is_template = 0
		   and g.namespace_id = 1
		   --and g.contained_by_gobject_id  = 0              -- Not sure about how to return containers
		   and odl.dio_id = @dio_id
		   and odl.sg_mx_primitive_id = @sg_prim
		   and g.tag_name > @startingAfterTagname

		--Added to optimize the performance for IOB END
        
        if @maxResultCount <> 0
            SET ROWCOUNT @maxResultCount

		select distinct g.gobject_id, 
			g.tag_name, 
			g.contained_name,
			g.hierarchical_name, 
	--      package.status_id as status, 
			CASE WHEN package.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0)--ver_warning_view.has_warning = 1 
					THEN 2 
				ELSE 0 
				END
			ELSE package.status_id
			END as status, 
			package.reference_status_id as refStatus,
			g.hosted_by_gobject_id,
			g.derived_from_gobject_id as derived_from_id,
			template_definition.base_gobject_id as base_type,  
			isnull((select user_profile_name from user_profile where user_guid = g.checked_out_by_user_guid),'') as checkoutbyname, 
			g.checked_out_by_user_guid as checkedout_by,
			folder_gobject_link.folder_id AS toolset_id, 
			g.checked_in_package_id,
			g.template_definition_id,       
			g.contained_by_gobject_id as container_id,  
			g.area_gobject_id as area_id, 
	--      package_checked_out.status_id as checked_out_package_status,
			CASE WHEN package_checked_out.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
					THEN 2 
				ELSE 0 
				END
			ELSE package_checked_out.status_id 
			END as checked_out_package_status,
			(g.is_template * 1) +
			(g.is_hidden * 2 ) +
			((CASE WHEN g.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
			((CASE WHEN g.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +
			((CASE WHEN (g.deployed_package_id <> 0) and ((g.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
			THEN 1  ELSE 0  END) * 16 ) +
			((CASE WHEN (g.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
			((CASE WHEN (g.namespace_id = 1 and template_definition.category_id = 3 and g.is_template = 0 and dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1 ) THEN 1 ELSE 0 END) * 64) +
			((CASE WHEN (g.namespace_id = 2 and template_definition.category_id = 3 and g.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
			((CASE WHEN (dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) THEN 1 ELSE 0 END) * 256) + 
			((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
						((g.deployed_package_id <> 0) and (dbo.is_partner_deployed(g.gobject_id) =  0))) then 1 else 0 end) * 512) +
			((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
						((g.deployed_package_id = 0) and (dbo.is_partner_deployed(g.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
			case when exists(select gobject_id from gobject where derived_from_gobject_id = g.gobject_id) --Hasderived_obj
				 then 2048   else 0  end +
			case when exists(select gobject_id from gobject where hosted_by_gobject_id = g.gobject_id) --Hasassigned_obj
				 then 4096   else 0  end + 
			case when exists(select gobject_id from gobject where contained_by_gobject_id =g.gobject_id) --HasContained_obj
				 then 8192   else 0  end +
			case when exists(select gobject_id from gobject where area_gobject_id = g.gobject_id) --HasBelongTo_obj
				 then 16384  else 0  end +
			((CASE WHEN (g.is_template = 0 and template_definition.category_id = 1) then
					dbo.is_gr_platform_id(g.gobject_id) 
				else 
					cast(0 as bit) end) * 32768) +
			ISNULL(deployed_intouch_viewapp.deploy_file_transfering,0) * 65536  +
			CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = g.gobject_id )
					then  131072 else 0 end                             
			as 'gObjectStatus',
			CAST (pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
			g.namespace_id,
			folder_gobject_link.folder_id,
			--IO Binding changes
			worktable.dio_id,
			worktable.sg_mx_primitive_id,
			worktable.MyDiName as 'MyDiName'
			--IO Binding changes end
		from  @worktable_noDI worktable 
		inner join gobject g on
		worktable.gobject_id = g.gobject_id
		inner join package 
			on g.gobject_id = package.gobject_id 
			and g.checked_in_package_id = package.package_id
		inner join template_definition on
			g.template_definition_id = template_definition.template_definition_id 
		inner join proxy_timestamp pt on
			g.gobject_id = pt.gobject_id
	
		left join package package_checked_out 
			on g.gobject_id = package_checked_out.gobject_id and
			g.checked_out_package_id = package_checked_out.package_id
	        
		left outer join visual_element_reference ver_warning_view on
			g.gobject_id = ver_warning_view.gobject_id and
			package.package_id = ver_warning_view.package_id and
			ver_warning_view.visual_element_bind_status = 0 and
			ver_warning_view.checked_in_unbound_visual_element_name <> '---'

		left outer join visual_element_reference ver_warning_view_checked_out on
			package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
			package_checked_out.package_id = ver_warning_view_checked_out.package_id and
			ver_warning_view_checked_out.visual_element_bind_status = 0 and
			ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
		left join folder_gobject_link on
			folder_gobject_link.gobject_id = g.gobject_id
		left outer join package checked_in_package on 
			g.gobject_id = checked_in_package.gobject_id and 
			g.checked_in_package_id = checked_in_package.package_id
		left outer join package deployed_package on 
			g.gobject_id = deployed_package.gobject_id and
			g.deployed_package_id = deployed_package.package_id
		left outer join deployed_intouch_viewapp on
				g.gobject_id = deployed_intouch_viewapp.gobject_id
		 --where g.is_hidden = 0
		 --  and g.is_template = 0
		 --  and g.namespace_id = 1
		 --  --and g.contained_by_gobject_id  = 0              -- Not sure about how to return containers
		 --  and template_definition.category_id not in (11, 12, 24) -- Leave out DIO
		 --  and odl.dio_id = @dio_id
		 --  and odl.sg_mx_primitive_id = @sg_prim
		 --  and g.tag_name > @startingAfterTagname
		order by    g.tag_name
	end
	else -- @varwhere == 0
	begin
		
		declare @rVal int
		declare @iterationcount int
		set @iterationcount =1

		 if @maxResultCount <> 0
		    SET ROWCOUNT @maxResultCount
		
		declare @tempgobjecttable table(id int primary key)

		insert into @tempgobjecttable
		select gobject_id from gobject 
		where tag_name>@startingAfterTagname
		order by tag_name

		declare @temptable table (gobject_id int primary key)
 
		set rowcount 0

		while 1=1
		begin
			insert into @temptable
			select g.gobject_id from gobject g
			inner join @tempgobjecttable tt on
			tt.id= g.gobject_id
			left outer join object_device_linkage odl
			on odl.gobject_id = g.gobject_id
			inner join template_definition td 
			on td.template_definition_id = g.template_definition_id
			and td.category_id not in(11,12,24)
			where odl.gobject_id is null
			and g.is_template = 0 
			and g.namespace_id = 1
			and g.is_hidden = 0		
			order by    g.tag_name			

            set @rVal = @@ROWCOUNT

			set @iterationcount = @iterationcount +1

			if @maxResultCount <> 0
			begin
				if (@rVal=0)
				begin 
					declare @retVal int
					select @retVal = COUNT(*) FROM @tempgobjecttable
					if (@retVal < @maxResultCount)
					begin
						break
					end
	
					declare @tempMaxCount int
					set @tempMaxCount = @maxResultCount *@iterationcount
					set rowcount @tempMaxCount
					delete from @tempgobjecttable
			
			
					 insert into @tempgobjecttable
					 select gobject_id from gobject 
					 where tag_name>@startingAfterTagname
					 order by tag_name 
					 set rowcount 0
				end
				else
				begin
					break
				end
			end
	        else
			begin
				break
			end
		end
		
		
        if @maxResultCount <> 0
            SET ROWCOUNT @maxResultCount

		select distinct g.gobject_id, 
					g.tag_name, 
					g.contained_name,
					g.hierarchical_name, 
			--      package.status_id as status, 
					CASE WHEN package.status_id = 0 THEN
						CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0)--ver_warning_view.has_warning = 1 
							THEN 2 
						ELSE 0 
						END
					ELSE package.status_id
					END as status, 
					package.reference_status_id as refStatus,
					g.hosted_by_gobject_id,
					g.derived_from_gobject_id as derived_from_id,
					template_definition.base_gobject_id as base_type,  
					isnull((select user_profile_name from user_profile where user_guid = g.checked_out_by_user_guid),'') as checkoutbyname, 
					g.checked_out_by_user_guid as checkedout_by,
					folder_gobject_link.folder_id AS toolset_id, 
					g.checked_in_package_id,
					g.template_definition_id,       
					g.contained_by_gobject_id as container_id,  
					g.area_gobject_id as area_id, 
			--      package_checked_out.status_id as checked_out_package_status,
					CASE WHEN package_checked_out.status_id = 0 THEN
						CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
							THEN 2 
						ELSE 0 
						END
					ELSE package_checked_out.status_id 
					END as checked_out_package_status,
					(g.is_template * 1) +
					(g.is_hidden * 2 ) +
					((CASE WHEN g.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
					((CASE WHEN g.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +
					((CASE WHEN (g.deployed_package_id <> 0) and ((g.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
					THEN 1  ELSE 0  END) * 16 ) +
					((CASE WHEN (g.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
					((CASE WHEN (g.namespace_id = 1 and template_definition.category_id = 3 and g.is_template = 0 and dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1 ) THEN 1 ELSE 0 END) * 64) +
					((CASE WHEN (g.namespace_id = 2 and template_definition.category_id = 3 and g.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
					((CASE WHEN (dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) THEN 1 ELSE 0 END) * 256) + 
					((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
								((g.deployed_package_id <> 0) and (dbo.is_partner_deployed(g.gobject_id) =  0))) then 1 else 0 end) * 512) +
					((CASE WHEN ((dbo.is_failover_enabled_for_gobject_id(g.gobject_id) = 1) and 
								((g.deployed_package_id = 0) and (dbo.is_partner_deployed(g.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
					case when exists(select gobject_id from gobject where derived_from_gobject_id = g.gobject_id) --Hasderived_obj
						 then 2048   else 0  end +
					case when exists(select gobject_id from gobject where hosted_by_gobject_id = g.gobject_id) --Hasassigned_obj
						 then 4096   else 0  end + 
					case when exists(select gobject_id from gobject where contained_by_gobject_id =g.gobject_id) --HasContained_obj
						 then 8192   else 0  end +
					case when exists(select gobject_id from gobject where area_gobject_id = g.gobject_id) --HasBelongTo_obj
						 then 16384  else 0  end +
					((CASE WHEN (g.is_template = 0 and template_definition.category_id = 1) then
							dbo.is_gr_platform_id(g.gobject_id) 
						else 
							cast(0 as bit) end) * 32768) +
					ISNULL(deployed_intouch_viewapp.deploy_file_transfering,0) * 65536  +
					CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = g.gobject_id )
							then  131072 else 0 end                             
					as 'gObjectStatus',
					CAST (pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
					g.namespace_id,
					folder_gobject_link.folder_id,
					--IO Binding changes
					0 as dio_id, -- odl.dio_id,
					cast(0 as smallint) as sg_mx_primitive_id, -- odl.sg_mx_primitive_id,
					null as 'MyDiName'
					--IO Binding changes end
				from  @temptable tempt  
				inner join gobject g 
				on tempt.gobject_id = g.gobject_id
				inner join package 
					on g.gobject_id = package.gobject_id 
					and g.checked_in_package_id = package.package_id
				inner join template_definition on
					g.template_definition_id = template_definition.template_definition_id
				inner join proxy_timestamp pt on
					g.gobject_id = pt.gobject_id
				left join package package_checked_out 
					on g.gobject_id = package_checked_out.gobject_id and
					g.checked_out_package_id = package_checked_out.package_id
	        
				left outer join visual_element_reference ver_warning_view on
					g.gobject_id = ver_warning_view.gobject_id and
					package.package_id = ver_warning_view.package_id and
					ver_warning_view.visual_element_bind_status = 0 and
					ver_warning_view.checked_in_unbound_visual_element_name <> '---'

				left outer join visual_element_reference ver_warning_view_checked_out on
					package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
					package_checked_out.package_id = ver_warning_view_checked_out.package_id and
					ver_warning_view_checked_out.visual_element_bind_status = 0 and
					ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
				left join folder_gobject_link on
					folder_gobject_link.gobject_id = g.gobject_id
				left outer join package checked_in_package on 
					g.gobject_id = checked_in_package.gobject_id and 
					g.checked_in_package_id = checked_in_package.package_id
				left outer join package deployed_package on 
					g.gobject_id = deployed_package.gobject_id and
					g.deployed_package_id = deployed_package.package_id
				left outer join deployed_intouch_viewapp on
						g.gobject_id = deployed_intouch_viewapp.gobject_id
				order by    g.tag_name
	end
end


go

