/**************************************************
Object Name :  internal_get_gobject_id_from_tag_name
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves a gobject_id for a given tag_name.
Used By	    :  CDI uses it in GetUserGuid call.
**************************************************/

CREATE PROCEDURE dbo.internal_get_gobject_id_from_tag_name
@tag_name nvarchar(329),
@gobject_d int  OUTPUT,
@derived_from_gobject_id int OUTPUT
 AS


begin
SET NOCOUNT ON

set @derived_from_gobject_id = 0
set @gobject_d = 0

select 
	@gobject_d = gobject_id,
	@derived_from_gobject_id = derived_from_gobject_id
from gobject 
where tag_name = @tag_name and namespace_id = 1  -- Automation Object



end

go

