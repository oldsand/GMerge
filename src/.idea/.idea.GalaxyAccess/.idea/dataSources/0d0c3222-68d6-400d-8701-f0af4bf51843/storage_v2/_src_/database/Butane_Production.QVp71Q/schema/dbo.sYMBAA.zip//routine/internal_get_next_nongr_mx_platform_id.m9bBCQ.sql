create proc dbo.internal_get_next_nongr_mx_platform_id
  @my_platform_id smallint out
as
begin
	declare @mytable table( mx_platform_id smallint )
	insert into @mytable(mx_platform_id) (select distinct mx_platform_id from instance i )

	select @my_platform_id = min(i.mx_platform_id) from @mytable i
	left join (select mx_platform_id from @mytable )
	  r on i.mx_platform_id + 1 = r.mx_platform_id
	where r.mx_platform_id is null and i.mx_platform_id <> 0

	if( @my_platform_id is null )
	  set @my_platform_id = 2
	else
	  set @my_platform_id = @my_platform_id + 1

--print @my_platform_id
end
go

