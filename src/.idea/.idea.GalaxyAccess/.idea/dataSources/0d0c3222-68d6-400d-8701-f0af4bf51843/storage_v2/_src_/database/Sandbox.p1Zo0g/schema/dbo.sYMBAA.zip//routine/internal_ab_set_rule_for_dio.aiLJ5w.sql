CREATE PROCEDURE dbo.internal_ab_set_rule_for_dio
	  @dio		int
    , @rule_id  int = NULL
	, @force	bit = 0
as
begin
    set nocount on

	declare @set_templ_id int
	declare @abd_rule_id int
	declare @abd_templ_rule_id int

	select @abd_rule_id = overridden_naming_rule_id
	FROM autobind_device dio
	WHERE dio_id = @dio

	if @@ROWCOUNT = 0
		return -1

	if @abd_rule_id IS NULL OR @force = 1
		UPDATE autobind_device SET overridden_naming_rule_id = @rule_id WHERE dio_id = @dio
	else
		return 1

    -- EXECUTE internal_ab_refresh_attribute_aliases 0, @dio

    return 0
end
go

