CREATE VIEW dbo.internal_localized_alarm_messages
AS
	--select g.tag_name + '.' + p.primitive_name 'Name', amd.default_message, amd.indexable_default_message, amd.phrase_id, amt.translated_message, amt.locale_id, am.gobject_id, am.package_id, am.mx_primitive_id from alarm_messages am
	select g.tag_name + '.' + p.primitive_name 'Name', amd.default_message, amd.phrase_id, amt.translated_message, amt.locale_id, am.gobject_id, am.package_id, am.mx_primitive_id from alarm_messages am
	inner join alarm_message_defaults amd on amd.phrase_id = am.phrase_id
	inner join alarm_message_translations amt on amt.phrase_id = amd.phrase_id
	inner join primitive_instance p on p.gobject_id = am.gobject_id and p.mx_primitive_id = am.mx_primitive_id and p.execution_group = 19
	inner join primitive_definition pd on pd.primitive_definition_id = p.primitive_definition_id and pd.primitive_name <> ''
	inner join gobject g on g.gobject_id = p.gobject_id and g.is_template = 0
	inner join package pkg on pkg.gobject_id = p.gobject_id and pkg.package_id = p.package_id and pkg.package_id = g.checked_in_package_id

go

