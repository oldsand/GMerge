/**************************************************
Object Name :  internal_is_itvapp_has_deployallsymbol_configuration_enable
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves a gobject_id for a given tag_name and check it is present in intouchviewapptemplate_allsymbols.
Used By	    :  CDI uses it in GetIncludeAllGraphicsOptionforITVAPP call.
**************************************************/

CREATE PROCEDURE dbo.internal_is_itvapp_has_deployallsymbol_configuration_enable
(
	@tag_name nvarchar(329),
	@gobject_d int OUTPUT
)
AS

begin
	SET NOCOUNT ON
	DECLARE @Id int
	DECLARE @c nvarchar
	set @gobject_d = 0
	set @Id = 0
	
	set @c = substring(@tag_name,1,1)
	if(@c = '$')
		begin
			-- Automation Object namespace_id = 1 
			-- while migration need to get the min object id for the tag_name.  
			select @Id = min(gobject_id) from gobject where tag_name = @tag_name and namespace_id = 1
		end
	else
		begin
			--get the derived_from_gobject_id for the tagname
			--check whether obtained derived_from_gobject_id is in table 
			--intouchviewapptemplate_allsymbols
			select @Id = g.derived_from_gobject_id  from gobject g
			where g.tag_name = @tag_name and namespace_id = 1
		end
		
	if exists (select * from intouchviewapptemplate_allsymbols where gobject_id = @Id)
	begin
		set @gobject_d = @Id
	end
	
end
go

