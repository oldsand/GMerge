create trigger trigger_delete_gobject
    on gobject
    instead of delete
as
    set nocount on

if not exists(select 1 from deleted)
begin
    return
end
begin tran    

    -- delete all childres....
    delete template
    from template, deleted
    where template.gobject_id = deleted.gobject_id

    delete instance
    from instance, deleted
    where instance.gobject_id = deleted.gobject_id

    delete package
    from package, deleted
    where package.gobject_id = deleted.gobject_id
    
    delete gobject_change_log
    from gobject_change_log, deleted
    where gobject_change_log.gobject_id = deleted.gobject_id

    delete platform
    from platform, deleted
    where platform.platform_gobject_id = deleted.gobject_id

    delete client_control_class_link
	from client_control_class_link,deleted
	where client_control_class_link.gobject_id = deleted.gobject_id

	delete gobject
    from gobject, deleted
    where gobject.gobject_id = deleted.gobject_id
	
commit
go

