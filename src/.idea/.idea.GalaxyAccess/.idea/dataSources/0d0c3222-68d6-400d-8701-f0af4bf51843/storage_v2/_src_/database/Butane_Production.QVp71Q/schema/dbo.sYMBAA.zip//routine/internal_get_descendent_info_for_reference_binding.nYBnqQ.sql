
CREATE PROCEDURE dbo.internal_get_descendent_info_for_reference_binding
	@gObjectId int
AS
begin
	set nocount on

    ;With CTE
	(
		gId, 
		istemplate,
		checked_in_package_id, 
		tag_name
	)as
	(	
		select
			gobject_id,
			is_template,
			checked_in_package_id,
			tag_name
		from gobject
		where derived_from_gobject_id = @gObjectId
		union all	
		select
			g.gobject_id,
			g.is_template,
			g.checked_in_package_id,
			g.tag_name			
		from CTE inner join gobject g on
			g.derived_from_gobject_id = CTE.gId
	)
	select *
	from CTE
	
	
end

go

