create proc dbo.internal_get_visual_element_descriptions
    -- comma separated list of visual element ids or file of ids
    @file_of_ve_ids nvarchar(4000),

	@user_guid nvarchar(64)
as
begin
    begin tran

    -- read @file_of_ve_ids
    create table  #ve_ids ( ve_id int)    
    insert #ve_ids(ve_id)
    	exec internal_select_ids @file_of_ve_ids



    create index i1 on #ve_ids (ve_id)

	select	gobject_id,
			tag_name,
			description,
			primitive_name,
			visual_element_type,
            visual_element_id,            
            visual_element_category,
            inherited_from_visual_element_id,
            is_thumbnail_dirty
	from internal_visual_element_description_per_user_view 
	inner join #ve_ids
	on #ve_ids.ve_id = visual_element_id
	where user_guid = @user_guid
	order by tag_name, primitive_name

	drop table #ve_ids    

    commit tran
end
go

