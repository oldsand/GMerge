create procedure dbo.internal_get_visual_element_ids 
@gobject_id int,
@package_id int,
@FileNameOfids nvarchar (265)
as
set nocount on
begin

	SET QUOTED_idENTIFIER OFF

	CREATE TABLE  #results_table(mx_primitive_id smallint)
	
	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	EXEC (@SQL)


    select 
        vev.mx_primitive_id,
        vev.visual_element_id 
    from
        visual_element_version vev
    inner join 
        #results_table r on
        vev.mx_primitive_id = r.mx_primitive_id 
    where 
        vev.gobject_id = @gobject_id and
        vev.package_id = @package_id 
    drop table  #results_table
end
go

