/*
** Arguments:
** @user_selection: File that contains objects selected by the user formatted as follows:
** <dio_id>, [sg_mx_primitive_id], [lo_id]
** dio_id has to be present in each row 
** sg_mx_primitive_id is optional. If 0, all scan-groups are considered for the prevailing dio_id
** lo_id is optional. If 0, all linked objects are considered for the prevailing scan-group (if sg_mx_primitive_id > 0), or dio
** Returns: {data-set}
** 
** Use this sproc to populate the new grid in the IDE.
*/
create PROCEDURE dbo.internal_ab_get_io_map_attribute_references
    @user_selection nvarchar(255)
as
begin
  set nocount on
  /*
    @AutoBoundInfo columns:
      dio_id                      int
    , sg_mx_primitive_id          smallint
    , lo_id                       int
    , lo_package_id               int
    , lo_prim_id                  smallint
    , lo_attr_id                  smallint
    , dio_tag_name                nvarchar (329)
    , dio_scan_group_name         nvarchar (329)
    , app_object_tag_name         nvarchar (329)
    , app_object_attr_name        nvarchar (329)
    , app_object_attr_type        smallint
    , app_object_io_attr          nvarchar (329)
    , binding_rule_id             int
    , binding_rule                nvarchar (500)
    , default_attr_reference      nvarchar (500)
    , xlate_rule_id               int
    , xlate_rule_name             nvarchar (329)
    , overridden_attr_reference   nvarchar (500)
  */
  DECLARE @gSQL nvarchar(2000)

  create table  #devjoin (dio_id int, sg_mx_primitive_id smallint, lo_id int, PRIMARY KEY (dio_id, sg_mx_primitive_id, lo_id))
  SET @gSQL = 'BULK INSERT #devjoin  FROM ''' + @user_selection + ''' 
             WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
  EXEC sp_executesql @gSQL

  --This is return if there is no IO attributes for the processing in the passed data
  if not exists (select 1 from autobound_attribute aba
		inner join #devjoin dj on aba.dio_id = dj.dio_id
		and aba.sg_mx_primitive_id = case when dj.sg_mx_primitive_id <> 0
						then dj.sg_mx_primitive_id else aba.sg_mx_primitive_id end
		and aba.gobject_id = case when dj.lo_id <> 0
						then dj.lo_id else aba.gobject_id end)
  begin 
	return
  end


  SELECT devjoin.dio_id                           AS 'DIO_id'
       , itvf.sg_mx_primitive_id                  AS 'ScanGroup_id'
       , itvf.lo_id                               AS 'LinkedObject_id'
       , dio_tag_name                             AS 'MyDI' 
       , dio_scan_group_name                      AS 'MySG'
       , app_object_tag_name                      AS 'MyObj' 
       , app_object_attr_name                     AS 'MyAttr' 
       , app_object_attr_type                     AS 'MxDataType'
       , app_object_io_attr                       AS 'MyAttrIOType'
       , xlate_rule_id                            AS 'OverrideType'
       , ISNULL (overridden_attr_reference, N'')  AS 'Override'
       , default_attr_reference                   AS 'DefaultAttrReference'
       , (CASE 
            WHEN xlate_rule_name IN (N'Radical_Override', N'Radical_Override_Default_SG', N'ASB_Reference')
              THEN overridden_attr_reference 
            WHEN xlate_rule_name IN (N'Device_Override',  N'Device_and_SG_Override')
              THEN overridden_attr_reference + N'.' + default_attr_reference
            ELSE
                  dio_tag_name + N'.' 
                + dio_scan_group_name + N'.' 
                + ISNULL (overridden_attr_reference, default_attr_reference) 
          END)                                    AS 'QualifiedItemRef'
    FROM #devjoin devjoin
    CROSS APPLY GetAutobindInfoForDIO (devjoin.dio_id, devjoin.sg_mx_primitive_id, devjoin.lo_id, DEFAULT, DEFAULT) itvf
    ORDER BY itvf.dio_tag_name, itvf.dio_scan_group_name, itvf.app_object_tag_name, itvf.app_object_attr_name
    OPTION (FORCE ORDER)
end
go

