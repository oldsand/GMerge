
create   proc dbo.internal_get_root_folder
	@folderId int
As
begin
    declare @objectId int
    select @objectId = @folderId
  
    declare @rootFolderId int
    select @rootFolderId = 0

    while 0 <> @objectId
    begin
    	select 
            @objectId = f.parent_folder_id, 
            @rootFolderId = f.folder_id
    	from folder f 
        where 
            folder_id = @objectId
    end

    select  
        folder_id,
		parent_folder_id, 
		depth,  
		folder_name,
		has_objects, 
		has_folders
	from folder 
	where 
    	folder_id = @rootFolderId
end
go

