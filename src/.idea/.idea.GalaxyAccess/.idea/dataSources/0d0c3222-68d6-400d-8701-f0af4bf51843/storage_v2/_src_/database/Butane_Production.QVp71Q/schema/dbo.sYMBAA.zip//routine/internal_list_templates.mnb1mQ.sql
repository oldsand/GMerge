/**************************************************/
/*Object Name :  internal_listtemplate                       */
/*Object Type :  Stored Proc.								 */
/*Purpose :    to provide proxy data for a all the templates */
/*Used By :    CDI									*/
/**************************************************/

create procedure dbo.internal_list_templates
@varwhere int
 AS
begin
set nocount on

select 
    proxyobj.gobject_id, 
    proxyobj.tag_name, 
    proxyobj.contained_name,
	proxyobj.hierarchical_name,
---    proxyobj.is_template,
    proxyobj.status,
	proxyobj.refStatus,
	proxyobj.hosted_by_gobject_id,
	proxyobj.derived_from_id,
	proxyobj.base_type as base_type,  
    'checkoutbyname' = case when proxyobj.checkedout_by is not null 
						then ( select user_profile_name from  user_profile
								where  user_guid = proxyobj.checkedout_by)
        else  ''
        end, 

    proxyobj.checkedout_by,
    proxyobj.toolset_id,
---    proxyobj.is_checkout,    
---	proxyobj.deployed_package_id as deployed_package_id,
	proxyobj.checked_in_package_id,
	proxyobj.template_definition_id,
---	proxyobj.hasderived_obj,	    
--- proxyobj.hasassigned_obj,
	proxyobj.container_id,
	proxyobj.area_id, 
--- proxyobj.hasContained_obj,
--- proxyobj.hasBelongTo_obj,
---	proxyobj.is_hidden,
---	proxyobj.software_upgrade_needed,
	proxyobj.checked_out_package_status,
	proxyobj.gObjectStatus,
    CAST ( proxyobj.timestamp_of_last_change  as bigint ) timestamp_of_last_change,
    proxyobj.namespace_id,
	proxyobj.folder_id
from  internal_list_objects_view proxyobj
where ( proxyobj.toolset_id = @varwhere ) and 
      ( proxyobj.is_template  = 1 ) and 
      ( proxyobj.is_hidden    = 0 ) and
	  ( proxyobj.container_id  = 0 )

end
go

