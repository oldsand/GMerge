
/**************************************************/
/*Object Name :  internal_setuserpreference									*/
/*Object Type :  Stored Proc.												*/
/*Purpose :    Procedure to set preference for given preference type & user	*/
/*Used By :    PackageServerNet												*/
/**************************************************/
create  proc dbo.internal_set_user_preference
@user_guid nvarchar(64),
@preference_type nvarchar(256),
@preference  image
as
begin

declare @user_profile_id int
set @user_profile_id = 0

select @user_profile_id = user_profile_id from
user_profile where user_guid = @user_guid

if ( select count(*) from user_preferences 
	 where user_profile_id = @user_profile_id
	 and preference_type = @preference_type ) = 0
	
	insert into user_preferences ( user_profile_id, preference_type, preferences)
	values(@user_profile_id,@preference_type,@preference)

else
	
	update user_preferences set preferences = @preference
	where user_profile_id = @user_profile_id
		and preference_type = @preference_type 	
	

end

go

