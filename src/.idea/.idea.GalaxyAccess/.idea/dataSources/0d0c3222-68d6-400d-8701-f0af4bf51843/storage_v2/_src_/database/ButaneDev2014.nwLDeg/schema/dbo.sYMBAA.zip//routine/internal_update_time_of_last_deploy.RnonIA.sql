-- update the TimeofLastDeploy in Galaxy Table
create  procedure dbo.internal_update_time_of_last_deploy
as 
begin
	UPDATE galaxy SET time_of_last_deploy = getDate()
    
end



go

