create proc dbo.internal_cascade_checkin_with_parent_info
    @parent_template_gobject_id int,
    @user_guid nvarchar(64),
    @cascade_uda_info bit,
    @cascade_script_info bit,
    @attribute_reference_file nvarchar(255),
    @attribute_reference_file_has_content int,
    @package_reference_status_file nvarchar(255),
    @package_reference_status_file_has_content int,
    @primitive_ids_file nvarchar(255),
    @primitive_ids_file_has_content int
as
begin
    set nocount on
	 
	-- get the user_profile_name for use with the change log...
	declare @user_profile_name nvarchar(256)
    select @user_profile_name  = user_profile_name 
	from user_profile 
	where user_guid = @user_guid

	if @user_profile_name is NULL
		set @user_profile_name = N'DefaultUser'

	declare @parent_template_checked_in_package_id int
	declare @parent_template_checked_out_package_id int

	select @parent_template_checked_in_package_id = checked_in_package_id,
			@parent_template_checked_out_package_id =  checked_out_package_id
	from gobject
	where gobject_id = @parent_template_gobject_id

	create table #dirty_primitives_results_table ( mx_primitive_id int primary key)
	if (@cascade_script_info = 1)
	begin
		insert into #dirty_primitives_results_table(mx_primitive_id)
		select pri.mx_primitive_id 
		from primitive_instance pri
		where pri.operation_on_primitive_mask <> 0
		and @parent_template_checked_out_package_id = pri.package_id
	end
    -- create a table based on input parameter
    
    declare @previous table 
	(
        gobject_id  int,
		parent_checked_out_package_id int,
        primary key (gobject_id)
    )

    declare @next table 
	(
        gobject_id  int,
		parent_checked_out_package_id int,
        primary key (gobject_id)
    )
	
	declare @affected_objects table
	(
		gobject_id int,
		message_text nvarchar(4000)
	)
	
	declare @derivation_level int
	

	-- table to be used in internal_multi_gobjects_checkout
	create table #results_table ( gobject_id int primary key)

	/*
		Steps:
		1) Find all objects directly derived from the passed-in object	
		2) Check these objects out
		3) Overwrite the inherited dynamic attributes with the ones in the parent's
		   checked-out package
		4) Go to the next level and do the same thing...(until the last level is complete)		
		5) Return a list of affected objects
		6) Calculate reference based on input files

	*/

	--1) Find all objects directly derived from the passed-in object	
    insert  @next
		(gobject_id,
		 parent_checked_out_package_id)
    select  
		gobject_children.gobject_id,
		gobject_parent.checked_out_package_id
	from gobject gobject_children
	inner join gobject gobject_parent on
		gobject_parent.gobject_id = @parent_template_gobject_id and
		gobject_parent.checked_out_package_id > 0
	where gobject_children.derived_from_gobject_id = @parent_template_gobject_id

	set @derivation_level = 1

    while exists (select '1' from @next )
    begin

		--2) Check these objects out

		truncate table #results_table

		insert into #results_table
			(gobject_id)
		select 
			gobject_id
		from @next
		
		insert into @affected_objects
		exec internal_multi_gobjects_checkout @user_guid, N'', 1

		declare	@timestamp datetime
		set @timestamp = getdate()

		insert into gobject_change_log
		( 
			gobject_id, 
			change_date, 
			operation_id, 
			user_comment, 
			configuration_version,
			user_profile_name 
		)
		select
			r.gobject_id,
			@timestamp,
			2,
			N'System checked out object during cascade checkin from parent.',
			g.configuration_version,
			@user_profile_name
		from #results_table r 
		inner join gobject g on
			r.gobject_id = g.gobject_id

			
		--3) Overwrite the inherited dynamic attributes with the ones in the parent's
		--   checked-out package
		if (@cascade_uda_info = 1)
		begin
		    exec internal_set_uda_info_from_parents_checked_out_package 
			    @derivation_level
        end
        
		if (@cascade_script_info = 1)
		begin
		    exec internal_set_script_info_from_parents_checked_out_package 
        end

		set @timestamp = getdate()
		insert into gobject_change_log
		( 
			gobject_id, 
			change_date, 
			operation_id, 
			user_comment, 
			configuration_version,
			user_profile_name 
		)
		select
			r.gobject_id,
			@timestamp,
			37, 
			N'System updated object configuration during cascade checkin from parent.',
			g.configuration_version,
			@user_profile_name
		from #results_table r
		inner join gobject g on
			r.gobject_id = g.gobject_id
		
		-- update the children's derived_from_package_id to point to their
		-- parent's checked_out_package_id

		-- bump up the deployable_configuration_version of the children.  
		-- This will trigger a pending update if they are deployed...
		update p
		set 
			p.deployable_configuration_version = p.deployable_configuration_version + 1,
			p.derived_from_package_id = n.parent_checked_out_package_id
		from @next n
		inner join gobject g on
			n.gobject_id = g.gobject_id
		inner join package p on
			p.gobject_id = g.gobject_id and
			p.package_id = g.checked_out_package_id
			

		--4) Go to the next level and do the same thing...(until the last level is complete)
		insert into @previous 
			(gobject_id,
			parent_checked_out_package_id)
		select
			gobject_id,
			parent_checked_out_package_id
		from @next

		delete
		from @next

		insert into @next
			(gobject_id,
			 parent_checked_out_package_id)
		select 
			g.gobject_id,
			gobject_parent.checked_out_package_id
		from @previous p -- parent table...
		inner join gobject g on
			g.derived_from_gobject_id = p.gobject_id
		inner join gobject gobject_parent on 
			gobject_parent.gobject_id =  g.derived_from_gobject_id

		delete
		from @previous
		
		set @derivation_level = @derivation_level + 1
	end
		
    if (@primitive_ids_file_has_content = 1)
    begin
        create table #primitive_ids_to_be_removed (
            mx_primitive_id int
        )
        
	    DECLARE @SQL3 nvarchar(2000)
	    SET @SQL3 = 'BULK INSERT #primitive_ids_to_be_removed  FROM ''' + @primitive_ids_file + ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '
	    EXEC sp_executesql @SQL3
        
        declare @descendents table
        (
            gobject_id int default 0,
            package_id int default 0,
            is_template bit,
            is_immediate_child bit,
            primary key(gobject_id, package_id)            
        )       

        insert @descendents(gobject_id, is_template, is_immediate_child)
            exec internal_get_gobject_descendants @parent_template_gobject_id

        update  de
        set     de.package_id = g.checked_out_package_id
        from    @descendents de
        inner join
                gobject g
        on  
                g.gobject_id = de.gobject_id                

     	delete  ar
    	from    
    	        attribute_reference ar
    	inner join 
    	        @descendents de
    	on
    	        ar.gobject_id = de.gobject_id
    	    and ar.package_id = de.package_id
    	inner join
    	        #primitive_ids_to_be_removed pr 
    	on
    	        ar.referring_mx_primitive_id = pr.mx_primitive_id    	    
    end

    
	-- update attribute reference
	if (@attribute_reference_file_has_content = 1)
	begin

	    CREATE TABLE  #attribute_references ( 
					    gobject_id int,
					    package_id int,
					    ref_prim_id int,
					    ref_attr_id int,
				        element_index int, 
				        res_gobject_id int default 0,
				        dest_obj_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS not null default '',
				        obj_sign int,
				        attr_sign int, 
				        res_mx_prim_id int,
				        res_mx_attr_id int,
				        res_mx_prop_id int,
				        attr_res_st int,
                        attr_idx int,
                        is_valid int,
                        reference_string nvarchar(700) COLLATE SQL_Latin1_General_CP1_CI_AS not null default ''
        )	
                        
        create index temp_idx_attribute_references on
            #attribute_references(gobject_id,package_id,ref_prim_id)

        create index temp_idx_attribute_references_on_dest_obj_name on
            #attribute_references(dest_obj_name)

            
	    DECLARE @SQL nvarchar(2000)
	    SET @SQL = 'BULK INSERT #attribute_references  FROM ''' + @attribute_reference_file + ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '
	    EXEC sp_executesql @SQL
    	
        update  tempar            
        set     
                tempar.res_gobject_id = g.gobject_id
        from    
                #attribute_references tempar
        inner join 
                gobject g
        on      
                tempar.dest_obj_name = g.tag_name

        update  tempar            
        set     
                tempar.package_id = g.checked_out_package_id
        from    
                #attribute_references tempar
        inner join 
                gobject g
        on      
                tempar.gobject_id = g.gobject_id
                
             --This requires only for ScriptExtension._AliasReferences 
             --because its unlocked attributes, we don’t want tot delete it.

                    	
    	delete  ar
    	from    attribute_reference ar
    	inner join 
    	        #attribute_references tempar
    	on      ar.gobject_id = tempar.gobject_id
    	    and ar.package_id = tempar.package_id
    	    and ar.referring_mx_primitive_id = tempar.ref_prim_id
    	    inner join primitive_instance pri 
    	on   	pri.gobject_id = ar.gobject_id
    		and pri.package_id = ar.package_id
    		and pri.mx_primitive_id = ar.referring_mx_primitive_id
    		and pri.extension_type = N'ScriptExtension'
    		and ar.referring_mx_attribute_id <> 102
    	    
    	    -- Update the context_String same as tag_name
    	    -- This will improve reference binding thread performance 
    	    
    	    
    	    
    	insert  attribute_reference(
                    gobject_id,
                    package_id,
                    referring_mx_primitive_id,
                    referring_mx_attribute_id,
	                element_index,
                    resolved_gobject_id,
                    reference_string,
                    context_string,
                    object_signature,
                    resolved_mx_primitive_id,
                    resolved_mx_attribute_id,
                    resolved_mx_property_id,
	                attribute_signature,
	                lock_type,
                    is_valid,
	                attr_res_status,
	                attribute_index)
	    (
	        select  atr.gobject_id,
	                atr.package_id,
	                atr.ref_prim_id,
	                atr.ref_attr_id,
	                atr.element_index,
	                atr.res_gobject_id,
	                atr.reference_string,
	                g.tag_name,
	                atr.obj_sign,
                    atr.res_mx_prim_id,
                    atr.res_mx_attr_id,
                    atr.res_mx_prop_id,
                    atr.attr_sign,
                    1,
                    atr.is_valid,
                    atr.attr_res_st,
                    atr.attr_idx
            from    #attribute_references atr
            inner join gobject g
            on 	  g.gobject_id = atr.gobject_id 
            where g.is_Template = 0	                       
	    )	    	    
	    
	    -- Set primitive_instance status for these primitives
	    update  pri
	    set     
	            pri.ref_status_id = 0
	    from    
	            primitive_instance pri
	    inner join 
	            #attribute_references tempar
	    on 
	        pri.gobject_id = tempar.gobject_id
	    and pri.package_id = tempar.package_id
	    and pri.mx_primitive_id = tempar.ref_prim_id


	    update  pri
	    set     
	            pri.ref_status_id = 2
	    from    
	            primitive_instance pri
	    inner join 
	            #attribute_references tempar
	    on 
	        pri.gobject_id = tempar.gobject_id
	    and pri.package_id = tempar.package_id
	    and pri.mx_primitive_id = tempar.ref_prim_id
	    where
	            tempar.is_valid = 1 -- is_valid == 1 means the reference is invalid ;(
	        
    	
    	
	    -- Update package reference status for those objects which has referencs
        update  pa
        set     pa.reference_status_id = 0
        from    
                package pa
        inner join 
                #attribute_references tempar
        on      
                pa.gobject_id = tempar.gobject_id
        and     pa.package_id = tempar.package_id


        update  pa
        set     pa.reference_status_id = 2
        from    
                package pa
        inner join 
			    primitive_instance pri
	    on
			    pa.gobject_id = pri.gobject_id
		    and	pa.package_id = pri.package_id
	    inner join
                #attribute_references tempar
        on      
                pri.gobject_id = tempar.gobject_id
        and     pri.package_id = tempar.package_id
	    where
			    pri.ref_status_id = 2
    end
    
--L00085436
  -- Set primitive_instance status for these primitives
-- If the invalid attribute reference is deleted from primitive
-- We need to reset the package status

		update  pa
        set     pa.reference_status_id = 0
        from    
                package pa
        inner join 
                @affected_objects tempar
        on      
                pa.gobject_id = tempar.gobject_id
        where   pa.package_type = 'O'


	-- Primitive instance's ref_status_id column is NOT VALID ANY MORE.
	-- So we need to set the Package Reference from Attribute_Reference table

        update  pa
        set     pa.reference_status_id = 2
        from    
                package pa
        inner join 
			    attribute_reference attr
	    on
			    pa.gobject_id = attr.gobject_id
		    and	pa.package_id = attr.package_id
	    inner join
                @affected_objects tempar
        on      
                attr.gobject_id = tempar.gobject_id
        where
			    attr.is_valid = 1
			    and pa.package_type = 'O'
		
		select 
			gobject_id,
			message_text
		from @affected_objects

		drop table #results_table
		drop table #dirty_primitives_results_table

		

	
end


go

