-- This stored procedure will return the GalaxyStatusInfo 
-- It will take input parameter as login user_guid and will output as 
-- total number of instances, total number of templates
-- total number of objects having errors and warnings,
-- total number of objects notdeployed, require changes (software pending or upgrade)
-- total number of objects checked out and checkout to logged -in user.
create procedure dbo.internal_get_galaxy_status
        @logged_in_userguid uniqueidentifier,
        @totalnumberofinstances int output,
        @totalnumberoftemplates int output,
        @numberofobjectswithErrors int output,
        @numberofobjectswithWarnings int  output,
        @numberOfInstancesNotDeployed int output,
        @numberofObjectsWithChanges int output,
        @numberofObjectsCheckedOut int output,  
        @numberofObjectsCheckedOutToLoggedinUser int output     
AS
begin

    select @totalnumberofinstances = count(*) 
    from instance i
    inner join gobject g on
	i.gobject_id = g.gobject_id and
	g.namespace_id <> 3 

    set @totalnumberofinstances = @totalnumberofinstances -1 -- remove the hidden gobject


    select @totalnumberoftemplates = count (*)
    from folder_gobject_link t
    inner join gobject g on
	t.gobject_id = g.gobject_id and
	g.namespace_id <> 3 


    set @numberofobjectswithErrors = 0 
    set @numberofobjectswithWarnings = 0 

    declare @temp int   

	-- CR L00086464. 
	-- '@numberofobjectswithWarnings' will return Only the objects list that are 
	-- only in the Warning meaning If the object is in both error and warning state, 
	-- then that object is not and returned in the variable '@numberofobjectswithWarnings'
	
	declare @gobject_with_warning table (gobject_id int primary key)	
	insert into @gobject_with_warning 
	select distinct(package.gobject_id)    
    from package
    inner join gobject on 
        gobject.gobject_id = package.gobject_id and
		gobject.checked_in_package_id = package.package_id and 
		package.status_id <> 1 	and 
		package.reference_status_id <> 1  		
	left outer join visual_element_reference ver_warning_view on
		gobject.gobject_id = ver_warning_view.gobject_id and
		package.package_id = ver_warning_view.package_id and
		ver_warning_view.visual_element_bind_status = 0 and
		ver_warning_view.checked_in_unbound_visual_element_name <> '---'
	where (
	(ver_warning_view.gobject_id > 0) or 
	(  ((package.status_id = 2) or (package.reference_status_id = 2)) and 
		package.status_id <> 1 	and 
		package.reference_status_id <> 1  and ver_warning_view.gobject_id is null)
	)

    SELECT @numberofobjectswithWarnings = count(*)
    from @gobject_with_warning       

    SELECT @numberofobjectswithErrors = count(*)
    from package      
    inner join gobject on 
        gobject.gobject_id = package.gobject_id 
    and gobject.checked_in_package_id = package.package_id 
    and ((package.status_id = 1) or (package.reference_status_id = 1))  


    select @numberOfInstancesNotDeployed = count(*) 
    from gobject g
    inner join instance i on g.gobject_id = i.gobject_id and g.deployed_package_id = 0 and
	g.namespace_id <> 3 

    set @numberOfInstancesNotDeployed  = @numberOfInstancesNotDeployed -1 -- hidden instance

    --Start:Fix for CR L00135656. Ported changes from the HF CR L00135254.
    declare @b bit 
    set @b = 1
    select @numberofObjectsWithChanges = count(*) from gobject g 
    inner join package p1 on g.gobject_id = p1.gobject_id 
    and g.checked_in_package_id = p1.package_id
    inner join package p2 on g.gobject_id = p2.gobject_id 
    and g.deployed_package_id = p2.package_id
    where (g.checked_in_package_id <> g.deployed_package_id  and g.deployed_package_id <> 0 and p1.deployable_configuration_version <> p2.deployable_configuration_version) 
    or (g.software_upgrade_needed = @b)
    --End:Fix for CR L00135656. Ported changes from the HF CR L00135254.

    select @numberofObjectsCheckedOut= count(*) from gobject
    where checked_out_package_id <>0

    select @numberofObjectsCheckedOutToLoggedinUser = count(*) from gobject 
    where (checked_out_package_id <>0) and 
    (checked_out_by_user_guid = @logged_in_userguid)

end
go

