/**************************************************
Object Name :  internal_get_browsercontrolinfo
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves all browser control information
               from a galaxy.
**************************************************/

CREATE PROCEDURE dbo.internal_get_browsercontrolinfo
AS

begin
    SET NOCOUNT ON

    select  distinct assembly_strong_name
    from    file_browserinfo_link

    SET NOCOUNT OFF

end

go

