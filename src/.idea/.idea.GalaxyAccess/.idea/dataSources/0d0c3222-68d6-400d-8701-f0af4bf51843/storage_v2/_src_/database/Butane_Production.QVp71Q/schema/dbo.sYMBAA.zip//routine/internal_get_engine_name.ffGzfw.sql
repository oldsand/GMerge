create proc dbo.internal_get_engine_name
@gobjectid int,
@enginename nvarchar(32) out
as
begin

set @enginename = (select isnull(engname.tag_name,'') from instance inst
			 left join instance inst1 on inst.mx_platform_id = inst1.mx_platform_id and inst.mx_engine_id = inst1.mx_engine_id and inst1.mx_object_id = 1
			 left join gobject engname on inst1.gobject_id = engname.gobject_id
			 where inst.gobject_id = @gobjectid )
set nocount on
end
go

