create procedure dbo.internal_get_referenced_visual_elements_after_last_deploy
@intouch_viewapp_gobject_id int
as
begin tran

	create  table #visual_element_ids_for_deployed_referenced_elements
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)

	create  table #visual_element_ids_for_checked_in_referenced_elements
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)

	create  table #visual_element_ids_delta_referenced_elements
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)
	
	--US 345803: Removed "IsITVAppPOC" registry key dependency to enable Light InTouchViewApp Concept.
	--ITVAPP POC START
	declare @intouch_viewapp_gobject_id_temp int
	set  @intouch_viewapp_gobject_id_temp = @intouch_viewapp_gobject_id
	--get the parent 
	declare @category_id int
		--store previous values
	select  @category_id = category_id 
			from gobject with (NOLOCK) 
			inner join template_definition on 
				gobject.template_definition_id = template_definition.template_definition_id
			where gobject_id = @intouch_viewapp_gobject_id
		
	if(@category_id = 26)
	begin
		--if category is OF ITVAPP (no need to check but doing it: get the derived from gobject id
		select @intouch_viewapp_gobject_id_temp = g.derived_from_gobject_id from gobject g 
		where g.gobject_id = @intouch_viewapp_gobject_id
	end
	--ITVAPP POC END
	
	
	-- get the checked-in references....
    insert #visual_element_ids_for_checked_in_referenced_elements
	(
		visual_element_id,
		gobject_id,
    	package_id,
	    mx_primitive_id ,
		visual_element_reference_index
	)
    select 
		vev.visual_element_id,
		ver.checked_in_bound_visual_element_gobject_id,
		ver.checked_in_bound_visual_element_package_id,
		ver.checked_in_bound_visual_element_mx_primitive_id,
		ver.visual_element_reference_index
    from visual_element_reference ver
    inner join visual_element_version vev on
        ver.checked_in_bound_visual_element_gobject_id = vev.gobject_id and
        ver.checked_in_bound_visual_element_package_id = vev.package_id and 
        ver.checked_in_bound_visual_element_mx_primitive_id = vev.mx_primitive_id and
        ver.visual_element_bind_status = 1
    inner join gobject g on
        g.gobject_id = ver.gobject_id and
        g.checked_in_package_id = ver.package_id
    where ver.gobject_id = @intouch_viewapp_gobject_id_temp


	-- get the deployed references....
    insert #visual_element_ids_for_deployed_referenced_elements
	(
		visual_element_id,
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_reference_index
	)
    select 
		vev.visual_element_id,
		ver.checked_in_bound_visual_element_gobject_id,
		ver.checked_in_bound_visual_element_package_id,
		ver.checked_in_bound_visual_element_mx_primitive_id,
		ver.visual_element_reference_index
    from visual_element_reference ver
    inner join visual_element_version vev on
        ver.checked_in_bound_visual_element_gobject_id = vev.gobject_id and
        ver.checked_in_bound_visual_element_package_id = vev.package_id and 
        ver.checked_in_bound_visual_element_mx_primitive_id = vev.mx_primitive_id and
        ver.visual_element_bind_status = 1
    inner join gobject g on
        g.gobject_id = ver.gobject_id and
        g.deployed_package_id = ver.package_id
    where ver.gobject_id = @intouch_viewapp_gobject_id_temp


    insert #visual_element_ids_delta_referenced_elements
	(
		visual_element_id,
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_reference_index
	)
    select 
		ci.visual_element_id,
		ci.gobject_id,
		ci.package_id,
		ci.mx_primitive_id,
		ci.visual_element_reference_index
    from #visual_element_ids_for_checked_in_referenced_elements ci
	where ci.visual_element_id not in
	(select 
		visual_element_id
	 from #visual_element_ids_for_deployed_referenced_elements )

	
	-- now, get all of the recursively referenced visual_elements...
	create  table #input_table
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)
	insert into #input_table
	(
 	 visual_element_id,
	 gobject_id,
	 package_id,
	 mx_primitive_id,
	 visual_element_reference_index 
	)
	select 
 	 visual_element_id,
	 gobject_id,
	 package_id,
	 mx_primitive_id,
	 visual_element_reference_index 
	from #visual_element_ids_delta_referenced_elements
	
	create table  #output_table 
	(
		visual_element_id int,
		gobject_id int,
   	    package_id int,
	    mx_primitive_id smallint,
		visual_element_reference_index int
	)

	exec internal_get_recursively_referenced_visual_elements
	
	insert into #final_output
	select 
		ot.visual_element_id,
		ot.visual_element_reference_index
	from #output_table ot
	where ot.visual_element_id not in
		(
			select 
				visual_element_id
			from #final_output
		)

	drop table #visual_element_ids_for_deployed_referenced_elements	
	drop table #visual_element_ids_for_checked_in_referenced_elements
	drop table #visual_element_ids_delta_referenced_elements

commit

go

