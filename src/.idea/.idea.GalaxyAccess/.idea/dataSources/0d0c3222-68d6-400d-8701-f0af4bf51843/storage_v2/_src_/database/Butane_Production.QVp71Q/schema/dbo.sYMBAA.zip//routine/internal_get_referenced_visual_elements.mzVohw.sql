--
-- Returns the all visual elements referenced by
-- a given visual element
--
-- Example:
--
--    exec internal_get_referenced_visual_elements '20,5', 0, '7F0312F4-0D1E-4D8D-84E2-1DEA26A65237'
--
create proc dbo.internal_get_referenced_visual_elements
(
    -- comma separated list of visual element ids or file of ids
    @ids_or_file_of_ids nvarchar(4000),
 
    -- set to 0 to find direct references
    -- set to 1 to find direct and indirect references
    @recursive as bit,
 
    -- user making request, will affect results returned
    @user_guid uniqueidentifier,

    -- optional argument: if name of deployed InTouchViewApp is 
    -- passed, the result set will be filtered and only visual elements
    -- that have been modified or created since the time of deploy will 
    -- be returned...
    @intouch_viewapp_name nvarchar(329) = ''
)
as begin
    -- put visual_element_ids into table
    create  table #visual_element_ids_for_referenced_elements(visual_element_id int)
    
    insert #visual_element_ids_for_referenced_elements(visual_element_id)
        exec internal_select_ids @ids_or_file_of_ids
 
    create table  #final_selection 
    (
        visual_element_id int,
        gobject_id int,
        package_id int,
		visual_element_reference_index int
    )

    create index final_selection_index on #final_selection (visual_element_id, gobject_id, package_id)

    declare @next_selection  table
    (
        visual_element_id int,
        gobject_id int,
        package_id int,
		visual_element_reference_index int
    )
 
    while( 1 = 1 )
    begin   

        insert into @next_selection    

            select 
                bound_vev.visual_element_id, 
                vev.gobject_id, 
                vev.package_id, 
                bver.visual_element_reference_index
            from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on 
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id
                and bver.package_id = vev.package_id
                and bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
            where bound_vev.visual_element_id not in 
            (select visual_element_id from #final_selection)
        union
            select 
                bound_vev.visual_element_id, 
                vev.gobject_id, 
                vev.package_id, 
                bver.visual_element_reference_index
            from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on 
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id
                and bver.package_id = vev.package_id
                and bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
            where bound_vev.visual_element_id not in 
            (select visual_element_id from #final_selection)




        delete from @next_selection where dbo.is_package_visible_to_user( gobject_id, package_id, @user_guid ) = 0		
	    truncate table #visual_element_ids_for_referenced_elements 		

        insert into #visual_element_ids_for_referenced_elements
	        select visual_element_id from @next_selection 

	    insert into #final_selection
	         select * from @next_selection 

         delete from @next_selection
 
        
    if( (@@ROWCOUNT = 0) or (@recursive = 0) )
      break
    end
    
    if(len(@intouch_viewapp_name)= 0)
    begin
        select visual_element_id , visual_element_reference_index
        from #final_selection 
        group by visual_element_id,visual_element_reference_index
        order by visual_element_reference_index
    end
    else
    begin
        -- Filter the result set for visual elements that
        -- were modified since last deploy...
        declare @intouch_viewapp_gobject_id int

        select @intouch_viewapp_gobject_id = gobject_id
        from gobject 
        where 
            tag_name = @intouch_viewapp_name and
            namespace_id = 1

        declare @after_timestamp timestamp
        select @after_timestamp = timestamp_of_deploy
        from deployed_intouch_viewapp
        where gobject_id = @intouch_viewapp_gobject_id
        -- room for optimization here...
        -- mx_primitive_id can be added to #final_selection to
        -- avoid a join with visual_element_version...
        select 
            u.visual_element_id , 
            u.visual_element_reference_index
        from #final_selection u
        inner join visual_element_version vev on
          u.visual_element_id = vev.visual_element_id
        inner join primitive_instance pri on
          vev.gobject_id = pri.gobject_id and
          vev.package_id = pri.package_id and
          vev.mx_primitive_id = pri.mx_primitive_id and
          pri.timestamp_of_last_change > @after_timestamp
        group by 
            u.visual_element_id,
            u.visual_element_reference_index
        order by u.visual_element_reference_index
                        
    end

    drop table #final_selection
    
end

go

