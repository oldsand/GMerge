--
-- Derive the HierarchicalName for an object base on the containedName
-- and then update it inside the gobject table
--
-- usage : internal_set_full_hierarchical_name gobject_id

CREATE proc dbo.internal_set_full_hierarchical_name 
	@gobject_id int
As

declare @objectId int
declare @tagname nvarchar(32)
declare @containedName nvarchar(32)
declare @hierarchicalName nvarchar(329)

select @objectId = @gobject_id
select @hierarchicalName = ''

while 0 <> @objectId
begin
	select @objectId = g.contained_by_gobject_id, @tagname = g.tag_name, @containedName = g.contained_name
	from gobject g where gobject_id = @objectId

	if( @@rowcount = 0 ) break

	if @hierarchicalName = ''
		begin
			if 0 = @objectId
				set @hierarchicalName = @tagname
			else
				set @hierarchicalName = @containedName
		end
	else
		begin
			if 0 = @objectId
				set @hierarchicalName = @tagname + '.' + @hierarchicalName	
			else
				set @hierarchicalName = @containedName + '.' + @hierarchicalName
		end
end

update gobject set hierarchical_name = @hierarchicalName where gobject_id = @gobject_id
update gobject set tag_name = @hierarchicalName where gobject_id = @gobject_id and is_template = 1
go

