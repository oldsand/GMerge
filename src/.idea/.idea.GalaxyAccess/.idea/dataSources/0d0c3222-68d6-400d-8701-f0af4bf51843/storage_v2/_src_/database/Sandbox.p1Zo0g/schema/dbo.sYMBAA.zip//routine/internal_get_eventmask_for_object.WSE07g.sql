create procedure dbo.internal_get_eventmask_for_object
    @gobject_id int
AS
set nocount on

begin
    declare @eventmask int
    set @eventmask = 0
    select  @eventmask = td.event_mask
    from    template_definition td 
    inner join gobject g
        on td.template_definition_id = g.template_definition_id
    where   g.gobject_id = @gobject_id

    select  @eventmask as eventmask

end
set nocount off
go

