CREATE  proc dbo.internal_get_operation_status
@operation_id int,
@status int out
as
set @status = 0

select @status = status 
from operation_status 
where operation_id = @operation_id
go

