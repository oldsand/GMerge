/*
	Takes a visual element and
	an output integer to indicate whether its being referenced
	or not...
*/
create proc dbo.internal_is_visual_element_being_referenced
    @visual_element_type nvarchar(32), 
	@visual_element_name nvarchar(362),
    -- user making request, will affect results returned
    @user_guid uniqueidentifier,
	@is_referenced int output
as
begin
    -- Assume the visual element information is incorrect
	set @is_referenced  = -1

	if exists
	(
		select '*'
		from internal_visual_element_description_per_user_view
		where 
			(visual_element_type = @visual_element_type and
			visual_element_name = @visual_element_name and
			user_guid = @user_guid)
		
	)
	begin
        -- Now it is a valid visual element type and name
		set @is_referenced  = 0

        -- Check whether it is being referenced or not
		if exists
		(
			select '*'
			from internal_visual_element_reference_per_user_view
			where 
				calculated_visual_element_name = @visual_element_name and
				visual_element_type = @visual_element_type and
				user_guid = @user_guid
			)
		begin
			set @is_referenced  = 1
		end
	end
end

go

