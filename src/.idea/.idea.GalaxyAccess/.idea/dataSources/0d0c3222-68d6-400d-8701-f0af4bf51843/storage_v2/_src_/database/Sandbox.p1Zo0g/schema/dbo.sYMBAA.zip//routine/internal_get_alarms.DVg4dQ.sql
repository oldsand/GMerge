CREATE PROCEDURE dbo.internal_get_alarms
(
	@filepath_of_gobject_ids nvarchar(265) 
	-- One gObject Id per line in an ANSI text file.
)
AS
BEGIN
	-- Returns rowset based on alarm view for the specified objects
	-- [full alarm name],[gObjectId],[PackageId],[mx_primitive_id]
	
	CREATE TABLE  #gobjectIds (gobject_id int primary key)
	DECLARE @SQL nvarchar(2000)
	
	SET @SQL = 'BULK INSERT #gobjectIds  FROM ''' + @filepath_of_gobject_ids + ''' WITH(
			    FIELDTERMINATOR = '','',
				TABLOCK,
				DATAFILETYPE  = ''widechar''       
				)'
	EXEC sp_executesql @SQL

	select alarms.name, alarms.gobject_id, alarms.package_id, alarms.mx_primitive_id from #gobjectIds gids
    inner join internal_all_alarms_view alarms on alarms.gobject_id = gids.gobject_id 
    
    drop table #gobjectIds
END
go

