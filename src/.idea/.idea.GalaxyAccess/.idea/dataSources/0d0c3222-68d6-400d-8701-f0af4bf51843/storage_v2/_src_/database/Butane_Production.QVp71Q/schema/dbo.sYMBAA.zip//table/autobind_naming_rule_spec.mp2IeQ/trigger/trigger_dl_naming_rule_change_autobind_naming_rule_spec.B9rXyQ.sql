CREATE TRIGGER trigger_dl_naming_rule_change_autobind_naming_rule_spec 
ON  [autobind_naming_rule_spec]
FOR INSERT, UPDATE
AS  
begin
	declare @rule_id int
	select @rule_id = rule_id
	from inserted 
	
    EXECUTE internal_ab_refresh_attribute_aliases 0, 0, 0, 0, 0, @rule_id
end
go

