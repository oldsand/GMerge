/*
    Uses the table #results_table as its input.  This table must
    be created and filled prior to the execution of this procedure.
*/
create procedure dbo.internal_set_uda_info_from_parents_checked_out_package
    @derivation_level int
as
begin 
    /*
    Steps:
    1)  Copy all owned dynamic_attibute rows that are UDAs into a temp table for all children
    2)  Delete all UDA rows for all of the children (this will delete owned as well as inherited)
    3)  Insert all inherited UDAs
    4)  Add the children's UDAs back keeping the parent sequence for mx_attribute_id
    5)  Overwrite the unlocked inherited UDA value with value from the child's checked-in package...
    --  Max parent - my max + 1
    */
    declare @children table
    (
        gobject_id int,
        checked_out_package_id int,
        checked_in_package_id int,
        derived_from_gobject_id int,
        parent_checked_out_package_id int,
        parent_checked_in_package_id int,
        is_template bit,
        primary key (gobject_id,checked_out_package_id)
    )
    
    begin tran
    insert into @children
    (
        gobject_id,
        checked_out_package_id,
        checked_in_package_id,
        derived_from_gobject_id ,
        parent_checked_out_package_id,
        parent_checked_in_package_id,
        is_template
    )
    select 
        child_gobject.gobject_id,
        child_gobject.checked_out_package_id,
        child_gobject.checked_in_package_id,
        child_gobject.derived_from_gobject_id,
        parent_gobject.checked_out_package_id,
        parent_gobject.checked_in_package_id,
        child_gobject.is_template
    from #results_table r with(nolock)
    inner join gobject child_gobject with(nolock) on
        r.gobject_id = child_gobject.gobject_id
    inner join gobject parent_gobject with(nolock) on
        child_gobject.derived_from_gobject_id = parent_gobject.gobject_id
    commit

    
    declare @child_owned_dynamic_attribute table
    (
        gobject_id int NOT NULL,
        package_id int NOT NULL,
        mx_primitive_id smallint NOT NULL,
        mx_attribute_id smallint NOT NULL,
        attribute_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
        mx_data_type smallint NOT NULL,
        is_array bit NOT NULL,
        security_classification smallint NOT NULL,
        mx_attribute_category int NOT NULL,
        lock_type int NOT NULL,
        mx_value text COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
        owned_by_gobject_id int NOT NULL,
        original_lock_type int NOT NULL ,
        dynamic_attribute_type smallint NOT NULL,
		bitvalues smallint NOT NULL
    )
    
    --1)    Copy all owned dynamic_attibute rows that are UDAs into a temp table for all children
    begin tran
    insert into @child_owned_dynamic_attribute
	(
        gobject_id,
        package_id,
        mx_primitive_id,
        mx_attribute_id,
        attribute_name,
        mx_data_type,
        is_array,
        security_classification,
        mx_attribute_category,
        lock_type,
        mx_value,
        owned_by_gobject_id,
        original_lock_type,
        dynamic_attribute_type,
        bitvalues
	)
    select	
		da.gobject_id,
		da.package_id,
		da.mx_primitive_id,
		da.mx_attribute_id,
		da.attribute_name,
		da.mx_data_type,
		da.is_array,
		da.security_classification,
		da.mx_attribute_category,
		da.lock_type,
		da.mx_value,
		da.owned_by_gobject_id,
		da.original_lock_type,
		da.dynamic_attribute_type,
		da.bitvalues
    from @children c
    inner join dynamic_attribute da with(nolock) on
        da.gobject_id = c.gobject_id and
        da.package_id = c.checked_out_package_id and 
        da.owned_by_gobject_id = da.gobject_id and
        da.mx_primitive_id = 2
    commit
    
    --2)  Delete all UDA rows for all of the children (this will delete owned as well as inherited)
    begin tran  
    delete
    from da
    from @children c
    inner join dynamic_attribute da on
        da.gobject_id = c.gobject_id and
        da.package_id = c.checked_out_package_id and
        da.mx_primitive_id = 2
    commit

    --3)  Insert all inherited UDAs
    begin tran  
    insert into dynamic_attribute
	(
        gobject_id,
        package_id,
        mx_primitive_id,
        mx_attribute_id,
        attribute_name,
        mx_data_type,
        is_array,
        security_classification,
        mx_attribute_category,
        lock_type,
        mx_value,
        owned_by_gobject_id,
        original_lock_type,
        dynamic_attribute_type,
        bitvalues
	)
    select 
        c.gobject_id,
        c.checked_out_package_id, 
        parent_dynamic_attribute.mx_primitive_id, 
        parent_dynamic_attribute.mx_attribute_id, 
        parent_dynamic_attribute.attribute_name, 
        parent_dynamic_attribute.mx_data_type, 
        parent_dynamic_attribute.is_array, 
        parent_dynamic_attribute.security_classification,
        parent_dynamic_attribute.mx_attribute_category, 
        parent_dynamic_attribute.lock_type, 
        parent_dynamic_attribute.mx_value, 
        parent_dynamic_attribute.owned_by_gobject_id, 
        parent_dynamic_attribute.original_lock_type, 
        parent_dynamic_attribute.dynamic_attribute_type,
        parent_dynamic_attribute.bitvalues 
    from @children c
    inner join dynamic_attribute parent_dynamic_attribute with(nolock) on
        parent_dynamic_attribute.gobject_id = c.derived_from_gobject_id and
        parent_dynamic_attribute.package_id = c.parent_checked_out_package_id and
        parent_dynamic_attribute.mx_primitive_id = 2
    commit

    --4)  Add the children's UDAs back into dynamic_attribute, keeping the parent sequence for mx_attribute_id
        -- Max parent - my max + 1  
    if exists(select '1' from @child_owned_dynamic_attribute)
    begin
        declare @child_mx_attribute_id_info table
        (
            gobject_id int,
            max_parent_mx_attribute_id int,
            max_child_mx_attribute_id int
        )
        begin tran
        insert into @child_mx_attribute_id_info
        (
            gobject_id,
            max_parent_mx_attribute_id,
            max_child_mx_attribute_id
        )
        select 
            pm.gobject_id,
            pm.max_parent_mx_attribute_id,
            cm.max_child_mx_attribute_id
        from
            (select 
                da.gobject_id gobject_id,
                max(da.mx_attribute_id) max_parent_mx_attribute_id
            from @children c
            inner join  dynamic_attribute da with(nolock) on
                da.gobject_id = c.gobject_id and
                da.package_id = c.checked_out_package_id and
                da.mx_primitive_id = 2
            group by 
                da.gobject_id) pm
        inner join
            (select 
                ca.gobject_id gobject_id,
                min(ca.mx_attribute_id) max_child_mx_attribute_id
            from @children c
            inner join  @child_owned_dynamic_attribute ca on
                ca.gobject_id = c.gobject_id and
                ca.package_id = c.checked_out_package_id and
                ca.mx_primitive_id = 2
            group by 
                ca.gobject_id) cm on
            pm.gobject_id = cm.gobject_id
        commit

        begin tran
        -- now, insert the owned UDAs with the correct numbering order...
        insert into dynamic_attribute
        (
            gobject_id ,
            package_id ,
            mx_primitive_id,
            mx_attribute_id,
            attribute_name,
            mx_data_type,
            is_array,
            security_classification,
            mx_attribute_category,
            lock_type,
            mx_value,
            owned_by_gobject_id,
            original_lock_type,
            dynamic_attribute_type,
            bitvalues
        )
        select
            cda.gobject_id ,
            cda.package_id,
            cda.mx_primitive_id,
            (ci.max_parent_mx_attribute_id  - ci.max_child_mx_attribute_id + 1 + cda.mx_attribute_id),
            cda.attribute_name,
            cda.mx_data_type,
            cda.is_array,
            cda.security_classification,
            cda.mx_attribute_category,
            cda.lock_type,
            cda.mx_value,
            cda.owned_by_gobject_id,
            cda.original_lock_type,
            cda.dynamic_attribute_type,
            cda.bitvalues
        from @child_owned_dynamic_attribute cda
        inner join @child_mx_attribute_id_info ci on
            cda.gobject_id = ci.gobject_id  
        commit
    end
    
    --5)  Overwrite the unlocked inherited UDA value with value from the child's checked-in package...
    -- handle the case where the UDA is unlocked in the parent...
    begin tran

    update checked_out_dynamic_attribute
    set 

        checked_out_dynamic_attribute.is_array = checked_in_dynamic_attribute.is_array,
        checked_out_dynamic_attribute.security_classification = checked_in_dynamic_attribute.security_classification,
        checked_out_dynamic_attribute.mx_value = checked_in_dynamic_attribute.mx_value--,
    from @children c
    inner join dynamic_attribute checked_out_dynamic_attribute with(nolock)on
        checked_out_dynamic_attribute.gobject_id = c.gobject_id and
        checked_out_dynamic_attribute.package_id = c.checked_out_package_id and
        checked_out_dynamic_attribute.lock_type = 0
    inner join dynamic_attribute checked_in_dynamic_attribute with(nolock)on
        checked_in_dynamic_attribute.gobject_id = c.gobject_id and
        checked_in_dynamic_attribute.package_id = c.checked_in_package_id
    where checked_out_dynamic_attribute.attribute_name = checked_in_dynamic_attribute.attribute_name
    and  checked_out_dynamic_attribute.mx_data_type = checked_in_dynamic_attribute.mx_data_type

    commit

    begin tran

    update checked_out_dynamic_attribute
    set 
        checked_out_dynamic_attribute.lock_type  = 
        case 
		when checked_out_dynamic_attribute.lock_type = 2 then -- Parent: LockedInParent will be in  Child : LockedInParent
            2
        when checked_out_dynamic_attribute.lock_type = 1 then -- Parent: LockedInMe will be in  Child : LockedInParent
            2
		when checked_out_dynamic_attribute.lock_type  = 0 then -- Parent: Unlocked will be 

			case when (( checked_in_dynamic_attribute.lock_type = 1 ) or ( checked_in_dynamic_attribute.lock_type = 2)) then -- If  Child : LockedInParent/LockedInMe will be in  Child : LockedInMe
				1
	        else
		        checked_out_dynamic_attribute.lock_type                 
			end

		end
    from @children c
    inner join dynamic_attribute checked_out_dynamic_attribute with(nolock)on
        checked_out_dynamic_attribute.gobject_id = c.gobject_id and
        checked_out_dynamic_attribute.package_id = c.checked_out_package_id and
		checked_out_dynamic_attribute.owned_by_gobject_id <> checked_out_dynamic_attribute.gobject_id
    inner join dynamic_attribute checked_in_dynamic_attribute with(nolock) on
        checked_in_dynamic_attribute.gobject_id = c.gobject_id and
        checked_in_dynamic_attribute.package_id = c.checked_in_package_id
    where checked_out_dynamic_attribute.attribute_name = checked_in_dynamic_attribute.attribute_name
		

    commit

    if (@derivation_level = 1)
    begin   
        begin tran
            update cco
            set lock_type = 1
            from @children c
            inner join dynamic_attribute cco with(nolock) on
                c.gobject_id = cco.gobject_id and
                c.checked_out_package_id = cco.package_id
            inner join dynamic_attribute pco with(nolock) on
                pco.gobject_id = c.derived_from_gobject_id and
                pco.package_id = c.parent_checked_out_package_id and
                pco.attribute_name = cco.attribute_name
            inner join dynamic_attribute pci with(nolock) on
                pci.gobject_id = pco.gobject_id and
                pci.package_id = parent_checked_in_package_id and
                pci.attribute_name = pco.attribute_name
            where pci.lock_type = 1 and 
                pco.lock_type = 0 and
                c.is_template = 1
        commit
    end

end
go

