/**************************************************/
/*Object Name :  internal_can_move_folders_to_folder                            */
/*Object Type :  Stored Proc.								*/
/*Purpose :    to check whether folders can be moved to new parent folder or not*/
/*Used By :    CDI									*/
/**************************************************/
create proc dbo.internal_can_move_folders_to_folder
@FileNameOfIds nvarchar (265),
@folder_id int
AS
begin
set nocount on

    CREATE TABLE  #folder_table ( folder_id int)
    DECLARE @SQL nvarchar(2000)
    SET @SQL = 'BULK INSERT #folder_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
    EXEC sp_executesql @SQL

	declare @error_code int

    declare @folders table(folderid int,myparent int,nLevel smallint)
    insert  into  @folders
        select f.folder_id,f.parent_folder_id,1
        from folder f 
        inner join #folder_table ft    
        on f.folder_id = ft.folder_id



    if(exists(select '*' from @folders where myparent = @folder_id))
    begin
        set @error_code = 1001 -- folder cannot be moved to immediate parent
        return @error_code
    end
    
    declare @parent_folder_type int
    select  @parent_folder_type = folder_type from folder where folder_id = @folder_id
    if  exists( select '*' from @folders fi 
                inner join folder f on  
                fi.folderid = f.folder_id
                where f.folder_type <> @parent_folder_type
               ) 		
    begin
        set @error_code = 1006 --'folder_type of target folder should be be same as that of the folders getting moved
        return @error_code
    end


    if  exists( 
                select '1'
                from @folders ct
                inner join  folder c on
                    c.folder_id = ct.folderid		    
                inner join folder cs on
                     c.folder_name = cs.folder_name and
                     cs.parent_folder_id = @folder_id and
                    c.folder_type = cs.folder_type
            )
    begin
        set @error_code = 1003 --'folder with same name already exists in the parent _folder
        return @error_code
    end


    declare @target_folder_depth int
    select  @target_folder_depth = depth from folder where folder_id = @folder_id
    if(@target_folder_depth = 10)
    begin
        set @error_code = 1005 -- Target folder_id depth should be less than 10
        return @error_code
    end


    declare @object_count integer
	declare @nLevel integer
    declare @row_inserted int
	select @object_count = count(*) from @folders


	IF @object_count > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN	
            set @row_inserted = 0
            insert into @folders
			select f.folder_id, f.parent_folder_id, @nLevel + 1
			from folder f inner join @folders fs on f.parent_folder_id = fs.folderid
			where nLevel = @nLevel


            set @row_inserted = @@rowcount
            if(exists(select '*' from @folders where folderid = @folder_id))
            begin
                set @error_code = 1002 -- folder cannot be moved to child folders
                return @error_code
            end

			if @row_inserted = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END

    drop table #folder_table

    declare @total_depth int
    set @total_depth = @target_folder_depth + @nLevel
    if(@total_depth > 10)
    begin
        set @error_code = 1004 -- Total Depth cannot exceed 10
        return @error_code
    end    

    set @error_code = @@error
    if @error_code <> 0 begin
        rollback
        return @error_code
    end

	return @error_code       



end

go

