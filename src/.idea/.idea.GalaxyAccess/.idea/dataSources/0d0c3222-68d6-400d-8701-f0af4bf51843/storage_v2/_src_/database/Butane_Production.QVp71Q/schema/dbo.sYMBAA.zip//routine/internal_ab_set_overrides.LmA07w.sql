create procedure dbo.internal_ab_set_overrides(
    @override_file nvarchar(255),
    @operationStatus int out)
AS 
BEGIN
  BEGIN TRAN

/*
Structure of @override_file:
typedef struct IODEVICEMAPWRITERECORD
{
    int _diObjectId;							-- gobject_id of DIO
    int _scanGroupId;							-- mx_primitive_id of scan-group
    int _linkedObjectId;					-- gobject_id of linked [app] object
    BSTR _bstrItemReferenceName;	-- MyObj.MyAttr.MyAttrIOType: (tag-name|*).uda_name.(inputsource|outputdest) 
		int _overrideType;						-- Override type (-1: Override attr; -2, -3, -4: Complete override) 
		BSTR _bstrOverrideName;				-- Override string
}IODEVICEMAPWRITERECORD;
*/
	CREATE TABLE #ab_attr_override_T
  (
    dio_id      					int
  	, sg_mx_primitive_id	smallint
    , lo_id								int	
    , lo_attr 						nvarchar(329)
    , override_type				int
    , override_value			nvarchar(329)
	)

  DECLARE @rowcnt INT
  DECLARE @ovrSQL nvarchar(2000)
  DECLARE @updObj table (gobject_id int)
  SET @ovrSQL = 'BULK INSERT #ab_attr_override_T  FROM ''' + @override_file + ''' 
              WITH (FIELDTERMINATOR = ''\t'', TABLOCK, DATAFILETYPE  = ''widechar'') '
  EXEC sp_executesql @ovrSQL

  -- Performance hint: Create non-clustered index on #ab_attr_override_T {dio_id, sg_mx_primitive_id, lo_id, lo_attr} after the bulk insert

  -- Change to Merge when SQL 2008 becomes MINVER
  UPDATE ab_attr 
     SET ab_attr.xlate_rule_id 	 			= attr_ovr.override_type
       , ab_attr.attr_alias						= CASE WHEN attr_ovr.override_type = 0 THEN NULL ELSE attr_ovr.override_value END
  OUTPUT INSERTED.gobject_id INTO @updObj
    FROM autobound_attribute ab_attr
  INNER JOIN #ab_attr_override_T attr_ovr
      ON attr_ovr.dio_id 							= ab_attr.dio_id
     AND attr_ovr.sg_mx_primitive_id 	= ab_attr.sg_mx_primitive_id
     AND attr_ovr.lo_id 							= ab_attr.gobject_id
  CROSS APPLY (SELECT * from itvfabSplitAttrRef (attr_ovr.lo_attr)) app_obj_io_ref -- split lo_attr into {ao_name, ao_attr, io_attr_ref}
  CROSS APPLY (SELECT * from itvfGetAutobindInfoForDIO (attr_ovr.dio_id, attr_ovr.sg_mx_primitive_id, attr_ovr.lo_id, app_obj_io_ref.ao_attr, app_obj_io_ref.io_attr_ref)) bind_info
   WHERE ab_attr.dio_id 							= bind_info.dio_id
     AND ab_attr.sg_mx_primitive_id 	= bind_info.sg_mx_primitive_id
     AND ab_attr.gobject_id 					= bind_info.lo_id
     AND ab_attr.mx_primitive_id 			= bind_info.lo_prim_id
     AND ab_attr.mx_attribute_id 			= bind_info.lo_attr_id
     AND ab_attr.element_index 				= bind_info.lo_element_index
  OPTION (FORCE ORDER)

  SET @rowcnt = @@ROWCOUNT

  set @operationStatus = CASE WHEN @rowcnt > 0 THEN 1 ELSE 0 END

  if @operationStatus = 1
  begin
    -- Mark deployed objects that are affected by the override operation as dirty
    -- It shouldn't matter if there are duplicate entries for a given [affected] object in @updObj
    declare @updPxy table (gobject_id int primary key)
    UPDATE g 
       SET deployment_pending_status = 1
    OUTPUT inserted.gobject_id INTO @updPxy
      FROM gobject g
    INNER JOIN @updObj o 
        ON o.gobject_id = g.gobject_id
     WHERE g.deployed_package_id != 0 
       AND g.deployment_pending_status = 0

    -- Update proxy timestamp for affected objects: We don't want duplicate gobject_ids here.
    -- This is why the updated gobject_ids were OUTPUT to @updPxy in the previous update.
    UPDATE pt
       SET pt.gobject_id = up.gobject_id
      FROM proxy_timestamp pt 
    INNER JOIN @updPxy up
        ON up.gobject_id = pt.gobject_id

    UPDATE galaxy
       SET max_proxy_timestamp = CAST (@@dbts  AS timestamp)
  end

  COMMIT

  return @rowcnt
END
go

