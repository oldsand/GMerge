create proc dbo.internal_remove_supported_locale
(
	@locale_id smallint
)
as
begin
	delete from supported_locales 
	where  locale_id = @locale_id	
end

go

