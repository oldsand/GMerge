create proc dbo.internal_IsObjectContainedByListedObjects(
				@ParentId int,
				@ChildIdList nvarchar(255),
				@IsCircularReference int out)
As
begin
	
	create table  #ChildListTable (gid int primary key)
	set @IsCircularReference = 0
	
	--Get the passed information (@ChildIdList) into table
	DECLARE @SQLC nvarchar(2000)
	SET @SQLC = 'BULK INSERT #ChildListTable  FROM ''' + @ChildIdList + ''' 
				WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
	EXECUTE sp_executesql @SQLC
	
	--take the passed object id
	DECLARE @ObjectID int 
	set @ObjectID = @ParentId
	
	--get all decendants for it (@ObjectID) in temp table
	declare @descendant_ObjectIDs table( gobject_id int)
	insert into @descendant_ObjectIDs exec internal_get_all_objects_contained_by_gobject @ObjectID
	
	--for each of @ChildIdList there should be entry in temp table
	--if the entry not present
	declare @count	int
	select @count = COUNT(1) from @descendant_ObjectIDs
	if (@count > 0)
	begin
		DECLARE @suspect_ObId int
		--get the object id for whcih entry not there
		select @suspect_ObId = X.gid from #ChildListTable X where X.gid not in (select gobject_id from @descendant_ObjectIDs)
		--get the all decendants for the object id for which entry not there
		declare @descendant_ObjectIDs2 table( gobject_id int)
		insert into @descendant_ObjectIDs2 exec internal_get_all_objects_contained_by_gobject @suspect_ObId
		--check whether the passed object id (parent id) is in decendants list. if present then circular refernce.
		if exists (select 1 from @descendant_ObjectIDs2 Y where Y.gobject_id = @ObjectID)
		begin
			set @IsCircularReference = 1
		end
		else
		begin
			set @IsCircularReference = 0
		end
	end
	drop table #ChildListTable
end
go

