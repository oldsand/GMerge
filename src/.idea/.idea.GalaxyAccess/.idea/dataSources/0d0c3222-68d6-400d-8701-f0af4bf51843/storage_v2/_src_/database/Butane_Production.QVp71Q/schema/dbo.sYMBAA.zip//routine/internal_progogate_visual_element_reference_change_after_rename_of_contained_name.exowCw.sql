create procedure dbo.internal_progogate_visual_element_reference_change_after_rename_of_contained_name
@gobject_id int
as
begin
-- First, get a list of objects who own visual elements at this containment level,
-- or below this level.  We need to process all of these objects because any relative 
-- references that depend on them could be affected.
declare @gobjects_at_or_below_level_of_renamed_object table
(
	gobject_id int primary key,
	mycontainer int
)


insert into @gobjects_at_or_below_level_of_renamed_object  ( gobject_id,mycontainer)
	(select @gobject_id,0 )
	



	;With CTE
	(
		gobject_id,
		contained_by_gobject_id 
	)
	as
	(
		select 
			g.gobject_id,
			g.contained_by_gobject_id 
		from @gobjects_at_or_below_level_of_renamed_object ao
		inner join gobject g on
			g.contained_by_gobject_id = ao.gobject_id
		union all
		select 
			g.gobject_id,
			g.contained_by_gobject_id 
		from CTE  inner join gobject g on
			g.contained_by_gobject_id = CTE.gobject_id 
		

	)
	insert into @gobjects_at_or_below_level_of_renamed_object		
	(
		gobject_id,
		mycontainer
	)
	select 
		gobject_id,
		contained_by_gobject_id 
	from CTE




-- Find out if there are any VEs that refer to any of this object's symbols via relative references...
declare @visual_elements_referring_to_actual_renamed_object table
(
	gobject_id int,
	package_id int,
	mx_primitive_id smallint,
	primary key (gobject_id,package_id,mx_primitive_id)
)

insert into @visual_elements_referring_to_actual_renamed_object
(
	gobject_id,
	package_id,
	mx_primitive_id
)
	select distinct
	ver.gobject_id,
	ver.package_id,
	ver.mx_primitive_id
	from visual_element_reference ver
	inner join @gobjects_at_or_below_level_of_renamed_object t on
		ver.checked_in_bound_visual_element_gobject_id = t.gobject_id
	where ver.is_relative_reference = 1

if @@rowcount = 0
	return


declare @referring_inherited_visual_elements table
(
	gobject_id int,
	package_id int,
	mx_primitive_id smallint,
	primary key (gobject_id,package_id,mx_primitive_id)
)

insert into @referring_inherited_visual_elements
(
	gobject_id,
	package_id,
	mx_primitive_id
)
	select distinct
	vev.gobject_id,
	vev.package_id,
	vev.mx_primitive_id
	from @visual_elements_referring_to_actual_renamed_object t
	inner join visual_element_version vev on
		t.gobject_id = vev.inherited_from_gobject_id and
		t.package_id = vev.inherited_from_package_id and
		t.mx_primitive_id = vev.inherited_from_mx_primitive_id 
	inner join visual_element ve on
		vev.visual_element_id = ve.visual_element_id and
		ve.inheritance_status = 'I'

		
if @@rowcount = 0
	return


-- now, we have the full list of visual elements that own references
-- that will be affected.  We will now delete these references and then 
-- add them back directly from the parent.  This will ensure that we get the new
-- contained name...

delete ver
from visual_element_reference ver 
inner join @referring_inherited_visual_elements rive on
	ver.gobject_id = rive.gobject_id and
	ver.package_id = rive.package_id and
	ver.mx_primitive_id = rive.mx_primitive_id


declare @affected_children table
(
	gobject_id int,
	package_id int,
	primary key (gobject_id,package_id)
)
insert into @affected_children
select
	distinct
	g.gobject_id,
	g.checked_in_package_id
from @referring_inherited_visual_elements t
inner join gobject g on
	t.gobject_id = g.gobject_id

-- iterate through this @affected_children and call 
-- internal_add_visual_element_references_from_parent for each object 
declare @child_gobject_id int
declare @package_id int

while(@@rowcount > 0)
begin
	select top(1)
		@child_gobject_id = gobject_id,
		@package_id = package_id
	from @affected_children t

	if(@child_gobject_id is not null)
		exec internal_add_visual_element_references_from_parent @child_gobject_id,@package_id, 'I'

	delete from @affected_children
	where gobject_id = @child_gobject_id and
		package_id = @package_id

	if (@@rowcount = 0)
	begin
		exec internal_bind_visual_element_references -- CR 117307
		break
	end

end

end
go

