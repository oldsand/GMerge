create proc dbo.internal_is_gobject_protected(   
                        @gObjectId int,
                        @isObjectProtected int out)
As
begin
      
      set @isObjectProtected = 0
      
      if exists(select 1 from gobject_protected 
      where gobject_protected.gobject_id = @gObjectId)
      begin
            set @isObjectProtected = 1
      end   
end
go

