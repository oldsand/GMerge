--This is Base Template information common in Instance proxys

Create PROCEDURE dbo.internal_get_base_template_infos_proxy
@templateId int,
@bAll	int
as
begin
	if  ( @bAll = 1 )
	begin
		SELECT  
  			td.template_definition_id,
			td.required_features AS required_feature_guid, 
			td.supported_features AS supported_feature_guid, 
			td.category_id AS category_id, 		
			td.codebase AS codebase,
            td.category_clsid AS category_package_guid,
            til.idebehavior_flags as idebehavior_flags            
		FROM	template_definition	td
        inner join template_idebehavior_link til 
        on  td.template_definition_id = til.template_definition_id
	end
	else 
	begin		
		--#gobject_ids is fill up by internal_get_gobject_ids_from_xml 		
		SELECT  
  			td.template_definition_id,
			td.required_features AS required_feature_guid, 
			td.supported_features AS supported_feature_guid, 
			td.category_id AS category_id, 		
			td.codebase AS codebase,
            td.category_clsid AS category_package_guid,
            til.idebehavior_flags as idebehavior_flags            
		FROM	template_definition td
        inner join template_idebehavior_link til
        on  td.template_definition_id = til.template_definition_id
		where td.template_definition_id = @templateId
	end
end
go

