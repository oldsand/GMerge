create proc dbo.internal_create_multi_objects
    @template_gobject_id int,
    @area_gobject_id int = 0,
    @hosted_by_gobject_id int = 0,
    @contained_by_gobject_id int = 0,
	@FileNameOfNames nvarchar(256)
as
set nocount on

begin

begin tran
	DECLARE @input_table table( 
		template_gid int, 
		tagname nvarchar(32)COLLATE SQL_Latin1_General_CP1_CI_AS, 
		area int, 
		container int,
		host int, 
		newgobject_id int, 
		contained_by int, 
		contained_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS, 
		parent_package_id int, 
		new_instance_package_id int 
	)	

	declare @created_objects_table table (
		tag_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS , 
		newgobject_id int
	)


SET QUOTED_IDENTIFIER OFF

CREATE TABLE  #results_table ( tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS  Not NULL)

DECLARE @SQL nvarchar(2000)

SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfNames + ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

EXEC sp_executesql @SQL

insert into @input_table( template_gid, tagname, area, container, host )
(select @template_gobject_id, rt.tag_name, @area_gobject_id, @contained_by_gobject_id,  @hosted_by_gobject_id from #results_table rt)

--------------------------------------
-- get the contained name 
--------------------------------------

update @input_table 
	set contained_by = gobj.contained_by_gobject_id,	 contained_name = gobj.contained_name , newgobject_id = -1
	from gobject gobj
	where gobj.gobject_id = template_gid

update @input_table
	set contained_name = inp.tagname
	from @input_table inp
	where inp.contained_by = 0

-------check allready exist if yes, update newgobject_id to 0
----now in all next statements use this to protect duplication of GOBJECT newgobject_id 
-----

--Catch duplicate names but only in the same namespace
declare @namespaceid as int

select @namespaceid=namespace_id from gobject where gobject_id=@template_gobject_id

update @input_table
set newgobject_id = 0 
from gobject gobj
where gobj.tag_name = tagname 
and gobj.namespace_id = @namespaceid

---------------------------------------
-- create the gobject row
---------------------------------------

declare @host_tree_level smallint
select @host_tree_level = case when category_id = 1 then 1 when category_id < 10 then 2 when category_id = 13 then 3 else 4 end
from gobject inner join template_definition on gobject.template_definition_id = template_definition.template_definition_id
where gobject_id = @template_gobject_id


insert into gobject
(
    template_definition_id,
    derived_from_gobject_id,
    contained_by_gobject_id,
    area_gobject_id,
    hosted_by_gobject_id,
    default_symbol_gobject_id,
    default_display_gobject_id,
    checked_in_package_id,
    checked_out_package_id,
    deployed_package_id,
    tag_name,
    namespace_id,
    contained_name,
    identity_guid,
    configuration_guid,
    configuration_version,
    is_template,
    is_hidden,
    software_upgrade_needed,
    hosting_tree_level,
    hierarchical_name
)
select
    gobject.template_definition_id,		-- template_definition_id
    gobject.gobject_id,					-- derived_from_gobject_id
    input_table.container,				-- contained_by_gobject_id
    input_table.area,					-- area_gobject_id
    input_table.host,					-- hosted_by_gobject_id
    0,									-- default_symbol_gobject_id
    0,									-- default_display_gobject_id
    0,									-- checked_in_package_id
    0,									-- checked_out_package_id
    0,									-- deployed_package_id
    input_table.tagname,				-- tag_name
    gobject.namespace_id,               -- namespace_id
    '',         -- contained_name
    NewId(),							-- identity_guid
    NewId(),							-- configuration_guid
    1,									-- configuration_version
    0,									-- is_template
    gobject.is_hidden,					-- is_hidden
    0,									-- software_upgrade_needed
    @host_tree_level,					-- hosting_tree_level
    input_table.tagname					-- hierarchical_name   
from 
    gobject gobject
	inner join @input_table input_table
	on input_table.template_gid = gobject.gobject_id 
	AND  input_table.newgobject_id != 0


--select @new_instance_gobject_id = @@IDENTITY

-- VS9: Use a new algorithm here
--
--update inputtable set inputtable.newgobject_id = gobject.gobject_id 
--from @input_table inputtable
--inner join gobject gobject
--	on inputtable.tagname = gobject.tag_name
--	AND  inputtable.newgobject_id != 0
-- VS9: End of comment
--

insert into @created_objects_table(tag_name, newgobject_id)
	select	max(gobject.tag_name),
			max(gobject.gobject_id)
	from	@input_table inputtable
	inner join gobject 
	on	inputtable.tagname = gobject.tag_name and gobject.namespace_id != 2 -- BackupObject
	group by gobject.gobject_id

update 	inputtable 
set 	inputtable.newgobject_id = created_gobject.newgobject_id 
from 	@input_table inputtable
inner join @created_objects_table created_gobject
	on inputtable.tagname = created_gobject.tag_name 
    AND inputtable.newgobject_id != 0

---------------------------------------
-- create the instance row
---------------------------------------

insert into instance ( gobject_id ) 
select newgobject_id from @input_table where newgobject_id != 0

-- Assign engines a mx_engine_id and mx_object_id even though they are not yet assign to a platform
declare @engines table(gobject_id int)

insert into @engines
select G.gobject_id
from gobject G inner join instance I on G.gobject_id = I.gobject_id
where I.mx_object_id = 0 and hosting_tree_level = 2

-- We have to set this one by one so that GetNextMxEngine can get
-- correct values 
while exists ( select gobject_id from @engines )
BEGIN
	declare @my_engine int
	select top 1 @my_engine = gobject_id from @engines
	
	update instance set mx_engine_id = dbo.get_next_mx_engine_id( 0 ), mx_object_id = 1
	where gobject_id = @my_engine

	delete from @engines where gobject_id = @my_engine
END


---------------------------------------
-- create the checked_in_package
---------------------------------------
insert into package 
(
    gobject_id,
    status_id,
	operation_status,
	derived_from_package_id
)
select	inputtable.newgobject_id,
		0, -- ePackageUnknownStatus
		3,
		p.package_id
from	package p
inner join @input_table inputtable on (inputtable.template_gid = p.gobject_id)
inner join gobject g on (g.checked_in_package_id = p.package_id) and ( g.gobject_id = inputtable.template_gid)
where (inputtable.newgobject_id != 0)

update @input_table
set new_instance_package_id = package_id
from package p 
where p.gobject_id = newgobject_id



-- record checked_in_package_id
update gobject 
set checked_in_package_id = p.package_id
from package p
inner join gobject g
	on g.gobject_id = p.gobject_id
	AND p.operation_status = 3

update package set operation_status = 4 
from package package
inner join gobject gobject
	on gobject.checked_in_package_id = package.package_id
	and package.gobject_id = gobject.gobject_id
	and package.operation_status = 3

update @input_table
set parent_package_id = g.checked_in_package_id 
from gobject g
where g.gobject_id = template_gid
AND  newgobject_id != 0

---------------------------------------
-- create primitive_instance rows
---------------------------------------

-- copy primitive_instance rows from template
insert into primitive_instance
(
	gobject_id,
    package_id,
    primitive_definition_id,
    primitive_name,
    mx_primitive_id,
    parent_mx_primitive_id,
    execution_group,
    execution_order,
	owned_by_gobject_id,
	extension_type,
	is_object_extension,
	entity_change_type,
	operation_on_primitive_mask,
    created_by_parent,
	status_id,
	ref_status_id,
--	primitive_attributes	
	mx_value_errors,
	mx_value_warnings,
	mx_value_reference_warnings		
)
select
    inputtable.newgobject_id,
    inputtable.new_instance_package_id,                   -- package_id
    primitive_instance.primitive_definition_id, -- primitive_definition_id
    primitive_instance.primitive_name,          -- primitive_name
    primitive_instance.mx_primitive_id,         -- mx_primitive_id
    primitive_instance.parent_mx_primitive_id,  -- parent_mx_primitive_id
    primitive_instance.execution_group,         -- execution_group
    primitive_instance.execution_order,         -- execution_order
	primitive_instance.owned_by_gobject_id,		-- owned_by_gobject_id
	primitive_instance.extension_type ,  		-- extension_type
	primitive_instance.is_object_extension,		-- is_object_extension
	1,
	0,
	1,
	primitive_instance.status_id,
	primitive_instance.ref_status_id,
	mx_value_errors,
	mx_value_warnings,
	mx_value_reference_warnings			
from primitive_instance
inner join @input_table inputtable
	on inputtable.template_gid = primitive_instance.gobject_id 
	and inputtable.parent_package_id = primitive_instance.package_id
	AND  inputtable.newgobject_id <> 0



-- insert appropriate attribute rows from the parent
insert into dynamic_attribute
(
	gobject_id,
	package_id,
	mx_primitive_id,
	mx_attribute_id,
	attribute_name,
	mx_data_type,
	is_array,
	security_classification,
	mx_attribute_category,
	lock_type,
	mx_value,
	owned_by_gobject_id,
    dynamic_attribute_type,
    bitvalues 

)
select 
    inputtable.newgobject_id,

    inputtable.new_instance_package_id,                   -- package_id
	parent_dynamic_attribute.mx_primitive_id,
    parent_dynamic_attribute.mx_attribute_id,       
	parent_dynamic_attribute.attribute_name,
	parent_dynamic_attribute.mx_data_type,
	parent_dynamic_attribute.is_array,
	parent_dynamic_attribute.security_classification,
	parent_dynamic_attribute.mx_attribute_category,
	case when parent_dynamic_attribute.lock_type = 1 then -- lock_type
  		 2
  	else
         parent_dynamic_attribute.lock_type               	
    end
    as lock_type,
	parent_dynamic_attribute.mx_value,
	case when parent_dynamic_attribute.mx_primitive_id = 2 then -- Common Primitive (UDAs)
  		 parent_dynamic_attribute.owned_by_gobject_id
  	else
         inputtable.newgobject_id               	
    end
    as owned_by_gobject_id,
    parent_dynamic_attribute.dynamic_attribute_type,
    parent_dynamic_attribute.bitvalues            
from dynamic_attribute parent_dynamic_attribute
inner join @input_table inputtable
	on  inputtable.template_gid = parent_dynamic_attribute.gobject_id 
	and inputtable.parent_package_id = parent_dynamic_attribute.package_id 
	and inputtable.newgobject_id <> 0



-- insert appropriate feature rows from the parent
insert into primitive_instance_feature_link
(
    gobject_id,
	package_id,
	mx_primitive_id,
    feature_id,
    feature_name,
    feature_type
)
select 
    inputtable.newgobject_id,
    inputtable.new_instance_package_id,                   -- package_id
	primitive_instance_feature_link.mx_primitive_id,
    primitive_instance_feature_link.feature_id,
    primitive_instance_feature_link.feature_name,
    primitive_instance_feature_link.feature_type
from primitive_instance_feature_link
inner join @input_table inputtable
	on inputtable.template_gid = primitive_instance_feature_link.gobject_id 
	and inputtable.parent_package_id = primitive_instance_feature_link.package_id
	AND  inputtable.newgobject_id <> 0


-- set container ids of instances appropriately
update gobject set contained_by_gobject_id = derivedTable.contained_by
from (	select child.newgobject_id, parent.newgobject_id as contained_by
		from @input_table parent, @input_table child
		where parent.template_gid = child.container
		AND  parent.newgobject_id != 0	
		AND  child.newgobject_id != 0	) As derivedTable
where derivedTable.newgobject_id = gobject.gobject_id	


    insert into proxy_timestamp (gobject_id)
    select newgobject_id
    from @input_table
    where newgobject_id != 0


    insert into gobject_filter_info_timestamp (gobject_id)
    select newgobject_id
    from @input_table
    where newgobject_id != 0

    -- return the recordSet of newly created object
	select newgobject_id, tagname from @input_table  
	---here is newgobject_id = 0 that means allready exist



commit

drop table #results_table

end
go

