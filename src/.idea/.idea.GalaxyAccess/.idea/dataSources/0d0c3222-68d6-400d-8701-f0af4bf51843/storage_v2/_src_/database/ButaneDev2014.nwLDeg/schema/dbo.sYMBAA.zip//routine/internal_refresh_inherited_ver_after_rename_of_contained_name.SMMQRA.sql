create procedure dbo.internal_refresh_inherited_ver_after_rename_of_contained_name
@renamed_object_gobject_id int
as
begin
declare @affected_gobjects table
(
	gobject_id int,
	checked_in_package_id int
)

	;With CTE
	(
		gobject_id, 
		checked_in_package_id,
		contained_by_gobject_id
	)as
	(	
		select
			g.gobject_id,
			g.checked_in_package_id,
			g.contained_by_gobject_id
		from gobject g
		where g.gobject_id = @renamed_object_gobject_id
		union all	
		select
			g.gobject_id,
			g.checked_in_package_id,
			g.contained_by_gobject_id
		from CTE 
		inner join gobject g on
			g.gobject_id = CTE.contained_by_gobject_id
	)
	insert into @affected_gobjects (gobject_id,checked_in_package_id)
	select gobject_id,checked_in_package_id
	from CTE

	-- iterate through the objects and delete their inherited 
	-- VERs, then add them back...
	declare @gobject_id int
	declare @checked_in_package_id int
	while(@@rowcount > 0)
	begin
		select top(1)
			@gobject_id = gobject_id,
			@checked_in_package_id = checked_in_package_id
		from @affected_gobjects
		order by gobject_id desc

		-- wipe out this object's inherited visual element references...
		delete ver
		from visual_element_version vev
		inner join visual_element_reference ver on
			vev.gobject_id = ver.gobject_id and
			vev.package_id = ver.package_id and
			vev.mx_primitive_id = ver.mx_primitive_id
		where vev.gobject_id = @gobject_id and
			vev.package_id = @checked_in_package_id and
			(
				vev.inherited_from_gobject_id <> vev.gobject_id 
			)
			
		if(@gobject_id is not null)
			exec internal_add_visual_element_references_from_parent @gobject_id, @checked_in_package_id, 'I'

		delete from @affected_gobjects
		where gobject_id = @gobject_id 
		
		select @gobject_id = @gobject_id from @affected_gobjects
		
		if (@@rowcount = 0)
		begin
			exec internal_bind_visual_element_references -- CR 117307
			break
		end

	end

end
go

