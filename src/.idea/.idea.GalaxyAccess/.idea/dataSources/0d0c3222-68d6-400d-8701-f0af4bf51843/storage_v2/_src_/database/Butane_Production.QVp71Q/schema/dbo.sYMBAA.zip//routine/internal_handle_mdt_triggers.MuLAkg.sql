--This SP will be called when we need to enable and disable the MDT (auto save triggers on the ArchestrA tables
-- When is_enable = 0, then trigger is disabled
-- When is_enable = 1, then trigger is enabled
create proc dbo.internal_handle_mdt_triggers
@is_enable bit = 0,
@FileNameOfTRs nvarchar (265)
AS 
begin
    set nocount on

    CREATE TABLE  #TRtable ( TRname nvarchar(256))
        
    if (@is_enable = 1)
    begin
        --read the info from the file to the table
         DECLARE @SQL nvarchar(2000)
         SET @SQL = 'BULK INSERT #TRtable   FROM ''' + @FileNameOfTRs + ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')' 
         EXEC (@SQL)
    end

    --Check if triggers are exists or not into the current galaxy
        if (@is_enable = 0)
        begin
        if exists (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'trigger_insert_gobject_change_log_autosave') AND type in (N'TR'))
        begin
            --check for its state: if it is enable then only disable it. The below condition will be set when the trigger is enable
            if (0 = OBJECTPROPERTY(OBJECT_ID('trigger_insert_gobject_change_log_autosave'), 'ExecIsTriggerDisabled'))
            begin
                alter table gobject_change_log disable trigger trigger_insert_gobject_change_log_autosave

                insert into  #TRtable
                select 'trigger_insert_gobject_change_log_autosave'
            end
        end
    
        if exists (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'trigger_delete_gobject_autosave') AND type in (N'TR')) 
        begin
            --check for its state: if it is enable then only disable it. The below condition will be set when the trigger is enable
            if (0 = OBJECTPROPERTY(OBJECT_ID('trigger_delete_gobject_autosave'), 'ExecIsTriggerDisabled'))
            begin
                alter table gobject disable trigger trigger_delete_gobject_autosave

                insert into  #TRtable
                select 'trigger_delete_gobject_autosave'
            end
        end

        select * from  #TRtable

        end
        else
        begin
        if exists(select 1 from  #TRtable)
        begin
            if exists (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'trigger_insert_gobject_change_log_autosave') AND type in (N'TR'))
            begin
                if exists(select 1 from  #TRtable where TRname = N'trigger_insert_gobject_change_log_autosave')
                begin
                    alter table gobject_change_log enable trigger trigger_insert_gobject_change_log_autosave
                end
            end
            if exists (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'trigger_delete_gobject_autosave') AND type in (N'TR')) 
            begin
                if exists(select 1 from  #TRtable where TRname = N'trigger_delete_gobject_autosave')
                begin
                    alter table gobject enable trigger trigger_delete_gobject_autosave
                end
            end
        end
    end
    
    drop table #TRtable
end
go

