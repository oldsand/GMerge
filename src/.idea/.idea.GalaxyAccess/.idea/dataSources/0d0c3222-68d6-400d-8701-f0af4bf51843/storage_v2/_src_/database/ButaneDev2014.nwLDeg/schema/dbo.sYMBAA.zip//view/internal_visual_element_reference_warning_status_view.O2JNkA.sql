create view dbo.internal_visual_element_reference_warning_status_view
as
select
	distinct
	g.gobject_id,
	p.package_id,
	case when (isnull(ver.gobject_id,0)> 0) then 1
	else 0
	end as has_warning
from package p with(nolock)
inner join gobject g with(nolock) on
	g.gobject_id = p.gobject_id
left outer join visual_element_reference ver with(nolock) on
	p.gobject_id = ver.gobject_id and
	p.package_id = ver.package_id and
	ver.visual_element_bind_status = 0 and
	ver.checked_in_unbound_visual_element_name <> '---'
go

