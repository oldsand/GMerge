-- This stored procedure is to list the ancestors information of an object
-- 1. If @gobject_id is valid, the returned value would be rows of
--    gobject_id, derived_from_gobject_id, tag_name(of this object)
-- 2. If @gobject_id is the gobject_id of a base template, one row 
--    will be returned and the ancestor is 0.
-- 3. If @gobject_id is invalid, this SP return 0 row
-- 
create proc dbo.internal_list_ancestors_for_object
    @gobject_id int,
    @bIsExcludeSelf bit = 0
as
begin
    set nocount on

	declare @exclude_gobject int
	
	if @bIsExcludeSelf = 0
		set @exclude_gobject = 0
    else
		set @exclude_gobject = @gobject_id

	
    ;with CTE(
        gobject_id,
        derived_from_gobject_id
    )
    as
    (
        select  gobject_id, 
                derived_from_gobject_id
        from    gobject
        where   gobject_id = @gobject_id
    
        union all

        select  g.gobject_id,
                g.derived_from_gobject_id
        from    CTE
        inner join
                gobject g
        on
                CTE.derived_from_gobject_id = g.gobject_id
    )

    select  CTE.gobject_id,
            CTE.derived_from_gobject_id,
            g.tag_name
    from    CTE
    inner join
            gobject g
    on
            g.gobject_id = CTE.gobject_id
			and g.gobject_id <> @exclude_gobject
    
end

go

