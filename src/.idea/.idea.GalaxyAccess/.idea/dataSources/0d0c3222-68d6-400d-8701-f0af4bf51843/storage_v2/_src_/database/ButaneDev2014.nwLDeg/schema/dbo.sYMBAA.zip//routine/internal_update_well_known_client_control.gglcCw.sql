-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
/*Object Name :  internal_update_well_known_client_control						      */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To update the info for all well known client controls in a given assembly*/
/*Used By	  :  PackageServerNet												  */
/**********************************************************************/

create PROCEDURE dbo.internal_update_well_known_client_control
(
    @primary_file_name nvarchar(256),
    @vendor_name nvarchar(256),
    @class_name_toolbox_info_file nvarchar(256)
)
as
begin
--Create temp table and bulk insert the values from file
create table  #control_list (class_name nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                           toolbox_info nvarchar(max) null default '')

DECLARE @gSQL nvarchar(2000)
SET @gSQL = 'BULK INSERT #control_list  FROM ''' + @class_name_toolbox_info_file+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
EXEC (@gSQL)

--First remove existing entries for this assembly
declare @file_id as int
select 
		@file_id = file_id 
from 
		file_table 
where 
		vendor_name = @vendor_name and
		file_name = @primary_file_name

delete 
		well_known_client_controls
where
		file_id = @file_id

--then insert the new entries
insert into 
			well_known_client_controls
select
		@file_id,class_name,toolbox_info
from
		#control_list

drop table #control_list


end
go

