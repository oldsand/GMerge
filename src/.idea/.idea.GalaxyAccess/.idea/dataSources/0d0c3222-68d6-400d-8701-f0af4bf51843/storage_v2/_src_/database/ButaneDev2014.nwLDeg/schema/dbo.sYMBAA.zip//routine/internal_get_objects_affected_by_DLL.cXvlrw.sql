create proc dbo.internal_get_objects_affected_by_DLL
    (
    @DLLName					nvarchar (256),	    -- Name of DLL or ClientControl being imported
    @VendorName					nvarchar (256),		-- Vendor of DLL or ClientControl being imported
	@DLLQualifier				int,				-- DLL or ClientControl qualifier: 0: DLL; 1: CC
    @DLLVersion					nvarchar (64) OUTPUT,    -- Version of the DLL, if already present, to be returned to the caller
    @DependencyCount			int OUTPUT,    -- Total number of objects that will be affected if this DLL|CC is imported (output)
    @DeployedDependencyCount	int OUTPUT    -- Count of deployed objects that will be affected if this DLL|CC is imported (output)
    )
as 
begin
      declare @affected_object table (gobject_id int)
      
      set @DLLVersion = N'0'
      set @DependencyCount = 0
      set @DeployedDependencyCount = 0
 
      if (@DLLQualifier = 1) -- Client Control
      begin
            declare @owning_gobject table (gobject_id int)
            declare @owning_veid table (visual_element_id int primary key (visual_element_id))
            --declare @affected_veid_with_dupl table (id int, type int)
            --declare @veid int
            
            -- Retrieve the gobject_ids of all client control objects that are directly associated with (@DLL, @Vendor)
            insert into @owning_gobject exec internal_get_clientcontrol_gids_associatedwith @DLLName, @VendorName
            /*
                  -- Debug:
                  -- select gobject_id as N'Owning Object' from @owning_gobject
            */
            
 
            -- Now retrieve the client control VE IDs.
            insert into @owning_veid 
            select distinct visual_element_id 
            from   visual_element_version vev
            inner join @owning_gobject oo on
                     vev.gobject_id = oo.gobject_id  
            /*
                  -- Debug:
                  -- select visual_element_id as N'Owning VEID' from @owning_veid
            */
			declare @veid_CC int
            declare @indirect_affected_ids_CC table 
            (
				type int,		-- 0: VEID; 1: view-app gobject_id
                id int			-- visual_element_id or [view-app] gobject_id 
            )
                        
            while (1 = 1)
            begin
                  set @veid_CC = (select top 1 visual_element_id from @owning_veid)
                  if (@@ROWCOUNT = 0 or @veid_CC is NULL)
                        break;
                  insert into @indirect_affected_ids_CC      exec internal_get_referring_visual_elements @veid_CC, 0, 2    
                  /*
                        -- Debug:
                        -- select visual_element_id as N'Referring VEID' from @affected_veid_with_dupl
                  */
                  delete @owning_veid where visual_element_id = @veid_CC
            end
            
            if (exists (select 1 from @indirect_affected_ids_CC))
            begin
                  insert into @affected_object
                  select distinct gobject_id
                  from   visual_element_version vev
                  inner join @indirect_affected_ids_CC veid on
                      vev.visual_element_id = veid.id
                  and veid.type = 0
                  
                  --ITVAPP
                  insert into @affected_object
                  select distinct 
                       g.gobject_id 
                  from gobject g
                  inner join @indirect_affected_ids_CC itvapp on
                       g.gobject_id = itvapp.id 
                  and  itvapp.type = 1
                  where g.namespace_id <> 3
                       --g.is_template = 0 and g.namespace_id <> 3
            end
      end
      else if (@DLLQualifier = 0) -- Script library
      begin
 
      --get the gobject ids from the primitive_instance_feature_link 
      --@affected_object will have the gobject ids where script dll is referred.
 
            insert into @affected_object
            select distinct g.gobject_id from gobject g 
        inner join primitive_definition pd on 
               pd.template_definition_id = g.template_definition_id
        inner join file_table ft on
                     ft.file_name = @DLLName 
           and ft.vendor_name = @VendorName
        inner join file_primitive_definition_link fdl on 
               --fdl.is_needed_for_runtime = 1 and
               fdl.primitive_definition_id = pd.primitive_definition_id                                             
           and fdl.file_id = ft.file_id
        union
        select g.gobject_id from gobject g 
        inner join primitive_instance_feature_link pfl on
               pfl.gobject_id = g.gobject_id
        inner join file_table ft on
                     ft.file_name = @DLLName  
           and ft.vendor_name = @VendorName
        inner join feature_file_link fl on
               fl.feature_id = pfl.feature_id         
           and fl.file_id = ft.file_id           
 
      --check for symbols objects
            --extract symbols ids
            declare @graphic_objects_ownScript table (gobject_id int)
            declare @veids_where_ownScript_referred table (veid int)
            
            insert into @graphic_objects_ownScript
            select g.gobject_id from gobject g
            inner join @affected_object ao on 
            ao.gobject_id = g.gobject_id
            and g.is_template = 0
            where g.namespace_id = 3
            
            if (exists (select 1 from @graphic_objects_ownScript))
            begin
            --get the visual element id for obtained gobject id from internal_visual_element_description_per_user_view/visual element version
                  insert into @veids_where_ownScript_referred
                  select VEV.visual_element_id from visual_element_version VEV
                  inner join @graphic_objects_ownScript symObj on
                  symObj.gobject_id = VEV.gobject_id
                  inner join visual_element VE on 
                  VEV.visual_element_id = VE.visual_element_id
                  
                  --call to internal_get_referring_visual_elements for each visual element ids
                  --this will give us the visual element ids in which it is referred.
                  if (exists (select 1 from @veids_where_ownScript_referred))
                  begin
                        declare @veid_Script int
                        declare @indirect_affected_ids table 
                        (
							type int,		-- 0: VEID; 1: view-app gobject_id
                            id int			-- visual_element_id or [view-app] gobject_id 
                        )
                                                
                        while (1 = 1)
                        begin
                              set @veid_Script = (select top 1 veid from @veids_where_ownScript_referred)
                              if (@@ROWCOUNT = 0 or @veid_Script is NULL)
                                    break;
                              insert into @indirect_affected_ids      exec internal_get_referring_visual_elements @veid_Script, 0, 2    
                              -- insert into @Itvapp_IDS exec internal_get_referring_visual_elements @veid, 0, 1
                              
                              delete @veids_where_ownScript_referred where veid = @veid_Script
                        end
            					
                        if (exists (select 1 from @indirect_affected_ids))
                        begin
                              insert into @affected_object
                              select distinct gobject_id
                              from   visual_element_version VEV
                              inner join @indirect_affected_ids veid on
                                      VEV.visual_element_id = veid.id
                                      and veid.type = 0
                              inner join visual_element VE on 
                                      VEV.visual_element_id = VE.visual_element_id
                                      
                              --for ITVAPP
                              insert into @affected_object
                              select distinct 
                                   g.gobject_id 
                              from gobject g
                              inner join @indirect_affected_ids itvapp on
                                   g.gobject_id = itvapp.id 
                              and  itvapp.type = 1
                              where g.namespace_id <> 3
                                   --g.is_template = 0 and g.namespace_id <> 3
                              
                        end --end of if (exists (select 1 from @indirect_affected_veids))
                                               
                  end --end of if (exists (select 1 from @veids_where_ownScript_referred))
                  
            end -- end of if (exists (select 1 from @graphic_objects_ownScript))
      end
      else  -- Unknown DLL type: simply return
            return
 
      set @DLLVersion = (select top 1 file_version from file_table where file_name = @DLLName and vendor_name = @VendorName)
      if (@DLLVersion is NULL or LEN (@DLLVersion) = 0)
            set @DLLVersion = N'0.0.0.0'
      /*
            -- Debug:
            --select gobject_id as N'Affected Object' from @affected_object
      */
      set @DependencyCount = (select COUNT(distinct gobject_id) from @affected_object)
 
      /*
            -- Debug:
            --select g.* from @affected_object ao
            --inner join gobject g
            --on g.gobject_id = ao.gobject_id
            --and g.deployed_package_id <> 0 and g.software_upgrade_needed = 0
      */
            
      set @DeployedDependencyCount = (
            select COUNT(distinct g.gobject_id) from gobject g 
            inner join @affected_object ao
            on g.gobject_id = ao.gobject_id
            where --g.checked_in_package_id > g.deployed_package_id  and
            g.deployed_package_id <> 0 and
            g.software_upgrade_needed = 0 
            )
 
end
go

