CREATE TRIGGER trigger_dl_naming_rule_change_autobind_device_template 
ON  [autobind_device_template]
FOR INSERT, UPDATE
AS  
begin
	declare @template_definition_id int
	select @template_definition_id = template_definition_id
	from inserted 
	
    EXECUTE internal_ab_refresh_attribute_aliases 0, 0, 0, @template_definition_id
end
go

