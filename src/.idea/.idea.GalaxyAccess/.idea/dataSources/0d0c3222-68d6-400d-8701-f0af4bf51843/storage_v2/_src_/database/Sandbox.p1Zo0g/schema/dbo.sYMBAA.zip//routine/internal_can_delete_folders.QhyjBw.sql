create proc dbo.internal_can_delete_folders
    @FileNameOfIds nvarchar (265)
AS
begin
    set nocount on

    CREATE TABLE  #folder_table (folder_id int)
    DECLARE @SQL nvarchar(2000)
    SET @SQL = 'BULK INSERT #folder_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
    EXEC sp_executesql @SQL

    declare @folders table(
        folder_id int primary key, 
        can_be_deleted bit, 
        reason_code int)    -- 0: Success  1: Invalid Folder  2:Has object


    insert  into  @folders(folder_id, can_be_deleted, reason_code)
        select  folder_id, 0, 1
        from    #folder_table

    update  rf
    set     rf.can_be_deleted = 1,
            rf.reason_code = 0
    from    @folders rf 
    inner join folder f on f.folder_id = rf.folder_id

    update  rf
    set     rf.can_be_deleted = 0,
            rf.reason_code = 2
    from    @folders rf
    inner join folder f on f.folder_id = rf.folder_id
    where   f.has_objects = 1
    
    select  folder_id, can_be_deleted, reason_code
    from    @folders
    
    drop table #folder_table

end

go

