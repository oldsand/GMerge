/*
This procedure gives all the files which are deployed on 
the given node name

usage:
exec internal_get_all_editor_package_files'
 'Nodename'
*/
CREATE    proc dbo.internal_get_all_editor_package_files
    @nodename nvarchar(256)
as
set nocount on
begin


	    declare @fileinfo table (      
	        file_id int, 
	        file_name nvarchar(256),
			subfolder_name varchar(256),
	        vendor_name nvarchar(256), 
	        registration_type int
	    )

if (upper(@nodename) = HOST_NAME()  or exists( select 1 from client_info where upper(client_name) = upper(@nodename) ))
begin
	    insert into @fileinfo
            select distinct  ft.file_id, ft.file_name, ft.subfolder, ft.vendor_name,ft.registration_type
            from gobject g
            inner join primitive_definition pd
                on g.template_definition_id = pd.template_definition_id
            inner join file_primitive_definition_link fpt
                on fpt.primitive_definition_id = pd.primitive_definition_id
                and ( fpt.is_needed_for_editor = 1 or fpt.is_needed_for_package = 1)
            inner join file_table ft
                on ft.file_id = fpt.file_id
		order by ft.file_name asc


	    insert into deployed_file (
                        file_id, 
                        node_name, 
                        need_to_delete, 
                        is_package_deployed, 
                        is_editor_deployed, 
                        is_runtime_deployed,
                        is_browser_deployed)
	    (
	        select  distinct 
                    fi.file_id, 
                    @nodename as node_name, 
                    0 as need_to_delete,
	                0 as is_editor_deployed,
                    0 as is_package_deployed,
                    0 as is_runtime_deployed,
                    0 as is_browser_deployed
	        from    @fileinfo fi
	        where   fi.file_id not in 
            (       select  distinct 
                            file_id 
                    from    deployed_file 
                    where   node_name = UPPER(@nodename) 
            )
	    )
	    
	    update deployed_file
		set file_version = ft.file_version,
		file_modified_time = ft.file_modified_time
		from file_table ft, deployed_file df
		where df.file_id = ft.file_id  and
			  df.node_name = UPPER(@nodename)
end
	    select fi.file_name, fi.vendor_name,fi.registration_type,fi.subfolder_name
	    from @fileinfo fi
		
end
set nocount off

go

