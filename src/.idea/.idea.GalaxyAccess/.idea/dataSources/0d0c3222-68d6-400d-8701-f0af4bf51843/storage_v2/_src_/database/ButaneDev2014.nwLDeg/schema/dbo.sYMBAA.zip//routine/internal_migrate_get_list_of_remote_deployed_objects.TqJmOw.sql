create proc dbo.internal_migrate_get_list_of_remote_deployed_objects
As

begin 
create table dbo.deployed_objects(tag_name nvarchar(329), namespace_id smallint)
create index idx_deployed_objects_on_tag_name_and_namespace_id on deployed_objects( tag_name, namespace_id )

delete from deployed_objects
insert into deployed_objects(tag_name, namespace_id)
select g.tag_name, g.namespace_id from gobject g inner join
instance i on g.gobject_id = i.gobject_id 
where g.deployed_package_id <> 0 and i.mx_platform_id > 1

create table migration_is_going_on (
    dummy smallint
)

end


go

