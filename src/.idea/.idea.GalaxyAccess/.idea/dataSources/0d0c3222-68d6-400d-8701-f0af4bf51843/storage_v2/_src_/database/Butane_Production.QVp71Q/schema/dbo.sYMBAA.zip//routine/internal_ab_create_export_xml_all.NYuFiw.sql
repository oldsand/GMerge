/*
** Procedure [internal_ab_create_export_xml_all]
** This is expected to be invoked by the export workflow
** this query returns all valid exportable overrides as XML written into a file name/path
** passed in the @resultXMLfilename parameter.
** We're using the FOR XML EXPLICIT qualifier to yield an XML string that looks like this:
** <root>
**    <Dev Nm="OPCClient_001">
**        <SG Nm="S1">
**            <Obj Nm="Area_001"/>
**            <Obj Nm="UserDefined_002"/>
**        </SG>
**        <SG Nm="S2">
**            <Obj Nm="T1">
**                <Attr Nm="Attribute001" IO="InputSource" Xlt="Radical_Override_Default_SG">
**                    <Ovr><![CDATA[dgoverride.oaoverride]]></Ovr>
**                </Attr>
**            </Obj>
**            <Obj Nm="UserDefined_001"/>
**        </SG>
**    </Dev>
** <root>
*/
CREATE procedure [dbo].[internal_ab_create_export_xml_all] 
(
    @resultXMLLength		int output
)
AS 
begin
    SET NOCOUNT ON
    DECLARE @resultXML NVARCHAR(max)
    set @resultXML 
        =  (SELECT * FROM 
               (SELECT 1            AS Tag
                     , null         AS Parent
                     , null         AS [root!1!]
                     , null         AS [Dev!2!Nm]
                     , null         AS [SG!3!Nm]
                     , null         AS [Obj!4!Nm]
                     , null         AS [Attr!5!Nm] 
                     , null         AS [Attr!5!IO]
                     , null         AS [Attr!5!Xlt]
                     , null         AS [Attr!5!Ovr!cdata]
                UNION 
                SELECT 2
                     , 1 as Parent
                     , null
                     , dio.tag_name
                     , null
                     , null
                     , null
                     , null
                     , null
                     , null
                  FROM object_device_linkage odl
                INNER JOIN gobject dio
                    ON dio.gobject_id = odl.dio_id
                UNION 
                SELECT 3
                     , 2 as Parent
                     , null
                     , dio.tag_name
                     , sg_pi.primitive_name
                     , null
                     , null
                     , null
                     , null
                     , null
                  FROM object_device_linkage odl
                INNER JOIN gobject dio
                    ON dio.gobject_id = odl.dio_id
                INNER JOIN primitive_instance sg_pi
                    ON sg_pi.gobject_id = dio.gobject_id
                   AND sg_pi.package_id = dio.checked_in_package_id
                   AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
                UNION 
                SELECT 4
                     , 3 as Parent
                     , null
                     , dio.tag_name
                     , sg_pi.primitive_name
                     , lo.tag_name
                     , null
                     , null
                     , null
                     , null
                  FROM object_device_linkage odl
                INNER JOIN gobject dio
                    ON dio.gobject_id = odl.dio_id
                INNER JOIN primitive_instance sg_pi
                    ON sg_pi.gobject_id = dio.gobject_id
                   AND sg_pi.package_id = dio.checked_in_package_id
                   AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
                INNER JOIN gobject lo
                    ON lo.gobject_id = odl.gobject_id
                UNION 
                SELECT 5
                     , 4 as Parent
                     , null
                     , dio.tag_name
                     , sg_pi.primitive_name
                     , lo.tag_name
                     , lo_pi.primitive_name
                     , lo_attr_def.attribute_name 
                     , ab_xlate.xlate_rule_name
                     , ab_attr.attr_alias
                  FROM object_device_linkage odl
                INNER JOIN gobject dio
                    ON dio.gobject_id = odl.dio_id
                INNER JOIN primitive_instance sg_pi
                    ON sg_pi.gobject_id = dio.gobject_id
                   AND sg_pi.package_id = dio.checked_in_package_id
                   AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
                INNER JOIN gobject lo
                    ON lo.gobject_id = odl.gobject_id
                INNER JOIN autobound_attribute ab_attr
                    ON ab_attr.dio_id = odl.dio_id
                   AND ab_attr.sg_mx_primitive_id = odl.sg_mx_primitive_id
                   AND ab_attr.gobject_id = lo.gobject_id
                INNER JOIN attribute_reference lo_attr_ref
                    ON lo_attr_ref.gobject_id = ab_attr.gobject_id
                   AND lo_attr_ref.package_id = lo.checked_in_package_id
                   AND lo_attr_ref.referring_mx_primitive_id = ab_attr.mx_primitive_id
                   AND lo_attr_ref.referring_mx_attribute_id = ab_attr.mx_attribute_id
                   AND lo_attr_ref.element_index = 0                                      -- No arrays for now.
                   AND lo_attr_ref.reference_string = N'---Auto---'
                INNER JOIN primitive_instance lo_pi
                    ON lo_pi.package_id = lo_attr_ref.package_id
                   AND lo_pi.gobject_id = lo_attr_ref.gobject_id
                   AND lo_pi.mx_primitive_id = lo_attr_ref.referring_mx_primitive_id
                INNER JOIN attribute_definition lo_attr_def
                    ON lo_attr_def.primitive_definition_id = lo_pi.primitive_definition_id
                   AND lo_attr_def.mx_attribute_id = lo_attr_ref.referring_mx_attribute_id
                INNER JOIN autobind_translation_rule ab_xlate
                    ON ab_xlate.xlate_rule_id = ab_attr.xlate_rule_id) A
                ORDER BY [Dev!2!Nm], [SG!3!Nm], [Obj!4!Nm]
                FOR XML EXPLICIT)
        
                -- Return @resultXML in 255-character chunks.
                DECLARE @chunk_sz int
                SET @resultXMLLength = LEN (@resultXML)
                SET @chunk_sz = 4000
                declare @sp int = 1, @substr_sz int
                while @sp <= @resultXMLLength
                begin
                    if (@resultXMLLength + 1 - @sp < @chunk_sz)
                        SET @substr_sz = @resultXMLLength + 1 - @sp
                    else
                        SET @substr_sz = @chunk_sz
                
                    SELECT SUBSTRING (@resultXML, @sp, @substr_sz) AS XMLChunk
                    SET @sp = @sp + @chunk_sz
                end


end
go

