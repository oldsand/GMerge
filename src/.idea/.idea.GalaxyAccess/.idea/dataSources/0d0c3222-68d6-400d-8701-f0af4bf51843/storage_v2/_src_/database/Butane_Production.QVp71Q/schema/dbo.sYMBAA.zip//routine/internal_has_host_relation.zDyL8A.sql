/**************************************************/
/*Object Name :  internal_has_host_relation			  */
/*Object Type :  Stored Proc.					  */
/*Purpose	  :  Proc. to verify whether the input objects */
/*               has host relation. */
/*Used By	  :  CDI() */
/**************************************************/

create	procedure dbo.internal_has_host_relation
    @FileNameOfIds nvarchar (265),
	@hasHostRelation bit output
AS
SET NOCOUNT ON
begin
	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #input_table ( gobject_id int)
	
	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #input_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	EXEC (@SQL)

	create table #object_host_table(hosted_by_gobject_id int, gobject_id int)
	create index i1 on #object_host_table(hosted_by_gobject_id)
	create index i2 on #object_host_table(gobject_id)

	create table #host_table(gobject_id int)
	create unique index i1 on #host_table(gobject_id)

	-- Filter out those invalid object ids
	insert	#host_table
	select	inputtable.gobject_id 
	from	#input_table inputtable inner join
		gobject gobject
	on	gobject.gobject_id = inputtable.gobject_id

	-- Reuse the #input_table to keep those valid objects
	truncate table #input_table

	insert	#input_table(gobject_id)
	select	gobject_id
	from	#host_table

	create unique index i1 on #input_table(gobject_id)
	
	-- Filter out those objects which don't have pending updates
	delete	#host_table
	from	#host_table hosttable 
	inner join	gobject gobject
		on	gobject.gobject_id = hosttable.gobject_id
	left join package checked_in_package   on 
		gobject.gobject_id = checked_in_package.gobject_id and 
		gobject.checked_in_package_id = checked_in_package.package_id
	left join package deployed_package  on 
		gobject.gobject_id = deployed_package.gobject_id and 
		gobject.deployed_package_id = deployed_package.package_id	
	where	( (checked_in_package.deployable_configuration_version 
			= deployed_package.deployable_configuration_version)
			or (gobject.deployed_package_id = 0))
			
			


	-- At this point, all the objects in #host_table are checked 
	-- to see whether they have host relation
	while (1=1)
	begin
		-- Expand the host relation tree based on input objects
		insert	#object_host_table(hosted_by_gobject_id, gobject_id)
		select	gobject.hosted_by_gobject_id, gobject.gobject_id
		from	gobject gobject inner join 
			#host_table hosttable
		on	gobject.hosted_by_gobject_id = hosttable.gobject_id

		if (@@rowcount = 0)
			break

		-- Delete the #host_table
		truncate table #host_table

		-- Insert into #host_table from next level
		insert	#host_table
		select	gobject_id
		from	#object_host_table 
		where	gobject_id not in 
			(select	hosted_by_gobject_id 
			from	#object_host_table)

		if (@@rowcount = 0)
			break

	end

	-- The whole tree has been built.
	if (exists (
		select	inputtable.*
		from	#input_table inputtable inner join
			#object_host_table object_host_table
		on	inputtable.gobject_id = object_host_table.hosted_by_gobject_id))
	begin
		set @hasHostRelation = 1
	end
	else
	begin
		set @hasHostRelation = 0
	end

end

go

