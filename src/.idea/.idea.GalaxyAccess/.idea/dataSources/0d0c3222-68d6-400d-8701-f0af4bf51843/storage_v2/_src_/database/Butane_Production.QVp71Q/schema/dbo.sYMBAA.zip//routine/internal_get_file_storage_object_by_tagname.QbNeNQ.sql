create proc dbo.internal_get_file_storage_object_by_tagname
    @tagname nvarchar(256)
as
begin
	set nocount on

	select	parent.tag_name
	from	gobject parent
	inner join gobject child on child.derived_from_gobject_id = parent.gobject_id
	where   child.tag_name = @tagname and child.is_template = 0

	union

	select	tag_name
	from	gobject 
    where	tag_name = @tagname and is_template = 1

	set nocount on
end
go

