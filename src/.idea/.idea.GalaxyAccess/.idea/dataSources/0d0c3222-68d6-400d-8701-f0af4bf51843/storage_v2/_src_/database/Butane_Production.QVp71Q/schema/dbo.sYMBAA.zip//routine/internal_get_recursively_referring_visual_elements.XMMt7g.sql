/*

Returns a list of recursively referring visual elments.

   Assumes that the following input and output tables are created prior to execution.
   The input table should contain the 'seed' references...
	create  table #input_table
   (
	 visual_element_id,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint
	)

    create table  #output_table 
    (
		visual_element_id,
        gobject_id int,
	    package_id int,
	    mx_primitive_id smallint
    )


*/

create procedure dbo.internal_get_recursively_referring_visual_elements
as    
begin tran

    create table #next_selection 
    (
		visual_element_id int,
        gobject_id int,
	    package_id int,
	    mx_primitive_id smallint
    )

insert into #next_selection
select 
		visual_element_id,
        gobject_id,
        package_id,
		mx_primitive_id
from
	#input_table
 
    while( 1 = 1 )
    begin   

        insert into #next_selection    
            select distinct --CR L00116751 added distinct clause to avoid duplicate rows
				vev_parent.visual_element_id,
                vev_parent.gobject_id, 
                vev_parent.package_id,
				vev_parent.mx_primitive_id
            from  visual_element_version vev_child
            inner join #input_table ids on 
                vev_child.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference ver_parent  on 
                ver_parent.checked_in_bound_visual_element_gobject_id = vev_child.gobject_id and
                ver_parent.checked_in_bound_visual_element_package_id = vev_child.package_id and
                ver_parent.checked_in_bound_visual_element_mx_primitive_id = vev_child.mx_primitive_id
			inner join visual_element_version vev_parent on
				ver_parent.gobject_id = vev_parent.gobject_id and
				ver_parent.package_id = vev_parent.package_id and
				ver_parent.mx_primitive_id = vev_parent.mx_primitive_id
            where not exists( select 1 from #output_table ot where ot.visual_element_id = vev_parent.visual_element_id )
        
        --delete from @next_selection where dbo.IsPackageVisibleToUser( gobject_id, package_id, @user_guid ) = 0		
	    truncate table #input_table 		

        insert into #input_table(visual_element_id)
	        select visual_element_id from #next_selection 

	    insert into #output_table
	         select * from #next_selection 
        
    if(@@ROWCOUNT = 0)
        begin
            drop table #next_selection
      break
    end
	
      truncate table #next_selection

    end
	
commit

go

