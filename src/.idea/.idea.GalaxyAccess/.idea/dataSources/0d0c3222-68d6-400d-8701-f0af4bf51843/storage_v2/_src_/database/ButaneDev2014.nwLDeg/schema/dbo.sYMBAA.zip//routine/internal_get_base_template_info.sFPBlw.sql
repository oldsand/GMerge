--this sp will return all the PrimitiveGUID related to each input gobject wilh its minor_version
CREATE procedure dbo.internal_get_base_template_info
	@gobject_id int -- gobject to delete
AS
begin
	set nocount on

	SELECT     primitive_definition.primitive_guid,primitive_definition.major_version
	FROM         gobject INNER JOIN
	                      primitive_definition ON gobject.template_definition_id = primitive_definition.template_definition_id
	WHERE     (gobject.derived_from_gobject_id = 0) and
		 (gobject.gobject_id = @gobject_id )
	ORDER BY primitive_definition.primitive_guid

	
end

go

