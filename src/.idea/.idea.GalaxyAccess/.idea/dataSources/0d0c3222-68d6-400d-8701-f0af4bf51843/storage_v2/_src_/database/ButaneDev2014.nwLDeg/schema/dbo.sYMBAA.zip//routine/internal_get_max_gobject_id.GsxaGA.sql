/************************************************************************************/
/*Object Name :  internal_get_max_gobject_id											*/
/*Object Type :  Stored Proc.														*/
/*Purpose	  :  Proc. to rettrieve the max GObject ID from Attribute_reference.	*/
/*Used By	  :  CDI																*/
/************************************************************************************/
CREATE PROCEDURE dbo.internal_get_max_gobject_id
 AS
begin
SET NOCOUNT ON

SELECT MAX(gobject_id) FROM attribute_reference


end
go

