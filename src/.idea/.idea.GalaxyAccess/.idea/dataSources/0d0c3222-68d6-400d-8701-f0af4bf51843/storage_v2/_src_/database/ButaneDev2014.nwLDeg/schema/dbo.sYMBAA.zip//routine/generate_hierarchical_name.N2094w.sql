create function dbo.generate_hierarchical_name(@objectId int)
returns nvarchar(329)
As

begin
    declare @myContainerId int    
    declare @tempName nvarchar(329), @myContainedName nvarchar(32)

    select  @myContainerId = contained_by_gobject_id, 
            @tempName = tag_name, 
            @myContainedName = contained_name
    from    gobject 
    where   gobject_id = @objectId
    
    if ( @myContainerId = 0 )
        return @tempName
    
    select  @tempName = hierarchical_name 
    from    gobject 
    where   gobject_id = @myContainerId

    return @tempName + '.' + @myContainedName
end
go

