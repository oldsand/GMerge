create proc dbo.internal_set_transferring_file_status
    @object_name nvarchar(256), -- tagname
    @platform_name nvarchar(256),    -- not being used yet
    @transferring bit,
    @result_message nvarchar(256) output
as
begin
    set nocount on

    update  div
    set     div.deploy_file_transfering = @transferring
    from    deployed_intouch_viewapp div
    inner join gobject g on g.gobject_id = div.gobject_id 
    where   g.tag_name = @object_name

    if (@@rowcount = 1)
	begin
        set @result_message = N''

		update	pt
		set		pt.gobject_id = pt.gobject_id
		from	proxy_timestamp pt
		inner join gobject g on pt.gobject_id = g.gobject_id
		where	g.tag_name = @object_name

		update galaxy
		set max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 
	end
    else
    begin
        set @result_message = N'Can not set transferring file status for object ' + @object_name
    end
end


go

