create proc dbo.internal_get_object_containment_depth
@gobject_id int, 
@level int OUTPUT

AS 
begin

set nocount on
set @level = 0

create table #gobject_ids( objectId int, depth int )
insert into #gobject_ids values(@gobject_id, @level)

while (select COUNT(*) from  #gobject_ids) > 0 
begin
	-- increment the depth for each level
	set @level = @level + 1

	-- get the children of the next level
	INSERT INTO #gobject_ids  (objectId, depth)	
   	SELECT gobject.gobject_id, @level
   	FROM gobject where contained_by_gobject_id in (select objectId from #gobject_ids)
	
	-- Remove all object of previous level
	delete from #gobject_ids where depth < @level
end

drop table #gobject_ids


end
go

