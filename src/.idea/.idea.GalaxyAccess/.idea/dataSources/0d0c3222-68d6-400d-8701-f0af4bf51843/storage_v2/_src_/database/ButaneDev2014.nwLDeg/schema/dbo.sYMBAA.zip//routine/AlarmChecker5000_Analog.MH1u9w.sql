-- =============================================
-- Author:		Travis Johnston
-- Create date: 10/3/2018
-- Description:	This stored procedure will compare analog alarm setpoints to our template and output any differences found.
-- =============================================
CREATE PROCEDURE [dbo].[AlarmChecker5000_Analog] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  DECLARE @archive TABLE
(
   ActionType VARCHAR(50),
  -- CreatedDate datetime,
   TemplateTagName VARCHAR(50),
   TemplateAlarm VARCHAR(50),
   TemplateSetpoint float,
   TemplateDelay int,
   TemplateEnabled bit,
  -- rowguid uniqueidentifier,
  --   SiteCreatedDate datetime,
   SiteTagName VARCHAR(50),
   SiteAlarm VARCHAR(50),
   SiteSetpoint float,
   SiteDelay int,
   SiteEnabled bit
 --  Siterowguid uniqueidentifier

);


/*
SET @sqlCommand = 'SELECT Tagname,Alarm,Setpoint,Delay,Enabled
FROM AlarmScraper_AnalogAlarms
WHERE Tagname LIKE ''' + @SiteReference + ''' and CreatedDate >= ''10-2-2018''' 
*/
SELECT Tagname,Alarm,Setpoint,Delay,Enabled 
INTO #TempTarget 
FROM AlarmScraper_AnalogAlarms


	MERGE #TempTarget AS TARGET
	USING (Select Tagname,Alarm,Setpoint,Delay,Enabled from AlarmScraper_AnalogTemplate) AS SOURCE 
	ON (((RIGHT(TARGET.Tagname, LEN(TARGET.Tagname)-8)) = SOURCE.TagName AND TARGET.Alarm = SOURCE.Alarm))
	WHEN MATCHED AND 
		TARGET.DELAY <> SOURCE.DELAY 
		OR TARGET.ENABLED <> SOURCE.ENABLED 
		OR TARGET.Setpoint <> SOURCE.Setpoint
	THEN 
	UPDATE 
	SET
		TARGET.DELAY = SOURCE.DELAY,
		TARGET.ENABLED = SOURCE.ENABLED,
		TARGET.Setpoint = SOURCE.Setpoint
	WHEN NOT MATCHED BY TARGET THEN 					
		INSERT (Tagname,Alarm,Setpoint,Delay,Enabled) 
		VALUES (Source.Tagname,Source.Alarm,Source.Setpoint,Source.Delay,Source.Enabled)
   OUTPUT
   $action AS ActionType,
   inserted.*,
   deleted.*
INTO @archive;


SELECT    
	CASE WHEN 
		ActionType = 'INSERT' 
	THEN 
		'Missing' 
	ELSE 
		'Different' 
	END 
		AS Action,
	TemplateTagName,
	SiteTagName,
	TemplateAlarm,
	SiteAlarm,
	TemplateSetpoint,
	SiteSetpoint,
	TemplateDelay,
	SiteDelay,
	TemplateEnabled,
	SiteEnabled
 FROM @archive 
 ORDER BY action, TemplateTagName, TemplateAlarm 


DROP TABLE #TempTarget

END
go

