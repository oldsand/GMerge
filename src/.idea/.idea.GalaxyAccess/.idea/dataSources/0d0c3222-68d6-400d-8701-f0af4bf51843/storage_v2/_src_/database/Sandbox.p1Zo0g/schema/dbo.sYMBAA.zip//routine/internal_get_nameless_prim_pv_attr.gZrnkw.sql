/**************************************************/
/*Object Name :  internal_get_nameless_prim_pv_attr		*/
/*Object Type :  Stored Proc.						*/
/*Purpose	  :  Procedure to get ID of the 'PV' attribute for a nameless primitive*/
/*		     for a given package ID*/
/*Used By	  :  CDI(reference resolution)          */
/**************************************************/
create procedure dbo.internal_get_nameless_prim_pv_attr
@varpkgID  int,
@vargobjectId int,
@varPrimID smallint out,
@varAttrID smallint out
AS
SET NOCOUNT ON
begin

	set @varAttrID = 0
	set @varPrimID = 0

	select 
	   @varPrimID = prim_inst.mx_primitive_id,
	   @varAttrID = attr_def.mx_attribute_id
	from  primitive_instance prim_inst 
	inner join attribute_definition attr_def on 
		  prim_inst.primitive_definition_id = attr_def.primitive_definition_id
	where 
		prim_inst.gobject_id = @vargobjectId
	and	prim_inst.package_id = @varpkgID 
	and prim_inst.primitive_name = '' 
	and attr_def.attribute_name = 'PV'

	--If Not found, look in the dynamic_attribute table
	if (@varAttrID = 0)
	begin
		    select 
			@varPrimID = prim_inst.mx_primitive_id,
			@varAttrID = dyna_attr.mx_attribute_id 
			from 
			primitive_instance prim_inst 
			inner join dynamic_attribute dyna_attr on 				
				prim_inst.gobject_id = dyna_attr.gobject_id 

				and prim_inst.mx_primitive_id = dyna_attr.mx_primitive_id
				and dyna_attr.package_id = @varpkgID
				and prim_inst.package_id = @varpkgID
				and prim_inst.primitive_name = '' 
				and dyna_attr.attribute_name = 'PV'	
				and dyna_attr.mx_attribute_category <> 16  -- MxCategory_SystemInternal_Browsable
				and dyna_attr.mx_attribute_category <> 17  -- MxCategory_PackageOnly_Calculated
	end
end

go

