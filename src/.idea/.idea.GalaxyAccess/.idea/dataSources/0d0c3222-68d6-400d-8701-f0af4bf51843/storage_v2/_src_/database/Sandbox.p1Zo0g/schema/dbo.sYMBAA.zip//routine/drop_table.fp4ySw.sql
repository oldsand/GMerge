-- Drops a single table from the current database.
-- Does nothing if the table doesn't exist
create proc dbo.drop_table
    @tableName nvarchar(80) -- name of table to be dropped
as
begin
    if exists (select * from dbo.sysobjects where id = object_id(@tableName) and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    begin
        declare @execString nvarchar(100)
        set @execString = 'drop table '+@tableName
        exec sp_executesql @execString
    end
end
go

