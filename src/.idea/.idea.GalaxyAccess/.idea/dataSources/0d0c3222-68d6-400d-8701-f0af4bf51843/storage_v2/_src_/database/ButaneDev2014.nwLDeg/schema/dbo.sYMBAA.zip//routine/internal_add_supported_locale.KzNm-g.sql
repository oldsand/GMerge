create proc dbo.internal_add_supported_locale
(
	@locale_id smallint
)
as
begin	
	if not exists (select 1 from supported_locales sls where sls.locale_id = @locale_id)
	begin
		insert into supported_locales 
		values (@locale_id)		
	end
end
go

