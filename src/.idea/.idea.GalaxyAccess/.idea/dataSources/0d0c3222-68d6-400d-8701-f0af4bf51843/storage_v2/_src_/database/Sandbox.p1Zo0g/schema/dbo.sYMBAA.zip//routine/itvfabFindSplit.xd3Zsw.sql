CREATE FUNCTION dbo.itvfabFindSplit (@attr_io_ref nvarchar(329))
RETURNS TABLE
/*
** Function that accepts an attribute IO reference string as object.uda.attr (tank.pressure.inputsource), and returns
** - the length of the passed reference string
** - the location of the first separator (5)
** - the location of the second separator (14)
*/
AS
  RETURN (
    SELECT length, first_split, (CASE WHEN first_split > 0 THEN length - CHARINDEX (N'.', REVERSE (@attr_io_ref)) + 1 ELSE 0 END) second_split 
      FROM (SELECT LEN(@attr_io_ref) AS length, CHARINDEX (N'.', @attr_io_ref) AS first_split) splits
  )
go

