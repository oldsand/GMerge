/*
** Procedure [internal_ab_import_xml]
** This procedure is invoked after an aaPKG is imported, to recreate all device linkages described in the passed XML file.
*/
CREATE procedure [dbo].[internal_ab_import_xml] 
( 
    @gObject_ids  nvarchar(265),
    @XMLpath      nvarchar(265) 
)
AS 
begin
    BEGIN TRAN
    set nocount on

    DECLARE @gSQL nvarchar(2000)  
    
    create table  #gObjId_list (gObj_id int primary key)
    SET @gSQL = 'BULK INSERT #gObjId_list  FROM ''' + @gObject_ids + ''' 
                 WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
    EXEC sp_executesql @gSQL

    IF @@ROWCOUNT = 0
        INSERT INTO #gObjId_list values (0)

	declare @affectedObj table (gobject_id int PRIMARY KEY)    
	
    -- Delete old linkages
	DELETE ab_attr
	  FROM autobound_attribute ab_attr
	INNER JOIN #gObjId_list links
	    ON links.gObj_id = ab_attr.gobject_id

    DELETE odl
    OUTPUT DELETED.gobject_id INTO @affectedObj
    FROM object_device_linkage odl
    INNER JOIN #gObjId_list links
        ON links.gObj_id = odl.gobject_id

    declare @XML XML
    declare @paramDef nvarchar(1000)
    
    SET @gSQL = N'SELECT @xmlOut = CONVERT (XML, BulkColumn)   FROM OPENROWSET (BULK ''' + @XMLpath + N''', SINGLE_BLOB) AS x'
    SET @paramDef = N'@xmlOut XML OUTPUT'
    EXEC sp_executesql  
         @gSQL
       , @paramDef
       , @xmlOut = @XML OUTPUT
    

    DECLARE @hDoc AS INT, @SQL NVARCHAR (MAX)

    EXEC sp_xml_preparedocument @hDoc OUTPUT, @XML

    -- Convert device, scan-group, and linked-object names to IDs, and create the linkages we shall attempt to reestablish
    -- The assertion of import preferences allows for situations to arise where:
    -- 1. The linked object is already linked, but needs its linkage realigned [is_linked =1]; and,
    -- 2. The linkage that this sproc purports to make already exists (nothing to be done) [is_linked = 2]
    declare @linkages table (gobject_id int PRIMARY KEY, dio_id int, sg_mx_primitive_id smallint, is_linked int)

    INSERT into @linkages (gobject_id, dio_id, sg_mx_primitive_id, is_linked)
    SELECT lo.gobject_id
         , dio.gobject_id
         , sg_pi.mx_primitive_id
         , CASE 
              WHEN odl.dio_id IS NULL THEN 0
              WHEN odl.dio_id = dio.gobject_id AND odl.sg_mx_primitive_id = sg_pi.mx_primitive_id THEN 2
              ELSE 1
           END
    FROM OPENXML(@hDoc, 'root/Dev/SG/Obj')
    WITH 
    (
        DeviceName nvarchar(329)    '../../@Nm'
      , ScanGroupName nvarchar(329) '../@Nm'
      , ObjectName nvarchar(329)    '@Nm'
    )
    INNER JOIN gobject dio
        ON dio.tag_name = DeviceName
    INNER JOIN primitive_instance sg_pi
        ON sg_pi.gobject_id = dio.gobject_id
       AND sg_pi.package_id = dio.checked_in_package_id
       AND sg_pi.primitive_name = ScanGroupName
    INNER JOIN primitive_definition pd
        ON pd.primitive_definition_id = sg_pi.primitive_definition_id
       AND pd.primitive_name in ('S', 'SG', 'ScanGroup1')
    INNER JOIN gobject lo
        ON lo.tag_name = ObjectName
    INNER JOIN #gObjId_list ol
        ON ol.gObj_id = lo.gobject_id
    LEFT OUTER JOIN object_device_linkage odl
        ON odl.gobject_id = lo.gobject_id
    
    -- Create new linkages
    INSERT INTO object_device_linkage
    SELECT gobject_id, dio_id, sg_mx_primitive_id
      FROM @linkages
     WHERE is_linked = 0

	--NOW process
	DELETE a 
      FROM @affectedObj a
	INNER JOIN @linkages l 
        ON l.gobject_id = a.gobject_id
       AND l.is_linked = 0

    -- Realign out-of-date linkages
    UPDATE odl
       SET dio_id = l.dio_id
         , sg_mx_primitive_id = l.sg_mx_primitive_id
      FROM object_device_linkage odl
    INNER JOIN @linkages l
        ON l.gobject_id = odl.gobject_id
       AND l.is_linked = 1
       
       
    -- All linkages have been made: Now to apply overrides.
    declare @overrides table (gobject_id int, mx_primitive_id smallint, mx_attribute_id smallint, xlate_rule_id int, override_str nvarchar(329))
    INSERT INTO @overrides
    SELECT lo.gobject_id, lo_attr_ref.referring_mx_primitive_id, lo_attr_ref.referring_mx_attribute_id, ab_xlate.xlate_rule_id, AttrOverride
    FROM OPENXML(@hDoc, 'root/Dev/SG/Obj/Attr')
    WITH 
    (
        ObjectName nvarchar(100)    '../@Nm'
      , AttributeName nvarchar(329) '@Nm'
      , AttrIOType nvarchar(50)     '@IO'
      , AttrXlateType nvarchar(329) '@Xlt'
      , AttrOverride nvarchar(329)  'Ovr'
    )
    INNER JOIN gobject lo
        ON lo.tag_name = ObjectName
    INNER JOIN @linkages links
        ON links.gobject_id = lo.gobject_id
    INNER JOIN attribute_reference lo_attr_ref
        ON lo_attr_ref.gobject_id = lo.gobject_id
       AND lo_attr_ref.package_id = lo.checked_in_package_id
       AND lo_attr_ref.element_index = 0
       AND lo_attr_ref.reference_string = N'---Auto---'
    INNER JOIN primitive_instance lo_pi
        ON lo_pi.package_id = lo_attr_ref.package_id
       AND lo_pi.gobject_id = lo_attr_ref.gobject_id
       AND lo_pi.mx_primitive_id = lo_attr_ref.referring_mx_primitive_id
       AND lo_pi.primitive_name = AttributeName
    INNER JOIN attribute_definition lo_attr_def
        ON lo_attr_def.primitive_definition_id = lo_pi.primitive_definition_id
       AND lo_attr_def.mx_attribute_id = lo_attr_ref.referring_mx_attribute_id
       AND lo_attr_def.attribute_name = AttrIOType
    INNER JOIN autobind_translation_rule ab_xlate
        ON ab_xlate.xlate_rule_name = AttrXlateType 

    -- Update autobound_attributes:
    UPDATE ab_attr
       SET ab_attr.xlate_rule_id = ov.xlate_rule_id
         , ab_attr.attr_alias = ov.override_str
      FROM autobound_attribute ab_attr
    INNER JOIN object_device_linkage odl
        ON odl.dio_id = ab_attr.dio_id
       AND odl.sg_mx_primitive_id = ab_attr.sg_mx_primitive_id
       AND odl.gobject_id = ab_attr.gobject_id
    INNER JOIN @overrides ov
        ON ov.gobject_id = odl.gobject_id
       AND ov.mx_primitive_id = ab_attr.mx_primitive_id
       AND ov.mx_attribute_id = ab_attr.mx_attribute_id


   -- Finally, updates required to precipitate reference-binding of newly applied overrides 
    UPDATE attribute_reference
       SET is_valid = 1
      FROM attribute_reference AR 
    INNER JOIN gobject g
        ON g.gobject_id = AR.gobject_id
    INNER JOIN @overrides o
        ON AR.gobject_id = o.gobject_id
       AND AR.package_id = g.checked_in_package_id
       AND AR.referring_mx_primitive_id = o.mx_primitive_id
       AND AR.referring_mx_attribute_id = o.mx_attribute_id
     WHERE AR.reference_string = N'---Auto---' 
        OR AR.reference_string like 'myDIO.%'

    UPDATE package 
       SET reference_status_id = 2
      FROM @overrides o
    INNER JOIN gobject g 
        ON o.gobject_id = g.gobject_id
    INNER JOIN package PK 
        ON g.gobject_id = PK.gobject_id
       AND g.checked_in_package_id = PK.package_id
    INNER JOIN attribute_reference AR 
        ON PK.gobject_id = AR.gobject_id 
       AND PK.package_id = AR.package_id 
       AND o.mx_primitive_id = AR.referring_mx_primitive_id 
       AND o.mx_attribute_id = AR.referring_mx_attribute_id 
       AND AR.is_valid = 1 
     WHERE PK.reference_status_id <> 2

	
	  -- Finally, the attribute reference table
	  UPDATE attribute_reference
		 SET is_valid = 1
		FROM attribute_reference AR 
	  INNER JOIN @affectedObj o
		  ON AR.gobject_id = o.gobject_id
	   WHERE reference_string = N'---Auto---' OR reference_string like 'myDIO.%'

		--START
		--set the package status after un-assignment of IO
		UPDATE package SET reference_status_id = 2
		FROM @affectedObj o
		inner join gobject g ON
		o.gobject_id = g.gobject_id 
		inner join package PK ON
		g.gobject_id = PK.gobject_id and
		g.checked_in_package_id = PK.package_id
		inner join attribute_reference AR ON
		PK.gobject_id = AR.gobject_id and
		PK.package_id = AR.package_id and
		AR.is_valid = 1 
		WHERE  reference_string = N'---Auto---' OR reference_string like 'myDIO.%'
	   --END
   	
	
    EXEC sp_xml_removedocument @hDoc
    COMMIT
end

go

