
/**************************************************
Object Name :  internal_multi_save_for_set_deploy_status
Purpose	    :  This procedure used to set the deploy status for passed Gobjects
				& it will mark the deployed files as deployed.

**************************************************/

create procedure dbo.internal_multi_save_for_set_deploy_status
	@GobjectInfoFileName nvarchar(256),
	@PackageIdsFileName nvarchar(256),
	@isRedeployOriginal int, 
	@mx_platform_id int,
	@node_name nvarchar(256)
as
begin
set nocount on	
	
SET QUOTED_IDENTIFIER on

CREATE TABLE  #deploy_info_table 
		( 
		gobject_id int, deploy_package_id int,
		deploy_version int, deploy_count int,package_id int
		)

CREATE TABLE  #packids_table ( packid int)

DECLARE @SQL nvarchar(2000)

begin tran

	

	SET @SQL = 'BULK INSERT #deploy_info_table  FROM ''' + @GobjectInfoFileName+ '''  WITH 
      (
         FIELDTERMINATOR = '','',
		 TABLOCK,
		 DATAFILETYPE  = ''widechar''       
      )'
	EXEC (@SQL)

	SET @SQL = 'BULK INSERT #packids_table  FROM ''' + @PackageIdsFileName+ ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')' 
	EXEC (@SQL)
	
	update gobject 
	set gobject.deployed_package_id = rt.deploy_package_id,
		gobject.deployed_version = rt.deploy_version,
		gobject.last_deployed_package_id = rt.deploy_package_id,
		gobject.deployment_pending_status = 0,
		gobject.software_upgrade_needed = 0
	from gobject 
	inner join #deploy_info_table rt
		on gobject.gobject_id = rt.gobject_id

	
	update package 
	set package_type = 'D'
	from package 
	inner join #deploy_info_table rt
		on package.package_id = rt.deploy_package_id
	        
-- set the timestamp for the deployed primitives
 
    declare @new_timestamp bigint
    exec internal_get_next_timestamp @new_timestamp out

    update pri  
    set timestamp_of_last_change = @new_timestamp
    from gobject g
    inner join #deploy_info_table rt on
		rt.gobject_id = g.gobject_id
	inner join gobject gobject_parent_tempate on
		g.derived_from_gobject_id =  gobject_parent_tempate.gobject_id
	inner join primitive_instance pri on 	 
        pri.gobject_id = gobject_parent_tempate.gobject_id and
        pri.package_id = gobject_parent_tempate.checked_in_package_id
	where pri.extension_type <> N'SymbolExtension' --HF CRL00131713 Ported from CR L00115710

	--delete the old package id
	delete	from package
	from package 
	inner join #packids_table 
	on package.package_id = #packids_table.packid		

	
	-- set last_deployed_rmcNode_name and last_deployed_Node_name 
	update	platform 
		set platform.last_deployed_node_name  = @node_name,
			platform.last_deployed_rmcNode_name  = platform.rmcNode_name,
			platform.last_deployed_portNMX  = platform.portNMX,
			platform.last_deployed_portRMC  = platform.portRMC,
			platform.last_deployed_portRPC  = platform.portRPC
	from platform
	inner join #deploy_info_table rt
	ON rt.gobject_id = platform.platform_gobject_id		


	--delete deployed_intouch_viewapp only if it is not RedeployOriginal
   if(@isRedeployOriginal <> 1)
   begin
		--first delete old rows if exists
		delete from deployed_intouch_viewapp
		where gobject_id in 
		(
			select g.gobject_id
			from #deploy_info_table rt
			inner join gobject g
				on g.gobject_id = rt.gobject_id
			inner join template_definition td on
				g.template_definition_id = td.template_definition_id
			where td.category_id = 26
		)
   end




    -- save state for diff comparison on re-deploy..
    declare @intouch_viewapp table (gobject_id int)
    
    insert into @intouch_viewapp(gobject_id)
    select g.gobject_id
    from #deploy_info_table rt
    inner join gobject g
    	on g.gobject_id = rt.gobject_id
    inner join template_definition td on
    g.template_definition_id = td.template_definition_id
    where td.category_id = 26
    
    declare @view_app_gobject_id int

    while(1=1)
    begin
        set @view_app_gobject_id = (select top 1 gobject_id 
        from @intouch_viewapp)
        if(@view_app_gobject_id < 1 or @view_app_gobject_id is null)
            break
        exec internal_store_intouch_viewapp_visual_element_dependency @view_app_gobject_id            
        delete 
        from @intouch_viewapp
        where gobject_id = @view_app_gobject_id 
    end
    
       

	--delete deployed_intouch_viewapp only if it is not RedeployOriginal
    if(@isRedeployOriginal <> 1)
    begin
		--add new rows 
		
		insert into deployed_intouch_viewapp
		(
			timestamp_of_deploy,
			gobject_id,
			deploy_file_transfering
		)
		select 
			cast(@@dbts as bigint),
			g.gobject_id,
			1
		from #deploy_info_table rt
		inner join gobject g
			on g.gobject_id = rt.gobject_id
		inner join template_definition td on
		g.template_definition_id = td.template_definition_id
		where td.category_id = 26
	end
	else if(@isRedeployOriginal = 1)
	begin

		insert into deployed_intouch_viewapp
		(
			timestamp_of_deploy,
			gobject_id,
			deploy_file_transfering
		)
		select 
			cast(@@dbts as bigint),
			g.gobject_id,
			1
		from #deploy_info_table rt
		inner join gobject g
			on g.gobject_id = rt.gobject_id
		inner join template_definition td on
		g.template_definition_id = td.template_definition_id
		where td.category_id = 26 and
			g.gobject_id not in
				(select 
					gobject_id 
				from deployed_intouch_viewapp)

		update diva 
		set deploy_file_transfering = 1
		from deployed_intouch_viewapp diva 
		inner join #deploy_info_table rt on
			diva.gobject_id = rt.gobject_id 
		inner join gobject g
			on g.gobject_id = rt.gobject_id
	end

	
commit tran

drop table #deploy_info_table
drop table #packids_table


end



go

