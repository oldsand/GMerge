/*
	This procedure takes the following table as its input
	create table #reference_target(gobject_id int primary key)

*/
create procedure dbo.internal_invalidate_references_to_objects
as
begin
	
	declare @reference_holder table (gobject_id int)

	update ar
	set is_valid = 1
	output 
		inserted.gobject_id
	into @reference_holder
	from  attribute_reference ar 
	inner join #reference_target rt on 
		ar.resolved_gobject_id =  rt.gobject_id


    -- set the package status of all affected objects whose references
    -- have been invalidated...
    update package set reference_status_id = 2
    from @reference_holder rh
    inner join gobject g on
        rh.gobject_id = g.gobject_id
    inner join package p on
        g.gobject_id = p.gobject_id and
        g.checked_in_package_id = p.package_id
    inner join attribute_reference ar on
        p.gobject_id = ar.gobject_id and
        p.package_id = ar.package_id and
		ar.is_valid = 1

    update pt
    set pt.gobject_id = pt.gobject_id
    from proxy_timestamp pt
    inner join @reference_holder rh on
        pt.gobject_id = rh.gobject_id 


end
go

