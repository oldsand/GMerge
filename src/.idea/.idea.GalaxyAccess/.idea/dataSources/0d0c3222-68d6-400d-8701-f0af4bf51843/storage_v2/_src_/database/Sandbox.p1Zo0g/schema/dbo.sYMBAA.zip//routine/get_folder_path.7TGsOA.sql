create  function dbo.get_folder_path(	@gobject_id int,@folderType int)
returns nvarchar(650)
as
begin
	declare @folderId int
    select @folderId = folder_id 
    from folder_gobject_link
    where gobject_id = @gobject_id

    declare   @path nvarchar(640)
    
    declare @objectId int
    declare @folder_name nvarchar(64)

    declare @separator nvarchar(2)
    set @separator = '$'
    
    select @objectId = @folderId
    select @path = ''

    while @objectId > 0 
    begin
    	select @objectId = f.parent_folder_id, @folder_name = f.folder_name
    	from folder f where folder_id = @objectId
    
    	if @path = ''
    		begin
    			if 0 = @objectId
    				set @path = @folder_name
    			else
    				set @path = @folder_name
    		end
    	else
    		begin
    			if 0 = @objectId
    				set @path = @folder_name + @separator + @path
    			else
    				set @path = @folder_name + @separator + @path
    
    		end
      end

      return @path
end
go

