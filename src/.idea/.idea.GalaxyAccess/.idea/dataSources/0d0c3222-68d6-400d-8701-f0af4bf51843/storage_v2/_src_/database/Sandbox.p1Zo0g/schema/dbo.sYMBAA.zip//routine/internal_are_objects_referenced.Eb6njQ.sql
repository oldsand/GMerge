create proc dbo.internal_are_objects_referenced
@file_of_gobject_ids nvarchar(265)
as
begin tran

    create table  #gobject_ids ( gobject_id int)	    
    declare @sql nvarchar(2000)    
    set @sql = 'bulk insert #gobject_ids  from ''' + @file_of_gobject_ids + ''' with(tablock,datafiletype  = ''widechar'')'
    exec (@sql)

	declare @gobject_ids_with_original_order_number table
		(
			original_order int identity(1,1),
			gobject_id int primary key,
			is_referenced bit
		)

	insert into @gobject_ids_with_original_order_number
		(gobject_id,
		 is_referenced)
	select 
		gobject_id,
		0
	from #gobject_ids

	drop table #gobject_ids 

	update gids
	set is_referenced = 1
	from @gobject_ids_with_original_order_number gids
	inner join attribute_reference ar on 
		ar.resolved_gobject_id = gids.gobject_id
	

	select 
		gobject_id,
		is_referenced
	from @gobject_ids_with_original_order_number
	order by original_order
	

commit
go

