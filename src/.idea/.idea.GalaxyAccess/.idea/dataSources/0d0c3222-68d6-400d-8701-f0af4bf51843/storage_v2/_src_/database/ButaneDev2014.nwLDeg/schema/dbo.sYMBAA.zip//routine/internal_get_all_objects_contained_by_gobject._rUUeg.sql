
CREATE  procedure dbo.internal_get_all_objects_contained_by_gobject
@gobject_id int
as 

	-- get the ids of this object and all its descendants ( in the container )
		declare @contain_level int
		declare @descendant table( gobject_id int, depth int )
		set @contain_level = 0

		insert into @descendant values(@gobject_id, @contain_level)

		while (select COUNT(*) from  @descendant where depth = @contain_level) > 0 
		begin

			-- get the children of the next level
			insert into @descendant  (gobject_id, depth)	
   			select gobject_id, @contain_level + 1
   			from gobject where contained_by_gobject_id in (select gobject_id from @descendant where depth = @contain_level)

			-- increment the depth for each level
			set @contain_level = @contain_level + 1
		end
select gobject_id from @descendant
go

