-- This is not a supported function. Data returned from this function may be incorrect.
--drop proc external_Attributelist
--go
--exec external_AttributeList 'ud1'
--exec external_AttributeList 'ud2'
--exec external_AttributeList '$Switch'

create proc dbo.external_attribute_list
@tagname nvarchar(329)
as
begin
	select pd.primitive_name,
		ad.attribute_name,
		'False' as IsUDA,
		'False' as IsInherited  from attribute_definition ad 
	inner join primitive_definition pd 
		on pd.primitive_definition_id = ad.primitive_definition_id
	inner join template_definition td 
		on td.template_definition_id = pd.template_definition_id
	inner join gobject gobj
		on gobj.template_definition_id = td.template_definition_id
		and gobj.tag_name = @tagname 
	union
	select '',da.attribute_name,'True' as IsUDA,
	case when da.gobject_id <> da.owned_by_gobject_id then 
	  'True'
	else
	  'False' 
	end as IsInherited from dynamic_attribute da
	inner join gobject gobj 
		on gobj.gobject_id = da.gobject_id 
		and gobj.checked_in_package_id = da.package_id
		and gobj.tag_name = @tagname 
	order by pd.primitive_name
end
go

