create proc dbo.internal_set_gobject_as_protected(
				@gObjectId int,
	            @bIsInsert bit,
    			@operationStatus int out)
As
set nocount on
begin
begin tran
	
	declare @bIsObjectProtected bit
	set @bIsObjectProtected = 0
	set @operationStatus = 0

	if @gObjectId = 0 return
	
	if exists (select '*' from gobject g inner join gobject_protected gp 
							on g.gobject_id = gp.gobject_id and g.gobject_id = @gObjectId)
	begin
		set @bIsObjectProtected = 1
	end

	if (@bIsObjectProtected = 1)
	begin
		 if (@bIsInsert = 0)
		 begin
			 delete from gobject_protected where gobject_id = @gObjectId
			 set @operationStatus = 1
		 end 
	end
	else
	begin
		if (@bIsInsert = 1)
		begin
			if exists (select '*' from gobject g where g.gobject_id = @gObjectId)
			begin
				insert into gobject_protected values (@gObjectId)
				set @operationStatus = 1
			end
		end
	end
		
commit

end
go

