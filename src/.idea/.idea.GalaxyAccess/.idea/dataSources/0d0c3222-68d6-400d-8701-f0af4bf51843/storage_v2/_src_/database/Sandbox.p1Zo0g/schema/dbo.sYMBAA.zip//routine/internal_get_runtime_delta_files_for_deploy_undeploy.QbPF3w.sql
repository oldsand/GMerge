-- calculates delta files between current and 
-- older version of platform

CREATE procedure dbo.internal_get_runtime_delta_files_for_deploy_undeploy
@FileNameOfIds nvarchar(400),
    @mx_platform_id int,
    @nodename nvarchar(256),
    @bDeploy int
as
set nocount on
begin
begin tran
	create table #package_ids( package_id int )	
	--create a table to file_ids which needs_to_deploy. 
	create table #file_ids( file_id int )

	create table #new_deploy_file_ids_config_update( file_id int )	
	create table #new_deploy_file_ids_soft_pend_update(file_id int)
	
	create table #results_table(file_id int)
	
	insert into #package_ids
		exec internal_select_ids @FileNameOfIds

	
	declare @selectedPlatformId int
	declare @oldPlatformPkgID int
	declare @softwarePendingUpdate int
	
	set	@selectedPlatformId = 0	
	select @selectedPlatformId = gobject_id from platform pt inner join
	package p on pt.platform_gobject_id = p.gobject_id inner join #package_ids pid
	on p.package_id = pid.package_id

	if(@selectedPlatformId > 0)
	BEGIN
		
		delete pid from #package_ids pid left outer join package p 
			on pid.package_id = p.package_id 
			where p.gobject_id <> @selectedPlatformId
				or p.gobject_id is null

		exec internal_get_runtime_files_for_packages

		insert into #new_deploy_file_ids_config_update
			select file_id from #file_ids
			
		insert into #new_deploy_file_ids_soft_pend_update 
			select file_id from #file_ids
			
		truncate table #file_ids
		
		set @softwarePendingUpdate = 0
		select @softwarePendingUpdate = g.software_upgrade_needed from gobject g 
			where g.gobject_id = @selectedPlatformId
					
		set @oldPlatformPkgID = 0 
			
		select @oldPlatformPkgID = p.package_id from platform pt inner join
			package p on pt.platform_gobject_id = p.gobject_id and
			(p.gobject_id = @selectedPlatformId) 
			left outer join #package_ids pid on pid.package_id = p.package_id
				where pid.package_id is null
			
			
		
		if((@oldPlatformPkgID > 0)and (@bDeploy = 1))
		BEGIN
			--delete file ids from the #new_deploy_file_ids_config_update which are already deployed (is_runtime_deployed = 1) on the node 
			delete ndfi from	#new_deploy_file_ids_config_update ndfi inner join deployed_file df 
						on		ndfi.file_id = df.file_id and
								df.node_name = @nodename and 
								df.is_runtime_deployed = 1
		
				
			insert into #results_table select file_id from #new_deploy_file_ids_config_update
		END

		if (@softwarePendingUpdate > 0)
		BEGIN			
			if (@bDeploy = 0)
			BEGIN
				insert into #file_ids select ndfi.file_id from #new_deploy_file_ids_soft_pend_update ndfi
					inner join deployed_file df on df.file_id = ndfi.file_id where 
					(df.node_name = @nodename and df.is_runtime_deployed = 1)
						
				delete fid from #file_ids fid left outer join file_pending_update fpu 
						on		fid.file_id = fpu.file_id and
								fpu.node_name = @nodename 
						where	fpu.file_id is null				
				
				insert into #results_table select file_id from #file_ids		
						
			END
			ELSE 
			BEGIN
				insert into #file_ids select ndfi.file_id from #new_deploy_file_ids_soft_pend_update ndfi 
					inner join file_pending_update fpu on fpu.file_id = ndfi.file_id
					where (fpu.node_name = @nodename)
									 
				insert into #results_table select file_id from #file_ids
				
			END
		END
			
		select distinct ft.file_id,file_name, vendor_name, registration_type , subfolder 
			from file_table ft inner join #results_table rt on ft.file_id = rt.file_id	
		
	END
	drop table #new_deploy_file_ids_config_update
	drop table #new_deploy_file_ids_soft_pend_update
	drop table #file_ids
	drop table #package_ids
	drop table #results_table
commit tran
end
go

