create procedure dbo.internal_multi_object_checkin
    @FileNameOfIds nvarchar (265),
    @being_called_internally bit = 0
as
begin

    set nocount on       

    begin tran      

    create table #validresults (
            gobject_id int primary key, 
            checked_out_package_id int, 
            deployed_package_id int,
            checked_in_package_id int,
            is_template bit,
            dio_id int,
            sg_mx_primitive_id smallint,
            is_autobound_device bit
    )
    create index temp_valid_results_on_gobject_id_and_checked_out_package_id on 
        #validresults(gobject_id,checked_out_package_id)
    
    if(@being_called_internally = 0)-- client is C++, a file is being passed in..
    begin        
        CREATE TABLE  #results_table ( gobject_id int)

        DECLARE @SQL nvarchar(2000)

        SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

        EXEC (@SQL)
    end

    -- Start HF CR L00137941
    if exists ( select 1
      from gobject g
    inner join #results_table r
        on r.gobject_id = g.gobject_id
    inner join template_definition td
        on td.template_definition_id = g.template_definition_id
    inner join lookup_category lcat
        on lcat.category_id = td.category_id and lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO') )
    begin
    create table #scan_groups_common (dio_id int
                                    , old_mx_primitive_id smallint
                                    , new_mx_primitive_id smallint
                                    , PRIMARY KEY CLUSTERED (dio_id, old_mx_primitive_id))
    create table #scan_groups_deleted (dio_id int
                                     , mx_primitive_id smallint
                                     , PRIMARY KEY CLUSTERED (dio_id, mx_primitive_id))

    --#scan_groups_common will have scan group entries present in both the checked-in and checked-out packages
    insert into #scan_groups_common
    select g.gobject_id as GID, pin.mx_primitive_id AS pinID, pout.mx_primitive_id as poutID
      from gobject g
    inner join #results_table r
        on r.gobject_id = g.gobject_id
    inner join primitive_instance pin
        on pin.gobject_id = g.gobject_id
       and pin.package_id = g.checked_in_package_id
    inner join primitive_instance pout
        on pout.gobject_id = g.gobject_id
       and pout.package_id = g.checked_out_package_id
       and pout.primitive_definition_id = pin.primitive_definition_id
    inner join primitive_definition pd
        on pd.primitive_definition_id = pout.primitive_definition_id 
       and pd.primitive_name in ('S', 'SG', 'ScanGroup1')
    inner join template_definition td
        on td.template_definition_id = g.template_definition_id
    inner join lookup_category lcat
        on lcat.category_id = td.category_id
       and lcat.category_name in (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
     where g.is_template = 0 
       and pin.primitive_name = pout.primitive_name

    --#scan_groups_deleted will have scan group primtive ids that are not renamed/deleted and have app objects linked
    insert into #scan_groups_deleted
    select odl.dio_id,sg_mx_primitive_id from object_device_linkage odl
    inner join #results_table r
        on r.gobject_id = odl.dio_id
    inner join primitive_instance pin
        on pin.gobject_id = odl.dio_id and pin.mx_primitive_id = odl.sg_mx_primitive_id
    inner join gobject g
        on g.gobject_id = odl.dio_id and g.checked_in_package_id = pin.package_id
       and g.is_template = 0
    except
    select dio_id,old_mx_primitive_id from #scan_groups_common

    end
    --End HF CR L00137941

    insert into #validresults ( 
        gobject_id,
        checked_out_package_id,
        deployed_package_id, 
        checked_in_package_id, 
        is_template,
        dio_id,
        sg_mx_primitive_id,
        is_autobound_device )
    select 
        rt.gobject_id,
        g.checked_out_package_id,
        g.deployed_package_id, 
        g.checked_in_package_id,
        g.is_template,
        ISNULL(odl.dio_id, 0),
        ISNULL(odl.sg_mx_primitive_id, 0),
        CASE WHEN ISNULL(abdev.dio_id, 0) = g.gobject_id THEN 1 ELSE 0 END        
    from #results_table rt
    inner join gobject g  on  rt.gobject_id = g.gobject_id 
    left outer join object_device_linkage odl on odl.gobject_id = g.gobject_id
    left outer join autobind_device abdev on abdev.dio_id = g.gobject_id
    where g.checked_out_package_id > 0 

    -->>-- Auto-binding
    -- Preserve manual overrides for objects that are linked to devices
    CREATE TABLE #autobound_attribute_transient (
                       gobject_id      int
                     , mx_primitive_id smallint
                     , mx_attribute_id smallint
                     , element_index   smallint
                     , linked_device   nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                     , default_ref     nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                     , xlate_rule_id   int
                     , attr_alias      nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                     , match_by_id      bit
                     , PRIMARY KEY (gobject_id, mx_primitive_id, mx_attribute_id, element_index))

    -- The autobound_attribute_transient table holds overrides across a check-in so that they may be reinstated after the check-in.
    INSERT INTO #autobound_attribute_transient
    SELECT itvf.lo_id, itvf.lo_prim_id, itvf.lo_attr_id, itvf.lo_element_index
         , itvf.dio_tag_name + '.' + itvf.dio_scan_group_name
         , itvf.app_object_attr_name + '.' + itvf.app_object_io_attr
         , itvf.xlate_rule_id, itvf.overridden_attr_reference
         , 1
      FROM #validresults vr
    INNER JOIN object_device_linkage odl
        ON odl.gobject_id = vr.gobject_id
    CROSS APPLY itvfGetAutobindInfoForDIO (odl.dio_id, odl.sg_mx_primitive_id, odl.gobject_id, DEFAULT, DEFAULT) itvf
    UNION  -- List of auto-bound attributes linked to DIO being checked in
    SELECT itvf.lo_id, itvf.lo_prim_id, itvf.lo_attr_id, itvf.lo_element_index
         , itvf.dio_tag_name + '.' + itvf.dio_scan_group_name
         , itvf.app_object_attr_name + '.' + itvf.app_object_io_attr
         , itvf.xlate_rule_id, itvf.overridden_attr_reference
         , 1
      FROM #validresults vr
    INNER JOIN autobind_device_topic adt
        ON adt.dio_id = vr.gobject_id
    CROSS APPLY itvfGetAutobindInfoForDIO (adt.dio_id, adt.sg_mx_primitive_id, DEFAULT, DEFAULT, DEFAULT) itvf
    OPTION (FORCE ORDER)     --L00136670


    DECLARE @obj_list nvarchar(max)
    select @obj_list = stuff ((select ',' + convert (NVARCHAR, gobject_id) from #validresults FOR XML PATH(''), TYPE).value('.', 'VARCHAR(max)'), 1, 1, '')

    EXEC internal_ab_update_transient_table @obj_list


    --<<-- Auto-binding
/*
L00101757
*/

    update  p 
    set     package_type = 'X' 
    from    package p
    inner join #validresults r
            on r.gobject_id = p.gobject_id 
           and r.checked_in_package_id = p.package_id           
 /*
L00101757
*/
    insert into old_checked_in_packages(package_id, gobject_id, is_template)
        select  g.checked_in_package_id,
                g.gobject_id,
                g.is_template
        from    gobject g
        inner join #validresults v
        on      g.gobject_id = v.gobject_id

    -- insert cancelled packages into table for
    -- internal_get_referenced_ids_for_deleted_dynamic_attributes to use...
    insert into packages_to_be_deleted
    select  g.gobject_id,
            g.checked_in_package_id
    from    gobject g
    inner join #validresults v
    on      g.gobject_id = v.gobject_id


    -- Check whether there is any object having visualization stuff
    declare @have_visual_element int
    set @have_visual_element = 0
    
    -- InTouchViewapp
    if (exists(
        select top 1
            g.gobject_id
        from    
            #validresults v
            inner join gobject g
                on  g.gobject_id = v.gobject_id
            inner join template_definition td
                on  td.template_definition_id = g.template_definition_id
                and td.category_id = 26
    ))
    begin
        set @have_visual_element = 1                
    end
            
    -- Whether object is a symbol or it has symbol extensions.
    if (@have_visual_element = 0)
    begin
        if (exists(
            select top 1
                g.gobject_id
            from 
                gobject g 
                inner join #validresults v on 
                    v.gobject_id = g.gobject_id
                inner join visual_element_version vev on 
                    vev.gobject_id = g.gobject_id
                and 
                    (vev.package_id = g.checked_in_package_id   
                    or  vev.package_id = g.checked_out_package_id
                    or  vev.package_id = g.deployed_package_id)
        ))
        begin
            set @have_visual_element = 1                
        end
    end
           
/*         
    insert change_log(gobject_id, package_id, need_to_call_ve, comment, spid, happened_at)
    (
        select  g.gobject_id, 
                g.checked_out_package_id,
                @have_visual_element,
                N'check_in',
                @@spid,
                GETDATE()
        from
                gobject g
                inner join #validresults v on 
                    v.gobject_id = g.gobject_id 
    )
*/
                   
    if (@have_visual_element = 1)
    begin
    create table #old_checked_in_package_for_processing_deleted_visual_elements
    (
        gobject_id int,
        package_id int,
        primary key (gobject_id,package_id)
    )

    insert into #old_checked_in_package_for_processing_deleted_visual_elements
    select  g.gobject_id,
            g.checked_in_package_id
    from    gobject g
    inner join #validresults v
    on      g.gobject_id = v.gobject_id

    exec internal_process_deleted_visual_elements

    drop table #old_checked_in_package_for_processing_deleted_visual_elements
    end
    
    update g 
    set     
            g.checked_out_by_user_guid = null, 
            g.checked_out_package_id = 0,
            g.checked_in_package_id = r.checked_out_package_id,
            g.configuration_version =  g.configuration_version + 1 
    from    #validresults r
    inner   join gobject g
            on r.gobject_id = g.gobject_id        


    --  try to bind any VERs that may be affected by this operation..
    --declare @affected_checked_in_unbound_elements table
    if (@have_visual_element = 1)
    begin
    CREATE TABLE  #affected_checked_in_unbound_elements
    (gobject_id int,
    package_id int,
    mx_primitive_id smallint,
    visual_element_reference_index int,
    checked_in_bound_visual_element_gobject_id int null,
    checked_in_bound_visual_element_package_id int null,
    checked_in_bound_visual_element_mx_primitive_id smallint null)
-- try to bind by ID first...
    --insert into @affected_checked_in_unbound_elements
    insert into #affected_checked_in_unbound_elements
    (gobject_id,
    package_id,
    mx_primitive_id ,
    visual_element_reference_index ,
    checked_in_bound_visual_element_gobject_id ,
    checked_in_bound_visual_element_package_id ,
    checked_in_bound_visual_element_mx_primitive_id )   
     
    select 
    distinct
        u.gobject_id,
        u.package_id,
        u.mx_primitive_id,
        u.visual_element_reference_index,
        v.gobject_id ,
        v.package_id ,
        v.mx_primitive_id
    from visual_element_reference u 
    inner join internal_visual_element_description_view v (noexpand)on
         v.visual_element_id = u.checked_in_unbound_visual_element_id
    inner   join #validresults r on
         r.gobject_id = v.gobject_id and
         r.checked_out_package_id = v.package_id -- r.checked_out_package_id is the gobject checked_in package_id

--    union
--
--    select 
--    distinct
--        u.gobject_id,
--        u.package_id,
--        u.mx_primitive_id,
--        u.visual_element_reference_index,
--        v.gobject_id ,
--        v.package_id ,
--        v.mx_primitive_id
--    from visual_element_reference u --(index = idx_visual_element_reference_on_checked_in_unbound_names )
--    inner join internal_visual_element_description_view v (noexpand) on
--        (u.checked_in_unbound_visual_element_name = v.visual_element_name and
--         u.checked_in_unbound_visual_element_type = v.visual_element_type )-- check index order....
--    inner   join #validresults r on
--         r.gobject_id = v.gobject_id and
--         r.checked_out_package_id = v.package_id -- r.checked_out_package_id is the gobject checked_in package_id


    --update the checked_in_bound ver columns....
    update  ver
    set 
        -- bound columns...
        ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
        ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
        ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
        --ver.visual_element_bind_status = 1,-- now a calculated column..
        -- unbound columns...
        ver.checked_in_unbound_visual_element_name = null,
        ver.checked_in_unbound_visual_element_type = null,
        ver.checked_in_unbound_tag_name = null,
        ver.checked_in_unbound_primitive_name = null,
        ver.checked_in_unbound_relative_object_name = null,
        ver.checked_in_unbound_visual_element_id = null
    from visual_element_reference ver 
    inner join #affected_checked_in_unbound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index

   truncate table #affected_checked_in_unbound_elements
-- now, try to bind by name

    insert into #affected_checked_in_unbound_elements
    (gobject_id,
    package_id,
    mx_primitive_id ,
    visual_element_reference_index ,
    checked_in_bound_visual_element_gobject_id ,
    checked_in_bound_visual_element_package_id ,
    checked_in_bound_visual_element_mx_primitive_id )   

    select 
    distinct
        u.gobject_id,
        u.package_id,
        u.mx_primitive_id,
        u.visual_element_reference_index,
        v.gobject_id ,
        v.package_id ,
        v.mx_primitive_id
    from visual_element_reference u --(index = idx_visual_element_reference_on_checked_in_unbound_names )
    inner join internal_visual_element_description_view v (noexpand) on
        (u.checked_in_unbound_visual_element_name = v.visual_element_name and
         u.checked_in_unbound_visual_element_type = v.visual_element_type )-- check index order....
    inner   join #validresults r on
         r.gobject_id = v.gobject_id and
         r.checked_out_package_id = v.package_id -- r.checked_out_package_id is the gobject checked_in package_id


    --update the checked_in_bound ver columns....
    update  ver
    set 
        -- bound columns...
        ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
        ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
        ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
        --ver.visual_element_bind_status = 1,-- now a calculated column..
        -- unbound columns...
        ver.checked_in_unbound_visual_element_name = null,
        ver.checked_in_unbound_visual_element_type = null,
        ver.checked_in_unbound_tag_name = null,
        ver.checked_in_unbound_primitive_name = null,
        ver.checked_in_unbound_relative_object_name = null,
        ver.checked_in_unbound_visual_element_id = null
    from visual_element_reference ver 
    inner join #affected_checked_in_unbound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index

    DROP table #affected_checked_in_unbound_elements

    -- try to bind any relative references that may have been affected by this operation..
    exec internal_bind_relative_visual_elements_for_gobjects 
    
    if exists(
           select 1 
           from #validresults r
               inner join visual_element_reference ver on
                 --ver.checked_out_bound_visual_element_gobject_id = r.gobject_id and 
                 ver.checked_out_visual_element_package_id = r.checked_out_package_id

    )
    begin
        update ver
        set 
            ver.checked_out_to_user_guid = null,
        ver.checked_out_visual_element_gobject_id = null,
            ver.checked_out_visual_element_package_id = null,
            -- checked-in bound data...
            ver.checked_in_bound_visual_element_gobject_id = ver.checked_out_bound_visual_element_gobject_id,
            ver.checked_in_bound_visual_element_package_id = ver.checked_out_bound_visual_element_package_id,
            ver.checked_in_bound_visual_element_mx_primitive_id = ver.checked_out_bound_visual_element_mx_primitive_id,
            -- checked-in unbound data...
            ver.checked_in_unbound_visual_element_name = ver.checked_out_unbound_visual_element_name,
            ver.checked_in_unbound_visual_element_type = ver.checked_out_unbound_visual_element_type,
            ver.checked_in_unbound_tag_name = ver.checked_out_unbound_tag_name,
            ver.checked_in_unbound_primitive_name = ver.checked_out_unbound_primitive_name,
            ver.checked_in_unbound_relative_object_name = ver.checked_out_unbound_relative_object_name,
            ver.checked_in_unbound_visual_element_id = ver.checked_out_unbound_visual_element_id,
            -- null out all unbound checked_out columns...
            ver.checked_out_bound_visual_element_gobject_id =  null,
            ver.checked_out_bound_visual_element_package_id = null,
            ver.checked_out_bound_visual_element_mx_primitive_id = null,
            ver.checked_out_unbound_visual_element_name = null,
            ver.checked_out_unbound_visual_element_type = null,
            ver.checked_out_unbound_tag_name = null,
            ver.checked_out_unbound_primitive_name = null,
            ver.checked_out_unbound_relative_object_name = null
        from #validresults r
        inner join visual_element_reference ver on
            --ver.checked_out_bound_visual_element_gobject_id = r.gobject_id and 
            ver.checked_out_visual_element_package_id = r.checked_out_package_id
    end        
    end
    else
    begin
        select 
            1 as gobject_id,
            1 as package_id,
            1 as mx_primitive_id,
            1 as visual_element_reference_index,
            1 as gobject_id ,
            1 as package_id ,
            1 as mx_primitive_id
        from         
            galaxy with(nolock)
        where 
            1 = 0    
    end

    /********************************************************************************
    *   for templates, change the package_type to the package_version number
    *   for the archived package(package pertaining to deployed instances...
    *********************************************************************************/
    
    update  p 
    set     package_type = p.package_version
    from    package p
    inner   join #validresults r
            on r.gobject_id = p.gobject_id and
            p.package_type = 'I' and
            r.is_template = 1
        
    update  p 
    set     package_type = 'I'                
    from    package p
    inner   join #validresults r
            on r.gobject_id = p.gobject_id 
            and r.checked_out_package_id = p.package_id

    -- Device Linkage (begin)
    -- Iterate through list of objevts being checked-in:
    -- If object is a device, refresh it autobound topics to account for new ones add and old ones removed
    -- If object is linked to a device, refresh its autobound attribute list to handle edits to them.
    declare @ab_gid int = 0
    declare @dio_id int
    declare @sg_mx_primitive_id smallint
    declare @refresh_topics bit
    declare @affectedObj table (gobject_id int primary key)
    declare @update_proxy_timestamp bit = 0
    while (1=1)
    begin
        select top 1 @ab_gid = gobject_id, @dio_id = dio_id, @sg_mx_primitive_id = sg_mx_primitive_id, @refresh_topics = is_autobound_device
        from #validresults
        where gobject_id > @ab_gid and is_template = 0
        order by gobject_id

        if @@ROWCOUNT = 0
            break
        
        if @refresh_topics = 1
        begin
            declare @marked_redeploy_pending int
            insert into @affectedObj select gobject_id from object_device_linkage odl where odl.dio_id = @ab_gid
            execute @marked_redeploy_pending = internal_ab_refresh_dio_topics @ab_gid
            if @marked_redeploy_pending = 1
                set @update_proxy_timestamp = 1
            execute @marked_redeploy_pending = internal_ab_handle_dio_change @ab_gid
            if @marked_redeploy_pending = 1
                set @update_proxy_timestamp = 1
        end
        else if @dio_id <> 0 and @sg_mx_primitive_id <> 0
            execute internal_ab_refresh_autobound_attrs @ab_gid, @dio_id, @sg_mx_primitive_id
        
    end
    
    --START
    update attribute_reference
    set is_valid = 1
    from  attribute_reference AR 
    inner join @affectedObj o
    on AR.gobject_id = o.gobject_id
    where reference_string = N'---Auto---' OR reference_string like 'myDIO.%'

    --set the package status after un-assignment of IO
    update package set reference_status_id = 2
    from @affectedObj o
    inner join gobject g on
    o.gobject_id = g.gobject_id 
    inner join package PK on
    g.gobject_id = PK.gobject_id and
    g.checked_in_package_id = PK.package_id
    inner join attribute_reference AR on
    PK.gobject_id = AR.gobject_id and
    PK.package_id = AR.package_id and
    AR.is_valid = 1 
    where  reference_string = N'---Auto---' OR reference_string like 'myDIO.%'
    --END
    -- Device Linkage (end)

--  --When Primary Engine gets checkin Backup enigne check is done before that in C++
--  --So don't use this logic
--  --copy deployable_configuration_version from partner if its namespace_id = 2. ( Redundant backup engine)
--  update  p 
--    set     p.deployable_configuration_version = primary_pack.deployable_configuration_version
--    from    package p
--    inner   join #validresults r
--            on r.gobject_id = p.gobject_id    
--    inner join gobject g
--          on g.gobject_id = r.gobject_id          
--  inner join redundancy red
--          on red.backup_gobject_id = g.gobject_id
--  inner join gobject partner_gobj
--          on red.primary_gobject_id = partner_gobj.gobject_id
--  inner join package primary_pack
--          on partner_gobj.checked_in_package_id = primary_pack.package_id
--  where   p.package_id = g.checked_in_package_id and
--            r.is_template = 0 
    
-- When checkin primary engine find backup engine and update backup eninge's deployable_configuration_version
-- from primary enigne's checkedin package

    CREATE TABLE  #backupengines( gobject_id int, primary_gobject_id int)
    
    insert into #backupengines
    select red.backup_gobject_id, red.primary_gobject_id
    from redundancy red
    inner join #validresults r
    on r.gobject_id = red.primary_gobject_id    
    
    update  p 
    set     p.deployable_configuration_version = primary_pack.deployable_configuration_version
    from    package p
    inner   join #backupengines r
            on r.gobject_id = p.gobject_id    
    inner join gobject g
            on g.gobject_id = r.gobject_id              
    inner join gobject partner_gobj
            on r.primary_gobject_id = partner_gobj.gobject_id
    inner join package primary_pack
            on partner_gobj.checked_in_package_id = primary_pack.package_id
    where   p.package_id = g.checked_in_package_id
            

    drop table #backupengines


   --if (CI > LD and LD > 0 ) then Unbind with LD package VE references & bind with CI package
    if (@have_visual_element = 1)
    begin
    CREATE TABLE  #unbind_vereferences ( gobject_id int, package_id int)        
    insert into #unbind_vereferences 
    select g.gobject_id, g.last_deployed_package_id
    from gobject g 
    inner join #validresults rt
    on g.gobject_id = rt.gobject_id
    where
            g.checked_in_package_id > g.last_deployed_package_id 
            and g.last_deployed_package_id > 0
         --   and g.deployed_package_id = 0         --D = 0 will not work for template s1
    
    if exists(select 1 from #unbind_vereferences)
    begin
        exec internal_unbind_with_gobject_and_package_id
        exec internal_bind_visual_element_references
    end

    drop table #unbind_vereferences 


    -- check to see if the primitive has changed or not.....
    -- call the proc to bump primitive timestamp if necessary....
        --777AR
    create table #modified_primitive 
            (gobject_id int, 
            package_id int,
            mx_primitive_id smallint)

    insert into #modified_primitive
            (gobject_id, 
            package_id,
            mx_primitive_id)
    select  res.gobject_id, 
            res.checked_out_package_id,
            pri.mx_primitive_id
    from #validresults res
    inner join primitive_instance pri on
            res.gobject_id = pri.gobject_id and
            res.checked_out_package_id = pri.package_id and
            pri.checked_out_primitive_version > pri.checked_in_primitive_version
    inner join visual_element_version vev on
          pri.gobject_id = vev.gobject_id and    
          pri.package_id = vev.package_id and
          pri.mx_primitive_id = vev.mx_primitive_id
    
    if (@@ROWCOUNT > 0)
    begin
        declare @new_timestamp bigint
        exec internal_get_next_timestamp @new_timestamp out
        update pri
        set timestamp_of_last_change = @new_timestamp
        from primitive_instance pri
        inner join #modified_primitive gci on
            pri.gobject_id = gci.gobject_id and
            pri.package_id = gci.package_id and
            pri.mx_primitive_id = gci.mx_primitive_id
    end

    drop table #modified_primitive
        
    end   --if (@have_visual_element = 1)

    update pri
    set     
        checked_in_primitive_version = pri.checked_out_primitive_version,
        entity_change_type = 1,
        operation_on_primitive_mask = 0
    from #validresults res   
    inner join primitive_instance pri on--with (index = i1) 
        pri.gobject_id = res.gobject_id and
        pri.package_id = res.checked_out_package_id


    if (@have_visual_element = 1)
    begin
    update  visual_element_version
    set     inherited_from_package_id = res.checked_out_package_id
    from    visual_element_version vev 
    inner join #validresults res on 
        vev.inherited_from_gobject_id = res.gobject_id
        and vev.inherited_from_package_id = res.checked_in_package_id
    end

    if (@being_called_internally = 0)-- client is C++, a file is being passed in..
    begin
        drop table #results_table
    end

    -- update timestamp of checked in package for visual element polling...
    declare @update_was_made bit
    set @update_was_made = 0
    
    if (@have_visual_element = 1)
    begin
        
    if exists(
        select '*'
        from visual_element_timestamp vet   
        inner join #validresults r on
        r.gobject_id = vet.gobject_id and
        r.checked_out_package_id = vet.package_id )
    begin
        -- modified visual elements...
        update vet
        set change_type = change_type
        from visual_element_timestamp vet   
        inner join #validresults r on
             r.gobject_id = vet.gobject_id and
             r.checked_out_package_id = vet.package_id -- r.checked_out_package_id is the gobject checked_in package_id
        
        set @update_was_made = 1
    end
        
    -- renamed visual_elements...
    if exists(
        select '*'
        from renamed_visual_element rve
        inner join #validresults r on
        r.gobject_id = rve.gobject_id and
        r.checked_out_package_id = rve.package_id )
    begin
        update rve
        set rve.gobject_id = rve.gobject_id
        from renamed_visual_element rve 
        inner join #validresults r on
             r.gobject_id = rve.gobject_id and
             r.checked_out_package_id = rve.package_id 
        
        set @update_was_made = 1
    end
    

    -- deleted visual_elements...
    if exists(
        select '*'
        from deleted_visual_element_version dve
        inner join #validresults r on
        r.gobject_id = dve.gobject_id and
        r.checked_out_package_id = dve.package_id )
    begin
        update dve
        set dve.gobject_id = dve.gobject_id
        from deleted_visual_element_version dve 
        inner join #validresults r on
             r.gobject_id = dve.gobject_id and
             r.checked_out_package_id = dve .package_id 

        set @update_was_made = 1
    end
    
    
    end

    if(@update_was_made = 1 OR @update_proxy_timestamp = 1)
    begin
        update galaxy
           set max_visual_element_timestamp = CASE WHEN @update_was_made = 1 THEN CAST ( @@dbts  AS timestamp ) ELSE max_visual_element_timestamp END 
             , max_proxy_timestamp = CASE WHEN @update_proxy_timestamp = 1 THEN CAST (@@dbts  AS timestamp) ELSE max_proxy_timestamp END
    end
    
    drop table #validresults
    commit tran

end


go

