create proc dbo.internal_get_folder
(
	@folder_id int,
    @folder_type smallint
)
as
begin
    
    if(@folder_id > 0)
    begin
    select  
        folder_id,
		parent_folder_id,
		depth,  
		folder_name,
		has_objects, 
		has_folders
	from folder 
	where 
        folder_id = @folder_id and
        folder_type = @folder_type
    end
    else
    begin
    select  
        0,
		0,
		0,  
		'',
		0, 
		0
    end


end
go

