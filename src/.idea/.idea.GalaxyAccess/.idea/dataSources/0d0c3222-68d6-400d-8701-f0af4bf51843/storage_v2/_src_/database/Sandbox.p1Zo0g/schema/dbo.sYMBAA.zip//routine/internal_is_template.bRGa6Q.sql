/*
This procedure will verify that input gobject_id = template or not
usage:
declare @P1 int
exec internal_IsTemplate
     gobject_id = 23, @P1
*/
CREATE   PROCEDURE dbo.internal_is_template
@gobject_id  nvarchar(400),
@isTemplate int  OUTPUT
 AS
begin
SET NOCOUNT ON
	set @isTemplate = 0
	SELECT @isTemplate = COUNT(gobject_id) FROM gobject 
	where is_template <> 0 and gobject_id = @gobject_id
SET NOCOUNT OFF
end
go

