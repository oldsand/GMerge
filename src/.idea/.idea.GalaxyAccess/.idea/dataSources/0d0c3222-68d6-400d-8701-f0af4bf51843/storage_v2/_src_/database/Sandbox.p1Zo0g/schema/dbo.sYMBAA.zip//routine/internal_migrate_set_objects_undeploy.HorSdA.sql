create proc dbo.internal_migrate_set_objects_undeploy
	@user_id nvarchar(64),
		@user_comment nvarchar(	1024)
As

begin 

if(@user_id <> N'')
begin
declare @user_profile_name nvarchar(256)
select @user_profile_name = user_profile_name from user_profile where user_guid = @user_id

insert into gobject_change_log
select gobject_id, getdate(), 8, @user_comment, configuration_version ,@user_profile_name
from gobject where deployed_package_id <> 0
end

update gobject 
set deployed_package_id = 0, software_upgrade_needed = 0, last_deployed_package_id = 0, deployment_pending_status = 0
where deployed_package_id <> 0

truncate table file_pending_update
-- delete from deployed_file
end

go

