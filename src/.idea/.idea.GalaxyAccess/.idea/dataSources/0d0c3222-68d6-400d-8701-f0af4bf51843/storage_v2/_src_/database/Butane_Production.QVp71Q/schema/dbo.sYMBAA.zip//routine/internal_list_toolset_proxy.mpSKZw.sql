/**************************************************/
/*Object Name :  internal_list_toolset_proxy                            */
/*Object Type :  Stored Proc.								   */
/*Purpose :    to provide proxy - info data for a given toolset */
/*Used By :    CDI									*/
/**************************************************/
CREATE  PROCEDURE dbo.internal_list_toolset_proxy                            
@varwhere int
 AS
begin
set nocount on

select
    'id' = folder.folder_id, 
    'toolsetname' =  folder.folder_name,     
    'bhasTemplates'  =   case when exists(select gobject_id from folder_gobject_link f where f.folder_id = @varwhere )
	                         then 1
						 else 0
						 end
from  folder where folder_id = @varwhere


end

go

