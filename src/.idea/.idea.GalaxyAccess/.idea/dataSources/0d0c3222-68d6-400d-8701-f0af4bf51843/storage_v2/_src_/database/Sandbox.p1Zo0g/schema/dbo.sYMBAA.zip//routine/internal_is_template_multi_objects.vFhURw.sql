/**************************************************
Object Name :  internal_is_template_multi_objects
Object Type :  Stored Proc. 
Purpose	    :  This procedure check whether specified objects are templates
Used By	    :  
**************************************************/

CREATE PROCEDURE dbo.internal_is_template_multi_objects
	@FileNameOfids nvarchar (265)
as
begin
set nocount on
	
	DECLARE @results_table table( 
		id					int PRIMARY KEY, 
		istemplate			bit, 
		ischeckedout		bit, 
		checked_out_by		uniqueidentifier,
		engine_pair_id1		int,
		engine_pair_id2		int
	) 
	
	declare	@failover_pair_table table(
		tag_name					nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS,
		gobject_id					int,
		failover_pair_gobject_id	int
	)

	SET QUOTED_idENTIFIER OFF

	CREATE TABLE  #results_table ( 
		gobject_id		int
	)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	EXEC (@SQL)

	insert into @results_table( 
					id, 
					engine_pair_id1, 
					engine_pair_id2
				)
	( 
		select	distinct
				gobject_id, 
				0, 
				0 
		from	#results_table 
	)

	drop table #results_table

	insert	@failover_pair_table(
					tag_name, 
					gobject_id, 
					failover_pair_gobject_id
				)
	(
		select	g.tag_name, g.gobject_id, 0
		from	@results_table res
		inner join gobject g on g.gobject_id = res.id 
		inner join template_definition t on t.template_definition_id = g.template_definition_id
		where	t.category_id = 3 
			and	g.is_template = 0
	)

	update	f
	set		failover_pair_gobject_id = g.gobject_id
	from	@failover_pair_table f 
	inner join gobject g on f.tag_name = g.tag_name
	where	g.gobject_id <> f.gobject_id

	delete	@failover_pair_table
	where	failover_pair_gobject_id = 0

	delete	res
	from	@results_table res 
	inner join @failover_pair_table f on f.gobject_id = res.id

	insert	@results_table(
				id, 
				engine_pair_id1, 
				engine_pair_id2
			)
	(
		select	gobject_id, 
				gobject_id, 
				failover_pair_gobject_id
		from	@failover_pair_table	
	)

	update	@results_table 
	set		istemplate = gobject.is_template,
			ischeckedout = 
				case when gobject.checked_out_package_id <> 0 then 
					1
				else
					0
				end,
			checked_out_by = gobject.checked_out_by_user_guid
	from	@results_table results_table
	inner join gobject gobject
	on gobject.gobject_id = results_table.id

	select * from @results_table


end
go

