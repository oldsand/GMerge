
-- returns a single visual element description row 
-- for the visual element as seen by the given user
create proc dbo.internal_get_visual_element_description
    @visual_element_id int,
    @user_guid uniqueidentifier
as
begin

    -- get default user if none supplied
    if @user_guid is null or @user_guid = '00000000-0000-0000-0000-000000000000'
        select @user_guid = user_guid 
        from user_profile 
        where user_profile_name= 'SystemEngineer'

    -- get the correct visual element for the given user
    declare @gobject_id int
    declare @package_id int
    declare @mx_primitive_id int

    select 
        @gobject_id = gobject_id,
        @package_id = package_id,
        @mx_primitive_id = mx_primitive_id
    from 
        visual_element_version
    where 
        visual_element_id = @visual_element_id
        and dbo.is_package_visible_to_user( gobject_id, package_id, @user_guid )=1

    select  gobject_id,
            tag_name,
            description,
            primitive_name,
            visual_element_type,
            visual_element_id,            
            visual_element_category,
            inherited_from_visual_element_id,
	    is_thumbnail_dirty
    from internal_visual_element_description_all_packages_view 
    where 
        gobject_id = @gobject_id
        and package_id = @package_id
        and mx_primitive_id = @mx_primitive_id
    order by tag_name, primitive_name
end

go

