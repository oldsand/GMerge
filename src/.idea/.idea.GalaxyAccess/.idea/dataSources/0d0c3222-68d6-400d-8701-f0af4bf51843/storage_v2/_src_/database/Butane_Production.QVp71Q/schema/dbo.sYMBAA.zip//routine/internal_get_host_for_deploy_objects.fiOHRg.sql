CREATE PROCEDURE dbo.internal_get_host_for_deploy_objects
    @FileNameOfIds nvarchar (265)
as
begin

SET NOCOUNT ON        
SET QUOTED_IDENTIFIER OFF

	create table #gobject_ids( gobject_id int )
	
	DECLARE @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #gobject_ids  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
	EXEC (@SQL)

	select distinct hosted_by_gobject_id from #gobject_ids, gobject
	where gobject.gobject_id = #gobject_ids.gobject_id
	and gobject.hosted_by_gobject_id not in ( select gobject_id from #gobject_ids )

    -- cleanup
    drop table #gobject_ids

    
end
go

