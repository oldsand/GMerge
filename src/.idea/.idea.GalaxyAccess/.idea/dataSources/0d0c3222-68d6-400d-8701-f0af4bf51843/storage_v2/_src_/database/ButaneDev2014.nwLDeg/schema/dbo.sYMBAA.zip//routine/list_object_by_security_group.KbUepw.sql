create proc dbo.list_object_by_security_group
@sec_grp_name nvarchar(256)
as
set nocount on
begin
--#deployed_pend will store has_pending_update as 1 if object is deployed and pending update stat
create table #deployed_pend (gobject_id int, has_pending_update int)
insert into #deployed_pend (gobject_id, has_pending_update)
	select g.gobject_id,
		   0
	from gobject g inner join package p
	on p.security_group = @sec_grp_name and
	p.gobject_id = g.gobject_id and
	g.is_hidden = 0 and
	g.derived_from_gobject_id <> 0 and
	g.checked_in_package_id = p.package_id and
	g.namespace_id <> 2 and g.namespace_id <> 3
	inner join template_idebehavior_link til
	on g.template_definition_id = til.template_definition_id  and
	til.shown_in_security_editor = 1
	
update #deployed_pend	
	set has_pending_update = 1
from #deployed_pend
inner join gobject g
on g.gobject_id = #deployed_pend.gobject_id
inner join package ckp
on ckp.gobject_id = g.gobject_id and
ckp.package_id = g.checked_in_package_id
inner join package deployedp
on deployedp.gobject_id = g.gobject_id and
deployedp.package_id = g.deployed_package_id
where deployedp.deployable_configuration_version <> ckp.deployable_configuration_version
select	g.tag_name,
		g.gobject_id,
		g.deployed_package_id,
		g.checked_in_package_id,
		dp.has_pending_update
from gobject g inner join #deployed_pend dp
on dp.gobject_id = g.gobject_id

drop table #deployed_pend
end

go

