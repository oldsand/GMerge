/*
This procedure will get called at the time of undeployment operation to set
the deployed_package_id for the provided gobject [used for rollback]
*/
create   proc dbo.internal_update_deployed_package_id
	@gobject_id int,
	@deployed_package_id int
as
begin
set nocount on
begin tran
	if ( @deployed_package_id = 0)
	begin
		update gobject set deployed_package_id = 0,
		software_upgrade_needed = 0, deployment_pending_status = 0  
		where (gobject_id = @gobject_id 
	and is_template = 0 )
	end
	else
	begin
		update gobject set deployed_package_id = @deployed_package_id, deployment_pending_status = 0  
		where (gobject_id = @gobject_id and is_template = 0 )
	end
commit tran

end
go

