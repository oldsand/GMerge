create trigger trigger_delete_folder
    on folder
    for delete
as
    set nocount on
if not exists(select 1 from deleted)
begin
    return
end
begin tran

	
        update folder 
        set has_folders = 0
        from folder f inner join deleted d
        on f.folder_id = d.parent_folder_id
        where f.folder_id not in  
        (
			select f.parent_folder_id 
			from folder f 
			inner join
			deleted d 
			on f.folder_type = d.folder_type            
		)
        
		insert into deleted_ids
		(
			table_id,
			deleted_id,
			deletion_time
		)
		select
			lt.table_id,
			d.folder_id,
			getdate()
		from deleted d
		inner join lookup_table_name lt
		on lt.table_name = 'folder'

        update galaxy
        set max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 


commit

go

