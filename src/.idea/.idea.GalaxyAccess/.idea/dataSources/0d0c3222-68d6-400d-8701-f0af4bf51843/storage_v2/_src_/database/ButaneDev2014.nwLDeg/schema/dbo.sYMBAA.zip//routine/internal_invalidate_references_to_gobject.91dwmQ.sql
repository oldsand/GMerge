-- Unassigns gobject @gobject_id from its host.
create proc dbo.internal_invalidate_references_to_gobject
    @gobject_id int
as
begin

    -- invalidate all reference to that instance
    update attribute_reference 
    set 
        is_valid = 0,
        resolved_gobject_id = 0,
        resolved_mx_primitive_id = 0,
        resolved_mx_attribute_id = 0,
        resolved_mx_property_id = 0
    where resolved_gobject_id = @gobject_id
end
go

