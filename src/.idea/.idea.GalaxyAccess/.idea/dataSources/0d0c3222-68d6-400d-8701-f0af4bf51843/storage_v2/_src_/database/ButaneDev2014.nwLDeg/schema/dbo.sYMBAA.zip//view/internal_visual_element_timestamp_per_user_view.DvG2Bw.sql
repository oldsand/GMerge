create view dbo.internal_visual_element_timestamp_per_user_view
as
select 
    v.gobject_id,
    v.package_id, 
    v.mx_primitive_id,
    v.visual_element_id, 
	vet.change_type,
	vet.timestamp_of_last_change,
	up.user_guid
from
	internal_visual_element_description_view v (noexpand)
inner join visual_element_timestamp vet on
	v.gobject_id = vet.gobject_id and
	v.package_id = vet.package_id and 
	v.mx_primitive_id = vet.mx_primitive_id
inner join gobject g on
	v.gobject_id = g.gobject_id
inner join dbo.user_profile up
    on g.checked_out_by_user_guid is null and v.package_id = g.checked_in_package_id
    or (g.checked_out_by_user_guid  = up.user_guid and v.package_type = 'O')
    or (g.checked_out_by_user_guid  <> up.user_guid and v.package_id = g.checked_in_package_id)

go

