create proc dbo.internal_group_gobjects_by_platform
@FileNameOfIds		NVARCHAR( 400 ),
	@operation_type smallint
AS
begin tran
	set nocount on
	
	create table #gobject_ids
	(
		gobject_id	int primary key
	)

	EXEC internal_construct_table_from_file @FileNameOfIds, '#gobject_ids'

	create table #deployOrder(gobject_id int primary key ,mx_platform_id int, mx_engine_id int)
	
	if(@operation_type = 0 )
	begin
		insert into #deployOrder 
		select	obj.gobject_id,ins.mx_platform_id,ins.mx_engine_id			
		from	instance ins
			inner join	#gobject_ids	obj
			on	obj.gobject_id = ins.gobject_id
			inner join	gobject g
			on	g.gobject_id = ins.gobject_id							
		where g.deployed_package_id > 0
		order by ins.mx_platform_id,ins.mx_engine_id,ins.mx_object_id
	end
	else
	begin
		insert into #deployOrder 
		select	obj.gobject_id,ins.mx_platform_id,ins.mx_engine_id			
		from	instance ins
			inner join	#gobject_ids	obj
			on	obj.gobject_id = ins.gobject_id		
		order by ins.mx_platform_id,ins.mx_engine_id,ins.mx_object_id

	end




	-- For Debugging
----	 select * from #deployOrder
	
	-- In MTD, if the Redundant enabled engines are in Partially deployed state,
	-- then we need to Deploy/Undeploy/[Re-Deploy/DepolyChanges] in the same thread.
	-- Hence we update the mx_platform_id of such partially deployed engines to be same 
	-- such that the Primary and Back-up Engines are grouped together and deployed/undeployed
    -- in the same thread. The updation of the mx_platform_id is done in 3 steps.
	
	-- The below logic involves 3 steps and is applicable for MTD 
	
	-- 1.	Select all the back Up engines in the List of the Object IDs	  
	
	-- 2.	Select all the Back up Engines which are in Partially Deployed state from the list of 
	--		engines obtained from step 1. 
	
	-- 3.	Update the Platform ID of the Partially Deployed Engines
	--		such that in Multi Threaded Deployment environment, the Primary and the Back up
	--		Engines are being deployed in the same thread. 

	-- Select all the back Up engines in the List of the Object IDs. 
	-- which are partial deployed

	declare @backupEngines table(
	gobject_id int primary key,
	primary_gobject_id int,
	partial_deployed int,
	partner_selected int,	
	backup_mx_platform_id int,
	primary_mx_platform_id int, 
	primary_mx_engine_id int
	)

	insert into @backupEngines 
	select 
		gi.gobject_id, 	
		dbo.get_failover_partner_id(gi.gobject_id),	
	CASE WHEN (
		g.deployed_package_id <> 0 
		and (dbo.is_partner_deployed(g.gobject_id) = 0) )
		then 1 else 0 end,
		0,
		i.mx_platform_id,
		0,
		0	
	from #gobject_ids gi 
		inner join gobject g on gi.gobject_id = g.gobject_id		
		inner join instance i on i.gobject_id = gi.gobject_id
	where g.namespace_id = 2
	
--select * from @backupEngines

	update @backupEngines
	set partner_selected = 1
	from @backupEngines be inner join #gobject_ids gi
		on be.primary_gobject_id = gi.gobject_id	
	
--select * from @backupEngines

	update @backupEngines
	set 
		primary_mx_platform_id = i.mx_platform_id,
		primary_mx_engine_id = i.mx_engine_id
	from @backupEngines be inner join instance i
		on i.gobject_id = be.primary_gobject_id 

--	select * from @backupEngines


	if exists(select gobject_id from @backupEngines)
	begin
		update #deployOrder 
			set mx_platform_id = be.backup_mx_platform_id
		from #deployOrder
		inner join instance i on 
			#deployOrder.gobject_id = i.gobject_id
		inner join @backupEngines be
		on 
				i.mx_platform_id = be.primary_mx_platform_id
			and 
				i.mx_engine_id = be.primary_mx_engine_id
			and 
				(be.partial_deployed = 1
				or
				be.partner_selected = 0)
		where
			i.mx_object_id <> 1	
			--it implies it is not platform
	end
	
	-- select * from #deployOrder
	if(@operation_type = 1)
	begin
		SELECT	mx_platform_id,			
				gobject_id
		from #deployOrder 
			order by mx_platform_id asc,mx_engine_id asc,
					gobject_id asc
		
	end
	else
	begin
			SELECT	mx_platform_id,			
					gobject_id
			from #deployOrder 
				order by mx_platform_id desc,mx_engine_id asc,
							gobject_id asc
	end
	-- For Debugging...
--		SELECT	do.mx_platform_id,			
--				do.gobject_id,
--				g.tag_name
--		from #deployOrder 
--		do
--		inner join gobject g
--		on g.gobject_id = do.gobject_id
--		order by mx_platform_id asc,
--    			 mx_engine_id asc,
--			     gobject_id asc
		
	DROP TABLE #gobject_ids

commit tran
go

