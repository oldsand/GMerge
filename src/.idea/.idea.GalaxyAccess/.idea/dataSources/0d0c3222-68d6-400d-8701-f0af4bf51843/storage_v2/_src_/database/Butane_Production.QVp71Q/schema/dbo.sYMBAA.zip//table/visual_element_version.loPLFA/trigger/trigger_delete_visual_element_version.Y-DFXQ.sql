create trigger trigger_delete_visual_element_version
    on visual_element_version
    for delete
as
    set nocount on
if not exists(select 1 from deleted)
begin
    return
end

begin tran

declare @visual_elements_that_no_longer_exist table(visual_element_id int,gobject_id int,package_id int,mx_primitive_id int)
-- first, get a list of all visual elements that are no longer referenced in this table
-- these are the visual_elements that we will work with in this trigger...
insert into @visual_elements_that_no_longer_exist
select d.visual_element_id,d.gobject_id,d.package_id,d.mx_primitive_id
from   deleted d
where  d.visual_element_id in
       (select visual_element_id from deleted where visual_element_id
          not in
          (select visual_element_id from visual_element_version)
        )

-- update the max_child_timestamp of any
-- object that references this visual element.....
declare @new_timestamp bigint
exec internal_get_next_timestamp @new_timestamp out

-- update the parents of the deleted visual_elements..
declare @update_count int
set @update_count = 0

if exists
    ( 
        select 1
        from visual_element_reference b
        inner join @visual_elements_that_no_longer_exist bound_vev on
        (b.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
         b.checked_in_bound_visual_element_package_id = bound_vev.package_id and
         b.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id)
        inner join primitive_instance pri on 
        b.gobject_id = pri.gobject_id and 
        b.package_id = pri.package_id and
        b.mx_primitive_id = pri.mx_primitive_id
	)
begin
    update pri
    set max_child_timestamp = @new_timestamp
    from visual_element_reference b
    inner join @visual_elements_that_no_longer_exist bound_vev on
        (b.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
         b.checked_in_bound_visual_element_package_id = bound_vev.package_id and
         b.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id)
    inner join primitive_instance pri on 
        b.gobject_id = pri.gobject_id and 
        b.package_id = pri.package_id and
        b.mx_primitive_id = pri.mx_primitive_id

    set @update_count = @@rowcount
end

if exists
    ( 
        select 1
        from visual_element_reference b
        inner join @visual_elements_that_no_longer_exist bound_vev on
        (b.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
        b.checked_out_bound_visual_element_package_id = bound_vev.package_id and
        b.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id)
        inner join primitive_instance pri on 
        b.gobject_id = pri.gobject_id and 
        b.package_id = pri.package_id and
        b.mx_primitive_id = pri.mx_primitive_id
	)
begin
    update pri
    set max_child_timestamp = @new_timestamp
    from visual_element_reference b
    inner join @visual_elements_that_no_longer_exist bound_vev on
        (b.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
         b.checked_out_bound_visual_element_package_id = bound_vev.package_id and
         b.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id)
    inner join primitive_instance pri on 
        b.gobject_id = pri.gobject_id and 
        b.package_id = pri.package_id and
        b.mx_primitive_id = pri.mx_primitive_id

    set @update_count = @update_count + @@rowcount
end
    
if (@update_count > 0)
begin
    exec internal_update_max_child_timestamp
end
----------------------------------------------------------
-- unbind visual elements...

	-- Create a table variable to store the affected objects.
	-- This will be used to update proxy timestamps...
	declare @all_affected_objects table(gobject_id int) 

    declare @affected_checked_in_bound_elements table
    (
		gobject_id int not null,
		package_id int not null,
		mx_primitive_id smallint not null,    
		visual_element_reference_index int not null,

		is_relative_reference bit not null,
		checked_in_unbound_visual_element_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_in_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_in_unbound_tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS ,
		checked_in_unbound_primitive_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS null,
		checked_in_unbound_relative_object_name nvarchar (329) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		checked_in_unbound_visual_element_id int null
	)

    declare @affected_checked_out_bound_elements table
    (
		gobject_id int not null,
		package_id int not null,
		mx_primitive_id smallint not null,    
		visual_element_reference_index int not null,
		--visual_element_bind_status char (1) not null,-- now a calculated column..
		is_relative_reference bit not null,
		checked_out_unbound_visual_element_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_out_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
		checked_out_unbound_tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS ,
		checked_out_unbound_primitive_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS null,
		checked_out_unbound_relative_object_name nvarchar (329)  COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		checked_out_unbound_visual_element_id int null
	)



-- first, unbind any checked-in visual_elements...

insert into @affected_checked_in_bound_elements
    (gobject_id,
    package_id,
    mx_primitive_id,
    visual_element_reference_index,

    is_relative_reference,
    checked_in_unbound_visual_element_name ,
    checked_in_unbound_visual_element_type ,
    checked_in_unbound_tag_name  ,
    checked_in_unbound_primitive_name ,
    checked_in_unbound_relative_object_name,
    checked_in_unbound_visual_element_id)
    select 
    b.gobject_id,
    b.package_id,
    b.mx_primitive_id,
    b.visual_element_reference_index,

    b.is_relative_reference,
    case when ver.is_relative_reference = 0 then    
        case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name 
        else g.tag_name 
        end
    else
		case when(len(g.hierarchical_name) > len(gme.hierarchical_name)) then
        'me'+ right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name)) )  +   '.' + pri.primitive_name
		else
			null
		end
    end,
    v.visual_element_type,
    g.tag_name,
    pri.primitive_name,
    case when ver.is_relative_reference = 1 then    
	case when(len(g.hierarchical_name) > len(gme.hierarchical_name)) then
        	right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name) -1))
	    else
        	null
	    end
    else 
        null
    end,
    d.visual_element_id
    from deleted d 
    inner join visual_element_reference b on     
        b.checked_in_bound_visual_element_gobject_id = d.gobject_id and
        b.checked_in_bound_visual_element_package_id = d.package_id and
        b.checked_in_bound_visual_element_mx_primitive_id = d.mx_primitive_id and
        b.checked_in_bound_visual_element_package_id = d.package_id 
    inner join visual_element v on d.visual_element_id = v.visual_element_id 
    inner join primitive_instance pri on pri.gobject_id = d.gobject_id and
        pri.package_id = d.package_id and 
        pri.mx_primitive_id = d.mx_primitive_id
    inner join gobject g on 
        g.gobject_id = d.gobject_id 
    inner join visual_element_reference ver on 
        b.gobject_id = ver.gobject_id and
        b.package_id = ver.package_id and
        b.mx_primitive_id = ver.mx_primitive_id and
        b.visual_element_reference_index = ver.visual_element_reference_index
    inner join gobject gme on ver.gobject_id = gme.gobject_id         


    --update the checked_in_unbound ver columns....
    update  ver
    set -- unbound columns...
        ver.checked_in_unbound_visual_element_name = wt.checked_in_unbound_visual_element_name,
        ver.checked_in_unbound_visual_element_type = wt.checked_in_unbound_visual_element_type,
        ver.checked_in_unbound_tag_name = wt.checked_in_unbound_tag_name,
        ver.checked_in_unbound_primitive_name = wt.checked_in_unbound_primitive_name,
        ver.checked_in_unbound_relative_object_name = wt.checked_in_unbound_relative_object_name,

        ver.checked_in_unbound_visual_element_id = wt.checked_in_unbound_visual_element_id,
        -- bound columns....
        ver.checked_in_bound_visual_element_gobject_id = null,
        ver.checked_in_bound_visual_element_package_id = null,
        ver.checked_in_bound_visual_element_mx_primitive_id = null
	output inserted.gobject_id
	into @all_affected_objects
    from visual_element_reference ver 
    inner join @affected_checked_in_bound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index



-- next, unbind any checked_out visual_elements...
insert into @affected_checked_out_bound_elements
    (gobject_id,
    package_id,
    mx_primitive_id,
    visual_element_reference_index,

    is_relative_reference,
    checked_out_unbound_visual_element_name ,
    checked_out_unbound_visual_element_type ,
    checked_out_unbound_tag_name  ,
    checked_out_unbound_primitive_name ,
    checked_out_unbound_relative_object_name,
    checked_out_unbound_visual_element_id)
    select 
    b.gobject_id,
    b.package_id,
    b.mx_primitive_id,
    b.visual_element_reference_index,
--    0,
    b.is_relative_reference,
    case when ver.is_relative_reference = 0 then    
        case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name 
        else g.tag_name 
        end
    else
     	case when(len(g.hierarchical_name) > len(gme.hierarchical_name)) then
			'me'+ right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name)) )  +   '.' + pri.primitive_name
		else
			null
		end
    end,
    v.visual_element_type,
    g.tag_name,
    pri.primitive_name,
    case when ver.is_relative_reference = 1 then    
	case when(len(g.hierarchical_name) > len(gme.hierarchical_name)) then
        	right(g.hierarchical_name,(len(g.hierarchical_name)- len(gme.hierarchical_name) -1))
	    else
        	null
	    end
    else 
        null
    end,
    d.visual_element_id
    from deleted d 
    inner join visual_element_reference b on     
        b.checked_out_bound_visual_element_gobject_id = d.gobject_id and
        b.checked_out_bound_visual_element_package_id = d.package_id and
        b.checked_out_bound_visual_element_mx_primitive_id = d.mx_primitive_id 
    inner join visual_element v on d.visual_element_id = v.visual_element_id
    inner join primitive_instance pri on pri.gobject_id = d.gobject_id and
        pri.package_id = d.package_id and 
        pri.mx_primitive_id = d.mx_primitive_id
    inner join gobject g on 
        g.gobject_id = d.gobject_id 
    inner join package p on
	d.gobject_id = p.gobject_id and
	p.package_id = d.package_id and
	p.package_type = 'O'
    inner join visual_element_reference ver on 
        b.gobject_id = ver.gobject_id and
        b.package_id = ver.package_id and
        b.mx_primitive_id = ver.mx_primitive_id and
        b.visual_element_reference_index = ver.visual_element_reference_index
    inner join gobject gme on ver.gobject_id = gme.gobject_id 

    --update the checked_out_unbound ver columns....
    update  ver
    set -- unbound columns...
        ver.checked_out_unbound_visual_element_name = wt.checked_out_unbound_visual_element_name,
        ver.checked_out_unbound_visual_element_type = wt.checked_out_unbound_visual_element_type,
        ver.checked_out_unbound_tag_name = wt.checked_out_unbound_tag_name,
        ver.checked_out_unbound_primitive_name = wt.checked_out_unbound_primitive_name,
        ver.checked_out_unbound_relative_object_name = wt.checked_out_unbound_relative_object_name,

        ver.checked_out_unbound_visual_element_id = wt.checked_out_unbound_visual_element_id,
        -- bound columns....
        ver.checked_out_bound_visual_element_gobject_id = null,
        ver.checked_out_bound_visual_element_package_id = null,
        ver.checked_out_bound_visual_element_mx_primitive_id = null
	output inserted.gobject_id
	into @all_affected_objects
    from visual_element_reference ver 
    inner join @affected_checked_out_bound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index



----- finished with unbinding visual_element references...
    
     --  try to bind any VERs that may be affected by the check-in operation....
    declare @affected_checked_in_unbound_elements table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        checked_in_bound_visual_element_gobject_id int not null,
        checked_in_bound_visual_element_package_id int not null,
        checked_in_bound_visual_element_mx_primitive_id smallint not null
    )
    

    -- note: The two insert queries below could simply
    --       be a single query with an "or" for the finela 
    --       join conditions, but SQL server wasn't optimizing
    --       properly so I was forced to split the query.
    --
    --       If you decide to join the queries back together,
    --       make sure you end up with a good query plan.
    insert into @affected_checked_in_unbound_elements
    (gobject_id,
    package_id,
    mx_primitive_id ,
    visual_element_reference_index ,
    checked_in_bound_visual_element_gobject_id ,
    checked_in_bound_visual_element_package_id ,
    checked_in_bound_visual_element_mx_primitive_id )    
    select 
        u.gobject_id,
        u.package_id,
        u.mx_primitive_id,
        u.visual_element_reference_index,
        v.gobject_id ,
        v.package_id ,
        v.mx_primitive_id
    from deleted d
    inner join gobject g on 
        g.gobject_id = d.gobject_id
    inner join internal_visual_element_description_view v (noexpand) on
        v.gobject_id = d.gobject_id
        and v.package_id = g.checked_in_package_id
    inner join visual_element_reference u on
          u.checked_in_unbound_visual_element_id   = v.visual_element_id 

    insert into @affected_checked_in_unbound_elements
        (gobject_id,
        package_id,
        mx_primitive_id ,
        visual_element_reference_index ,
        checked_in_bound_visual_element_gobject_id ,
        checked_in_bound_visual_element_package_id ,
        checked_in_bound_visual_element_mx_primitive_id )    
    select 
        u.gobject_id,
        u.package_id,
        u.mx_primitive_id,
        u.visual_element_reference_index,
        v.gobject_id ,
        v.package_id ,
        v.mx_primitive_id
    from deleted d
    inner join gobject g on 
        g.gobject_id = d.gobject_id
    inner join internal_visual_element_description_view v (noexpand) on
        v.gobject_id = d.gobject_id
        and v.package_id = g.checked_in_package_id
    inner join visual_element_reference u on
        u.checked_in_unbound_visual_element_name = v.visual_element_name
         and u.checked_in_unbound_visual_element_type = v.visual_element_type 
    where not exists( 
        select 1 
        from @affected_checked_in_unbound_elements ub
        where 
            ub.gobject_id = u.gobject_id
            and ub.package_id = u.package_id
            and ub.mx_primitive_id = u.mx_primitive_id
            and ub.visual_element_reference_index = u.visual_element_reference_index )

    if exists ( select 1 from @affected_checked_in_unbound_elements )
    begin
        --update the checked_in_bound ver columns....
    update  ver
    set 
        -- bound columns...
        ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
        ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
        ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,

        -- unbound columns...
        ver.checked_in_unbound_visual_element_name = null,
        ver.checked_in_unbound_visual_element_type = null,
        ver.checked_in_unbound_tag_name = null,
        ver.checked_in_unbound_primitive_name = null,
        ver.checked_in_unbound_relative_object_name = null,
        ver.checked_in_unbound_visual_element_id = null
	output inserted.gobject_id
	into @all_affected_objects
    from visual_element_reference ver 
    inner join @affected_checked_in_unbound_elements wt on
        wt.gobject_id = ver.gobject_id and
        wt.package_id = ver.package_id and
        wt.mx_primitive_id = ver.mx_primitive_id and
        wt.visual_element_reference_index = ver.visual_element_reference_index
    end


--    place deleted visual_element names in table 
--    this is done for InTouchViewApp re-deployment

    
 if exists(select '*' from deployed_intouch_viewapp)
    begin
        insert into deleted_visual_element(visual_element_name)    

        select     
            case when pri.primitive_name <> '' 
                then g.tag_name + '.' + pri.primitive_name 
                else g.tag_name 
            end

        from @visual_elements_that_no_longer_exist d 
        inner join primitive_instance pri on 
            pri.gobject_id = d.gobject_id and
            pri.package_id = d.package_id and 
            pri.mx_primitive_id = d.mx_primitive_id
        inner join gobject g on 
            g.gobject_id = d.gobject_id 
    end


  delete from 
    visual_element 
  where visual_element_id in (select visual_element_id from @visual_elements_that_no_longer_exist)

	if exists(select '1' from @all_affected_objects)
	begin
			declare @distinct_affected_objects table(gobject_id int primary key)

			insert into @distinct_affected_objects
			select distinct gobject_id
			from @all_affected_objects

			update pt
			set pt.gobject_id = pt.gobject_id
			from proxy_timestamp pt
			inner join @distinct_affected_objects dao on
				pt.gobject_id = dao.gobject_id 

			update gfi
			set gfi.gobject_id = gfi.gobject_id
			from gobject_filter_info_timestamp gfi
			inner join @distinct_affected_objects dao on
				gfi.gobject_id = dao.gobject_id 


			declare @max_proxy_timestamp bigint
			select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

			update galaxy
			set max_proxy_timestamp = @max_proxy_timestamp
	end    
    

commit

go

