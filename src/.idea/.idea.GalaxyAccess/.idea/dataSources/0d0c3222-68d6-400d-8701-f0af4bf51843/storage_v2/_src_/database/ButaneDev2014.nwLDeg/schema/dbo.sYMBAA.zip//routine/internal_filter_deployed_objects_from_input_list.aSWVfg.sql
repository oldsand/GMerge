create proc dbo.internal_filter_deployed_objects_from_input_list
as 
begin
	delete #childList
	from #childList cl
	inner join gobject g
	on cl.gid = g.gobject_id
	where g.deployed_package_id <> 0
end
go

