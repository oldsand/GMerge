/*********************************************************/
/*Object Name :  internal_get_platform_count               */
/*Object Type :  Stored Proc.                            */
/*Purpose	  :  Procedure to Get the count of Platforms */
/*Used By	  :  CDI()                                   */
/*********************************************************/
create procedure dbo.internal_get_platform_count
@nPlatforms int out 
AS
begin
    set @nPlatforms = (select count (*) from instance where mx_engine_id = 1 and mx_object_id = 1)
end
go

