CREATE proc dbo.internal_save_gobject 
@xmlschema ntext,
@dynamicattributefile nvarchar(255),
@dynamicattributefileisempty int,
@xmlrefschema ntext
as 
begin tran
	set nocount on
	declare @h int
	declare @status_id smallint
	execute sp_xml_preparedocument @h output,@xmlschema

	-- find out if this is a template
	declare @isTemplate nvarchar(32)
	declare @gobjectid  int
	declare @package_id integer
	declare @checked_in_pkg_id int
	declare @deploy_pkg_id int
	declare @last_deploy_pkg_id int
	declare @deployversion int
	declare @configversion int
	declare @sec_group nvarchar(32)
	declare @bFor_GobjectOnly int
    declare @reference_status int

	set @gobjectid = 0
	set @isTemplate = 0
	set @package_id = 0
	set @status_id = 0
	set @reference_status = 0
	set @checked_in_pkg_id = 0
	set @deploy_pkg_id = 0
	set @last_deploy_pkg_id = 0
	set @deployversion = 0
	set @configversion = 0
	set @bFor_GobjectOnly = -1

	select	@gobjectid = o.id,@isTemplate = o.is_template,
			@package_id = o.package_id,
			@status_id = o.status_id,
			@reference_status = o.reference_status_id,
			@checked_in_pkg_id = o.checked_in_package_id,
			@deploy_pkg_id = o.deployed_package_id,
			@last_deploy_pkg_id = o.last_deployed_package_id,
			@deployversion = o.deploy_version,
			@configversion = o.config_version,
			@sec_group = o.sec_group,
			@bFor_GobjectOnly = o.bFor_GobjectOnly
	from openxml (@h,'/ROOT/gObject',1)
	with ( id int './@id',
		 is_template nvarchar(32) './@is_template',
		 package_id int './@package_id',
		 status_id int './@status_id',
		 reference_status_id int './@reference_status_id',
		 checked_in_package_id int './@checked_in_package_id',
		 deployed_package_id int './@deployed_package_id',
		 last_deployed_package_id int './@last_deployed_package_id',
		 deploy_version int './@deploy_version',
		 config_version int './@config_version',
		 sec_group nvarchar(32) './@sec_grp',
		 bFor_GobjectOnly int './@bFor_GobjectOnly' ) o

--UPDATE PACKAGE TABLE
declare @blobTable table( blobValue image )
insert into @blobTable select o.Attribute_Values from openxml (@h,'/ROOT/gObject',1) with (Attribute_Values image './Attribute_Values') o 
--	( select o.Attribute_Values from openxml (@h,'/ROOT/gObject',1) with (Attribute_Values text './Attribute_Values') o    )

update package 
set 
	status_id = @status_id,
	reference_status_id = @reference_status,
	security_group = @sec_group
from package, @blobTable
where package_id = @package_id


-- update the configuration_guid of the gobject everytime there is a save happening on this

	update	gobject 
	set		gobject.configuration_guid = NewId(),
	        gobject.checked_in_package_id = @checked_in_pkg_id
	from	gobject 
	where	gobject.gobject_id = @gobjectid


  if( @deploy_pkg_id > 0 )
    update gobject set gobject.deployed_package_id = @deploy_pkg_id from gobject where gobject.gobject_id = @gobjectid

  if( @last_deploy_pkg_id > 0 )
    update gobject set gobject.last_deployed_package_id = @last_deploy_pkg_id from gobject where gobject.gobject_id = @gobjectid

  if( @deployversion <> 0 )
    update gobject set gobject.deployed_version = @deployversion from gobject where gobject.gobject_id = @gobjectid

  if( @configversion <> 0 )
    update gobject set gobject.configuration_version = @configversion from gobject where gobject.gobject_id = @gobjectid


if (@bFor_GobjectOnly = 1)
	begin
	EXECUTE sp_xml_removedocument @h
	
	return -- returns Because user just wants to save GOBJECT. This is called at Deploy operation
	end



-- Primitive Instance Table
  declare @prim_inst table
  (
	gobject_id int,
    package_id int,
    mx_primitive_id smallint,
    primitive_definition_id int,
    primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    parent_mx_primitive_id int,
    execution_group int,
    execution_order int,
	owned_by_gobject_id int,
	extension_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	is_object_extension bit,
	checked_in_primitive_version int,
	checked_out_primitive_version int
   )

   insert into @prim_inst 
   select	@gobjectid,
			o.package_id,
			o.mx_primitive_id,
			o.primitive_definition_id,
			o.primitive_name,
			o.parent_mx_primitive_id,
			o.execution_group,
			o.execution_order,
			o.owned_by_gobject_id,
			o.extension_type,
			o.is_object_extension,
			o.checked_in_primitive_version,
			o.checked_out_primitive_version
   from openxml (@h,'/ROOT/gObject/Primitive_Inst',1) 
   with (  package_id int './../@package_id',
	       mx_primitive_id smallint './@mx_primitive_id',
	       primitive_definition_id int './@primitive_definition_id',
	       primitive_name nvarchar(329) './@primitive_name',
	       parent_mx_primitive_id int './@parent_mx_primitive_id',
	       execution_group int './@execution_group',
	       execution_order int './@execution_order',
		   owned_by_gobject_id int './@owned_by_gobject_id',
		   extension_type nvarchar(329) './@extension_type',
		   is_object_extension bit './@is_object_extension',
		   checked_in_primitive_version int './@checked_in_primitive_version',
		   checked_out_primitive_version int './@checked_out_primitive_version') o

-- delete the primitive_instance table
  delete from primitive_instance  
  where gobject_id = @gobjectid and package_id = @package_id 
   
   -- Insert Into Primitive Instance Table
  insert into primitive_instance (
					gobject_id,
					package_id,
					mx_primitive_id,
					primitive_definition_id,
					primitive_name,
					parent_mx_primitive_id,
					execution_group,
					execution_order,
					owned_by_gobject_id,
					extension_type,
					is_object_extension,
					checked_in_primitive_version,
					checked_out_primitive_version)
	select	@gobjectid,o.package_id,
			o.mx_primitive_id,
			o.primitive_definition_id,
			o.primitive_name,
			o.parent_mx_primitive_id,
			o.execution_group,
			o.execution_order, 
			o.owned_by_gobject_id,
			o.extension_type,
			o.is_object_extension,
			o.checked_in_primitive_version,
			o.checked_out_primitive_version
	from	@prim_inst o 



   -- Attribute Template Table
   if ( @isTemplate = 'True' )
      begin

	   declare @attr_template table
	   (
             mx_primitive_id			smallint,
			 mx_attribute_id			smallint,
			 security_classification	int,
			 mx_data_type				int,
			 mx_value					text,
			 lock_type					int,
			 original_lock_type			int
	   )
	
	   insert into @attr_template 
	   select	o.mx_primitive_id,
				o.mx_attribute_id,
				o.security_classification,
				o.mx_data_type,
				o.mx_value,
				o.lock_type,
				o.original_lock_type
	   from openxml (@h,'/ROOT/gObject/Primitive_Inst/Attribute',1)
	   with ( mx_primitive_id smallint './../@mx_primitive_id' ,
			  mx_attribute_id smallint './@mx_attribute_id',
	          security_classification int './@security_classification',
	          mx_data_type int './@mx_data_type',
	          mx_value  text './mx_value',
	          lock_type int './@lock_type',
	          original_lock_type int './@original_lock_type' ) o

       delete from template_attribute  where gobject_id = @gobjectid and package_id =  @package_id 
           
       insert into template_attribute ( 
							gobject_id,package_id,mx_primitive_id,
							mx_attribute_id,
							security_classification,
							mx_data_type,
							mx_value,
							lock_type,
							original_lock_type)
				select	@gobjectid,@package_id,a_Temp.mx_primitive_id,
						a_Temp.mx_attribute_id,
						a_Temp.security_classification,
						a_Temp.mx_data_type,
						a_Temp.mx_value,
						a_Temp.lock_type,
						a_Temp.original_lock_type
				from	@attr_template a_Temp
      end
   else if  ( @isTemplate = 'False' )
     begin

		 delete from attribute_reference where gobject_id = @gobjectid and package_id = @package_id
 		 declare @hRefXML int
		 execute sp_xml_preparedocument @hRefXML output,@xmlrefschema
		 declare @attr_reference_inst table
		 (
			gobject_id   int,
			package_id   int,
			referring_mx_primitive_id smallint,
			referring_mx_attribute_id smallint,
			element_index             smallint,
			dest_object_name          nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS ,
			resolved_gobject_id       int,
			reference_string          nvarchar(700) COLLATE SQL_Latin1_General_CP1_CI_AS,
			context_string            nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
			object_signature          int,
			resolved_mx_primitive_id  smallint,
			resolved_mx_attribute_id  smallint,
			resolved_mx_property_id   smallint,
			attribute_signature       int,
			lock_type                 int,
			attr_res_status           int,
			attribute_index           smallint,
			is_valid				  bit			 
		 )
		 
		 insert   into   @attr_reference_inst
		          select o.gobject_id,
				         o.package_id,
						 o.referring_mx_primitive_id,
						 o.referring_mx_attribute_id,
						 o.element_index,
						 o.dest_object_name,
						 0,
						 o.reference_string,
						 o.context_string,
						 o.object_signature,
						 o.resolved_mx_primitive_id,
						 o.resolved_mx_attribute_id,
						 o.resolved_mx_property_id,
						 o.attribute_signature,
						 o.lock_type,
						 o.attr_res_status,
						 o.attr_index,
						 o.is_dirty
                  from   openxml (@hRefXML, '/ROOT/gRef',1 )
				  with ( gobject_id int './@gobject_id',
						 package_id int './@package_id',
						 referring_mx_primitive_id smallint './@refPrimid',
						 referring_mx_attribute_id smallint './@refAttrid',
						 dest_object_name          nvarchar(32) './@destObjName',
						 element_index             smallint './@index',
						 reference_string          nvarchar(700) './@fullreference',
						 context_string            nvarchar(32)  './@context',
						 object_signature          int           './@objsign',
						 resolved_mx_primitive_id  smallint      './@resPrimid',
						 resolved_mx_attribute_id  smallint      './@resAttrid',
						 resolved_mx_property_id   smallint      './@resPropid',
						 attribute_signature       int           './@attrsign',
						 lock_type                 int           './@lock',
						 attr_res_status           int           './@attrResStatus',
						 attr_index                smallint      './@attribute_index',
						 is_dirty                  bit           './@is_dirty' ) o
		EXECUTE sp_xml_removedocument @hRefXML
        
		update attr_ref
		set    resolved_gobject_id = ( select isnull(gobj.gobject_id,0) 
										from gobject gobj
										where gobj.tag_name = attr_ref.dest_object_name and gobj.namespace_id = 1) -- Automation Object
       from @attr_reference_inst attr_ref

		update attr_ref
		set    resolved_gobject_id = 0 
     		from @attr_reference_inst attr_ref
		where attr_ref.resolved_gobject_id is null

	
	   insert into attribute_reference(gobject_id,
									   package_id,
									   referring_mx_primitive_id,
									   referring_mx_attribute_id,
									   element_index,
									   resolved_gobject_id,
									   reference_string,
									   context_string,
									   object_signature,
									   resolved_mx_primitive_id,
									   resolved_mx_attribute_id,
									   resolved_mx_property_id,
									   attribute_signature,
									   lock_type,
									   is_valid,
									   attr_res_status,
									   attribute_index )
               select attr_ref.gobject_id,
			          attr_ref.package_id,
					  attr_ref.referring_mx_primitive_id,
					  attr_ref.referring_mx_attribute_id,
					  attr_ref.element_index,
					  attr_ref.resolved_gobject_id,
					  attr_ref.reference_string,
					  attr_ref.context_string,
					  attr_ref.object_signature,
					  attr_ref.resolved_mx_primitive_id,
					  attr_ref.resolved_mx_attribute_id,
					  attr_ref.resolved_mx_property_id,
					  attr_ref.attribute_signature,
					  attr_ref.lock_type,
					  attr_ref.is_valid,
					  attr_ref.attr_res_status,
					  attr_ref.attribute_index
               from   @attr_reference_inst attr_ref       
	 end



	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #dynamic_attributes_table ( 
		 gobject_id                 int,	
		 package_id					int,
		 mx_attribute_id			smallint,
         mx_primitive_id			smallint,
		 attribute_name				nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
		 mx_data_type				smallint,
		 is_array					bit,
		 security_classification	smallint,
		 mx_attribute_category		int,
		 lock_type					int,
		 mx_value					text,
		 owned_by_gobject_id		int,
		 original_lock_type			int,
          dynamic_attribute_type     smallint,
         bitvalues					smallint
	)

	if (@dynamicattributefileisempty = 0)
	begin
		DECLARE @SQL nvarchar(2000)
		SET @SQL = 'BULK INSERT #dynamic_attributes_table  FROM ''' + @dynamicattributefile+ ''' 
					WITH (FIELDTERMINATOR = '',\t'', TABLOCK, DATAFILETYPE  = ''widechar'') '
		EXEC (@SQL)
	end




	--Delete all the dynamic attributes associated with this packge
	delete from dynamic_attribute where gobject_id = @gobjectid and package_id = @package_id


	--insert the dynamic attributes
	if (@dynamicattributefileisempty = 0)
	begin
		if (exists(select * from #dynamic_attributes_table))
		begin
			insert into dynamic_attribute (
						gobject_id,
						package_id,
						mx_primitive_id,
						mx_attribute_id,
						attribute_name, 
						mx_data_type, 
						is_array, 
						security_classification, 
						mx_attribute_category, 
						lock_type, 
						mx_value, 
						owned_by_gobject_id,
						original_lock_type,
                        			dynamic_attribute_type,
						bitvalues)
			select	dInst.gobject_id,
					dInst.package_id,
					dInst.mx_primitive_id,
					dInst.mx_attribute_id, 
					dInst.attribute_name, 
					dInst.mx_data_type, 
					dInst.is_array, 
					dInst.security_classification, 
					dInst.mx_attribute_category, 
					dInst.lock_type, 
					dInst.mx_value, 
					dInst.owned_by_gobject_id,
					dInst.original_lock_type,
                    			dInst.dynamic_attribute_type,
					dInst.bitvalues
			from	#dynamic_attributes_table dInst
		end
	end

-- END : Update dynamic attributes associated with this package

-- BEGIN : Update features assocaited with this gObject

	declare @pinst_feature table
	(
		 feature_id int,
		 feature_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  ,
		 feature_type nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  ,
		 mx_primitive_id int,
 		 package_id int
	)

	--Load all the primitive_instnaces from XML DOM whos feature list needs to be updated
	insert into @pinst_feature
	select *
	from openxml (@h, '/ROOT/gObject/Primitive_Inst/Feature', 1)
	with (	 feature_id int				'./@feature_id',
			 feature_name nvarchar(256)	'./@feature_name',
			 feature_type nvarchar(256)	'./@feature_type',
			 mx_primitive_id int		'./../@mx_primitive_id' ,
	         package_id int				'./../../@package_id' ) o

	----Delete the previous feature associations for this packge
	delete from primitive_instance_feature_link  
		where gobject_id = @gobjectid and package_id = @package_id


	--Insert the new feature associations 
	insert into primitive_instance_feature_link
    (
      gobject_id,
      package_id,
      mx_primitive_id,
      feature_id,
      feature_name,
      feature_type
    )
	select @gobjectid,
		   @package_id,
		   pif.mx_primitive_id, 
		   isnull(f.feature_id,0), 
		   isnull(pif.feature_name,''),
		   isnull(pif.feature_type,'') 
	from @pinst_feature pif
	left outer join feature f --Find the feature_id
		on  pif.feature_name = f.feature_name 
		and pif.feature_type = f.feature_type

-- END : Update features assocaited with this gObject

	drop table #dynamic_attributes_table

EXECUTE sp_xml_removedocument @h


commit tran



go

