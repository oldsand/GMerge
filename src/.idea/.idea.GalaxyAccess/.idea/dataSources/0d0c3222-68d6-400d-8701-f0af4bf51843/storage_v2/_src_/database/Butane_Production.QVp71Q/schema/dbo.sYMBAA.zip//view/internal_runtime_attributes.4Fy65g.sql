--
-- This view is used to supply the GalaxyTagDictionary with tagnames 
-- for the InTouch tag browser.
--
create view dbo.internal_runtime_attributes
as
select 
    case when primitive_instance.primitive_name = '' then
        gobject.tag_name + '.' 
        + attribute_definition.attribute_name
        + case when attribute_definition.is_array = 1 then '[]' else '' end
    else
        gobject.tag_name + '.' + primitive_instance.primitive_name + 
        '.' + attribute_definition.attribute_name
    end as full_attribute_name,

    attribute_definition.mx_data_type as datatype,

    isnull(area.tag_name,		
        case when template_definition.category_id = 13 then	-- Category Area
			gobject.tag_name
		else
			 '<UnAssigned>'
		end) as area,

    derived_from.tag_name as template
from 
    gobject
inner join instance 
    on instance.gobject_id = gobject.gobject_id
inner join template_definition
    on template_definition.template_definition_id = gobject.template_definition_id
    and template_definition.runtime_clsid <> '{00000000-0000-0000-0000-000000000000}'
inner join package
    on package.package_id = gobject.checked_in_package_id
inner join primitive_instance 
    on primitive_instance.package_id = package.package_id
inner join attribute_definition
    on primitive_instance.primitive_definition_id = attribute_definition.primitive_definition_id
    and attribute_definition.attribute_name not like '[_]%'
    and attribute_definition.mx_attribute_category IN (2,3,4,5,6,7,8,9,10,11,24) -- runtime readable
inner join gobject derived_from
    on derived_from.gobject_id = gobject.derived_from_gobject_id
left join gobject area
    on area.gobject_id = gobject.area_gobject_id
go

