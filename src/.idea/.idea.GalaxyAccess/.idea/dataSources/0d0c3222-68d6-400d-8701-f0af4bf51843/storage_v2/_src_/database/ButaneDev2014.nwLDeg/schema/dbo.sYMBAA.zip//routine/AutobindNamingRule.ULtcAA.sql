CREATE FUNCTION dbo.AutobindNamingRule (@dio_id int, @sg_mx_primitive_id smallint)
RETURNS @namingRules TABLE (
    io_type NCHAR(1) PRIMARY KEY,
    rule_id INT,
    naming_rule NVARCHAR (512)
) AS 
BEGIN
    DECLARE @io_types TABLE (io_type NCHAR(1))
    INSERT INTO @io_types VALUES (N'I'), (N'O')

	INSERT INTO @namingRules
    SELECT iot.io_type,
           ISNULL (dio_topic_spec.rule_id,
               ISNULL (dio_spec.rule_id,
                   ISNULL (dio_templ_spec.rule_id,
                       ISNULL (dio_cat_spec.rule_id, 0)))),
           ISNULL (dio_topic_spec.rule_spec,
               ISNULL (dio_spec.rule_spec,
                   ISNULL (dio_templ_spec.rule_spec,
                       ISNULL (dio_cat_spec.rule_spec, N'<HierarchicalName>.<AttributeName>'))))
    FROM  @io_types iot
    INNER JOIN autobind_device dio
       ON dio.dio_id = @dio_id
    INNER JOIN autobind_device_topic topic
       ON topic.dio_id = dio.dio_id
      AND topic.sg_mx_primitive_id = @sg_mx_primitive_id
    INNER JOIN gobject g
       ON g.gobject_id = dio.dio_id
    INNER JOIN template_definition td
       ON td.template_definition_id = g.template_definition_id
    INNER JOIN lookup_category lcat
       ON lcat.category_id = td.category_id
    LEFT OUTER JOIN autobind_device_category dio_cat
       ON dio_cat.category_id = lcat.category_id
    LEFT OUTER JOIN autobind_device_template dio_templ
       ON dio_templ.template_definition_id = td.template_definition_id
    LEFT OUTER JOIN autobind_naming_rule_spec dio_templ_spec
       ON dio_templ_spec.rule_id = dio_templ.rule_id
      AND dio_templ_spec.io_type = iot.io_type
    LEFT OUTER JOIN autobind_naming_rule_spec dio_cat_spec
       ON dio_cat_spec.rule_id = dio_cat.rule_id
      AND dio_cat_spec.io_type = iot.io_type
    LEFT OUTER JOIN autobind_naming_rule_spec dio_spec
       ON dio_spec.rule_id = dio.overridden_naming_rule_id
      AND dio_spec.io_type = iot.io_type
    LEFT OUTER JOIN autobind_naming_rule_spec dio_topic_spec
       ON dio_topic_spec.rule_id = topic.overridden_naming_rule_id
      AND dio_topic_spec.io_type = iot.io_type

    RETURN
END
go

