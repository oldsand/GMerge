/********************************************************************/
/*Object Name :  internal_mark_browser_files                          */
/*Object Type :  Stored Proc.                                       */
/*Purpose :      Used by Deploy/Undeploy methods to mark browser    */
/*               files for deploy/undeploy                          */
/*Used By :      CDI                                                */
/********************************************************************/

CREATE     PROCEDURE dbo.internal_mark_browser_files
    @FileNameOfIds nvarchar(400),
    @location nvarchar(256),
    @markDeployed int -- 1:Deployed 0:Undeployed
AS
begin
    set nocount on

    begin tran
    
    SET QUOTED_IDENTIFIER OFF

	CREATE TABLE #results_table ( 
        file_id int 
    )		

    DECLARE @SQL nvarchar(2000)

    SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds + ''' WITH(TABLOCK, DATAFILETYPE=''widechar'')'

    EXEC (@SQL)

    update  deployed_file 
    set     is_browser_deployed = @markDeployed
    from    deployed_file df
    inner join #results_table rt
        on df.file_id = rt.file_id
    where   df.node_name = @location


    delete  file_pending_update
    from    file_pending_update fpu
    inner join #results_table rt
        on  fpu.file_id = rt.file_id
    where   fpu.node_name = @location


    drop table #results_table
    commit tran

    set nocount off
end
go

