create proc dbo.internal_set_host_and_mx_ids
	@gparentid int, 
	@gobjectid int,
	@usedefaultlogic int,
	@my_platform_id smallint out,
	@my_engine_id smallint out,
	@my_object_id smallint out

As
begin tran



declare @my_category_id		int
declare @hosting_tree_level int

-- get my category id
select	@my_category_id = category_id
from	template_definition t, gobject g
where	t.template_definition_id = g.template_definition_id and g.gobject_id = @gobjectid

if @my_category_id = 23 OR @gparentid = 0
	begin
		-- idxCategoryGalaxy: all Mx ids are 0
		set @my_platform_id = 0
		set @my_engine_id 	= 0
		set @my_object_id 	= 0
		set @hosting_tree_level = 0
	end
else if @my_category_id = 1
	begin
		-- idxCategoryPlatformEngine
		set @my_engine_id 	= 1
		set @my_object_id 	= 1
		set @hosting_tree_level = 1 
	
		-- Calculate my platform id from this galaxy
		if @usedefaultlogic = 1
	        begin
			  exec internal_get_next_mx_platform_id @my_platform_id out	
			  if @my_platform_id is NULL
				select @my_platform_id = max(mx_platform_id) + 1 from instance
			end
		else
            begin
				exec internal_get_next_nongr_mx_platform_id @my_platform_id out
				if @my_platform_id is NULL
					select @my_platform_id = max(mx_platform_id) + 1 from instance	
			end 

	end
else if @my_category_id < 10  
	begin	
		-- 2 to 9 are other type of Engines	
		
		-- Inherit platform_id from my host ( which is a platform )
		select @my_platform_id = mx_platform_id
		from instance i
		where i.gobject_id = @gparentid
		
		-- Object id is alway 1 ( first object on this engine )
		set @my_object_id = 1
		set @hosting_tree_level = 2
	
		-- Calculate my engine id
        exec internal_get_next_mx_engine_id @my_platform_id,@my_engine_id out
			
		if @my_engine_id is NULL
			select @my_engine_id = max(mx_engine_id) + 1 from instance where mx_platform_id = @my_platform_id
	end
else -- all other types ( appObject, Symbols, Production objects, etc...)
	begin

		-- Inherit platform_id  and engine id from my host ( doesn't matter what category my parent is )
		select @my_platform_id = mx_platform_id, @my_engine_id = mx_engine_id
		from instance i
		where i.gobject_id = @gparentid

		-- Calculate mx_object_id
		if ( @my_platform_id > 0 )
			begin
                declare @max_object_id int

		  		select @max_object_id = max(mx_object_id) from instance where mx_platform_id = @my_platform_id and mx_engine_id = @my_engine_id
				
				declare @totalobj int
				set @totalobj = (select count(*) from instance where mx_platform_id = @my_platform_id and mx_engine_id = @my_engine_id )
				-- If total no. of objects and maximum id are not same then use the algorithm to find the
				-- holes
				if ( @max_object_id <> @totalobj)
				  begin
				    exec internal_get_next_mx_object_id @my_platform_id,@my_engine_id,@my_object_id out
                  end
                else
				  set @my_object_id = @max_object_id + 1

				-- get hosting tree level
				select @hosting_tree_level = hosting_tree_level + 1 from gobject where gobject_id = @gparentid
			end
		else
			begin
				set @my_object_id = 0
				set @hosting_tree_level = 0
			end

	end

-- Check if the engine or the object is exceed of its limit
-- Note that Platform is engine 1 and engine start at mx_engine_id = 2 to 1001
if ( @my_engine_id > 1001  )
begin
	rollback tran
	set NOCOUNT ON
	return 0x80040550 -- E_ASSIGN_ENGINE_EXCEED_LIMIT
end

if ( @my_object_id > 30000 )
begin
	rollback tran
	set NOCOUNT ON
	return 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
end

-- set Mx IDs
update instance set mx_platform_id = @my_platform_id, mx_engine_id = @my_engine_id, mx_object_id = @my_object_id
where gobject_id = @gobjectid

-- set Host and tree_level
update gobject set hosted_by_gobject_id = @gparentid, hosting_tree_level = @hosting_tree_level
where gobject_id = @gobjectid 

set NOCOUNT ON

commit tran

go

