create proc dbo.internal_set_area_association(
    @childIdList nvarchar(255),
    @parentId int,
    @assocType smallint,
    @updatecontainname int,
    @operationStatus int out)
As 
begin
    
	if @parentId = 0 return	-- UNASSIGNMENT, should call internal_unset_association

    begin tran
    set nocount on

    -- ASSIGNMENT
        
    declare @retAffectedObjects table(gobject_id int, is_toolset bit)
    declare @mx_platform_id smallint, @mx_engine_id smallint, @mx_object_id smallint
    declare @childId int, @child_platform_id smallint, @child_engine_id smallint
    declare @parentCategory int, @childCategory int, @my_container int 
    declare @objCount int, @nLevel smallint
    declare @is_template bit    

    select @parentCategory = category_id, @is_template = is_template
    from gobject inner join template_definition
    on gobject.template_definition_id = template_definition.template_definition_id
    where gobject_id = @parentId

    if(@parentCategory <> 13) -- if host is not area then return
    begin
        rollback tran
        return  
    end

    create table  #childList (gid int primary key)
    DECLARE @gSQL nvarchar(2000)
    SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
                WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
    EXEC (@gSQL)

    exec internal_filter_deployed_objects_from_input_list
    
    truncate table CurrentSessionContainedName 

    declare @count  int
    declare @baseid int
    declare @i      int
    declare @bit    bit

    IF @assocType = 2  -- SET AREA: Parent can only be AREA
    BEGIN

        declare @childInfo table (
            obj_id int primary key , 
            cat_id smallint, 
            my_container int, 
            has_children bit, 
            nLevel smallint, 
            mx_platform_id smallint, 
            mx_engine_id smallint)
    
        insert into @childInfo select H.gid, T.category_id, G.contained_by_gobject_id,
        case when exists ( select gobject_id from gobject where contained_by_gobject_id = H.gid ) then 1 else 0 end,
        1, mx_platform_id, mx_engine_id
        from #childList H inner join gobject G on H.gid = G.gobject_id
        inner join template_definition T on T.template_definition_id = G.template_definition_id
        inner join instance I on G.gobject_id = I.gobject_id
        

        -- Add the old Area into list of affected objects since the Area is changed
        insert into @retAffectedObjects
        select area_gobject_id, 0 from gobject inner join @childInfo on gobject_id = obj_id

        -- set the dirty flag for reference string
        update attribute_reference set is_valid = 1
        from attribute_reference AR inner join @childInfo on AR.gobject_id = obj_id
        where reference_string like 'myArea.%' or reference_string like 'myHost.%'
        
        -- CASE CHILDREN ARE ENGINES: set new Area for these engines
        IF exists ( select obj_id from @childInfo where cat_id < 10 )
        BEGIN
            --delete any objects from the list which are backup engines as they cannot be assigned to area by itself
            delete @childInfo  from @childInfo c inner join gobject g  on 
            g.gobject_id = c.obj_id where c.cat_id < 10
            and g.namespace_id = 2
            -- Update gobject table
            update gobject set area_gobject_id = @parentId 
            from gobject inner join @childInfo on gobject_id = obj_id
            where cat_id < 10 and gobject.namespace_id = 1
            -- Update gobject table for backup engines if any
            update gobject set area_gobject_id = @parentId where gobject_id in 
		        (select dbo.get_failover_partner_id(g.gobject_id) from @childInfo cI 
            inner join gobject g on g.gobject_id = cI.obj_id and g.namespace_id = 1
			where dbo.get_failover_partner_id(g.gobject_id) > 0)
            
             --insert backup engine info into affected objects for broadcast
            insert into @retAffectedObjects
            select dbo.get_failover_partner_id(g.gobject_id),0 from @childInfo cI 
            inner join gobject g on g.gobject_id = cI.obj_id and g.namespace_id = 1
            where dbo.get_failover_partner_id(g.gobject_id) > 0

            -- remove any engines we already set
            delete from @childInfo where cat_id < 10

        END 

        -- CASE CHILDREN ARE DEVICES: Set Area for these Devices
        IF exists ( select obj_id from @childInfo where (cat_id = 12 or cat_id =11 or cat_id =24) )
        BEGIN
            update gobject set area_gobject_id = @parentId
            from gobject inner join @childInfo on gobject_id = obj_id
            where (cat_id = 12 or cat_id =11 or cat_id =24)

            -- remove any devices we already set
            delete from @childInfo where (cat_id = 12 or cat_id =11 or cat_id =24)
        END

        -- CASE CHILDREN ARE AREAS ( This is the same as SetContainer )
        IF exists ( select obj_id from @childInfo where cat_id = 13 )
        BEGIN
            declare @AreaInfo2 table(obj_id int, cat_id smallint, nLevel smallint)

            insert into @AreaInfo2 select H.gid, T.category_id, 1
            from #childList H inner join gobject G on H.gid = G.gobject_id
            inner join template_definition T on T.template_definition_id = G.template_definition_id

            -- Remove any object which is not an Area
            delete from @AreaInfo2 where cat_id <> 13
        
             -- Add the old Container into list of affected objects since the Area is changed
            insert into @retAffectedObjects
            select contained_by_gobject_id, 0 from gobject inner join @AreaInfo2 on gobject_id = obj_id


            --L00013135
            truncate table CurrentSessionContainedName 
            insert into CurrentSessionContainedName 
                select CI.obj_id as obj_id , contained_name
                from @AreaInfo2 CI inner join gobject G on G.gobject_id = CI.obj_id

            select @count = count(Uniqeid) from CurrentSessionContainedName
            if (@count > 0)
            begin
                select @baseid = min(Uniqeid) from CurrentSessionContainedName 

                set @i = 0
                while (@i < @count)
                begin
                    update  CurrentSessionContainedName 
					set		containedname = dbo.set_contained_name(obj_id, @parentId)
                    where   Uniqeid = @i + @baseid

                    set @i = @i + 1
                end
            end

            -- update gobject table
            update gobject set contained_by_gobject_id = @parentId, area_gobject_id = @parentId, contained_name = CSC.containedname
            from gobject inner join CurrentSessionContainedName CSC on gobject_id = CSC.obj_id



            -- Update hierarchical Name of these objects and their descendants
            set @nLevel = 1                 
            while 1 > 0
            BEGIN

                 if ( @nLevel > 1 )
                BEGIN
                    -- Add any objects which the hierarchical name changed
                    insert into @retAffectedObjects
                    select obj_id, 0 from @AreaInfo2 where cat_id = 13 and nLevel = @nLevel                     
                END

                -- Update the Hierarchical Name of any contained Area, this has to do in layer 
				update gobject set hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
                from gobject G inner join @AreaInfo2 O on G.gobject_id = O.obj_id
                where nLevel = @nLevel

                insert into @AreaInfo2
                select gobject_id, 13, @nLevel + 1 
                from gobject G inner join @AreaInfo2 CI on G.contained_by_gobject_id = CI.obj_id
                where nLevel = @nLevel

                if @@rowcount = 0 break
                set @nLevel = @nLevel + 1
            END -- while                        
        END

        -- CASE CHILDREN ARE APPLICATION OBJECTS:
        declare @newAppobjects int
        set @newAppobjects = 0
        select @newAppobjects = count(*) from @childInfo where (cat_id = 10 or cat_id = 25 or cat_id = 17 or cat_id = 26) 
        IF ( @newAppobjects <> 0 )
        BEGIN

            -- Get the new mx_paltform_id and mx_engine_id for which these app object will move to
            select @mx_platform_id = mx_platform_id, @mx_engine_id = mx_engine_id from instance where gobject_id = @parentId

            declare @MaxObjectsinInstanceTable int
            select @MaxObjectsinInstanceTable  = count(*) 
            from instance where  mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id
            
            if (@mx_engine_id > 0)
            begin
                set @MaxObjectsinInstanceTable = @MaxObjectsinInstanceTable + @newAppobjects
                IF ( @MaxObjectsinInstanceTable > 30000 )
                begin
                    rollback tran
                    set @operationStatus = 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
                     
                    return
    
                end
            end


            -- Remove any object which is not App Object
            delete from @childInfo where not (cat_id = 10 or cat_id = 25 or cat_id = 17 or cat_id = 26)
            
            -- Add the old Container into list of affected objects since the Area is changed
            insert into @retAffectedObjects
            select contained_by_gobject_id, 0 from gobject inner join @childInfo on gobject_id = obj_id
            
            -- Child is AppObject, set Host, Area --> parent Id and Container --> Zero  
            update gobject 
            set hosted_by_gobject_id = @parentId, 
                area_gobject_id = @parentId
            from gobject innner join @childInfo on gobject_id = obj_id
            where (cat_id = 10 or cat_id = 25)

            
            -- handle ViewApps differently...
            update gobject 
            set area_gobject_id = @parentId
            from gobject innner join @childInfo on gobject_id = obj_id
            where (cat_id = 17 or cat_id = 26)


            update gobject 
            set contained_by_gobject_id = 0
            from gobject innner join @childInfo on gobject_id = obj_id
            where (cat_id = 10 or cat_id = 25) and contained_by_gobject_id <> 0
            

            -- set the dirty flag for reference string only if the platform has changed  ( in case of engine, mx_engine_id is not unique )
            -- note that reference string for 'myArea' has been set before
            update attribute_reference set is_valid = 1
            from  attribute_reference AR inner join @childInfo on AR.gobject_id = obj_id
            where (reference_string like 'myPlatform.%' and mx_platform_id <> @mx_platform_id) 
                       or (reference_string like 'myEngine.%' and (mx_platform_id <> @mx_platform_id or mx_engine_id <> @mx_engine_id )  ) 
                       or (reference_string like 'myHost.%') or (reference_string like 'myContainer%')                                          

            -- Add all contained descendants to the list

            select @objCount = count(*) from @childInfo where has_children = 1
            IF @objCount > 0
            BEGIN
                set @nLevel = 1
                
                while 1 > 0
                BEGIN
                    -- Update the Hierarchical Name of any contained objects, this has to do in layer
                    -- L00130319 : Merged from CR L00130744 Hierarchical Names will be updated with the TagName if contained_by_gobject_id is 0  
                    -- As we are updating the g_Object table with contained_by_gobject_id = 0 for ceratin 
                    -- categeories of objects above in  Line 247 do not update the Hierarchical Name 
                    -- of the objects for which contained_by_gobject_id is 0. Upadting may lead to VERL corruption
                    -- beacuse of different Hierarchial names    
                    update gobject set area_gobject_id = @parentId, hosted_by_gobject_id = @parentId, hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
                    from gobject G inner join @childInfo O on G.gobject_id = O.obj_id
                    where contained_by_gobject_id <> 0 and nLevel = @nLevel

                    insert into 
                           @childInfo 
                    select gobject_id, 10, CI.obj_id, 0, @nLevel + 1, CI.mx_platform_id, CI.mx_engine_id
                    from gobject G inner join @childInfo CI on G.contained_by_gobject_id = CI.obj_id
                    where nLevel = @nLevel

                    if @@rowcount = 0 break
                    set @nLevel = @nLevel + 1

                    -- set the dirty flag for reference string only if the platform has changed  ( in case of engine, mx_engine_id is not unique )
                    update attribute_reference set is_valid = 1
                    from  attribute_reference AR inner join @childInfo on AR.gobject_id = obj_id
                    where (nLevel = @nLevel) and
                    ( (reference_string like 'myPlatform.%' and mx_platform_id <> @mx_platform_id) 
                      or (reference_string like 'myEngine.%' and (mx_platform_id <> @mx_platform_id or mx_engine_id <> @mx_engine_id) ) 
                      or (reference_string like 'myHost.%') or (reference_string like 'myContainer%')  or (reference_string like 'myArea.%') )                                      

                END -- while
            END

            --IO linked the objects to the device/scan group to which Area is linked 
			--(only if objects are not linked to any other device)
			--Get the area device information
			declare @dio_id int
			declare @sg_id smallint
			set @dio_id = 0
			set @sg_id = 0
			
			select @dio_id = dio_id, @sg_id = sg_mx_primitive_id  from object_device_linkage 
			where gobject_id = @parentId
			
			if(@@ROWCOUNT <> 0)
			begin
				insert into object_device_linkage 
				select appobj.obj_id, @dio_id,@sg_id from @childInfo appobj
				inner join gobject g on
				g.gobject_id = appobj.obj_id
				and g.is_template = 0
				and g.area_gobject_id = @parentId
				left outer join object_device_linkage odl on
                odl.gobject_id = g.gobject_id
                where odl.gobject_id is NULL
			end


            insert  into @retAffectedObjects select ar.gobject_id,0 
            from attribute_reference ar 
            inner join  @childInfo on ar.resolved_gobject_id = obj_id


            set @bit = 1
            update attribute_reference set is_valid = 1, resolved_gobject_id = 0
            from attribute_reference AR inner join @childInfo on AR.resolved_gobject_id = obj_id

            update  package 
            set     reference_status_id = 2
            from    package PK 
            inner join attribute_reference AR 
                on  PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
            inner join @childInfo 
                on AR.resolved_gobject_id = obj_id
            where   is_valid = @bit 

            update  package 
            set     reference_status_id = 2
            from    package PK 
            inner join attribute_reference AR 
                on  PK.gobject_id = AR.gobject_id and PK.package_id = AR.package_id
            inner join @childInfo 
                on  AR.gobject_id = obj_id
            where   is_valid = @bit 


            -- set the package status of all affected objects whose references
            -- have been invalidated...
            update package set reference_status_id = 2
            from @retAffectedObjects ao
            inner join gobject g on
	            ao.gobject_id = g.gobject_id
            inner join package PK on
	            g.gobject_id = PK.gobject_id and
	            g.checked_in_package_id = PK.package_id
            inner join attribute_reference AR on
	            PK.gobject_id = AR.gobject_id and
	            PK.package_id = AR.package_id and
	        AR.is_valid = 1


            -- We just move an App Object to an Area of another engine then we need to reset the mx ids of all descendant
            -- For any objects moving within its engine ( same platform and engine ) we do not need to set its mx ids
            delete from @childInfo where mx_platform_id = @mx_platform_id and mx_engine_id = @mx_engine_id

            select @objCount = count(*) from @childInfo
            IF @objCount > 0
            BEGIN
                -- If the parent is not yet assigned, then all mx ids should be 0
                IF ( @mx_engine_id = 0 )
                BEGIN
                    update instance 
					set 
						mx_platform_id = 0, 
						mx_engine_id = 0, 
						mx_object_id = 0
                    from instance Inst 
					inner join @childInfo Objs on 
						Inst.gobject_id = Objs.obj_id and
						Objs.cat_id <> 26 -- See note below (Note#1)

                END

                ELSE -- get new mx ids for these App Objects
                BEGIN
                    declare @myObjects table( idx int identity(1,1), gobject_id int)
                    insert into @myObjects select obj_id from @childInfo
					
                    update instance 
					set
						mx_platform_id = @mx_platform_id, 
						mx_engine_id = @mx_engine_id, 
						mx_object_id = MxIdList.mxId
                    from instance Inst 
					inner join @myObjects Objs on 
						Inst.gobject_id = Objs.gobject_id
					inner join @childInfo ci on
						ci.obj_id = Objs.gobject_id and
						ci.cat_id <> 26 -- See note below (Note#1)
					inner join dbo.get_mx_object_ids(@mx_platform_id, @mx_engine_id, @objCount) MxIdList on 
						Objs.idx = MxIdList.idx

                END                         
            END                                 
        END -- Child is App Objects

        insert @retAffectedObjects(gobject_id, is_toolset)
        select obj_id, 0
        from    @childInfo

    END -- @assocType = 2


    -- Check if we have any object over the limit
    if exists ( select mx_engine_id from instance where mx_engine_id > 1000 and mx_platform_id = @mx_platform_id )
    begin
        rollback tran
        set @operationStatus = 0x80040550 -- E_ASSIGN_ENGINE_EXCEED_LIMIT
    end

    else if exists ( select mx_object_id from instance where mx_object_id > 30000 and mx_platform_id = @mx_platform_id
                and mx_engine_id = @mx_engine_id)

    begin
        rollback tran
        set @operationStatus = 0x80040551 -- E_ASSIGN_OBJECT_EXCEED_LIMIT
    end

    else
    begin
        -- wipe out contained name of top level objects
        if ( @updatecontainname > 0 )
        begin
          update gobject set contained_name = '', hierarchical_name = tag_name
          from gobject g inner join #childList ch on ch.gid = g.gobject_id 
          where g.contained_by_gobject_id = 0 and g.contained_name <> ''
        end

        commit tran

        set @operationStatus = 0 -- S_OK

        delete from @retAffectedObjects where gobject_id = 0
        select distinct * from @retAffectedObjects order by is_toolset

    end

    
-- Note#1
--	 IntouchViewApps will need to maintain thier original hosting structure
--   This should not be changed by area association.

end
go

