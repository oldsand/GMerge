/***********************************************************************
 This stored procedure check a list of files, calculates and returns 
 the list of Editor or Package files required for certain node.
 ***********************************************************************/

create  PROCEDURE dbo.internal_get_n_update_editor_package_files_for_dependent_files
        @Nodename nvarchar(256), 
        @ecodemoduletype int,
        @fileOfDependencyFile nvarchar(255),
        @fileOfDependencyFileHasContent int
AS
begin
    SET NOCOUNT ON

    begin tran

	create table  #dependent_file(
	    file_name nvarchar (256)  COLLATE SQL_Latin1_General_CP1_CI_AS not null,
	    subfolder_name nvarchar (256)  COLLATE SQL_Latin1_General_CP1_CI_AS not null,
	    vendor_name nvarchar (256)  COLLATE SQL_Latin1_General_CP1_CI_AS not null,	    
	    registration_type int not null,
        is_needed_for_package bit not null,
        is_needed_for_editor bit not null,
        is_needed_for_runtime bit not null,
    )

	if (@fileOfDependencyFileHasContent = 1 )
	begin
		DECLARE @gSQL nvarchar(2000)
		SET @gSQL = 'BULK INSERT #dependent_file  FROM ''' + @fileOfDependencyFile+ ''' 
					WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
		EXEC (@gSQL)	
	end
    
    declare @fileinfo table ( 
        primitive_guid uniqueidentifier, 
        file_id int, 
        file_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
        vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
        subfolder_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
        registration_type int
    )

    ------------------------step 1 ...Get all the file required for Package or Editor Code Modules..
    IF (@ecodemoduletype = 4) -- Package code module type
    BEGIN
        insert into @fileinfo (primitive_guid, file_id , file_name, vendor_name, subfolder_name,registration_type)
        (
            select distinct 
                    NULL, 
                    f.file_id, 
                    f.file_name, 
                    f.vendor_name, 
                    f.subfolder_name,
                    f.registration_type
            from    file_table f 
            inner join #dependent_file d
                on  f.file_name = d.file_name
                and f.vendor_name = d.vendor_name
                and f.subfolder = d.subfolder_name
                and f.registration_type = d.registration_type
            where   d.is_needed_for_package = 1
        )
    END
    ELSE IF (@ecodemoduletype = 2) -- Package & Editor code module type
    BEGIN
        insert into @fileinfo (primitive_guid, file_id , file_name, vendor_name, subfolder_name,registration_type)
        (
            select distinct 
                    NULL, 
                    f.file_id, 
                    f.file_name, 
                    f.vendor_name, 
                    f.subfolder,
                    f.registration_type
            from    file_table f 
            inner join #dependent_file d
                on  f.file_name = d.file_name
                and f.vendor_name = d.vendor_name
                and f.subfolder = d.subfolder_name
                and f.registration_type = d.registration_type
            where   d.is_needed_for_package = 1 or d.is_needed_for_editor = 1
        )

    END

    
    ------------------------step 2 ...Get all the filelist required for Package or Editor Code Modules..which are not yet deployed (new files)
    declare @filelist table
        ( 
			primitive_guid uniqueidentifier, 
			file_id int, 
			file_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			subfolder_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			registration_type int, 
			software_upgrade_needed int 
		)

    declare @nSUN int
    set @nSUN = 0

    insert into @filelist(primitive_guid, file_id , file_name, vendor_name, subfolder_name, registration_type,software_upgrade_needed)
    (
      select distinct ft.primitive_guid , ft.file_id,ft.file_name,ft.vendor_name ,ft.subfolder_name,ft.registration_type,@nSUN
      from @fileinfo ft where ft.file_id not in (select file_id from deployed_file
      where  deployed_file.node_name =UPPER(@Nodename) and (deployed_file.is_editor_deployed = 1 
        or deployed_file.is_package_deployed = 1 or deployed_file.is_runtime_deployed = 1))
    )

    ------------------------step 3 ...Add all the filelist required for Package or Editor Code Modules..which are required to be deleted as they are old..because they havent been removed
    --when template got deleted so we need to update them when a new template or file will come..
    set @nSUN = 1
    insert into @filelist(primitive_guid, file_id , file_name, vendor_name, subfolder_name,registration_type,software_upgrade_needed)
    (
      select distinct ft.primitive_guid , ft.file_id,ft.file_name,ft.vendor_name ,ft.subfolder_name, ft.registration_type,@nSUN
      from @fileinfo ft where ft.file_id in (select file_id from deployed_file
      where  deployed_file.node_name = UPPER(@Nodename) and need_to_delete = 1 )
    )

    ------------------------step 4 ..-- Update need_to_delete to 0 for all files in both deployed_file 
    -- @filelist table and update is_XX_deployed columns


    insert into deployed_file (file_id, node_name, need_to_delete, is_package_deployed, is_editor_deployed, is_runtime_deployed, is_browser_deployed)
    (
        select distinct file_id, @Nodename as node_name, 0 as need_to_delete,
            0 as is_editor_deployed,0 as is_package_deployed,0 as is_runtime_deployed,
            0 as is_browser_deployed
        from @fileinfo ft
        where ft.file_id not in (select distinct file_id from deployed_file where node_name = UPPER(@Nodename) )
    )
    
         update deployed_file
		set file_version = ft.file_version,
		file_modified_time = ft.file_modified_time
		from file_table ft, deployed_file df
		where df.file_id = ft.file_id  and
			  df.node_name = UPPER(@Nodename)
    ------------------------step 5 ..-- Insert into deployed files which are new files..which r getting deployed for the first time..

    set @nSUN = 1
    insert into @filelist(primitive_guid, file_id , file_name, vendor_name, subfolder_name,registration_type,software_upgrade_needed )
    (
      select distinct ft.primitive_guid , ft.file_id,ft.file_name,ft.vendor_name ,ft.subfolder_name,ft.registration_type,@nSUN
      from @fileinfo ft where ft.file_id in (select file_id from file_pending_update
      where  file_pending_update.node_name = UPPER(@Nodename) )
    )

    -- Get list of files that need to be installed on the specified node
    select  distinct 
            N'', 
            file_name, 
            vendor_name, 
            registration_type,
            software_upgrade_needed,
            file_id ,
            subfolder_name
    from    @filelist 
    order by software_upgrade_needed DESC
    
    commit tran
end
go

