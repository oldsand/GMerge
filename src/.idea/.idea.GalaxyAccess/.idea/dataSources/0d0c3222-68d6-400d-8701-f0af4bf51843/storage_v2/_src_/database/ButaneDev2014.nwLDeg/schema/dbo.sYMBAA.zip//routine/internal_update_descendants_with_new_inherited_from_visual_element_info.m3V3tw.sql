-- When this method is called, @template_gobject_id should be valid.
-- The template must be in checked_out state.
-- 
create procedure dbo.internal_update_descendants_with_new_inherited_from_visual_element_info
    @user_guid nvarchar(64),
	@template_gobject_id int,
    @attribute_reference_file nvarchar(255),
    @attribute_reference_file_has_content int,
    @package_reference_status_file nvarchar(255),
    @package_reference_status_file_has_content int,
    @primitive_ids_file nvarchar(255),
    @primitive_ids_file_has_content int    
as 
set nocount on

begin tran
	declare @user_profile_name nvarchar(256)
    select @user_profile_name  = user_profile_name 
	from user_profile 
	where user_guid = @user_guid

	if @user_profile_name is NULL
		set @user_profile_name = N'DefaultUser'		

	declare @checked_out_package_id int
	declare @checked_in_package_id int
	select  
		@checked_in_package_id = checked_in_package_id,
		@checked_out_package_id = checked_out_package_id
	from gobject
	where gobject_id = @template_gobject_id
		and checked_out_package_id > 0

	-- temp table to hold affected inherited visual elements...
	declare @affected_inherited_visual_element table
	(
		gobject_id int,
		package_id int,
		mx_primitive_id int
	)
	
	
	-- handle content propogation by pointing the inherited
	-- visual elements to the new parent package...
	update vev
	set vev.inherited_from_package_id = @checked_out_package_id
	output 
		inserted.gobject_id,
		inserted.package_id,
		inserted.mx_primitive_id 
	into @affected_inherited_visual_element
	from  visual_element_version vev
	inner join gobject g on
		(vev.gobject_id = g.gobject_id and vev.package_id = g.checked_in_package_id) 
		--or
		--(vev.gobject_id = g.gobject_id and vev.package_id = g.deployed_package_id) 
	where 
		vev.inherited_from_gobject_id = @template_gobject_id and
		vev.inherited_from_package_id = @checked_in_package_id and
		vev.gobject_id <> @template_gobject_id	


	update template_attribute_child
	set template_attribute_child.mx_value = template_attribute_parent.mx_value
	from  visual_element_version vev
	inner join gobject gobject_child on
		vev.gobject_id = gobject_child.gobject_id
	inner join template_attribute template_attribute_child on
		vev.gobject_id  = template_attribute_child.gobject_id and
		vev.package_id = template_attribute_child.package_id and
		vev.mx_primitive_id = template_attribute_child.mx_primitive_id
	inner join template_attribute template_attribute_parent on
		vev.inherited_from_gobject_id = template_attribute_parent.gobject_id and
		vev.inherited_from_package_id = template_attribute_parent.package_id and
		vev.mx_primitive_id = template_attribute_parent.mx_primitive_id and
		template_attribute_child.mx_attribute_id = template_attribute_parent.mx_attribute_id
	where 
		vev.inherited_from_gobject_id = @template_gobject_id and
		vev.inherited_from_package_id = @checked_out_package_id and
		vev.gobject_id <> @template_gobject_id 	
	
	--We need to cascade the Symbol Primitive also. VEV table has only Visual element primitive 
	--entries, which got updated above. for every symbol primitive we will always have 2 rows in
	--primitive_instance table. first is SymbolPrimitive and second is visual element primitive.
	update template_attribute_child
	set template_attribute_child.mx_value = template_attribute_parent.mx_value
	from  visual_element_version vev
	inner join gobject gobject_child on
		vev.gobject_id = gobject_child.gobject_id
	inner join template_attribute template_attribute_child on
		vev.gobject_id  = template_attribute_child.gobject_id and
		vev.package_id = template_attribute_child.package_id and
		vev.mx_primitive_id-1 = template_attribute_child.mx_primitive_id
	inner join template_attribute template_attribute_parent on
		vev.inherited_from_gobject_id = template_attribute_parent.gobject_id and
		vev.inherited_from_package_id = template_attribute_parent.package_id and
		vev.mx_primitive_id-1 = template_attribute_parent.mx_primitive_id and
		template_attribute_child.mx_attribute_id = template_attribute_parent.mx_attribute_id
	where 
		vev.inherited_from_gobject_id = @template_gobject_id and
		vev.inherited_from_package_id = @checked_out_package_id and
		vev.gobject_id <> @template_gobject_id 
		
	update	package
	set		derived_from_package_id = @checked_out_package_id
	where	derived_from_package_id = @checked_in_package_id

    --update the timestamp of inherited visual elements...
    declare @new_timestamp bigint
    exec internal_get_next_timestamp @new_timestamp out
    
    update pri
    set pri.timestamp_of_last_change = @new_timestamp
    from  @affected_inherited_visual_element ave
    inner join primitive_instance pri on
        pri.gobject_id = ave.gobject_id and
        pri.package_id = ave.package_id and
        pri.mx_primitive_id = ave.mx_primitive_id
	inner join visual_element_version child_vev on
		ave.gobject_id = child_vev.gobject_id and
		ave.package_id = child_vev.package_id and
		ave.mx_primitive_id = child_vev.mx_primitive_id
	inner join primitive_instance parent_pri on
		parent_pri.gobject_id = child_vev.inherited_from_gobject_id and
		parent_pri.package_id = child_vev.inherited_from_package_id and
		parent_pri.mx_primitive_id = child_vev.inherited_from_mx_primitive_id
	where parent_pri.checked_out_primitive_version > parent_pri.checked_in_primitive_version
		
		
	
    -- update error, warning status for descendent
    declare @template_visual_element_primitive_status table
    (
        gobject_id int default 0,
        package_id int default 0,
        mx_primitive_id int default 0,
        status_id smallint not null default 0,
        mx_value_errors text not null,
        mx_value_warnings text not null,
        primary key(mx_primitive_id)
    )

    insert  @template_visual_element_primitive_status
    (
        gobject_id,
        package_id,
        mx_primitive_id,
        status_id,
        mx_value_errors,
        mx_value_warnings
    )
    select  
        pri.gobject_id,
        pri.package_id,
        pri.mx_primitive_id,
        pri.status_id,
        pri.mx_value_errors,
        pri.mx_value_warnings
    from
        primitive_instance pri
    inner join
        gobject g
    on
        pri.gobject_id = g.gobject_id
    and pri.package_id = g.checked_out_package_id
    and g.gobject_id = @template_gobject_id
    inner join
        primitive_definition pd
    on
        pri.primitive_definition_id = pd.primitive_definition_id
    and (pd.primitive_name = 'SymbolExtension'or pd.primitive_name = 'DisplayExtension')
    
    declare @descendents_to_be_updated table
    (
        gobject_id int default 0,
        package_id int default 0,
        is_template bit,
        is_immediate_child bit,
        primary key(gobject_id, package_id)            
    )       

    insert @descendents_to_be_updated
    (
        gobject_id, 
        is_template, 
        is_immediate_child
    )
    exec internal_get_gobject_descendants @template_gobject_id

    update  de
    set     de.package_id = g.checked_in_package_id
    from    @descendents_to_be_updated de
    inner join
            gobject g
    on  
            g.gobject_id = de.gobject_id                
    
    update  pri_descendent
    set     pri_descendent.status_id = tvs.status_id,
            pri_descendent.mx_value_errors = tvs.mx_value_errors,
            pri_descendent.mx_value_warnings = tvs.mx_value_warnings
    from    primitive_instance pri_descendent 
    inner join 
            @descendents_to_be_updated de
    on 
            pri_descendent.gobject_id = de.gobject_id
    and     pri_descendent.package_id = de.package_id
    inner join
            @template_visual_element_primitive_status tvs
    on
            tvs.mx_primitive_id = pri_descendent.mx_primitive_id

    
    -- Reset the package status
    update  pa
    set     pa.status_id = 0
    from    package pa
    inner join 
            @descendents_to_be_updated de
    on      de.gobject_id = pa.gobject_id
        and de.package_id = pa.package_id

    -- Set package status to warning if necessary
    update  pa
    set     pa.status_id = 2
    from    package pa 
    inner join 
            @descendents_to_be_updated de
    on      de.gobject_id = pa.gobject_id
        and de.package_id = pa.package_id
    inner join
            primitive_instance pri
    on 
            pri.gobject_id = pa.gobject_id
        and pri.package_id = pa.package_id
        and pri.status_id = 2


    -- Set package status to error if necessary
    update  pa
    set     pa.status_id = 1
    from    package pa 
    inner join 
            @descendents_to_be_updated de
    on      de.gobject_id = pa.gobject_id
        and de.package_id = pa.package_id
    inner join
            primitive_instance pri
    on 
            pri.gobject_id = pa.gobject_id
        and pri.package_id = pa.package_id
        and pri.status_id = 1
    

    if (@primitive_ids_file_has_content = 1)
    begin
        create table #primitive_ids_to_be_removed (
            mx_primitive_id int
        )
        
	    DECLARE @SQL3 nvarchar(2000)
	    SET @SQL3 = 'BULK INSERT #primitive_ids_to_be_removed  FROM ''' + @primitive_ids_file + ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '
	    EXEC (@SQL3)
        
        declare @descendents table
        (
            gobject_id int default 0,
            package_id int default 0,
            is_template bit,
            is_immediate_child bit,
            primary key(gobject_id, package_id)            
        )       

        insert @descendents(gobject_id, is_template, is_immediate_child)
            exec internal_get_gobject_descendants @template_gobject_id

        update  de
        set     de.package_id = g.checked_in_package_id
        from    @descendents de
        inner join
                gobject g
        on  
                g.gobject_id = de.gobject_id                

     	delete  ar
    	from    
    	        attribute_reference ar
    	inner join 
    	        @descendents de
    	on
    	        ar.gobject_id = de.gobject_id
    	    and ar.package_id = de.package_id
    	inner join
    	        #primitive_ids_to_be_removed pr 
    	on
    	        ar.referring_mx_primitive_id = pr.mx_primitive_id    	    
--
        update  primitive_instance
        set     primitive_instance.ref_status_id = 0
        from    primitive_instance
        inner join
                @descendents de
        on  
                primitive_instance.gobject_id = de.gobject_id                
			and	primitive_instance.package_id = de.package_id
    	inner join
    	        #primitive_ids_to_be_removed pr 
    	on
    	        primitive_instance.mx_primitive_id = pr.mx_primitive_id    	    

    end
	
		
	-- update attribute reference
	if (@attribute_reference_file_has_content = 1)
	begin

	    CREATE TABLE  #attribute_references ( 
					    gobject_id int,
					    package_id int,
					    ref_prim_id int,
					    ref_attr_id int,
				        element_index int, 
				        res_gobject_id int default 0,
				        dest_obj_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS not null default '',
				        obj_sign int,
				        attr_sign int, 
				        res_mx_prim_id int,
				        res_mx_attr_id int,
				        res_mx_prop_id int,
				        attr_res_st int,
                        attr_idx int,
                        is_valid int,
                        reference_string nvarchar(700) COLLATE SQL_Latin1_General_CP1_CI_AS not null default ''
        )	
                        
        create index temp_idx_attribute_references on
            #attribute_references(gobject_id,package_id,ref_prim_id)
            
	    DECLARE @SQL nvarchar(2000)
	    SET @SQL = 'BULK INSERT #attribute_references  FROM ''' + @attribute_reference_file + ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '
	    EXEC (@SQL)
    	
        update  tempar            
        set     tempar.res_gobject_id = g.gobject_id
        from    
                #attribute_references tempar
        inner join 
                gobject g
        on      
                tempar.dest_obj_name = g.tag_name
                    	
    	delete  ar
    	from    attribute_reference ar
    	inner join 
    	        #attribute_references tempar
    	on      ar.gobject_id = tempar.gobject_id
    	    and ar.package_id = tempar.package_id
    	    and ar.referring_mx_primitive_id = tempar.ref_prim_id
    	    
    	    
    	 -- Update the context_String same as tag_name
   	     -- This will improve reference binding thread performance 
   	     

    	insert  attribute_reference(
                    gobject_id,
                    package_id,
                    referring_mx_primitive_id,
                    referring_mx_attribute_id,
	                element_index,
                    resolved_gobject_id,
                    reference_string,
                    context_string,
                    object_signature,
                    resolved_mx_primitive_id,
                    resolved_mx_attribute_id,
                    resolved_mx_property_id,
	                attribute_signature,
	                lock_type,
                    is_valid,
	                attr_res_status,
	                attribute_index)
	    (
	        select  att.gobject_id,
	                att.package_id,
	                att.ref_prim_id,
	                att.ref_attr_id,
	                att.element_index,
	                att.res_gobject_id,
	                att.reference_string,
	                g.tag_name,
	                att.obj_sign,
                    att.res_mx_prim_id,
                    att.res_mx_attr_id,
                    att.res_mx_prop_id,
                    att.attr_sign,
                    1,
                    att.is_valid,
                    att.attr_res_st,
                    att.attr_idx
            from    #attribute_references att
            inner join gobject g
            on g.gobject_id = att.gobject_id	
            where g.is_template = 0             	                
	    )
	    
	    -- Set primitive_instance status for these primitives
	    update  pri
	    set     
	            pri.ref_status_id = 0
	    from    
	            primitive_instance pri
	    inner join 
	            #attribute_references tempar
	    on 
	        pri.gobject_id = tempar.gobject_id
	    and pri.package_id = tempar.package_id
	    and pri.mx_primitive_id = tempar.ref_prim_id


	    update  pri
	    set     
	            pri.ref_status_id = 2
	    from    
	            primitive_instance pri
	    inner join 
	            #attribute_references tempar
	    on 
	        pri.gobject_id = tempar.gobject_id
	    and pri.package_id = tempar.package_id
	    and pri.mx_primitive_id = tempar.ref_prim_id
	    where
	            tempar.is_valid = 1 -- is_valid == 1 means the reference is invalid ;(
	        
	
	    -- Update package reference status for those objects which has referencs
        update  pa
        set     pa.reference_status_id = 0
        from    
                package pa
        inner join 
                #attribute_references tempar
        on      
                pa.gobject_id = tempar.gobject_id
        and     pa.package_id = tempar.package_id


         update  pa
        set     pa.reference_status_id = 2
        from    
                package pa     
	    inner join
                #attribute_references tempar
        on      
                pa.gobject_id = tempar.gobject_id
        and     pa.package_id = tempar.package_id
        inner join
                attribute_reference attr
        on      
                attr.gobject_id = tempar.gobject_id
        and     attr.package_id = tempar.package_id        
	    where
			    attr.is_valid = 1

    end



    -- Update package reference status for those objects which has referencs
    update  pa
    set     pa.reference_status_id = 0
    from    
            package pa
    inner join 
            @descendents_to_be_updated de
    on      
            pa.gobject_id = de.gobject_id
    and     pa.package_id = de.package_id


	-- Primitive instance's ref_status_id column is NOT VALID ANY MORE.
	-- So we need to set the Package Reference status based on Attribute_Reference table


    update  pa
    set     pa.reference_status_id = 2
    from    
            package pa    
    inner join
            @descendents_to_be_updated de
    on      
            pa.gobject_id = de.gobject_id
    and     pa.package_id = de.package_id
    inner join
                attribute_reference attr
        on      
                attr.gobject_id = de.gobject_id
        and     attr.package_id = de.package_id        
	where
			    attr.is_valid = 1



	-- return all affected objects...
	declare @affected_gobjects table
	(
		gobject_id int,
		package_id int,
		primary key (gobject_id,package_id)
	)
	insert into @affected_gobjects
	output inserted.gobject_id
	select distinct 
		gobject_id,
		package_id
	from  @affected_inherited_visual_element

	-- bump up the configuration_version of each affected object...
	update g
	set configuration_version = configuration_version + 1
	from @affected_gobjects ao
	inner join gobject g on
		ao.gobject_id = g.gobject_id
	

    -- add change log
	declare	@timestamp datetime
	set @timestamp = getdate()
	insert into gobject_change_log
	( 
		gobject_id, 
		change_date, 
		operation_id, 
		user_comment, 
		configuration_version,
		user_profile_name 
	)
	select
		r.gobject_id,
		@timestamp,
		38,
    	N'System updated object graphics during cascade checkin from parent.',		
		g.configuration_version,
		@user_profile_name
	from @affected_gobjects r
	inner join gobject g on
		r.gobject_id = g.gobject_id

 
	-- find out if the visual element references have changed for this template
	-- and propogage the visual element references if necessary...
	declare @ver_change_has_occurred bit
	exec internal_has_objects_visual_element_references_changed @template_gobject_id, @ver_change_has_occurred out
	if(@ver_change_has_occurred = 0)
	begin
		commit
		return
	end
	else
	begin
		/*
		 propogate visual element references changes
		 1) Delete all visual element references associated with VEs inherited from this template from the checked in package.
		 2) Add all visual element refernces inherited from this template.
		 3) Bind the references.
		***************************************************************************************************************************/
		-- 1) Delete all visual element references associated with VEs inherited from this template from the checked in package.

		--select * from @affected_inherited_visual_element
		delete ver
		from visual_element_reference ver
		inner join @affected_inherited_visual_element ave on
			ver.gobject_id = ave.gobject_id and
			ver.package_id = ave.package_id and
			ver.mx_primitive_id = ave.mx_primitive_id

		-- 2) Add all visual element references inherited from this template.
		declare @child_gobject_id int
		declare @child_package_id int

		while exists(select '1' from @affected_gobjects )
		begin
			select top 1
				@child_gobject_id = gobject_id,
				@child_package_id = package_id
			from @affected_gobjects 
			order by gobject_id            

			exec internal_add_visual_element_references_from_gobject
				@child_gobject_id ,
				@child_package_id ,
				@template_gobject_id,
				@checked_out_package_id
			
			delete 
			from @affected_gobjects
			where gobject_id = @child_gobject_id
			
		end

		--3) Bind the references.
		exec internal_bind_visual_element_references
	end
        
commit

go

