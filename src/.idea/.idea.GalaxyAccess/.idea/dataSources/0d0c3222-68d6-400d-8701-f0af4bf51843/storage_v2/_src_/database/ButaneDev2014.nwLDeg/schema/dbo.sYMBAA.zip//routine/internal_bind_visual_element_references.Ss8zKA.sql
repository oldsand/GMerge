create procedure dbo.internal_bind_visual_element_references
as

if exists(select 1 from galaxy where is_migration_in_progress = 1)
    return

begin tran

    declare @timestamp_of_last_bind timestamp
    declare @all_affected_objects table(gobject_id int)

    select @timestamp_of_last_bind = timestamp_of_last_visual_element_reference_bind
    from galaxy 

    declare @new_ts bigint
    exec internal_get_next_timestamp @new_ts out
 
    
	
    if not exists(
		select '*'
		from visual_element_reference
		where unbound_timestamp > @timestamp_of_last_bind)
	begin
		   update galaxy 
		   set timestamp_of_last_visual_element_reference_bind = @new_ts  --CR L00126782
		commit
		return
	end

    declare @checked_in_non_relative_unbound_elements_to_bind table
    (
        gobject_id int,
        package_id int,
        mx_primitive_id smallint,
        visual_element_reference_index int,
        checked_in_bound_visual_element_gobject_id int null,
        checked_in_bound_visual_element_package_id int null,
        checked_in_bound_visual_element_mx_primitive_id smallint null,
        primary key 
        ( 
            gobject_id, 
            package_id, 
            mx_primitive_id, 
            visual_element_reference_index 
        ) 
    )

    declare @checked_out_non_relative_unbound_elements_to_bind table
    (
        gobject_id int,
        package_id int,
        mx_primitive_id smallint,
        visual_element_reference_index int,
        checked_out_bound_visual_element_gobject_id int null,
        checked_out_bound_visual_element_package_id int null,
        checked_out_bound_visual_element_mx_primitive_id smallint null,
        checked_out_visual_element_package_id int null,
        checked_out_to_user_guid uniqueidentifier null,
        primary key 
        ( 
            gobject_id, 
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )
    
    declare @checked_in_relative_unbound_elements_to_bind table
    (
        gobject_id int,
        package_id int,
        mx_primitive_id smallint,
        visual_element_reference_index int,
        checked_in_bound_visual_element_gobject_id int null,
        checked_in_bound_visual_element_package_id int null,
        checked_in_bound_visual_element_mx_primitive_id smallint null,
        primary key 
        ( 
            gobject_id, 
            package_id, 
            mx_primitive_id, 
            visual_element_reference_index 
        )
    )

    declare @checked_out_relative_unbound_elements_to_bind table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id smallint not null,
        visual_element_reference_index int not null,
        checked_out_bound_visual_element_gobject_id int null,
        checked_out_bound_visual_element_package_id int null,
        checked_out_bound_visual_element_mx_primitive_id smallint null,
        checked_out_visual_element_package_id int null,
        checked_out_to_user_guid uniqueidentifier null,
        primary key 
        ( 
            gobject_id, 
            package_id, 
            mx_primitive_id, 
            visual_element_reference_index 
        )
    )

    
	-- try to bind non-relative checked-in visual_elements......    
    -- using 2 queries instead of 1 to increase performance.
    -- if you combint this insert and insert below, make sure the performance is still good. - Brian

	-- for non-hierarchical visual element names:
	insert into @checked_in_non_relative_unbound_elements_to_bind
		(gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_reference_index,
		checked_in_bound_visual_element_gobject_id,
		checked_in_bound_visual_element_package_id,
		checked_in_bound_visual_element_mx_primitive_id)
	select     
		ver.gobject_id,
		ver.package_id,
		ver.mx_primitive_id ,
		ver.visual_element_reference_index,
 		vw.gobject_id,
 		vw.package_id,
 		vw.mx_primitive_id
	from visual_element_reference ver --(index = idx_visual_element_reference_checked_in_unbound_tag_name_primitive_name_type)
	inner join internal_visual_element_description_view vw (noexpand) on
          (ver.checked_in_unbound_visual_element_name = vw.visual_element_name)
		    and ( 
                    (ver.checked_in_unbound_visual_element_type = vw.visual_element_type) 
               or 
               (ver.checked_in_unbound_visual_element_type is null) 
                 )
	inner join gobject referee on
		referee.gobject_id = vw.gobject_id and
		referee.checked_in_package_id = vw.package_id and
		referee.namespace_id <> 2
    where
        ver.is_relative_reference = 0 and
        ver.checked_in_bound_visual_element_gobject_id is null
 		and ver.checked_in_bound_visual_element_package_id is null
	    and ver.checked_in_bound_visual_element_mx_primitive_id is null
        and ver.visual_element_bind_status = 0 
        and ver.unbound_timestamp > @timestamp_of_last_bind

	-- for Hierarchical visual element names:
	insert into @checked_in_non_relative_unbound_elements_to_bind
		(gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_reference_index,
		checked_in_bound_visual_element_gobject_id,
		checked_in_bound_visual_element_package_id,
		checked_in_bound_visual_element_mx_primitive_id)
	select     
		ver.gobject_id,
		ver.package_id,
		ver.mx_primitive_id ,
		ver.visual_element_reference_index,
 		vw.gobject_id,
 		vw.package_id,
 		vw.mx_primitive_id
	from visual_element_reference ver --(index = idx_visual_element_reference_checked_in_unbound_tag_name_primitive_name_type)
	inner join internal_visual_element_description_view vw (noexpand) on
          (ver.checked_in_unbound_visual_element_name = vw.hierarchical_visual_element_name)
		    and ( 
                    (ver.checked_in_unbound_visual_element_type = vw.visual_element_type) 
               or 
               (ver.checked_in_unbound_visual_element_type is null) 
                 )
	inner join gobject referee on
		referee.gobject_id = vw.gobject_id and
		referee.checked_in_package_id = vw.package_id and
		referee.namespace_id <> 2
    where
        ver.is_relative_reference = 0 and
        ver.checked_in_bound_visual_element_gobject_id is null
 		and ver.checked_in_bound_visual_element_package_id is null
	    and ver.checked_in_bound_visual_element_mx_primitive_id is null
        and ver.visual_element_bind_status = 0 
        and ver.unbound_timestamp > @timestamp_of_last_bind
		and not exists 
        (
            select 1 
            from @checked_in_non_relative_unbound_elements_to_bind b
            where 
                ver.gobject_id = b.gobject_id 
                and ver.package_id = b.package_id
                and ver.mx_primitive_id = b.mx_primitive_id
                and ver.visual_element_reference_index = b.visual_element_reference_index
        )



	-- for hierarchical and non-hierarchical visual element names:
	insert into @checked_in_non_relative_unbound_elements_to_bind
		(gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_reference_index,
		checked_in_bound_visual_element_gobject_id,
		checked_in_bound_visual_element_package_id,
		checked_in_bound_visual_element_mx_primitive_id)
	select     
		ver.gobject_id,
		ver.package_id,
		ver.mx_primitive_id ,
		ver.visual_element_reference_index,
 		vw.gobject_id,
 		vw.package_id,
 		vw.mx_primitive_id
	from visual_element_reference ver --(index = idx_visual_element_reference_checked_in_unbound_tag_name_primitive_name_type)
	inner join internal_visual_element_description_view vw (noexpand) on
		ver.checked_in_unbound_visual_element_id = vw.visual_element_id
	inner join gobject referee on
		referee.gobject_id = vw.gobject_id and
		referee.checked_in_package_id = vw.package_id and
		referee.namespace_id <> 2
    where
        ver.is_relative_reference = 0 and
        ver.checked_in_bound_visual_element_gobject_id is null
 		and ver.checked_in_bound_visual_element_package_id is null
	    and ver.checked_in_bound_visual_element_mx_primitive_id is null
        and ver.visual_element_bind_status = 0 
        and ver.unbound_timestamp > @timestamp_of_last_bind
        and not exists 
        (
            select 1 
            from @checked_in_non_relative_unbound_elements_to_bind b
            where 
                ver.gobject_id = b.gobject_id 
                and ver.package_id = b.package_id
                and ver.mx_primitive_id = b.mx_primitive_id
                and ver.visual_element_reference_index = b.visual_element_reference_index
        )



		
    -- try to bind non-relative checked-out visual_elements......
    -- using 2 queries instead of 1 to increase performance.
    -- if you combint this insert and insert below, make sure the performance is still good. - Brian
	insert into @checked_out_non_relative_unbound_elements_to_bind
	(gobject_id,
	package_id,
	mx_primitive_id,
	visual_element_reference_index,
	checked_out_bound_visual_element_gobject_id,
	checked_out_bound_visual_element_package_id,
	checked_out_bound_visual_element_mx_primitive_id,
	checked_out_visual_element_package_id ,
	checked_out_to_user_guid )
	select     
	ver.gobject_id,
	ver.package_id,
	ver.mx_primitive_id ,
	ver.visual_element_reference_index,
	vw.gobject_id,
	vw.package_id,
	vw.mx_primitive_id,
	vw.package_id,
	referee_gobject.checked_out_by_user_guid
	from visual_element_reference ver --(index = idx_visual_element_reference_checked_in_unbound_tag_name_primitive_name_type)
	inner join internal_visual_element_description_view vw (noexpand) on
          (ver.checked_out_unbound_visual_element_name = vw.visual_element_name)
		    and ( 
                    (ver.checked_out_unbound_visual_element_type = vw.visual_element_type) 
               or 
               (ver.checked_out_unbound_visual_element_type is null) 
                 )
	inner join gobject referee_gobject on
		referee_gobject.gobject_id = vw.gobject_id and
		referee_gobject.checked_out_package_id = vw.package_id and
		referee_gobject.namespace_id <> 2
	where
	ver.is_relative_reference = 0 
	and ver.checked_out_bound_visual_element_gobject_id is null 
	and ver.checked_out_bound_visual_element_package_id is null 
	and ver.checked_out_bound_visual_element_mx_primitive_id is null
	and ver.visual_element_bind_status = 0 
	and ver.unbound_timestamp > @timestamp_of_last_bind

	insert into @checked_out_non_relative_unbound_elements_to_bind
	(gobject_id,
	package_id,
	mx_primitive_id,
	visual_element_reference_index,
	checked_out_bound_visual_element_gobject_id,
	checked_out_bound_visual_element_package_id,
	checked_out_bound_visual_element_mx_primitive_id,
	checked_out_visual_element_package_id ,
	checked_out_to_user_guid )
	select     
	ver.gobject_id,
	ver.package_id,
	ver.mx_primitive_id ,
	ver.visual_element_reference_index,
	vw.gobject_id,
	vw.package_id,
	vw.mx_primitive_id,
	vw.package_id,
	referee_gobject.checked_out_by_user_guid
	from visual_element_reference ver --(index = idx_visual_element_reference_checked_in_unbound_tag_name_primitive_name_type)
	inner join internal_visual_element_description_view vw (noexpand) on
		ver.checked_out_unbound_visual_element_id = vw.visual_element_id
	inner join gobject referee_gobject on
		referee_gobject.gobject_id = vw.gobject_id and
		referee_gobject.checked_out_package_id = vw.package_id and
		referee_gobject.namespace_id <> 2
	where
	ver.is_relative_reference = 0 
	and ver.checked_out_bound_visual_element_gobject_id is null 
	and ver.checked_out_bound_visual_element_package_id is null 
	and ver.checked_out_bound_visual_element_mx_primitive_id is null
	and ver.visual_element_bind_status = 0 
	and ver.unbound_timestamp > @timestamp_of_last_bind
    and not exists (
        select 1 
        from @checked_out_non_relative_unbound_elements_to_bind b
        where 
            ver.gobject_id = b.gobject_id 
            and ver.package_id = b.package_id
            and ver.mx_primitive_id = b.mx_primitive_id
            and ver.visual_element_reference_index = b.visual_element_reference_index
        )
	

    --  Finished binding non-relative references.....

    -- try to bind relative visual_elements....
    -- checked in....
    declare @checked_in_relative_bind_candidates table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id int not null,
        visual_element_reference_index int not null,
        expected_hierarchical_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS not null, 
        visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS, 
        visual_element_id int,
        primary key
        (
            gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )

    insert into @checked_in_relative_bind_candidates
    (
        gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        expected_hierarchical_name,
        visual_element_type,
        visual_element_id
    )
    select
        ver.gobject_id,
        ver.package_id,
        ver.mx_primitive_id,
        ver.visual_element_reference_index,
        g.hierarchical_name 
        + case when len(checked_in_unbound_relative_object_name) > 0 then N'.'+ checked_in_unbound_relative_object_name else '' end
        + case when len(ver.checked_in_unbound_primitive_name) > 0  then '.' + left(ver.checked_in_unbound_primitive_name,32) else '' end 
            hierarchical_visual_element_name,
        ver.checked_in_unbound_visual_element_type,
        ver.checked_in_unbound_visual_element_id
    from visual_element_reference ver 
    inner join gobject g on 
        g.gobject_id = ver.gobject_id
    where
        ver.checked_in_bound_visual_element_gobject_id is null
        and ver.checked_in_bound_visual_element_package_id is null
        and ver.checked_in_bound_visual_element_mx_primitive_id is null
        and ver.unbound_timestamp > @timestamp_of_last_bind
        and ver.is_relative_reference = 1  


    -- two queries below form a single "or", single query
    -- performs badly
    insert into @checked_in_relative_unbound_elements_to_bind
    (gobject_id,
    package_id,
    mx_primitive_id,
    visual_element_reference_index,
    checked_in_bound_visual_element_gobject_id,
    checked_in_bound_visual_element_package_id,
    checked_in_bound_visual_element_mx_primitive_id)
    select
        u.gobject_id,
    	u.package_id,
    	u.mx_primitive_id ,
    	u.visual_element_reference_index,
        v.gobject_id,
        v.package_id,
        v.mx_primitive_id
    from @checked_in_relative_bind_candidates u
    inner join internal_visual_element_description_view v (noexpand) on 
        (u.expected_hierarchical_name = v.hierarchical_visual_element_name
        and (v.visual_element_type = u.visual_element_type or u.visual_element_type is null  ) )
    inner join gobject referee on
		referee.gobject_id = v.gobject_id and
		referee.checked_in_package_id = v.package_id and
		referee.namespace_id <> 2

    insert into @checked_in_relative_unbound_elements_to_bind
    (gobject_id,
    package_id,
    mx_primitive_id,
    visual_element_reference_index,
    checked_in_bound_visual_element_gobject_id,
    checked_in_bound_visual_element_package_id,
    checked_in_bound_visual_element_mx_primitive_id)
    select
        u.gobject_id,
    	u.package_id,
    	u.mx_primitive_id ,
    	u.visual_element_reference_index,
        v.gobject_id,
        v.package_id,
        v.mx_primitive_id
    from @checked_in_relative_bind_candidates u
    inner join internal_visual_element_description_view v (noexpand) on 
        u.visual_element_id = v.visual_element_id
    inner join gobject referee on
		referee.gobject_id = v.gobject_id and
		referee.checked_in_package_id = v.package_id and
		referee.namespace_id <> 2
    where not exists (
        select 1 
        from @checked_in_relative_unbound_elements_to_bind b
        where 
            u.gobject_id = b.gobject_id 
            and u.package_id = b.package_id
            and u.mx_primitive_id = b.mx_primitive_id
            and u.visual_element_reference_index = b.visual_element_reference_index
        )

    declare @checked_out_relative_bind_candidates table
    (
        gobject_id int not null,
        package_id int not null,
        mx_primitive_id int not null,
        visual_element_reference_index int not null,
        expected_hierarchical_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
        checked_out_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
        visual_element_id int
        primary key
        (
            gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index
        )
    )


    insert into @checked_out_relative_bind_candidates
    select
        ver.gobject_id,
        ver.package_id,
        ver.mx_primitive_id,
        ver.visual_element_reference_index,
        g.hierarchical_name 
        + isnull( N'.'+ checked_out_unbound_relative_object_name, '' )
        + case when ver.checked_out_unbound_primitive_name <> '' then '.' + left(ver.checked_out_unbound_primitive_name,32) else '' end 
            hierarchical_visual_element_name,
        ver.checked_out_unbound_visual_element_type,
        ver.checked_out_unbound_visual_element_id
    from visual_element_reference ver 
    inner join gobject g on 
        g.gobject_id = ver.gobject_id
    where
        ver.checked_out_bound_visual_element_gobject_id is null
        and ver.checked_out_bound_visual_element_package_id is null
        and ver.checked_out_bound_visual_element_mx_primitive_id is null
        and ver.unbound_timestamp > @timestamp_of_last_bind
        and ver.is_relative_reference = 1  


    insert into @checked_out_relative_unbound_elements_to_bind
    (
        gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        checked_out_bound_visual_element_gobject_id,
        checked_out_bound_visual_element_package_id,
        checked_out_bound_visual_element_mx_primitive_id,
        checked_out_visual_element_package_id,
        checked_out_to_user_guid
    )
    select
        u.gobject_id,
    	u.package_id,
    	u.mx_primitive_id ,
    	u.visual_element_reference_index,
        v.gobject_id,
        v.package_id,
        v.mx_primitive_id,
        referee.checked_out_package_id,
        referee.checked_out_by_user_guid
    from @checked_out_relative_bind_candidates u
    inner join internal_visual_element_description_view v (noexpand) on 
        u.expected_hierarchical_name = v.hierarchical_visual_element_name
        and 
        ( 
            u.checked_out_unbound_visual_element_type = v.visual_element_type
            or u.checked_out_unbound_visual_element_type is null 
        )
    inner join gobject referee on
		referee.gobject_id = v.gobject_id and
		referee.checked_out_package_id = v.package_id and
		referee.namespace_id <> 2

    insert into @checked_out_relative_unbound_elements_to_bind
    (
        gobject_id,
        package_id,
        mx_primitive_id,
        visual_element_reference_index,
        checked_out_bound_visual_element_gobject_id,
        checked_out_bound_visual_element_package_id,
        checked_out_bound_visual_element_mx_primitive_id,
        checked_out_visual_element_package_id,
        checked_out_to_user_guid
    )
    select
        u.gobject_id,
    	u.package_id,
    	u.mx_primitive_id ,
    	u.visual_element_reference_index,
        v.gobject_id,
        v.package_id,
        v.mx_primitive_id,
        referee.checked_out_package_id,
        referee.checked_out_by_user_guid
    from @checked_out_relative_bind_candidates u
    inner join internal_visual_element_description_view v (noexpand) on 
        u.visual_element_id = v.visual_element_id
    inner join gobject referee on
		referee.gobject_id = v.gobject_id and
		referee.checked_out_package_id = v.package_id and
		referee.namespace_id <> 2
    where not exists (
        select 1 
        from @checked_out_relative_unbound_elements_to_bind b
        where 
            u.gobject_id = b.gobject_id 
            and u.package_id = b.package_id
            and u.mx_primitive_id = b.mx_primitive_id
            and u.visual_element_reference_index = b.visual_element_reference_index
        )
    
    
    -- update VER table...
    --update the checked_in_bound ver columns....
    if exists (select 1 from @checked_in_non_relative_unbound_elements_to_bind)
    begin
        update  ver
        set 
            --checked_in bound columns....
            ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
            ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
            ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
            --checked_in unbound columns....
            ver.checked_in_unbound_visual_element_name = null,
            ver.checked_in_unbound_visual_element_type = null,
            ver.checked_in_unbound_tag_name = null,
            ver.checked_in_unbound_primitive_name = null,
            ver.checked_in_unbound_relative_object_name = null,
            ver.checked_in_unbound_visual_element_id = null
		output inserted.gobject_id
		into @all_affected_objects
        from visual_element_reference ver 
        inner join @checked_in_non_relative_unbound_elements_to_bind wt on
            wt.gobject_id = ver.gobject_id and
            wt.package_id = ver.package_id and
            wt.mx_primitive_id = ver.mx_primitive_id and
            wt.visual_element_reference_index = ver.visual_element_reference_index
    end


    --update the checked_out_bound ver columns....
    if exists (select 1 from @checked_out_non_relative_unbound_elements_to_bind)
    begin
        update  ver
        set 
            --checked_out bound columns....
            ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
            ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
    
            ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
            --ver.visual_element_bind_status = 1,-- now a calculated column..
            ver.checked_out_visual_element_package_id = wt.checked_out_visual_element_package_id,
            ver.checked_out_to_user_guid = wt.checked_out_to_user_guid,
            --checked_out unbound columns....
            ver.checked_out_unbound_visual_element_name = null,
            ver.checked_out_unbound_visual_element_type = null,
            ver.checked_out_unbound_tag_name = null,
            ver.checked_out_unbound_primitive_name = null,
            ver.checked_out_unbound_relative_object_name = null,
            ver.checked_out_unbound_visual_element_id = null
		output inserted.gobject_id
		into @all_affected_objects
        from visual_element_reference ver 
        inner join @checked_out_non_relative_unbound_elements_to_bind wt on
            wt.gobject_id = ver.gobject_id and
            wt.package_id = ver.package_id and
            wt.mx_primitive_id = ver.mx_primitive_id and
            wt.visual_element_reference_index = ver.visual_element_reference_index
    end

    --update the checked_in_bound ver columns....
    if exists (select 1 from @checked_in_relative_unbound_elements_to_bind)
    begin
        update  ver
        set 
            -- bound columns...
            ver.checked_in_bound_visual_element_gobject_id = wt.checked_in_bound_visual_element_gobject_id,
            ver.checked_in_bound_visual_element_package_id = wt.checked_in_bound_visual_element_package_id,
            ver.checked_in_bound_visual_element_mx_primitive_id = wt.checked_in_bound_visual_element_mx_primitive_id,
            -- unbound columns...
            ver.checked_in_unbound_visual_element_name = null,
            ver.checked_in_unbound_visual_element_type = null,
            ver.checked_in_unbound_tag_name = null,
            ver.checked_in_unbound_primitive_name = null,
            ver.checked_in_unbound_relative_object_name = null
		output inserted.gobject_id
		into @all_affected_objects
        from visual_element_reference ver 
        inner join @checked_in_relative_unbound_elements_to_bind wt on
            wt.gobject_id = ver.gobject_id and
            wt.package_id = ver.package_id and
            wt.mx_primitive_id = ver.mx_primitive_id and
            wt.visual_element_reference_index = ver.visual_element_reference_index
    end


    --update the checked_out_bound ver columns....
    if exists (select 1 from @checked_out_relative_unbound_elements_to_bind)
    begin
        update  ver
        set 
            --checked_out bound columns....
            ver.checked_out_bound_visual_element_gobject_id = wt.checked_out_bound_visual_element_gobject_id,
            ver.checked_out_bound_visual_element_package_id = wt.checked_out_bound_visual_element_package_id,
            ver.checked_out_bound_visual_element_mx_primitive_id = wt.checked_out_bound_visual_element_mx_primitive_id,
            ver.checked_out_visual_element_package_id = wt.checked_out_visual_element_package_id,
            ver.checked_out_to_user_guid = wt.checked_out_to_user_guid,
            -- unbound columns...
            ver.checked_out_unbound_visual_element_name = null,
            ver.checked_out_unbound_visual_element_type = null,
            ver.checked_out_unbound_tag_name = null,
            ver.checked_out_unbound_primitive_name = null,
            ver.checked_out_unbound_relative_object_name = null
		output inserted.gobject_id
		into @all_affected_objects
        from visual_element_reference ver 
        inner join @checked_out_relative_unbound_elements_to_bind wt on
            wt.gobject_id = ver.gobject_id and
            wt.package_id = ver.package_id and
            wt.mx_primitive_id = ver.mx_primitive_id and
            wt.visual_element_reference_index = ver.visual_element_reference_index
    end



    --null out any unbound checked-out string columns that did not bind...
    update visual_element_reference
    set 
        checked_out_unbound_visual_element_name = null,
        checked_out_unbound_visual_element_type = null,
        checked_out_unbound_tag_name = null,
        checked_out_unbound_primitive_name = null,
        checked_out_unbound_relative_object_name = null,
        checked_out_unbound_visual_element_id = null,
        checked_out_visual_element_package_id = null,
        checked_out_to_user_guid = null
    where checked_out_visual_element_package_id is null and
        unbound_timestamp > @timestamp_of_last_bind
        and (
        checked_out_unbound_visual_element_name is not null
        or checked_out_unbound_visual_element_type is not null
        or checked_out_unbound_tag_name is not null
        or checked_out_unbound_primitive_name is not null
        or checked_out_unbound_relative_object_name is not null
        or checked_out_unbound_visual_element_id is not null
        or checked_out_visual_element_package_id is not null
        or checked_out_to_user_guid is not null )

	if exists(select '1' from @all_affected_objects)
	begin
			declare @distinct_affected_objects table(gobject_id int primary key)

			insert into @distinct_affected_objects
			select distinct gobject_id
			from @all_affected_objects

			update pt
			set pt.gobject_id = pt.gobject_id
			from proxy_timestamp pt
			inner join @distinct_affected_objects dao on
				pt.gobject_id = dao.gobject_id 

			update gfi
			set gfi.gobject_id = gfi.gobject_id
			from gobject_filter_info_timestamp gfi
			inner join @distinct_affected_objects dao on
				gfi.gobject_id = dao.gobject_id 


			declare @max_proxy_timestamp bigint
			select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

			update galaxy 
			set timestamp_of_last_visual_element_reference_bind = @new_ts  --CR L00126782

			update galaxy
			set max_proxy_timestamp = @max_proxy_timestamp
	end

    	    
commit
go

