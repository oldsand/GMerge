/*
selects all gobject_ids hosted by an object.
*/
create procedure dbo.internal_get_all_hosted_gobjects
	@gobject_id int  -- gobject_id of the host
as

set nocount on

-------------------------------------------------------
-- calculate all objects hosted by @gobject_id
------------------------------------------------------

-- table for return value
declare @ResultSet table( gobject_id int)

-- table for gobjects in a particular iteration in the while loop
declare @WorkingSet table( gobject_id int)

insert into @WorkingSet values( @gobject_id )

while (
	select count(*) 
    from  gobject 
    where hosted_by_gobject_id in ( select * from @WorkingSet ) 
            and hosted_by_gobject_id <> 0
     ) > 0
begin
	-- table for all the descendants of the @WorkingSet gobjects
	declare @TemporaryCache table( gobject_id int )

	delete from @TemporaryCache

	insert into @TemporaryCache( gobject_id )
	( 
		select gobject_id from gobject 
        where hosted_by_gobject_id in ( select * from @WorkingSet ) 
                and hosted_by_gobject_id <> 0
	)

	delete from @WorkingSet

	insert into @WorkingSet select gobject_id from @TemporaryCache

	insert into @ResultSet select * from @TemporaryCache
end

select * from @ResultSet
go

