/**************************************************/
/*Object Name :  internal_gethostedgobject					*/
/*Object Type :  Stored Proc.								*/
/*Purpose :    Procedure to find out the host and its tagname*/
/*Used By :    CDI											*/
/**************************************************/
create proc dbo.internal_get_hosted_gobject
@tagname nvarchar(329),
@hostedbygobject_id int out,
@hosttagname    nvarchar(329) out
as
begin
set @hosttagname = ''
set @hostedbygobject_id = (select hosted_by_gobject_id from gobject where tag_name = @tagname and namespace_id = 1) -- Automation Object
if ( @hostedbygobject_id > 0 )
  exec internal_get_tag_name @hostedbygobject_id,@hosttagname out

end

go

