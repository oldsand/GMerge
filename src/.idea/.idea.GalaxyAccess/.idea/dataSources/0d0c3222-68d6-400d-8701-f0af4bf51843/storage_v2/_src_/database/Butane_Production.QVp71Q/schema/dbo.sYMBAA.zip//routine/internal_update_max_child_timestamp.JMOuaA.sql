
create proc dbo.internal_update_max_child_timestamp
as

declare @timestamp_of_last_cascade bigint
declare @new_timestamp_of_last_cascade bigint
select @timestamp_of_last_cascade = timestamp_of_last_cascade from galaxy
 
if not exists 
    ( 
        select 1 
        from primitive_instance pri 
        where 
            pri.timestamp_of_last_change > @timestamp_of_last_cascade 
    )
    and not exists
    ( 
        select 1 
        from primitive_instance pri 
        where 
            pri.max_child_timestamp > @timestamp_of_last_cascade 
    )
begin
    return
end
 
begin tran
exec internal_get_next_timestamp @new_timestamp_of_last_cascade out
update galaxy 
set timestamp_of_last_cascade = @new_timestamp_of_last_cascade
 
 
--create a table variable to store
--visual elements one reference level at a time...
--declare @modified_visual_element table 
create table #modified_visual_element 
(
    gobject_id int not null,
    package_id int not null,
    mx_primitive_id int not null,
    max_child_timestamp bigint not null
    ,primary key ( gobject_id, package_id, mx_primitive_id) 
)
 
-- create a table variable to store
-- the group of VEs to be updated next...
--declare @to_be_processed_visual_element table 
create table #to_be_processed_visual_element 
(
    gobject_id int not null,
    package_id int not null,
    mx_primitive_id int not null,
    max_child_timestamp bigint not null
    ,primary key
    ( 
        gobject_id, 
        package_id, 
        mx_primitive_id
    ) 
)
 
-- create a table to hold all processed elements...
-- declare @processed_visual_element table 
create table #processed_visual_element
(
    gobject_id int not null,
    package_id int not null,
    mx_primitive_id int not null
    ,primary key
    ( 
        gobject_id, 
        package_id, 
        mx_primitive_id
    ) 
)
 
-- insert the first rows based on the last_cascade time.  
-- this will act as the seed for this process....
-- uses two queries to avoid an "or" statement which
-- slows performance.  Don't combine these with an or before
-- first running large system performance tests.
insert into #modified_visual_element
select 
    vev.gobject_id,
    vev.package_id,
    vev.mx_primitive_id,
    case when pri.timestamp_of_last_change > pri.max_child_timestamp then 
        pri.timestamp_of_last_change
    else 
        pri.max_child_timestamp
    end 
from primitive_instance pri with(index(idx_primitive_instance_on_timestamp_of_last_change))
inner loop join visual_element_version vev on
    pri.gobject_id = vev.gobject_id 
    and pri.package_id = vev.package_id 
    and pri.mx_primitive_id = vev.mx_primitive_id 
where  pri.timestamp_of_last_change > @timestamp_of_last_cascade

insert into #modified_visual_element
select 
    vev.gobject_id,
    vev.package_id,
    vev.mx_primitive_id,
    case when pri.timestamp_of_last_change > pri.max_child_timestamp then 
        pri.timestamp_of_last_change
    else 
        pri.max_child_timestamp
    end 
from primitive_instance pri with(index(idx_primitive_instance_on_max_child_timestamp))
inner join visual_element_version vev on
    pri.gobject_id = vev.gobject_id 
    and pri.package_id = vev.package_id 
    and pri.mx_primitive_id = vev.mx_primitive_id 
where  pri.max_child_timestamp > @timestamp_of_last_cascade
    and not exists
    ( 
        select 1 from #modified_visual_element mve
        where mve.gobject_id = pri.gobject_id
        and mve.package_id = pri.package_id
        and mve.mx_primitive_id = pri.mx_primitive_id )
 

/*
	Mark dependent visual element thumbnails dirty ...

*/
		create table #modified_primitive 
            (
				gobject_id int, 
				package_id int,
				mx_primitive_id smallint
			)
		insert into #modified_primitive
		(
			gobject_id ,
			package_id ,
			mx_primitive_id
		)
		select
			gobject_id ,
			package_id ,
			mx_primitive_id
		from #modified_visual_element

		exec internal_mark_dependent_visual_element_thumbnails_as_dirty

		drop table #modified_primitive


declare @update_max_child_timestamp table
(
  gobject_id int not null,
  package_id int not null,
  mx_primitive_id int not null,
  child_max_timestamp bigint not null,
  primary key
    ( 
        gobject_id, 
        package_id, 
        mx_primitive_id
    ) 
) 
insert into @update_max_child_timestamp
(
   gobject_id,
   package_id,
   mx_primitive_id,
   child_max_timestamp
)
select b.gobject_id, 
       b.package_id, 
       b.mx_primitive_id,
       max(mve.max_child_timestamp) 
from #modified_visual_element mve
inner join  visual_element_reference b on
            (b.checked_in_bound_visual_element_gobject_id = mve.gobject_id and
             b.checked_in_bound_visual_element_package_id = mve.package_id and
             b.checked_in_bound_visual_element_mx_primitive_id = mve.mx_primitive_id) 
        group by 
            b.gobject_id,
            b.package_id,
            b.mx_primitive_id
 
update primitive_instance
set max_child_timestamp = 
    case when max_child_timestamp > childMax.child_max_timestamp then 
        max_child_timestamp
    else
        childMax.child_max_timestamp
    end
from
@update_max_child_timestamp childMax
where primitive_instance.gobject_id = childMax.gobject_id and
    primitive_instance.package_id = childMax.package_id and
    primitive_instance.mx_primitive_id = childMax.mx_primitive_id 
 
-- now that the first set of parents are updated, start walking up the VE reference tree...
insert into
    #to_be_processed_visual_element
select 
    parent_vev.gobject_id,
    parent_vev.package_id,
    parent_vev.mx_primitive_id,
    max(pri.max_child_timestamp)
from #modified_visual_element mve
inner join visual_element_version bound_vev on
    mve.gobject_id = bound_vev.gobject_id
    and mve.package_id = bound_vev.package_id
    and mve.mx_primitive_id = bound_vev.mx_primitive_id
inner join visual_element_reference b on
     (b.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
      b.checked_in_bound_visual_element_package_id = bound_vev.package_id and
      b.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id)
inner join primitive_instance pri on 
      pri.gobject_id = b.gobject_id and
      pri.package_id = b.package_id and
      pri.mx_primitive_id = b.mx_primitive_id
inner join visual_element_version parent_vev on
      pri.gobject_id = parent_vev.gobject_id and
      pri.package_id = parent_vev.package_id and
      pri.mx_primitive_id = parent_vev.mx_primitive_id
where pri.max_child_timestamp <= mve.max_child_timestamp 
group by
    parent_vev.gobject_id,
    parent_vev.package_id,
    parent_vev.mx_primitive_id
 
 
insert into #processed_visual_element
select 
    gobject_id,
    package_id,
    mx_primitive_id
from 
    #modified_visual_element mve
where not exists (
    select 1 from #processed_visual_element pve 
    where 
        pve.gobject_id = mve.gobject_id
        and pve.package_id = mve.package_id
        and pve.mx_primitive_id = mve.mx_primitive_id )
 
declare @NoOfModifiedVEs int
select @NoOfModifiedVEs = COUNT(*) from #modified_visual_element
truncate table #modified_visual_element
 
while(@NoOfModifiedVEs > 0)
begin
 
    insert into #modified_visual_element
    (
        gobject_id,
        package_id,
        mx_primitive_id,
        max_child_timestamp
    )
    select 
        gobject_id,
        package_id,
        mx_primitive_id,
        max_child_timestamp
    from #to_be_processed_visual_element
 
    truncate table #to_be_processed_visual_element
    delete from @update_max_child_timestamp
    insert into @update_max_child_timestamp
    (
       gobject_id,
       package_id,
       mx_primitive_id,
       child_max_timestamp
    )
            select pri.gobject_id, 
                   pri.package_id, 
                   pri.mx_primitive_id,
                   max(mve.max_child_timestamp)
            from visual_element_reference b
            inner join primitive_instance pri on 
                b.gobject_id = pri.gobject_id and 
                b.package_id = pri.package_id and
                b.mx_primitive_id = pri.mx_primitive_id
          inner join visual_element_version bound_vev on
                (b.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                 b.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                 b.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id) 
            inner join #modified_visual_element mve on 
                mve.gobject_id = bound_vev.gobject_id
                and mve.package_id = bound_vev.package_id
                and mve.mx_primitive_id = bound_vev.mx_primitive_id
            group by pri.gobject_id,pri.package_id,pri.mx_primitive_id
 
 
    update primitive_instance
    set max_child_timestamp = 
        case when max_child_timestamp > childMax.child_max_timestamp then 
            max_child_timestamp
       else
            childMax.child_max_timestamp
        end
    from
        @update_max_child_timestamp childMax 
    where primitive_instance.gobject_id = childMax.gobject_id and
        primitive_instance.package_id = childMax.package_id and
        primitive_instance.mx_primitive_id = childMax.mx_primitive_id 
    
    insert into
        #to_be_processed_visual_element
    select 
        parent_vev.gobject_id,
        parent_vev.package_id,
        parent_vev.mx_primitive_id,
        max(pri.max_child_timestamp)
    from #modified_visual_element mve
    inner join visual_element_reference b on
         (b.checked_in_bound_visual_element_gobject_id = mve.gobject_id and
          b.checked_in_bound_visual_element_package_id = mve.package_id and
          b.checked_in_bound_visual_element_mx_primitive_id = mve.mx_primitive_id) 
    inner join primitive_instance pri on 
          pri.gobject_id = b.gobject_id and
          pri.package_id = b.package_id and
          pri.mx_primitive_id = b.mx_primitive_id
   inner join visual_element_version parent_vev on
          pri.gobject_id = parent_vev.gobject_id and
          pri.package_id = parent_vev.package_id and
          pri.mx_primitive_id = parent_vev.mx_primitive_id
    where pri.max_child_timestamp <= mve.max_child_timestamp 
        and not exists
        (select 1
         from #processed_visual_element x
            where 
                x.gobject_id = parent_vev.gobject_id
                and x.package_id = parent_vev.package_id
                and x.mx_primitive_id = parent_vev.mx_primitive_id
        )
    group by 
        parent_vev.gobject_id,
        parent_vev.package_id,
        parent_vev.mx_primitive_id
 
    insert into #processed_visual_element
    select 
        gobject_id,
        package_id,
        mx_primitive_id
    from 
        #modified_visual_element mve
    where not exists
    (
        select 1 from #processed_visual_element pve 
        where 
            pve.gobject_id = mve.gobject_id
            and pve.package_id = mve.package_id
            and pve.mx_primitive_id = mve.mx_primitive_id 
    )
    select @NoOfModifiedVEs = COUNT(*) from #modified_visual_element
    truncate table #modified_visual_element
    
end

drop table #modified_visual_element
drop table #to_be_processed_visual_element
drop table #processed_visual_element
 
commit


go

