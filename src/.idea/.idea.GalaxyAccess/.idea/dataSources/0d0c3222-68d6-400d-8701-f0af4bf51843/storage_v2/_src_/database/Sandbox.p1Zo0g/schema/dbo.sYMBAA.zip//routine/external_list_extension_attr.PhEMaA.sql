--Not a supported function.  The data returned may be incorrect.
--exec external_list_extension_attr '$Room'
-- Proc to get the list of extension and which extensions etc.
create proc dbo.external_list_extension_attr
@tagname nvarchar(329)
as
begin
--set @tagname = '$Room'
declare @extended_prims table
(
	gobjid int,
	prim_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
	attr_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS ,
	prim_extension_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS 
)

insert into @extended_prims 
select distinct pi.gobject_id,pi.primitive_name,da.attribute_name,pi.extension_type from primitive_instance pi 
inner join gobject gobj on pi.gobject_id = gobj.gobject_id and gobj.tag_name = @tagname
 and pi.extension_type <> ''
left join dynamic_attribute da 
	on pi.primitive_name = da.attribute_name
	and pi.gobject_id = da.gobject_id 

declare @temp_ext table
(
	gobjid int,
	primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS 
)
insert into @temp_ext select distinct gobjid,prim_name from @extended_prims where attr_name is null


-- get the dynamic attribute info first
select  gobj.tag_name as 'Object Name', 
	da.attribute_name as 'Attribute Name',
	'True' as 'IsDynamicAtribute',
	case when da.attribute_name in (select tpi.attr_name from @extended_prims tpi where tpi.prim_extension_type = 'alarmextension') then
		1
	else
		0 
	end as 'Has Alarm Extension',
	case when da.attribute_name in (select tpi.attr_name from @extended_prims tpi where tpi.prim_extension_type = 'inputoutputextension') then
		1
	else
		0
	end as 'Has Input/Output Extension',
	case when da.attribute_name in (select tpi.attr_name from @extended_prims tpi where tpi.prim_extension_type = 'inputextension') then
		1
	else
		0
	end as 'Has Input Extension',
	case when da.attribute_name in (select tpi.attr_name from @extended_prims tpi where tpi.prim_extension_type = 'outputextension') then
		1
	else
		0
	end as 'Has Output Extension',
	case when da.attribute_name in (select tpi.attr_name from @extended_prims tpi where tpi.prim_extension_type = 'historyextension') then
		1
	else
		0
	end as 'Has History Extension'
from gobject gobj inner join dynamic_attribute da on gobj.gobject_id = da.gobject_id 
--inner join primitive_instance pi on pi.gobject_id = da.gobject_id 
--	and pi.primitive_name = da.attribute_name
where gobj.tag_name = @tagname 

union 

select @tagname as 'Object Name',
	pi.primitive_name as 'Attribute Name',
	'False' as 'IsDynamicAtribute',
	case when pi.primitive_name in ( select ep.prim_name from @extended_prims ep where ep.attr_name is null and ep.prim_extension_type = 'alarmextension') then
	1
	else
	0 
	end as 'Has Alarm Extension',
	case when pi.primitive_name in ( select ep.prim_name from @extended_prims ep where ep.attr_name is null and ep.prim_extension_type = 'inputoutputextension') then
		1
	else
		0
	end as 'Has Input/Output Extension',
	case when pi.primitive_name in ( select ep.prim_name from @extended_prims ep where ep.attr_name is null and ep.prim_extension_type = 'inputextension' )then
		1
	else
		0
	end as 'Has Input Extension',
	case when pi.primitive_name in ( select ep.prim_name from @extended_prims ep where ep.attr_name is null  and ep.prim_extension_type = 'outputextension') then
		1
	else
		0
	end as 'Has Output Extension',
	case when pi.primitive_name in ( select ep.prim_name from @extended_prims ep where ep.attr_name is null  and ep.prim_extension_type = 'historyextension') then
		1
	else
		0
	end as 'Has History Extension'
	from @temp_ext pi

end
go

