create procedure dbo.internal_unmangle_template_name
@templateId int
AS

set nocount on  
begin

  declare @baseName nvarchar(32), @uniqueName nvarchar(32)
  declare @tagName nvarchar(329), @containedName nvarchar(32)
   -- Namespace_ID 1 = Automation Object
  select @tagName = tag_name,  @containedName = contained_name from gobject where namespace_id = 1 and gobject_id = @templateId and is_template = 1
  if @containedName = ''
	set @baseName = @tagName
  else
	set @baseName = '$' + @containedName

  declare @maxno int, @maxnolength int, @baseNameLength int
  set @baseNameLength = len(@baseName)
  set @maxno = 0
  set @maxnolength = 1
  set @uniqueName = @baseName

  while 0 < 1
    begin
	
	-- Find out if this name is unique 	
	if  exists ( select * from gobject where tag_name = @uniqueName and is_template = 1 and @templateId <> gobject_id and namespace_id = 1) -- Automation Object
		begin
			set @maxno = @maxno + 1
			set @maxnolength = len(cast(@maxno as nvarchar )) + 1
			if ( @baseNameLength +  @maxnolength ) > 32 
				set @uniqueName = SUBSTRING(@baseName, 1, 32 - @maxnolength ) + '_' + cast(@maxno as nvarchar )
			else	  		
	  			set @uniqueName = @baseName + '_' + cast(@maxno as nvarchar)
		end
	else
	  	begin
	    	-- set the tagname base on the contained_name and reset the contained name for a match with new tagname	
			set @baseName = SUBSTRING(@uniqueName, 2, 32)
			update gobject set tag_name = @uniqueName, contained_name = @baseName where gobject_id = @templateId and is_template = 1
	    	break
	  	end
    end
end



go

