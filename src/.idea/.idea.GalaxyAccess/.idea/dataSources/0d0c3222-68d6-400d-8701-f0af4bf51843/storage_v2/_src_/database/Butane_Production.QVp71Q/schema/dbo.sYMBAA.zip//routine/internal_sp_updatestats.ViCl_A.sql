CREATE PROCEDURE dbo.internal_sp_updatestats
WITH EXECUTE AS 'dbo'
AS
	EXEC sp_updatestats
go

