/**************************************************/
/*Object Name :  internal_get_area							*/
/*Object Type :  Stored Proc.								*/
/*Purpose :    Procedure to find out the are and its tagname*/
/*Used By :    CDI											*/
/**************************************************/
create proc dbo.internal_get_area
@tagname nvarchar(329),
@areagobject_id int out,
@areatagname    nvarchar(329) out
as
begin
set @areatagname = ''
set @areagobject_id = (select area_gobject_id from gobject where tag_name = @tagname and namespace_id = 1) -- Automation Object
if ( @areagobject_id > 0 )
  exec internal_get_tag_name @areagobject_id,@areatagname out

end
go

