create proc dbo.internal_rename_fsobject
	@gobject_id int,
	@newName_in nvarchar(329),
	@name_type int,	
	@errorCode int out
as
set nocount on
begin
begin tran
set @errorCode = 0

declare @isDeployed int
declare @isBackUpEngine int
declare @isPrimaryEngine int
declare @isFullyUndeployed int
declare @isAreaApplicationOrCustomObject int
declare @isDeviceIntegrationInstanceObject int
declare @containedByGobjectID int
declare @failOverPartnerId int
declare @namespace_id int
declare @original_name nvarchar(329) 
declare @category_id int
declare @ioBindindPostProcRequired int
declare @updategalaxy bit = 0


-- // set variables...
select
      @original_name                     = ilov.tag_name,
      @isDeployed                        = ilov.IsDeployed,
      @isPrimaryEngine                   = ilov.IsPrimaryEngine,
      @isBackUpEngine                    = ilov.IsBackupEngine,
      @isFullyUndeployed                 = (case when  (ilov.deployed_package_id = 0 and dbo.is_partner_deployed(ilov.gobject_id) = 0) then '1' else '0' end),
      @isAreaApplicationOrCustomObject   = (case when ilov.category_id in (10,13,25) then '1' else '0' end ),
      @isDeviceIntegrationInstanceObject = (case when ilov.is_template = 0 and ilov.category_id in (11,12,24) then '1' else '0' end ),
      @containedByGobjectID              = ilov.container_id,
      @failOverPartnerId                 = dbo.get_failover_partner_id(@gobject_id),
      @category_id                       = ilov.category_id
 from internal_list_objects_view ilov
where ilov.gobject_id = @gobject_id

if @isBackUpEngine > 0
begin
	set @errorCode = 1001 -- eObjectisBackupEngine
	ROLLBACK TRAN
	return
end
else if @isDeployed > 0
begin
	set @errorCode = 1002 -- eObjectisDeployed
	ROLLBACK TRAN
	return
end
else if (@isPrimaryEngine = 1 and @isFullyUndeployed = 0 ) --check to see if@isPrimaryEngine is necessary.......
begin
	set @errorCode = 1003 -- eObjectNotFullyUndeployed
	ROLLBACK TRAN
	return
end
else if (@isAreaApplicationOrCustomObject > 0 )
begin
	declare @bHasDeployChild int
	exec internal_has_contained_descendant_deployed 1,@bHasDeployChild out
	if @bHasDeployChild > 0
	begin
		set @errorCode = 1004 -- eObjectHasContainedChildrenDeployed
		ROLLBACK TRAN
		RETURN
	end

end
else if @name_type = 2
begin
	set @errorCode = 1005 -- eObjectisnotAreaorApplicationObject
end

-- all checks have been completed... now perform the name change...
-- even though we return after setting the error code... we should still check to ensure that the error code
-- is 0

-- Any renamed visual elements that result from this call must be handled
-- appropriately...
-- if this is a VEL, we need to archive the old name for polling clients...
if(@name_type = 1)
begin
	declare @renamed_visual_element_row_count int
	set @renamed_visual_element_row_count = 0
	insert into renamed_visual_element
		(
		 gobject_id,
		 package_id,
		 mx_primitive_id,
		 visual_element_id,
		 old_visual_element_name,
		 new_visual_element_name,
		 visual_element_type)
	select
		v.gobject_id,
		v.package_id,
		v.mx_primitive_id, 
		v.visual_element_id,
		v.visual_element_name,
		@newName_in,
		v.visual_element_type
	from internal_visual_element_description_view v (noexpand)
	where 
		v.gobject_id = @gobject_id and
		v.is_library_visual_element = 1

	set @renamed_visual_element_row_count = @@rowcount

	insert into renamed_visual_element
		(
		 gobject_id,
		 package_id,
		 mx_primitive_id,
		 visual_element_id,
		 old_visual_element_name,
		 new_visual_element_name,
		 visual_element_type)
	select
		v.gobject_id,
		v.package_id,
		v.mx_primitive_id, 
		v.visual_element_id,
		v.visual_element_name,
		@newName_in + '.' + v.primitive_name,
		v.visual_element_type
	from internal_visual_element_description_view v (noexpand)
	where 
		v.gobject_id = @gobject_id and
		v.is_library_visual_element = 0

	set @renamed_visual_element_row_count = 
		@renamed_visual_element_row_count + @@rowcount


	if(@renamed_visual_element_row_count > 0)
	begin
		update galaxy
		set max_visual_element_timestamp = CAST ( @@dbts  AS timestamp ) 
	end

end


declare @effectedObjects table(obj_id int,mycontainer int,nLevel smallint)

insert into  @effectedObjects(obj_id,mycontainer,nLevel) values(@gobject_id,0,1)

if @name_type = 1 -- update tagname
begin	
    select  @namespace_id = namespace_id 
    from    gobject 
    where   gobject_id = @gobject_id    

    IF Exists(  SELECT  gobject_id 
                FROM    gobject 
                WHERE   tag_name = @newName_in  
                and     namespace_id = @namespace_id  
                and     gobject_id <> @gobject_id )
	BEGIN
		set @errorCode = 1006 -- eDuplicateTagNamenotAllowed
		ROLLBACK TRAN
		return
	END

	if ( @namespace_id = 3)
	begin
		DECLARE @galaxyName nvarchar(329) 
		select @galaxyName = db_name()
		if ( @galaxyName = @newName_in )
		begin
			set @errorCode = 1006
			rollback tran
			return
		end
	end

    -->>-- Auto-binding
    if (@isDeviceIntegrationInstanceObject = 1)
    begin
        CREATE TABLE #autobound_attribute_transient (
                           gobject_id      int
                         , mx_primitive_id smallint
                         , mx_attribute_id smallint
                         , element_index   smallint
                         , linked_device   nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS 
                         , default_ref     nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                         , xlate_rule_id   int
                         , attr_alias      nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                         , PRIMARY KEY (gobject_id, mx_primitive_id, mx_attribute_id, element_index))

        -- The autobound_attribute_transient table holds overrides across the rename operation, so that they may be reinstated.
        INSERT INTO #autobound_attribute_transient
        SELECT itvf.lo_id, itvf.lo_prim_id, itvf.lo_attr_id, itvf.lo_element_index
             , itvf.dio_tag_name + '.' + itvf.dio_scan_group_name
             , itvf.app_object_attr_name + '.' + itvf.app_object_io_attr
             , itvf.xlate_rule_id, itvf.overridden_attr_reference
          FROM autobind_device_topic adt
        CROSS APPLY itvfGetAutobindInfoForDIO (adt.dio_id, adt.sg_mx_primitive_id, DEFAULT, DEFAULT, DEFAULT) itvf
         WHERE adt.dio_id = @gobject_id
        OPTION (FORCE ORDER) 	--L00136670 

        set @ioBindindPostProcRequired = @@ROWCOUNT
    end
    --<<-- Auto-binding

    update  gobject 
    set     tag_name = @newName_in			
    where   gobject_id = @gobject_id

	update  attribute_reference 
    set     context_string = @newName_in                                              
    where   gobject_id = @gobject_id


	--If failover partner exists, update that object as well... 
	if @failOverPartnerId > 0
	begin
        update  gobject 
        set     tag_name = @newName_in 
        where   gobject_id = @failOverPartnerId

		insert into @effectedObjects  values (@failOverPartnerId,0,0)
	end
	-- Now, update User_Profile...
		if (@category_id = 1)
		begin
			update user_profile set default_platform_tag_name = @newName_in
				where default_platform_tag_name = @original_name
		end
		else if (@category_id = 3)
		begin
			update user_profile set default_app_engine_tag_name = @newName_in		
				where default_app_engine_tag_name = @original_name
		end
		else if (@category_id = 4)
		begin
			update user_profile set default_view_engine_tag_name = @newName_in
				where default_view_engine_tag_name = @original_name
		end	
		else if (@category_id = 13)
		begin
			update user_profile set default_area_tag_name = @newName_in
				where default_area_tag_name = @original_name
		end

	-- re-bind any unbound visual elements that will be "fixed" by this rename...
	if exists(
			 select 1 
			 from visual_element_reference
			 where 
				(checked_out_unbound_tag_name = @newName_in) or
				(checked_in_unbound_tag_name = @newName_in)
			 )
	begin
			exec internal_bind_visual_element
				null,
				null,
				null,
				@newName_in
	end


end


-- update contained name -- check to ensure that the type is contained_name
if (@name_type = 1 or @containedByGobjectID = 0) or @name_type = 2   
begin
	-- First, update the object itself.....
	-- check to ensure that the contained name is unique within the tree...	
    if (@name_type = 2)
    begin
        IF EXISTS(  select  * 
                    from    gobject 
                    where   contained_name = @newName_in 
                    and     contained_by_gobject_id = @containedByGobjectID 
                    and     gobject_id <> @gobject_id
                    and     gobject_id <> @containedByGobjectID )
	BEGIN
		set @errorCode = 1007 -- eDuplicateContainedNameNotAllowed
		ROLLBACK TRAN
		return
	END
    end

	-- update contained name only if object is area or application object 	           
    IF (@isAreaApplicationOrCustomObject = 1) and (@name_type = 2) 
        BEGIN
		-- update contained name	
		update gobject set contained_name = @newName_in where gobject_id = @gobject_id 
       END       

	-- update all the hierachial name for descendant objects 
	-- and add them to @effectedObjects
	declare @objCount integer
	declare @nLevel integer
	select @objCount = count(*) from @effectedObjects
	
	IF @objCount > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN
	
			update gobject set hierarchical_name = dbo.generate_hierarchical_name(G.gobject_id)
			from gobject G inner join @effectedObjects O on G.gobject_id = O.obj_id
			where nLevel = @nLevel
	
			update gobject set tag_name = hierarchical_name
			from gobject G inner join @effectedObjects O on G.gobject_id = O.obj_id
			where nLevel = @nLevel and G.is_template = 1
	
			insert into @effectedObjects
			select gobject_id, CI.obj_id, @nLevel + 1
			from gobject G inner join @effectedObjects CI on G.contained_by_gobject_id = CI.obj_id
			where nLevel = @nLevel
	
			if @@rowcount = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END
END

declare @effectedTemplates table(gobject_id int);

WITH TemplateHierarchy (gobject_id, derived_from_gobject_id) AS
(
   -- Base case
   SELECT
      gobject_id,
	  0 as derived_from_gobject_id
   FROM gobject
   WHERE gobject_id = @gobject_id and is_template = 1

   UNION ALL

   -- Recursive step
   (SELECT
      g.gobject_id,
      g.derived_from_gobject_id
   FROM gobject g
      INNER JOIN TemplateHierarchy th ON
      g.derived_from_gobject_id = th.gobject_id and g.is_template = 1)
)

insert into @effectedTemplates
select gobject_id from TemplateHierarchy

insert into @effectedTemplates
select distinct gobject_id from visual_element_reference 
where (checked_in_bound_visual_element_gobject_id = @gobject_id) or (checked_out_bound_visual_element_gobject_id = @gobject_id)

if (@name_type = 2)
begin 

	declare @owner_of_reference int
	declare @is_template bit
	select 
		@owner_of_reference =
		case is_template 
		when 0
			then derived_from_gobject_id
		else
		   @gobject_id
		end,
		@is_template = is_template
	from gobject
	where gobject_id = @gobject_id
	
	if(@is_template = 1)
	begin
		exec internal_progogate_visual_element_reference_change_after_rename_of_contained_name @owner_of_reference
	end
	else
	begin
		exec internal_refresh_inherited_ver_after_rename_of_contained_name @gobject_id 
	end

end

----Get the list of @effectedObjects ---
SELECT eo.obj_id, td.category_id  
FROM @effectedObjects eo,
gobject gob,
template_definition td
where 
eo.obj_id= gob.gobject_id and gob.template_definition_id = td.template_definition_id 


--IO binding changes: need to update the time stamp for the linked app objects
if (@ioBindindPostProcRequired <> 0)
begin 
    declare @ret_status int

    exec @ret_status = internal_ab_handle_dio_change @gobject_id

    if @ret_status = 1
    begin
    	set @updategalaxy = 1        
    end
end

if (@isDeviceIntegrationInstanceObject = 1)
begin
	--check if any objects are linked to it or not
	
	update pt
	set pt.gobject_id = pt.gobject_id
	from proxy_timestamp pt
	inner join object_device_linkage odl on
	odl.gobject_id = pt.gobject_id
	and odl.dio_id = @gobject_id

	set @updategalaxy = 1
end

	if @updategalaxy  = 1
	begin
        	UPDATE galaxy
           	SET max_proxy_timestamp = CAST (@@dbts  AS timestamp)
	end

-- Start: Fix for CR L00134970: Ported from HF L00137148
--From @effectedTemplates, identify if there is any itvapp template is there or not
--if yes get the list of its instances..
--then update the proxy time stamp for all the isntances.
declare @intouch_viewapp_instances table 
	(gobject_id int)
insert into @intouch_viewapp_instances
			(
				gobject_id
			)	
select distinct g.gobject_id 
from gobject g
inner join @effectedTemplates afft on
g.derived_from_gobject_id = afft.gobject_id 
inner join template_definition td on
g.template_definition_id = td.template_definition_id
and td.category_id = 26 --Only ITVAPP
where g.is_template = 0 -- Only instances

-- Update the proxy timestamps of the instances...
if exists (select 1 from @intouch_viewapp_instances)
begin
	update pt
	set pt.gobject_id = pt.gobject_id
	from proxy_timestamp pt
	inner join @intouch_viewapp_instances itvappinstance
	on pt.gobject_id = itvappinstance.gobject_id
	
	declare @max_proxy_timestamp bigint
	select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

	update galaxy
	set max_proxy_timestamp = @max_proxy_timestamp
end
-- End: Fix for CR L00134970: Ported from HF L00137148

----Get the list of @effectedTemplates
SELECT distinct gobject_id from @effectedTemplates

exec internal_bind_relative_visual_elements_for_gobjects 


COMMIT TRAN
END-- Proc end


go

