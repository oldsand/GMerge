create trigger trigger_insert_gobject_change_log
    on gobject_change_log
    for insert
as
    set nocount on
    declare @operation_id int
    select  @operation_id = operation_id from inserted
    if (@operation_id = 14 or @operation_id = 30) -- Create Instance or Rename Tag_name..
    begin
        declare @tag_name nvarchar(329)
        declare @gobject_id int
        select @gobject_id = gobject_id from inserted
    
        select @tag_name = tag_name from gobject where @gobject_id
           = gobject_id 
        
        if exists (select '*' from gobject_log_details
        where gobject_id = @gobject_id)
        begin
            update gobject_log_details set tag_name = @tag_name where gobject_id = @gobject_id
        end
        else
        begin
            insert  gobject_log_details values (@gobject_id, @tag_name)
        end
    end
go

