/**************************************************
Object Name :  internal_multi_save_for_set_undeploy_status
Object Type :  Stored Proc. 
Purpose	    :  This procedure used for set  undeploy status
				and marking runtime files to undeploy
Used By	    :  CCdi::MultiSaveForSetUnDeployStatus
**************************************************/

create procedure dbo.internal_multi_save_for_set_undeploy_status
	@FileNameOfIds nvarchar (265),	
	@mx_platform_id int,    
	@isRedeployOriginal int,
	@attribute_translation_required int out    
as
begin

set nocount on

begin tran

	SET QUOTED_IDENTIFIER OFF		
		create table  #gobjects_undeployed( gobject_id int)
		DECLARE @SQL nvarchar(2000)
		SET @SQL = 'BULK INSERT #gobjects_undeployed  FROM ''' + @FileNameOfIds + ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
		EXEC (@SQL)
		---- 1.Mark undeployed status for the objects 

		--don't move this one down, this is looking packge_type
		--exec internal_fix_intouch_viewapp_folders @FileNameOfIds
		
-- new block...
    	update package 
		set package.package_type = 'L'
		from gobject
			inner join #gobjects_undeployed 
				on gobject.gobject_id = #gobjects_undeployed.gobject_id
        inner join package p on p.gobject_id = #gobjects_undeployed.gobject_id
                and gobject.deployed_package_id = p.package_id and p.package_type = 'D'
                and gobject.gobject_id in (select gobject_id from package where package_type = 'I')      

    	update package 
		set package.package_type = 'I'
		from gobject
			inner join #gobjects_undeployed 
				on gobject.gobject_id = #gobjects_undeployed.gobject_id
        inner join package p on p.gobject_id = #gobjects_undeployed.gobject_id
                and gobject.deployed_package_id = p.package_id 
                and p.package_type = 'D'       --new piece...
        
    	update gobject 
		set gobject.deployed_package_id = 0,		    
			gobject.software_upgrade_needed = 0,
			gobject.deployment_pending_status = 0
		from gobject 
			inner join #gobjects_undeployed 
				on gobject.gobject_id = #gobjects_undeployed.gobject_id	


	
    --delete attribute info from attributes_translation_table
    exec internal_attributeTranslationRequired @attribute_translation_required out

    if(@attribute_translation_required = 1 )    
    begin
        delete  attributes_translation_table
        from attributes_translation_table inner join #gobjects_undeployed
        on attributes_translation_table.gobject_id = #gobjects_undeployed.gobject_id

        select @attribute_translation_required = count(*) from attributes_translation_table
    end
    
		-----2. If platform gets undeployed, then Mark files to undeploy
		declare @platformcount int
		select @platformcount = count(*) from platform where 
			platform.platform_gobject_id in (select gobject_id from #gobjects_undeployed)
		if(@platformcount > 0 )
		begin
			--1. Get node name
			DECLARE @node_name as nvarchar(256)
			SELECT @node_name = case platform.last_deployed_node_name 
			when '' then platform.node_name 
			else platform.last_deployed_node_name 
			end
			FROM platform 
			inner join #gobjects_undeployed
			on platform.platform_gobject_id = #gobjects_undeployed.gobject_id
			
			-- 2 Update file_pending_update table..remove the entries for all the files from file_pending_update which will get removed on undeploy
			delete from file_pending_update where 
			((node_name = @node_name) and 
				(	file_id in (select distinct file_id from 
					deployed_file where 
					deployed_file.is_runtime_deployed = 1 and 
					deployed_file.is_package_deployed = 0 and
					deployed_file.is_editor_deployed = 0
				)
			)) 

			-- 3 Update deployed_file table
			update deployed_file
			set is_runtime_deployed = 0			
			where deployed_file.is_runtime_deployed = 1 and	
					  deployed_file.node_name = @node_name 					
			
			-- 4 Set last_deployed_node_name = ''
			update platform set
				platform.last_deployed_node_name = '',
				platform.last_deployed_rmcNode_name = '',
				platform.last_deployed_portNMX = 0,
				platform.last_deployed_portRMC = 0,
				platform.last_deployed_portRPC = 0
			where platform.last_deployed_node_name = @node_name				

		end
		-----------------------------------

		--delete deployed_intouch_viewapp only if it is not RedeployOriginal
        if(@isRedeployOriginal <> 1)
        begin
        
        update gobject 
		set gobject.last_deployed_package_id = 0			
		from gobject 
			inner join #gobjects_undeployed 
				on gobject.gobject_id = #gobjects_undeployed.gobject_id	
				        
        delete from deployed_intouch_viewapp
        where gobject_id in        
            (select g.gobject_id
             from #gobjects_undeployed u
             inner join gobject g
             	on g.gobject_id = u.gobject_id
             inner join template_definition td on
             g.template_definition_id = td.template_definition_id
             where td.category_id = 26)

		end

        delete from 
        deployed_intouch_viewapp_visual_element_dependency
        where gobject_id in        
            (select g.gobject_id
             from #gobjects_undeployed u
             inner join gobject g
             	on g.gobject_id = u.gobject_id
             inner join template_definition td on
             g.template_definition_id = td.template_definition_id
             where td.category_id = 26)

		drop table #gobjects_undeployed

commit tran

end

go

