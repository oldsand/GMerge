
CREATE  procedure dbo.internal_can_do_undo_checkout
-- send list of object ids to sql as XMLDoc
@FileNameOfIds nvarchar (265)
AS
SET NOCOUNT ON
begin

--reasoncode 
--1 : Object is not exist
--2 : Object is already Checked_in

	Declare @gobject_ids table (gobject_id int,reasoncode int default 0)


	SET QUOTED_IDENTIFIER OFF

	CREATE TABLE  #results_table ( gobject_id int)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')'

	EXEC sp_executesql @SQL

	insert into @gobject_ids( gobject_id )
		( select gobject_id from #results_table )
	
	drop table #results_table


--1 : Object is not exist
update @gobject_ids
set		reasoncode = 1				
where	gobject_id NOT IN(select gobject_id from gobject)

--2 : Object is already Checked_in
update @gobject_ids set reasoncode = 2
from @gobject_ids  goids
left join gobject
on goids.gobject_id = gobject.gobject_id		
where gobject.checked_out_package_id=0

--Now return all
select gobject_id,reasoncode from  @gobject_ids


end

go

