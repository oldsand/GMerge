CREATE PROCEDURE dbo.internal_import_alarm_messages
(
	@locale_id smallint,

	@alarmToPhraseMapFilePath nvarchar(265),
	-- Unicode CSV: [ObjectTagname].[AlarmName],[PhraseId]

	@translationFilePath nvarchar(265),
	-- Unicode CSV: [PhraseId],[Default Message],[Translated Message] 

	@error_code int out 
	-- Reports success or failure of the entire operation 
	-- (e.g. locale not available)

	-- Returns the status of each imported alarm translations in a dataset containing the full alarm name
	-- and a corresponding result code:
	--	1= Set successfully								
	--	2= Not set: Alarm not found  
	--	3= Not set: Default alarm message mismatch
)
AS
BEGIN
	set nocount on

	if not exists (select 1 from supported_locales sls where sls.locale_id = @locale_id)
	begin
		set @error_code = 1000
		return
	end

	UPDATE STATISTICS alarm_message_timestamps
	UPDATE STATISTICS alarm_messages
	UPDATE STATISTICS alarm_message_defaults
	UPDATE STATISTICS alarm_message_translations

	create table #new_alarm_messages
	(	
		phrase_id int,
		full_alarm_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS primary key		
	)
	
	DECLARE @SQL nvarchar(1000)
	SET @SQL = 'BULK INSERT #new_alarm_messages FROM ''' + @alarmToPhraseMapFilePath + ''' WITH (FIELDTERMINATOR = ''\t'', TABLOCK, DATAFILETYPE  = ''widechar'' ) '
	EXEC (@SQL)

	create table #new_alarm_message_translations
	(
		phrase_id int PRIMARY KEY,
		default_message nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS,
		translated_message nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS
	)

	-- '\0' non visible field terminator will be used for the translation file, it can't appear in data
	SET @SQL = 'BULK INSERT #new_alarm_message_translations FROM ''' + @translationFilePath + ''' WITH (FIELDTERMINATOR = ''\0'', TABLOCK, DATAFILETYPE  = ''widechar'' ) '
	EXEC (@SQL)

	declare @updated_alarm_phrases table 
	(
		phrase_id int primary key,
		result tinyint
	)

	declare @updated_alarm_results table 
	(
		full_alarm_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS primary key,
		result tinyint
	)

	-- insert new translation records if not null and not present in database
	insert into alarm_message_translations 
	select distinct uams.phrase_id, @locale_id, namts.translated_message from unlocalized_alarm_messages(@locale_id) uams 
	inner join #new_alarm_messages nams on nams.full_alarm_name = uams.Name
	inner join #new_alarm_message_translations namts on namts.phrase_id = nams.phrase_id 
	where --uams.indexable_default_message = left(namts.default_message,450) and 
		namts.default_message = uams.default_message and
		namts.translated_message is not null


	-- Do the actual update - remember any phrase that was sucessfully translated
	update internal_localized_alarm_messages
	set translated_message = namts.translated_message
	output nams.phrase_id, 1 into @updated_alarm_phrases
	from internal_localized_alarm_messages lams
	inner join #new_alarm_messages nams on nams.full_alarm_name = lams.Name
	inner join #new_alarm_message_translations namts on namts.phrase_id = nams.phrase_id 
	where lams.locale_id = @locale_id and --lams.indexable_default_message = left(namts.default_message,450) and 
		namts.default_message = lams.default_message and
		namts.translated_message is not null

	-- Also mark any alarm phrase as "successfully" translated if its translation was not specified
	insert into @updated_alarm_phrases
	select namts.phrase_id, 1 from #new_alarm_message_translations namts 
	where namts.translated_message is null
		
	--
	-- Now we need to set the return status correctly for each alarm
	--

	-- Add success rows for any alarm whose phrase was reported 
	-- successful above because its translation was not specified
	insert into @updated_alarm_results
	select nams.full_alarm_name, 1 from #new_alarm_messages nams 
	inner join #new_alarm_message_translations namts on namts.phrase_id = nams.phrase_id 
	inner join @updated_alarm_phrases uaps on uaps.phrase_id = nams.phrase_id
	where namts.translated_message is null 

	-- Also add success rows for any alarm whose translation was actually updated
	insert into @updated_alarm_results
	select nams.full_alarm_name, 1 from #new_alarm_messages nams 
	inner join @updated_alarm_phrases uaps on uaps.phrase_id = nams.phrase_id
	inner join internal_localized_alarm_messages lams on lams.Name = nams.full_alarm_name 
	inner join #new_alarm_message_translations namts on namts.phrase_id = nams.phrase_id 
	where namts.translated_message is not null and lams.locale_id = @locale_id


	-- Optimization: Create a table containing all the alarm names that will be used below to detect nonexistent alarms.
	declare @all_alarm_names table 
	(
		full_alarm_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS primary key
	)
	insert into @all_alarm_names
	select Name from internal_all_alarms_view aav 
	inner join #new_alarm_messages nams on nams.full_alarm_name = aav.name
	
	-- Add additional result codes for the translations that were not updated
	insert into @updated_alarm_results
	select nams.full_alarm_name, 
		   ( select case when exists(select 1 from @all_alarm_names aans where nams.full_alarm_name = aans.full_alarm_name) 
			 then 3 else 2 end ) 
	from #new_alarm_messages nams 
	left join @updated_alarm_results uars on uars.full_alarm_name = nams.full_alarm_name
	where uars.full_alarm_name is null

	select * from @updated_alarm_results where result <> 1 order by full_alarm_name 
	
	drop table #new_alarm_messages
	drop table #new_alarm_message_translations

	set @error_code = 0
	
END
go

