-- finds the visual_element_id for a given VE reference
-- sets the visual_element_id to 0 if VE cannot be resolved..
-- System will attempt to bind this reference at a later time
create proc dbo.internal_resolve_visual_element_reference
  @gobject_id int,
  @package_id int,
  @mx_primitive_id smallint,
  @visual_element_reference_index int,
  @reference_string nvarchar(3620)
as
begin
    set nocount on
    declare @visual_element_id int
    declare @visual_element_name nvarchar(3620)
    declare @visual_element_type nvarchar(329)
    declare @tag_name nvarchar(32)
    declare @primitive_name nvarchar(329)
    declare @is_relative_reference bit
    declare @relative_object_name nvarchar(329)
    declare @is_hierarchical_visual_element_name bit
    
    set @relative_object_name = ''
    -- break the reference down into its parts
    set @primitive_name = N'' -- initialize out param
    exec internal_parse_visual_element_reference_string
        @reference_string,
        @visual_element_type output,
        @tag_name output,
        @primitive_name output,
        @visual_element_name output,
        @is_relative_reference output,
        @relative_object_name output,
        @is_hierarchical_visual_element_name output
       
    if(@is_relative_reference = 1)  
    begin
        -- the tag_name is not relevant, so we will not store it..
        set @tag_name = null
	end



    -- add to visual_element_reference table

    if(@is_hierarchical_visual_element_name = 0)
    begin
        insert into #visual_element_reference_info
           (gobject_id,
            package_id,
            mx_primitive_id,    
            visual_element_reference_index,
            is_relative_reference,
            -- target section
            visual_element_name ,
            visual_element_type,
            tag_name,
            primitive_name ,
            relative_object_name) 
    
        values
            
           (@gobject_id,
            @package_id,
            @mx_primitive_id,
            @visual_element_reference_index,
            @is_relative_reference,
            -- target section
            @visual_element_name,
            @visual_element_type,
            @tag_name,
            @primitive_name,
            @relative_object_name)
    end
    else -- visual element is being resolved by hierarchical_visual_element_name
    begin
        insert into #visual_element_reference_info
           (gobject_id,
            package_id,
            mx_primitive_id,    
            visual_element_reference_index,
            is_relative_reference,
            -- target section
            hierarchical_visual_element_name,
            visual_element_type,
            tag_name,
            primitive_name ,
            relative_object_name) 
    
        values
            
           (@gobject_id,
            @package_id,
            @mx_primitive_id,
            @visual_element_reference_index,
            @is_relative_reference,
            -- target section
            @visual_element_name,
            @visual_element_type,
            @tag_name,
            @primitive_name,
            @relative_object_name)
    
    end
end

go

