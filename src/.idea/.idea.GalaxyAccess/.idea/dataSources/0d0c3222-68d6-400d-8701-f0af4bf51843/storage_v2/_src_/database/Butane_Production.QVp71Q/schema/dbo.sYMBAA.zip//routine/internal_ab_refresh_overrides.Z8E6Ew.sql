/*
** Procedure [internal_ab_refresh_overrides]
** This is an internal sproc, typically invoked by internal_ab_assign_app_object_to_device.
** It refreshes alias entries made by autobound_attributes that have endured name changes (tag- or attribute-name).
*/
CREATE PROCEDURE dbo.internal_ab_refresh_overrides
    @dio_id               int
    , @sg_mx_primitive_id smallint = 0
as
begin
  set nocount on

  UPDATE ab_attr
     SET ab_attr.attr_alias = dbo.internal_ab_evaluate_translation_rule (bind_info.default_attr_reference, bind_info.xlate_rule_id)
    FROM autobound_attribute ab_attr
  CROSS APPLY (SELECT * from itvfGetAutobindInfoForDIO (ab_attr.dio_id, ab_attr.sg_mx_primitive_id, ab_attr.gobject_id, DEFAULT, DEFAULT) bi 
                WHERE bi.lo_prim_id = ab_attr.mx_primitive_id
                  AND bi.lo_attr_id = ab_attr.mx_attribute_id
                  AND bi.lo_element_index = ab_attr.element_index
                  AND bi.xlate_rule_id > 0) bind_info
   WHERE ab_attr.dio_id  = @dio_id
     AND ab_attr.sg_mx_primitive_id = (CASE WHEN @sg_mx_primitive_id <> 0 THEN @sg_mx_primitive_id ELSE ab_attr.sg_mx_primitive_id END)

  RETURN 0
end
go

