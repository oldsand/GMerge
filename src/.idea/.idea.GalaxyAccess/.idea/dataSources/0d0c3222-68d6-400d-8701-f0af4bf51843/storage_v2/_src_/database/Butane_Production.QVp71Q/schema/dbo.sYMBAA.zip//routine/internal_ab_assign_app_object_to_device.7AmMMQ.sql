/*
** Procedure [internal_ab_assign_app_object_to_device]
** This is typically called from internal_ab_set_linkage.
*/
CREATE PROCEDURE dbo.internal_ab_assign_app_object_to_device
    @gobject_id               int               -- ID of the @gobject whose attributes are to be [re[assigned
    , @dio_id                 int               -- DIO to which @gobject's attributes are to be [re]assigned
    , @sg_mx_primitive_id     smallint          -- SG (within @dio_id) to which @gobject's attributes are to be [re]assigned
    , @old_sg_mx_primitive_id smallint = 0      -- SG from which @gobject's attributes are to be reassigned
    , @old_dio_id             int = 0           -- DIO from which @gobject's attributes are to be reassigned
as
begin
    set nocount on
    declare @result int
    declare @attrs_relocated int
    set @result = 0
    set @attrs_relocated = 0

    -- First, verify that a topic exists for @dio_id that has an mx_primitive_id of @sg_mx_primitive_id
    if NOT EXISTS (select * from autobind_device_topic where dio_id = @dio_id and sg_mx_primitive_id = @sg_mx_primitive_id)
        RETURN -1    -- bad assignment

    /*
    ** An attribute of an object may only be assigned to a single dio|scan-group. Also, for now, we do not support the relocation of individual 
    ** attributes of an object. That, however, doesn't imply that the attributes of an application object may not be distributed across (linked to)
    ** more than one DIO (dio|scan-group). It only means that the smallest unit of relocation is all attributes of an object that are linked to
    ** the scan-group of a DIO, and the largest unit of relocation is all attributes of an object that are lined to a DIO (across all configured
    ** scan-groups for the DIO).
    ** Assume that @gobject_id represents an object that's already been assigned to a DIO, simply update its linkage info in autobound_attribute.
    ** The specification of @old_dio_id and @old_sg_mx_primitive_id requires some discussion:
    ** - If both are 0 (default), neither is used in the update where clause: The change in assignment to @gobject_id's attribute is global.
    ** - If only @old_dio_id is non-zero, only those attributes of @gobject_id's that are assigned to @old_dio_id are selected for reassignment.
    ** - If both @old_dio_id and @old_sg_mx_primitive_id are non-zero, then only those attributes assigned to a combination thereof are reassigned.
    ** - If only @sg_mx_primitive_id is non-zero, and equivalency is established between @old_dio_id and @dio_id
    */
    if @old_dio_id <> 0 AND @old_dio_id <> @dio_id OR @old_sg_mx_primitive_id <> 0 AND @old_sg_mx_primitive_id <> @sg_mx_primitive_id
    begin
        if @old_dio_id = 0      -- the dio equivalency case
            set @old_dio_id = @dio_id

/**      
		-- Move old aliases created for this app object in the old SG to the new SG
        MERGE   autobound_attribute_alias AS new_sg_aliases
        USING   (
            SELECT @dio_id AS dio_id
                 , @sg_mx_primitive_id AS sg_mx_primitive_id
                 , aliases.attr_name
                 , aliases.attr_alias
                 , aliases.xlate_rule_id
              FROM autobound_attribute_alias AS aliases
        	  INNER JOIN autobound_attribute abattrs 
                ON abattrs.dio_id = aliases.dio_id
               AND abattrs.sg_mx_primitive_id = aliases.sg_mx_primitive_id
               AND abattrs.alias_id = aliases.alias_id
               AND abattrs.gobject_id = @gobject_id
             WHERE aliases.dio_id = @old_dio_id
               AND aliases.sg_mx_primitive_id = CASE WHEN @old_sg_mx_primitive_id <> 0 THEN @old_sg_mx_primitive_id ELSE aliases.sg_mx_primitive_id END
        ) AS old_sg_aliases 
        ON (new_sg_aliases.dio_id = old_sg_aliases.dio_id AND new_sg_aliases.sg_mx_primitive_id = old_sg_aliases.sg_mx_primitive_id AND new_sg_aliases.attr_name = old_sg_aliases.attr_name)
        WHEN NOT MATCHED BY TARGET -- Existing alias entries take precedence over merges, so don't handle the "WHEN MATCHED" case.
        THEN INSERT(dio_id, sg_mx_primitive_id, attr_name, attr_alias, xlate_rule_id) 
             VALUES(old_sg_aliases.dio_id, old_sg_aliases.sg_mx_primitive_id, old_sg_aliases.attr_name, old_sg_aliases.attr_alias, old_sg_aliases.xlate_rule_id);
**/
        -- Perform 'move' of attributes from old sg to new
        UPDATE autobound_attribute
           SET dio_id = @dio_id
             , sg_mx_primitive_id = @sg_mx_primitive_id
         WHERE gobject_id = @gobject_id
           AND dio_id = @old_dio_id
           AND sg_mx_primitive_id = CASE WHEN @old_sg_mx_primitive_id <> 0 THEN @old_sg_mx_primitive_id ELSE sg_mx_primitive_id END

        set @attrs_relocated = @@ROWCOUNT
    end
    
    if @attrs_relocated = 0 
        EXECUTE internal_ab_refresh_autobound_attrs @gobject_id, @dio_id, @sg_mx_primitive_id
	-- else
 --        -- All assignable attributes have now been reassigned to the new device|scan-group. Identify and press into service usable aliases.
 --        EXECUTE internal_ab_refresh_attribute_aliases @gobject_id, @dio_id, @sg_mx_primitive_id 

    RETURN 0
end
go

