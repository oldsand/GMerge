create procedure dbo.internal_record_visual_element_changes
@gobject_id int,
@package_id int,
@user_guid uniqueidentifier
as
set nocount on
begin tran
	declare @change_detected bit
	set @change_detected = 0

declare @updated_visual_element_ids table(visual_element_id int)

-- handle deleted visual elements....
	declare @temp_deleted_visual_elements table(	gobject_id int,
						package_id int,
						mx_primitive_id int,
						visual_element_name nvarchar(329),
						visual_element_type nvarchar(32),
						visual_element_id int)

	insert into @temp_deleted_visual_elements
	(
		gobject_id ,
		package_id ,
		mx_primitive_id ,
		visual_element_name ,
		visual_element_type,
		visual_element_id
	)









	select 
		va.gobject_id,
		va.package_id,
		va.mx_primitive_id,
		va.visual_element_name,
		va.visual_element_type,
		va.visual_element_id
	from visual_element_archive va
	where va.persisted_for_gobject_id =@gobject_id and
		va.visual_element_id not in
		(
			select 
				visual_element_id
			from internal_visual_element_description_per_user_view
			where gobject_id = @gobject_id and
				  package_id = @package_id and
				  user_guid = @user_guid

		)

	if(@@rowcount > 0)
	begin
		set @change_detected = 1
		insert into deleted_visual_element_version
		(
				gobject_id ,
				package_id ,
				mx_primitive_id ,
				visual_element_name ,
				visual_element_type,
				visual_element_id
		)
		select 	gobject_id ,
				package_id ,
				mx_primitive_id ,
				visual_element_name ,
				visual_element_type,
				visual_element_id 
		from @temp_deleted_visual_elements
	end

-- handle renamed visual elements...
	declare @temp_renamed_visual_elements table(
											 gobject_id int,
											 package_id int,
											 mx_primitive_id int,
											 visual_element_id int,
											 old_visual_element_name nvarchar(329),
											 new_visual_element_name nvarchar(329),
											 visual_element_type nvarchar(32))
							
	insert into @temp_renamed_visual_elements
		(
		 gobject_id,
		 package_id,
		 mx_primitive_id,
		 visual_element_id ,
		 old_visual_element_name,
		 new_visual_element_name,








		 visual_element_type)
	select
		v.gobject_id,
		v.package_id,
		v.mx_primitive_id,
		v.visual_element_id,
		a.visual_element_name,
		v.visual_element_name,
		v.visual_element_type
	from internal_visual_element_description_per_user_view v
	inner join visual_element_archive a on
		v.gobject_id = @gobject_id and
		a.visual_element_id = v.visual_element_id and
		a.visual_element_name <> v.visual_element_name
	where v.user_guid = @user_guid

	if(@@rowcount > 0)
	begin
		insert into renamed_visual_element
		(
			gobject_id,
		    package_id,
		    mx_primitive_id,
		    visual_element_id ,
		    old_visual_element_name,
		    new_visual_element_name,
		    visual_element_type 
		)
		select  gobject_id,
			    package_id,
			    mx_primitive_id,
			    visual_element_id ,
			    old_visual_element_name,
			    new_visual_element_name,
			    visual_element_type 
		from @temp_renamed_visual_elements

		set @change_detected = 1
	end

	if(@change_detected <> 0)
	begin
		update galaxy
		set max_visual_element_timestamp = CAST ( @@dbts  AS timestamp ) 

		insert into @updated_visual_element_ids
		select visual_element_id from @temp_deleted_visual_elements
		union
		select visual_element_id from @temp_renamed_visual_elements
	end

	delete 
	from visual_element_archive
    where persisted_for_gobject_id = @gobject_id

	select distinct ver.gobject_id from internal_visual_element_reference_view ver
	inner join @updated_visual_element_ids up on up.visual_element_id = ver.visual_element_id
	inner join gobject g on g.gobject_id = ver.gobject_id
	where g.is_template = 1

commit

go

