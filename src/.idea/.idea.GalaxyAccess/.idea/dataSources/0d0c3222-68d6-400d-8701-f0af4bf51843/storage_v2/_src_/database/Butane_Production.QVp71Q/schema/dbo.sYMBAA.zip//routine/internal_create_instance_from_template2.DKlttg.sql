create proc dbo.internal_create_instance_from_template2
    @template_gobject_id int,
    @input_tag_name nvarchar(32),
    @new_instance_gobject_id int out,
    @derived_from_name nvarchar(32),
    @area_gobject_id int = 0,
    @hosted_by_gobject_id int = 0,
    @contained_by_gobject_id int = 0,
	@namespace_id int = 1
as
set nocount on

declare @host_tree_level smallint
declare @contained_by int
declare @contained_name nvarchar(32)
declare @tag_name nvarchar(32)

set @new_instance_gobject_id = 0

begin tran

if (len(@input_tag_name) = 0)
    exec internal_get_unique_name @derived_from_name, @namespace_id, @tag_name output
else
    set @tag_name = @input_tag_name
    

if (exists(
    select  1
    from    gobject
    where   tag_name = @tag_name
    and     namespace_id = @namespace_id))
begin
    rollback tran
    return
end
    
---------------------------------------
-- get the contained name 
---------------------------------------

select @contained_by = contained_by_gobject_id, @contained_name = contained_name, 
	   @host_tree_level = 
	   case 
			when category_id = 23 then 0 -- Galaxy 
			when category_id = 1 then 1  -- Platform
			when category_id < 10 then 2 -- Engine
			when category_id = 11 then 3 -- IONetwork
			when category_id = 24 then 3 -- idxCategoryPostIO
			when category_id = 13 then 3 -- Area
			else 4 
		end								--Applicationobjects	   
from gobject inner join template_definition on gobject.template_definition_id = template_definition.template_definition_id
where gobject_id = @template_gobject_id

IF @contained_by = 0  set @contained_name = ''

---------------------------------------
-- create the gobject row
---------------------------------------

insert into gobject
(
    template_definition_id,
    derived_from_gobject_id,
    contained_by_gobject_id,
    area_gobject_id,
    hosted_by_gobject_id,
    default_symbol_gobject_id,
    default_display_gobject_id,
    checked_in_package_id,
    checked_out_package_id,
    deployed_package_id,
    tag_name,
    contained_name,
    identity_guid,
    configuration_guid,
    configuration_version,
    is_template,
    is_hidden,
    software_upgrade_needed,
    hosting_tree_level,
    hierarchical_name,
	namespace_id

)
select
    template_definition_id,    -- template_definition_id
    gobject_id,                -- derived_from_gobject_id
    @contained_by_gobject_id,  -- contained_by_gobject_id
    @area_gobject_id,          -- area_gobject_id
    @hosted_by_gobject_id,     -- hosted_by_gobject_id
    0,                         -- default_symbol_gobject_id
    0,						   -- default_display_gobject_id
    0,                         -- checked_in_package_id
    0,						   -- checked_out_package_id
    0,						   -- deployed_package_id
    @tag_name,                 -- tag_name
    @contained_name,           -- contained_name
    NewId(),                   -- identity_guid
    NewId(),                   -- configuration_guid
    1,                         -- configuration_version
    0,                         -- is_template
    is_hidden,                 -- is_hidden
    0,                         -- software_upgrade_needed
    @host_tree_level,          -- hosting_tree_level
    @tag_name,                 -- hierarchical_name  
	@namespace_id			   -- namespace_id
from 
    gobject 
where 
    gobject_id = @template_gobject_id

select @new_instance_gobject_id = @@IDENTITY


---------------------------------------
-- create the instance row
---------------------------------------
if ( @host_tree_level = 2 )
	insert into instance ( gobject_id, mx_engine_id, mx_object_id ) values ( @new_instance_gobject_id, dbo.get_next_mx_engine_id(0), 1 )
else
	insert into instance ( gobject_id ) values ( @new_instance_gobject_id )


---------------------------------------
-- create the checked_in_package
---------------------------------------

declare @derived_from_package_id int

select	@derived_from_package_id = checked_in_package_id
from	gobject
where	gobject_id = @template_gobject_id
 
insert into package 
(
		gobject_id,
		status_id,
--		instance_attributes,
		security_group,
		derived_from_package_id
)
select	@new_instance_gobject_id,
		0, -- ePackageUnknownStatus
--		instance_attributes,
		security_group,
		package_id
from	package
where	package_id = @derived_from_package_id
and     gobject_id = @template_gobject_id

declare @new_instance_package_id int
select @new_instance_package_id = @@IDENTITY

-- record checked_in_package_id
update gobject 
set checked_in_package_id = @new_instance_package_id
where gobject_id = @new_instance_gobject_id


---------------------------------------
-- create primitive_instance rows
---------------------------------------

-- copy primitive_instance rows from template
insert into primitive_instance
(
    gobject_id,
    package_id,
    primitive_definition_id,
    primitive_name,
    mx_primitive_id,
    parent_mx_primitive_id,
    execution_group,
    execution_order,
	owned_by_gobject_id,
	extension_type,
	is_object_extension,
	entity_change_type,
	operation_on_primitive_mask,
    created_by_parent,
	status_id,
	ref_status_id,
	mx_value_errors,
	mx_value_warnings,
	mx_value_reference_warnings		    
)
select
    @new_instance_gobject_id,
    @new_instance_package_id,                   -- package_id
    primitive_definition_id, -- primitive_definition_id
    primitive_name,          -- primitive_name
    mx_primitive_id,         -- mx_primitive_id
    parent_mx_primitive_id,  -- parent_mx_primitive_id
    execution_group,         -- execution_group
    execution_order,         -- execution_order
	owned_by_gobject_id,		-- owned_by_gobject_id
	extension_type,   		-- extension_type
	is_object_extension,		-- is_object_extension
	1,
	0,
	1,
	status_id,
	ref_status_id,
	mx_value_errors,
	mx_value_warnings,
	mx_value_reference_warnings		    	
from  primitive_instance 
where primitive_instance.gobject_id = @template_gobject_id 
and   primitive_instance.package_id = @derived_from_package_id


---------------------------------------
-- create dynamic_attribute rows
---------------------------------------

-- insert appropriate attribute rows from the parent
insert into dynamic_attribute
(
	gobject_id,
	package_id,
	mx_primitive_id,
	mx_attribute_id,
	attribute_name,
	mx_data_type,
	is_array,
	security_classification,
	mx_attribute_category,
	lock_type,
	mx_value,
	owned_by_gobject_id,
	original_lock_type,
    dynamic_attribute_type,
    bitvalues
)
select 
    @new_instance_gobject_id,
    @new_instance_package_id,                   -- package_id
    parent_dynamic_attribute.mx_primitive_id, 
    parent_dynamic_attribute.mx_attribute_id,       
	parent_dynamic_attribute.attribute_name,
	parent_dynamic_attribute.mx_data_type,
	parent_dynamic_attribute.is_array,
	parent_dynamic_attribute.security_classification,
	parent_dynamic_attribute.mx_attribute_category,
	case when parent_dynamic_attribute.lock_type = 1 then -- lock_type
  		 2
  	else
         parent_dynamic_attribute.lock_type               	
    end
    as lock_type,
	parent_dynamic_attribute.mx_value,
	case when parent_dynamic_attribute.mx_primitive_id = 2 then -- Common Primitive (UDAs)
  		 parent_dynamic_attribute.owned_by_gobject_id
  	else
         @new_instance_gobject_id               	
    end
    as owned_by_gobject_id,
	case when parent_dynamic_attribute.lock_type = 1 then -- lock_type
  		 2
  	else
         parent_dynamic_attribute.lock_type               	
    end as original_lock_type,
    parent_dynamic_attribute.dynamic_attribute_type,
    parent_dynamic_attribute.bitvalues
from 
	dynamic_attribute parent_dynamic_attribute
where 
    parent_dynamic_attribute.package_id = @derived_from_package_id
and parent_dynamic_attribute.gobject_id = @template_gobject_id


---------------------------------------
-- create primitive_instance_feature_link
---------------------------------------

--insert appropriate feature rows from the parent
insert into primitive_instance_feature_link
(
	gobject_id,
	package_id,
	mx_primitive_id,
    feature_id,
    feature_name,
    feature_type
)

select 
    @new_instance_gobject_id,
    @new_instance_package_id,                   -- package_id
    primitive_instance_feature_link.mx_primitive_id,
    primitive_instance_feature_link.feature_id,
    primitive_instance_feature_link.feature_name,
    primitive_instance_feature_link.feature_type
from 
    primitive_instance_feature_link
where 
    primitive_instance_feature_link.package_id = @derived_from_package_id
and primitive_instance_feature_link.gobject_id = @template_gobject_id

insert into proxy_timestamp(gobject_id)
select @new_instance_gobject_id

insert into gobject_filter_info_timestamp(gobject_id)
select @new_instance_gobject_id


commit
go

