-- deletes a single gobject row, and all dependencies
create procedure dbo.internal_delete_fsobject
            @gobject_id int, -- gobject to delete
            @clean_user_info int 
AS
begin tran

    set nocount on
    ---------------------------------------------

    -- sanity checks

    ---------------------------------------------

    -- start failover

    declare @failOverPartnerID int
    declare @is_failover_enabled int
    declare @tagName nvarchar(329)
    declare @isFullyUndeployed int
    declare @mustUpdateUserProfile bit
    declare @derivedFromgObjectID int
    declare @is_object_a_template bit

	-- if object is a Visual Element Library symbol,
	-- record the deletion for polling clients..
	insert into deleted_visual_element_version
	(
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_name,
		visual_element_type,
		visual_element_id
	)
	select
		v.gobject_id ,
		v.package_id ,
		v.mx_primitive_id ,
		v.visual_element_name ,
		v.visual_element_type,
		v.visual_element_id
	from internal_visual_element_description_view v (noexpand)
	where 
		v.gobject_id = @gobject_id
		

	if(@@rowcount > 0)
	begin
		update galaxy
		set max_visual_element_timestamp = CAST ( @@dbts  AS timestamp ) 
	end

	declare @effectedITVAList table(gobject_id int)
	insert into @effectedITVAList
	select distinct gobject_id from visual_element_reference 
	where (checked_in_bound_visual_element_gobject_id = @gobject_id) or (checked_out_bound_visual_element_gobject_id = @gobject_id)

    -- first, we will find out the type of object that we are attempting to delete
    -- we will use this information to update the user_profile table..  
    declare @category_id int
    
    select 
        @category_id =  td.category_id,
        @tagName = g.tag_name,
        @derivedFromgObjectID =  derived_from_gobject_id,
        @is_object_a_template = is_template
    from gobject g 
    inner join template_definition td on 
        g.template_definition_id = td.template_definition_id    
    where g.gobject_id = @gobject_id

	-- delete from folder_gobject_link
    delete from folder_gobject_link where gobject_id = @gobject_id
    -- check to see if fsObject is failoverenabled.....
    select @is_failover_enabled = dbo.is_failover_enabled_for_gobject_id(@gobject_id)


    -- if failover enabled, we must perform checks and delete failover partner as well....

    if (@is_failover_enabled >= 1) 
        begin
            declare @isPrimary int
            select @isPrimary = internal_list_objects_view.IsPrimaryEngine ,
                   @failOverPartnerID = dbo.get_failover_partner_id(@gobject_id),
                   @isFullyUndeployed = (case when  (internal_list_objects_view.deployed_package_id = 0 and dbo.is_partner_deployed(internal_list_objects_view.gobject_id) = 0) then '1' else '0' end) 
            from 
                    internal_list_objects_view 
            where   internal_list_objects_view.gobject_id = @gobject_id
            if ( @isPrimary = 1 )
               begin
                if (@isFullyUndeployed  = 1) 
                begin
                    -- delete object and backup partner...
                    delete from gobject where gobject_id in (@gobject_id,@failOverPartnerID)    
                    delete from redundancy where primary_gobject_id = @gobject_id
                    set @mustUpdateUserProfile = 1
                end
               end
            else
              begin  
                 if (@isFullyUndeployed  = 1) 
                begin
                    delete from gobject where gobject_id = @gobject_id
                    delete from redundancy where backup_gobject_id = @gobject_id
                    set @mustUpdateUserProfile = 0
                end
              end
        end
    else -- object is not failover enabled...
        begin
            delete from gobject where gobject_id = @gobject_id
            --delete from platform table
            delete from platform where platform.platform_gobject_id = @gobject_id
              if(@derivedFromgObjectID = 0) --if it is base template
              begin 
          declare @codebase_t nvarchar(322)
        set @codebase_t = (select codebase from template_definition where base_gobject_id = @gobject_id)

                if( (select count(*) from template_definition where codebase = @codebase_t) = 1)
				begin	
                    delete template_migration_policy 
                    from   template_migration_policy tmp
                    inner join template_definition td 
                            on td.base_gobject_id = @gobject_id
                           and td.codebase = tmp.migrate_to_codebase
                end

                delete  template_definition
                from    template_definition
                where   template_definition.base_gobject_id = @gobject_id
              end
            set @mustUpdateUserProfile = 1
        end 
        
    --START delete the gobject info from the intouchviewapptemplate_allsymbols table
    delete from intouchviewapptemplate_allsymbols where gobject_id = @gobject_id
	--END delete the gobject info from the intouchviewapptemplate_allsymbols table
        
	--START delete the gobejct id from the gobject_protected table
	delete from gobject_protected where gobject_id = @gobject_id
	--END

	--START: Delete the object information form the object linkage table
    if (@category_id = 11 OR @category_id = 12 OR @category_id = 24)
    begin
        delete from object_device_linkage where dio_id = @gobject_id
        delete from autobind_device where dio_id = @gobject_id
    end
    else    
    begin
        delete from ab_attr
          from autobound_attribute ab_attr
        inner join object_device_linkage odl 
            on odl.dio_id = ab_attr.dio_id
           and odl.sg_mx_primitive_id = ab_attr.sg_mx_primitive_id
           and odl. gobject_id = ab_attr.gobject_id
        where odl.gobject_id = @gobject_id
        delete from object_device_linkage where gobject_id = @gobject_id
    end
	--END

    -- now, update user_profile to remove object from default object column....
    if (@mustUpdateUserProfile = 1 and @clean_user_info = -1 )
    begin
        if (@category_id = 1)
        begin
            update user_profile set default_platform_tag_name = null
                where default_platform_tag_name = @tagName
        end
        else if (@category_id = 3)
        begin
            update user_profile set default_app_engine_tag_name = null      
                where default_app_engine_tag_name = @tagName
        end
   	    else if (@category_id = 4)
        begin
            update user_profile set default_view_engine_tag_name = null        
                where default_view_engine_tag_name = @tagName
        end         
        else if (@category_id = 13)
        begin
            update user_profile set default_area_tag_name = null        
                where default_area_tag_name = @tagName
        end


    end
    
    delete 
    from gobject_filter_info_timestamp
    where gobject_id = @gobject_id
    
	select gobject_id from @effectedITVAList

    
commit



go

