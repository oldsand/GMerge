/*
selects gobject_ids for all objects to be included in
the cascade deploy or undeploy of a given gObject
(based on IDE's Deployment View)
*/
Create PROCEDURE dbo.internal_get_deployment_view_children
    @gObjectId int
AS
set nocount on
begin

--first verify that object is of type galaxy 
if exists(select * from gobject g inner join template_definition td on 
g.template_definition_id = td.template_definition_id
and g.gobject_id = @gObjectId and td.category_id = 23)
begin
	select gobject_id from gobject where is_template = 0
	and gobject_id <>@gObjectId
	and namespace_id <> 3 
end
else
begin
		--All the objects which need are contained_by,hosted_by or assigned to a gobject_id
		--can be easily figure it out by either it is a platform,engine or area
		--If it is a platform
		declare @mx_platform_id int
		declare @mx_engine_id int
		declare @mx_object_id int
			select @mx_platform_id = mx_platform_id,@mx_engine_id = mx_engine_id,
			@mx_object_id = mx_object_id
			from instance where instance.gobject_id = @gObjectId
		--if it is platform
		--if @mx_engine_id = 1 and @mx_object_id = 1 
		if(@mx_engine_id = 1) AND (@mx_object_id = 1 )
		begin
			select gobject_id from instance where mx_platform_id = @mx_platform_id	
			and gobject_id <> @gObjectId
			return
		end
		--if it is engine
		--if @mx_engine_id <> 1 and @mx_object_id = 1 then it is engine
		if(@mx_engine_id > 1) AND (@mx_object_id = 1 )
		begin
			select gobject_id from instance where mx_platform_id = @mx_platform_id	
			and mx_engine_id = @mx_engine_id	
			and gobject_id <> @gObjectId
			return
		end
		--if it is area
		declare @category_id int
		begin
			select  @category_id = category_id from gobject inner join template_definition
			on gobject.template_definition_id = template_definition.template_definition_id
			where gobject_id = @gObjectId
		end
		--take action now..
		if(@category_id = 13 )
		begin
			select gobject_id from gobject where (hosted_by_gobject_id = @gObjectId )
			return
		end
		-- table for return value
		declare @ResultSet table( gid int)

		-- table for gobjects in a particular iteration in the while loop
		create table #WorkingSet ( gid int)

		insert into #WorkingSet values( @gObjectId )

		-- table for list of gobjects that are direct children of a specific gobject
		declare @DirectChildSet table( gid int)

		insert into @DirectChildSet( gid )
		( 
			select gobject_id from gobject 
				inner join template_definition t
					on t.template_definition_id = gobject.template_definition_id
			where
			   ( t.category_id = 10 and contained_by_gobject_id > 0 and contained_by_gobject_id  in (select * from #WorkingSet) )
			   or
			   ( t.category_id = 10 and contained_by_gobject_id = 0 and area_gobject_id in (select * from #WorkingSet) )
			   or
   			   ( t.category_id = 25 and contained_by_gobject_id > 0 and contained_by_gobject_id  in (select * from #WorkingSet) )
			   or
			   ( t.category_id <> 10 and hosted_by_gobject_id in (select * from #WorkingSet) )
		)

		while (
			select count(*) 
			from @DirectChildSet 
			 ) > 0
		begin
			-- table for all the descendants of the #WorkingSet gobjects
			declare @TemporaryCache table( gid int )

			delete from @TemporaryCache

			insert into @TemporaryCache( gid )
			( 
				select gobject_id from gobject 
					inner join template_definition t
						on t.template_definition_id = gobject.template_definition_id
				where
				   ( t.category_id = 10 and contained_by_gobject_id > 0 and contained_by_gobject_id  in (select * from #WorkingSet) )
				   or
				   ( t.category_id = 10 and contained_by_gobject_id = 0 and area_gobject_id in (select * from #WorkingSet) )
				   or
   				   ( t.category_id = 25 and contained_by_gobject_id > 0 and contained_by_gobject_id  in (select * from #WorkingSet) )
				   or
				   ( t.category_id <> 10 and hosted_by_gobject_id in (select * from #WorkingSet) )
			)

			truncate table #WorkingSet

			insert into #WorkingSet select gid from @TemporaryCache

			delete from @DirectChildSet
			
			insert into @DirectChildSet( gid )
			( 
				select gobject_id from gobject 
					inner join template_definition t
						on t.template_definition_id = gobject.template_definition_id
				where
				   ( t.category_id = 10 and contained_by_gobject_id > 0 and contained_by_gobject_id  in (select * from #WorkingSet) )
				   or
				   ( t.category_id = 10 and contained_by_gobject_id = 0 and area_gobject_id in (select * from #WorkingSet) )
				   or
   				   ( t.category_id = 25 and contained_by_gobject_id > 0 and contained_by_gobject_id  in (select * from #WorkingSet) )
				   or
				   ( t.category_id <> 10 and hosted_by_gobject_id in (select * from #WorkingSet) )
			)

			insert into @ResultSet select * from @TemporaryCache
		end
		select distinct * from @ResultSet
end


end

go

