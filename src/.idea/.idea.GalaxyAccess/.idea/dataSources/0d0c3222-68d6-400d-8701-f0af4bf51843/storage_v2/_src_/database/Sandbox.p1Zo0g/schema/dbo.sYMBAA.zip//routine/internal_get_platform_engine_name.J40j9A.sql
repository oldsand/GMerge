/**************************************************/
/*Object Name :  internal_get_platform_engine_name				*/
/*Object Type :  Stored Proc.										*/
/*Purpose :    Procedure to get the platform and engine name and their IDs for a given object*/
/*Used By :    CDI													*/
/**************************************************/
create procedure dbo.internal_get_platform_engine_name
@vargobjectID int,
@varEngineName nvarchar(329) out,
@varPlatformName nvarchar(329) out,
@varEngineID     int out,
@varplatID       int out
AS
begin

SET NOCOUNT ON

set @varEngineName = ''
set @varPlatformName = ''
declare @platformID int
declare @engineID   int
declare @objectID   int

select @platformID = mx_platform_id,
       @engineID   = mx_engine_id,
       @objectID   = mx_object_id 
from   instance 
where gobject_id = @vargobjectID

if ( @objectID = 1 and @engineID > 1 )
  begin        
  
  -- It's an engine 
  exec internal_get_tag_name @vargobjectID,@varEngineName out

  -- get the myhost from gobject table
  declare @vMyhostID  int
  set @vMyhostID = (select hosted_by_gobject_id from gobject where gobject_id = @vargobjectID)

  -- get the platform name from the gobject table
  if ( @vMyhostID > 0 )
     exec internal_get_tag_name @vMyhostID,@varPlatformName out
  
  set @varEngineID = @objectID

  end 
else 
  begin
    if ( @engineID = 1 )
      begin
        -- It's a platform so let us return both platform and engine with same name
		exec internal_get_tag_name @vargobjectID,@varEngineName out
        set @varPlatformName = @varEngineName
        set @varplatID = @objectID
      end 
    else 
      begin
        -- it's an app object 
        -- Get the Engine Name
        declare @vEngineID  int
		if ( @engineID > 0 )
				set @vEngineID = (select   gobject_id 
									from   instance 
									where  mx_object_id = 1 
									 and   mx_engine_id = @engineID
									 and   mx_platform_id = @platformID)
		else
			set @vEngineID = 0

        if ( @vEngineID > 0 )
	   exec internal_get_tag_name @vEngineID,@varEngineName out

        -- Get the Platform Name
        declare @vPlatformID  int
		if ( @platformID > 0 )
				set @vPlatformID = (select gobject_id from   instance 
									where  mx_engine_id= 1 and  mx_platform_id = @platformID )
		else
			set @vPlatformID = 0

        if ( @vPlatformID > 0 )
			exec internal_get_tag_name @vPlatformID,@varPlatformName out
	
		set @varEngineID = @engineID
        set @varplatID = @platformID
      end 
  end
end
go

