create proc dbo.internal_move_folder
(
	@folder_id int,
	@parent_folder_id int
)
AS
begin

declare @ErrorCode int

    begin tran
	declare @folder_name nvarchar(250)
	declare @folder_type int

	select @folder_name = folder_name, @folder_type = folder_type from folder 
	where folder_id = @folder_id 

    	IF not exists( select folder_id from folder where 
		folder_name = @folder_name
		and folder_type = @folder_type
		and parent_folder_id = @parent_folder_id )
	BEGIN
            declare @depth int
            declare @currentparentId int
            if(@parent_folder_id = 0)
            begin
                set @depth = 0
            end
            else
            begin
                select @depth = depth from folder where folder_id = @parent_folder_id
            end    

            select @currentparentId = parent_folder_id from folder where folder_id = @folder_id

            set @depth = @depth + 1

	        update folder set 
            parent_folder_id = @parent_folder_id,
            depth = @depth
            where folder_id = @folder_id

            -- fix the depth of all the children folders
            declare @childfolders table(folderid int,myparent int,nLevel smallint)
            insert  into  @childfolders(folderid,myparent,nLevel) values(@folder_id,@parent_folder_id,1)        
           	declare @nLevel integer
        	BEGIN
        		set @nLevel = 1
        		while 1 > 0
        		BEGIN	
                    set @depth = @depth + 1
        	        update folder set 
                    depth = @depth            
                    where folder_id in (select f.folder_id
        			from folder f inner join @childfolders fs 
                    on f.parent_folder_id = fs.folderid
        			where nLevel = @nLevel)
                    
                    insert into @childfolders
        			select f.folder_id, f.parent_folder_id, @nLevel + 1
        			from folder f inner join @childfolders fs on f.parent_folder_id = fs.folderid
        			where nLevel = @nLevel

        
        			if @@rowcount = 0 break
        			set @nLevel = @nLevel + 1
        		END	-- while
        	END       
            -- end here
        
				
         
            IF exists( select folder_id from folder where has_folders = 0 and folder_id = @parent_folder_id)   
            begin
                update folder set has_folders = 1 where folder_id = @parent_folder_id
            end

            select parent_folder_id from folder 
                    where folder_id = @folder_id

            select folder_id from folder where 
                    parent_folder_id in (select parent_folder_id from folder 
                    where folder_id = @folder_id)

            IF not exists( select folder_id from folder where 
                    parent_folder_id = @currentparentId)
            begin
                update folder set has_folders = 0  where 
                folder_id = @currentparentId
            end
	END	
	ELSE
	BEGIN
	    set @ErrorCode = 1003 --'folder with same name already exists in the parent _folder
        rollback
		return
	END	

    set @ErrorCode = @@error
    if @ErrorCode <> 0 begin
        rollback
        return @ErrorCode
    end

    update galaxy
    set max_proxy_timestamp = cast(@@dbts as bigint)

    commit

    return @ErrorCode

end
go

