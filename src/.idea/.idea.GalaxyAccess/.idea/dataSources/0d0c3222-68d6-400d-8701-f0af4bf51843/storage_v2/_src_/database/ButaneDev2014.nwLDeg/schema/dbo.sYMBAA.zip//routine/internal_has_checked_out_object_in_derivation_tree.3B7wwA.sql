--Description :: This storec_proc checks whether any child object of the input object is checkedout or not
create proc dbo.internal_has_checked_out_object_in_derivation_tree
	@gObjectId int,
    @reason_code int  OUTPUT ---- returns 1 means checkedout objects --2 means object doesnot exists
AS
begin
    set nocount on
    set @reason_code = 0
    declare @has_checked_out_object int
    set @has_checked_out_object = 0    
    declare @objectCount int

    -- check if object exists in database
   select  @objectCount = count(*) from gobject where gobject_id = @gObjectId    
   if(@objectCount = 0)
    BEGIN
        set	@reason_code = 2				
    END
   else
    BEGIN
        -- check if it has checkedout children    
    
    	declare @ResultSet table( 
    				gobject_id int, 
    				derived_from_gobject_id int, 
    				nLevel int)
    	declare @WorkingSet table( gobject_id int)
    	declare @TempWorkingSet table( gobject_id int)
    	declare @nLevel int
    
    	set @nLevel = 0
    
    	insert	@ResultSet 
    		select	go.gobject_id, 
        			go.derived_from_gobject_id, 
    				@nLevel
    		from	gobject go
            left outer join gobject parent on
                       go.derived_from_gobject_id = parent.gobject_id
       		where	go.gobject_id = @gObjectId
    
    	insert into @WorkingSet values( @gObjectId )
    
    	while (1=1)
    	begin
    		set @nLevel = @nLevel + 1
            
            insert @ResultSet
    			select	go.gobject_id, 
    					go.derived_from_gobject_id, 
    					@nLevel
    			from	gobject go, @WorkingSet ws, gobject parent
    			where	go.derived_from_gobject_id = ws.gobject_id
    				and	go.derived_from_gobject_id = parent.gobject_id
    
    
    		insert @TempWorkingSet
    			select	go.gobject_id 
    			from	gobject go, @WorkingSet ws
    			where	go.derived_from_gobject_id = ws.gobject_id
    				and	go.is_template = 1
    
    
    
    		delete	@WorkingSet
    
    		insert 	@WorkingSet
    			select	gobject_id 
    			from	@TempWorkingSet
    		
    		delete @TempWorkingSet
    
            set @has_checked_out_object = (select count(rt.gobject_id) from @ResultSet rt 
            inner join gobject go on rt.gobject_id = go.gobject_id where (go.checked_out_package_id <> 0) and (go.gobject_id <> @gObjectId))
    
    		if(@has_checked_out_object<>0)
            begin
    			set @reason_code = 1 
                break            
            end
    
    		if (not exists (select * from @WorkingSet))
    			break
    	end
    END
end
go

