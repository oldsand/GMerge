create proc dbo.internal_get_categoryid_from_gobjectid
	@gobjectid int
as
select	t.category_id
from	template_definition t,
		gobject g
where	t.template_definition_id = g.template_definition_id and
		g.gobject_id = @gobjectid
go

