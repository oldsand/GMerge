
-- Returns Platform nodename for a given Mx Platform ID depending upon the deploy_action
CREATE   procedure dbo.internal_get_platform_node_name
    @mxPlatformId  smallint,
    @deploy_action  int, -- 1 then it is a redeployOriginal else it is a Normal deploy or deploy changes
    @node_name nvarchar(256)  OUTPUT
as 
set nocount on
begin
	if(@deploy_action = 1)
		BEGIN
			--P2 CR9886 There can be case that we r going to redeploy a object which is never deployed
			--I mean object is getting redeploy original but its never deployed then we need to have to take 
			-- the node_name not the last deployed node name
			--SELECT     @node_name = platform.last_deployed_node_name

			SELECT @node_name =  case platform.last_deployed_node_name when '' then platform.node_name else platform.last_deployed_node_name end
			FROM platform INNER JOIN
	        instance ON platform.platform_gobject_id = instance.gobject_id
			WHERE     (instance.mx_platform_id = @mxPlatformId) AND (instance.mx_engine_id = 1)
		END	
	else	
		BEGIN
			SELECT     @node_name = platform.node_name
			FROM         platform INNER JOIN
	                instance ON platform.platform_gobject_id = instance.gobject_id
			WHERE (instance.mx_platform_id = @mxPlatformId) 
				AND (instance.mx_engine_id = 1)
		END

	print @node_name		

end



go

