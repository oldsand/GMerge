create procedure dbo.internal_get_new_visual_element_id
@new_id int out
as
insert into visual_element_id  default values
set @new_id = @@identity
delete 
from visual_element_id 
where visual_element_id = @new_id

go

