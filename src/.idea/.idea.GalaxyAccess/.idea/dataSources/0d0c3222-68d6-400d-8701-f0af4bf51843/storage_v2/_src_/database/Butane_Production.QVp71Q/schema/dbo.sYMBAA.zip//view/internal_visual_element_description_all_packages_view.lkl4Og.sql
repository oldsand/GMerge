create view dbo.internal_visual_element_description_all_packages_view
as
 
select 
    vev.gobject_id,
    vev.visual_element_id, 
    ve.visual_element_type,
    ve.visual_element_category,                   
    case when pri.primitive_name <> '' then g.tag_name + '.' + pri.primitive_name else g.tag_name end as visual_element_name, 
    p.package_id, 
    vev.mx_primitive_id,
    ve.inheritance_status, 
    ove.description,
    ove.thumbnail,
    g.tag_name tag_name,
    pri.primitive_name, 
    g.tag_name gobject_tag_name,
    p.package_type,
    case when pri.primitive_name <> '' then g.hierarchical_name + '.' + pri.primitive_name else g.hierarchical_name end as hierarchical_visual_element_name, 
    g.hierarchical_name gobject_hierarchical_name,
    case when pri.primitive_name = '' then 1 else 0 end is_library_visual_element,
    vev.inherited_from_visual_element_id,
    ove.is_thumbnail_dirty
from visual_element_version vev
inner join gobject g on
     vev.gobject_id = g.gobject_id
inner join package p on 
     vev.package_id = p.package_id
inner join primitive_instance pri on           
     vev.gobject_id = vev.gobject_id and
    vev.package_id = pri.package_id and 
    vev.mx_primitive_id = pri.mx_primitive_id
inner join owned_visual_element ove on
    vev.inherited_from_visual_element_id = ove.visual_element_id and
    vev.inherited_from_gobject_id = ove.gobject_id and
    vev.inherited_from_package_id = ove.package_id and 
    vev.inherited_from_mx_primitive_id = ove.mx_primitive_id
inner join visual_element ve on 
    vev.visual_element_id = ve.visual_element_id

go

