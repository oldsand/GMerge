--***********************************************************************************************************************
--***	
--***	OBJECT NAME:	get_mx_engine_id_of_redundant_engine
--***	DESCRIPTION:		Get mx_engine_id for failover partner Appengine where object is hosted.
--***	
--***	USAGE: 		dbo.get_mx_engine_id_of_redundant_engine(21) --(where 21 is the gobject_id of the object)
--***	
--***	RETURNS :
--***	=========
--***	0 			- If object does not have a failover partner
--***	gobject_id	- If object has a failover partner
--***	
--***********************************************************************************************************************

Create function dbo.get_mx_engine_id_of_redundant_engine( 
	@gobject_id int
	)
returns smallint
as
begin
	
	declare @PartnerMxEngineID smallint	
	declare @MyAppEngineGid integer
	select @MyAppEngineGid = i1.gobject_id from instance i1 inner join instance i2
	on i1.mx_platform_id = i2.mx_platform_id and 
	i1.mx_engine_id = i2.mx_engine_id and i1.mx_object_id = 1
	where i2.gobject_id = @gobject_id

	select @PartnerMxEngineID = i.mx_engine_id from instance i where i.gobject_id = 
	dbo.get_failover_partner_id(@MyAppEngineGid)
	
	if (@PartnerMxEngineID is null)
		set @PartnerMxEngineID  =  0

	return @PartnerMxEngineID
		
end



go

