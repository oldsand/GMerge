/**************************************************/
/*Object Name :  internal_getGobjectIDsByName                            */
/*Object Type :  Stored Proc.								   */
/*Purpose :    Used by QueryObjectsByName For Instances only to provide GobjectIDs*/
/*Used By :    CDI									*/
/**************************************************/
CREATE  PROCEDURE dbo.internal_get_gobjects_by_name

@FileNameOfNames nvarchar (265)
 AS
begin
set nocount on


SET QUOTED_IDENTIFIER OFF

CREATE TABLE  #results_table ( tag_name nvarchar(329)COLLATE SQL_Latin1_General_CP1_CI_AS not null)

DECLARE @SQL nvarchar(2000)

SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfNames + ''' WITH(TABLOCK, DATAFILETYPE=''widechar'')'

EXEC (@SQL)

select gobject_id from gobject  inner join #results_table rt on 
(gobject.tag_name = rt.tag_name) and (gobject.is_template = 0) and (gobject.namespace_id = 1) -- Automation Object

drop table #results_table

set nocount off
end
go

