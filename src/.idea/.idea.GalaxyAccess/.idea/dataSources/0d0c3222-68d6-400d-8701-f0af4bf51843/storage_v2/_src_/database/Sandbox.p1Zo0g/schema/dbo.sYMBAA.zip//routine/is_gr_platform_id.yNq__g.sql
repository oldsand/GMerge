
--***********************************************************************************************************************
--***      
--***      OBJECT NAME:  IsGRPlatformId
--***      DESCRIPTION:  Function is used to find out if a gobject id is GR Platform or not
--***      
--***      USAGE:      dbo.IsGRPlatformId( 21 ) --(where 21 is the gobject id)
--***                  Function is used by view: internal_proxyobj
--***      RESTRICTIONS: This function can be used only for Instance objects. NOT FOR TEMPLATE
--***      RETURNS :
--***      =========
--***      >1 - If object is GRPlatform
--***      0  - If object is not GRPlatform
--***      0  - If gobjectid is Template or object not exist in database
--***********************************************************************************************************************


CREATE function dbo.is_gr_platform_id( 
            @gobjectid int
            )
returns bit
as
begin
            
	declare @mxplatformid smallint
	set @mxplatformid = 0
	declare @mxengineid smallint
	set @mxengineid = 0


	SELECT  @mxplatformid = instance.mx_platform_id, 
		@mxengineid = instance.mx_engine_id			
	FROM  gobject INNER JOIN instance
	ON instance.gobject_id = gobject.gobject_id			
	where @gobjectid = gobject.gobject_id 	

	declare @isgr bit
	if (@mxplatformid = 1 and @mxengineid = 1) 
		begin
		    set @isgr = 1
		end
	else
		begin
		    set @isgr = 0
		end
	return @isgr
end
go

