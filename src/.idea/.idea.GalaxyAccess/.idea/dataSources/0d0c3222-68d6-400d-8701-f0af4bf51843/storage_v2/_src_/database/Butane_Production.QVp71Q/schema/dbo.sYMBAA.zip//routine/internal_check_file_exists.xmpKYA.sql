CREATE proc dbo.internal_check_file_exists
(
    @file_name nvarchar(256), -- todo: match column of file table
    @subfolder nvarchar(256),
    @vendor_name nvarchar(256),
    @file_id int out
)
as
begin
	select @file_id = file_id from file_table where LOWER(file_name)=LOWER(@file_name)
         and LOWER(vendor_name)=LOWER(@vendor_name) and LOWER(subfolder)=LOWER(@subfolder)
end
go

