--
-- This helper function is used to append the array bounds
-- onto a tagname for display while browsing tags from InTouch.
--
-- used by the internal_get_runtime_attributes view

create function dbo.array_bounds_string( 
	@dim1 as smallint, 
	@dim2 as smallint, 
	@dim3 as smallint 
	)
returns varchar(6)
as
begin
	if @dim1 > 0
		return '[]'
	if @dim2 > 0
		return '[][]'
	if @dim3 > 0
		return '[][][]'
	return ''
end
go

