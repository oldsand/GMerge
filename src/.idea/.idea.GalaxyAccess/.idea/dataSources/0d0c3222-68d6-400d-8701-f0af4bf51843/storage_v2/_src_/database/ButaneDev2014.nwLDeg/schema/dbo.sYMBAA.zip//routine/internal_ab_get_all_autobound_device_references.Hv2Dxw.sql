/*
** Argument: @gobject_id
** @gobject_id: ID of the DIO to which app objects are linked, or an app object that is bound to a DIO.
** Returns:
** ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
** |dio_id|DIO-tag-name|Scan-group name|app-object-tag-name|app-object-attribute name|Binding Rule|AppObject I/O Reference|xlate rule|override (if any)|fully qualified attr name|attr-alias-id|
** ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
** 
** Use this sproc to populate the new grid in the IDE.
*/
CREATE PROCEDURE dbo.internal_ab_get_all_autobound_device_references
    @dio_id               int           -- gobject_id of the host DIO
    , @gobject_id         int = 0       -- optional gobject_id of the app object linked to the DIO
    , @sg_mx_primitive_id smallint = 0  -- optional scan-group (mx_primitive_id)
as
begin
  set nocount on
  /*
    @AutoBoundInfo columns:
      dio_id                      int
    , sg_mx_primitive_id          smallint
    , lo_id                       int
    , lo_package_id               int
    , lo_prim_id                  smallint
    , lo_attr_id                  smallint
    , dio_tag_name                nvarchar (329)
    , dio_scan_group_name         nvarchar (329)
    , app_object_tag_name         nvarchar (329)
    , app_object_attr_name        nvarchar (329)
    , app_object_attr_type        smallint
    , app_object_io_attr          nvarchar (329)
    , binding_rule_id             int
    , binding_rule                nvarchar (500)
    , default_attr_reference      nvarchar (500)
    , xlate_rule_id               int
    , xlate_rule_name             nvarchar (329)
    , overridden_attr_reference   nvarchar (500)
  */

  SELECT dio_id
       , sg_mx_primitive_id
       , dio_tag_name + N'.' + dio_scan_group_name AS 'MyDI'
       , app_object_tag_name + N'.' + app_object_attr_name + N'.' + app_object_io_attr AS 'MyAttrRef'
       , app_object_attr_type AS 'MxDataType'
       , binding_rule 
       , dio_tag_name + N'.' + dio_scan_group_name + N'.' + default_attr_reference AS 'DefaultItemRef'
       , ISNULL (xlate_rule_name, N'None') AS 'Xlate'
       , ISNULL (overridden_attr_reference, N'') AS 'Override'
       , (CASE 
            WHEN xlate_rule_name IN (N'Radical_Override', N'Radical_Override_Default_SG', N'ASB_Reference')
              THEN overridden_attr_reference 
            WHEN xlate_rule_name IN (N'Device_Override',  N'Device_and_SG_Override')
              THEN overridden_attr_reference + N'.' + default_attr_reference
            ELSE 
                dio_tag_name + N'.'
              + dio_scan_group_name + N'.'
              + ISNULL (overridden_attr_reference, default_attr_reference) 
          END) AS 'QualifiedItemRef'
    FROM itvfGetAutobindInfoForDIO (@dio_id, @sg_mx_primitive_id, @gobject_id, DEFAULT, DEFAULT)

end
go

