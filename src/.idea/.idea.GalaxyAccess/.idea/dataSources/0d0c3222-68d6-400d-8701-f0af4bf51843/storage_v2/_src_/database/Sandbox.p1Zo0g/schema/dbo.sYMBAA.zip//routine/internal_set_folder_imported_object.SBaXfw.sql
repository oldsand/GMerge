create proc dbo.internal_set_folder_imported_object
@gobjectId int,
@folder_id int,
@folder_type int

as
begin

    update folder_gobject_link set folder_id = @folder_id 
    where gobject_id = @gobjectId and folder_type = @folder_type

    -- if the gobject does not exists in the database then insert a new row for it
    if ( @@ROWCOUNT = 0 )
      insert into folder_gobject_link(folder_id,folder_type,gobject_id) 
        select @folder_id,@folder_type,@gobjectId

    
end

go

