-- Returns true if a given package is visible to a given user.
-- Used to filter what is in a given users current view
--
-- Example: dbo.is_package_visible_to_user( 5,32,'7F0312F4-0D1E-4D8D-84E2-1DEA26A65237' )
create function dbo.is_package_visible_to_user ( 
    @gobject_id as int, 
    @package_id as int, 
    @user_guid as uniqueidentifier  ) 
    returns  bit
as
begin
    declare @checked_out_by_user_guid uniqueidentifier
    declare @checked_out_package_id int
    declare @checked_in_package_id int
    select 
        @checked_in_package_id = checked_in_package_id,
        @checked_out_by_user_guid = checked_out_by_user_guid ,
        @checked_out_package_id = checked_out_package_id
    from gobject 
    where gobject_id = @gobject_id

    -- everybody sees checked in version if it isn't checked out
    if( @checked_out_by_user_guid is null and @checked_in_package_id = @package_id )
        return 1

    -- you see checked out version if it is checked out to you
    if( @checked_out_by_user_guid = @user_guid and @checked_out_package_id = @package_id )
        return 1

    -- you see checked in version if it is checked out to somebody else
    if( @checked_out_by_user_guid <> @user_guid  and @checked_in_package_id = @package_id )
        return 1

    return 0
end
go

