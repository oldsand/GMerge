create procedure dbo.internal_update_visual_element_thumbnail
@visual_element_id int,
@thumbnail image
as
begin tran

	declare @inherited_from_visual_element_id int
	declare @gobject_id int
	select @inherited_from_visual_element_id = inherited_from_visual_element_id,
			@gobject_id = gobject_id
	from visual_element_version
	where visual_element_id = @visual_element_id

	update ove
	set 
		thumbnail = @thumbnail,
		is_thumbnail_dirty = 0
	from owned_visual_element ove
	inner join gobject g on
		g.gobject_id = ove.gobject_id and
		g.checked_in_package_id = ove.package_id
	where ove.visual_element_id = @inherited_from_visual_element_id
	
	--L00082780 - Update proxy timestamp when thumbnail is updated for a toolbox graphic
	declare @namespace_id smallint
	select @namespace_id = namespace_id from gobject where gobject_id= @gobject_id
	if @namespace_id = 3 --Library Graphic
	begin
		exec internal_update_gobject_timestamp @gobject_id,0
	end
	---L00082780
commit
go

