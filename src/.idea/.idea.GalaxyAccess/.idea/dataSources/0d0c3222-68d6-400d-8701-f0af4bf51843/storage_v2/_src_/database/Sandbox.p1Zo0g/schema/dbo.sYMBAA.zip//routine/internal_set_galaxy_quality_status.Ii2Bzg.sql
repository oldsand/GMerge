
/**************************************************/
/*Object Name :  internal_set_galaxy_quality_status			*/
/*Object Type :  Stored Proc.								*/
/*Purpose :    Procedure to set galaxy quality status		*/
/*Used By :    PackageServerNet								*/
/**************************************************/
create  proc dbo.internal_set_galaxy_quality_status
@quality_status ntext, ---- Change this to nvarchar(max) when we move to YUKON
@setdefaultonly bit
as
begin
set nocount on
begin tran

        declare @galaxy_instance_gid integer            	

    if ( select count(*) from galaxy_settings ) = 0 
    begin
		
		select @galaxy_instance_gid = gg.gobject_id               
    	from gobject gg
    	where gg.derived_from_gobject_id in (
    	select gobject_id 
    	from gobject 
    	where tag_name = N'$Galaxy')
    	
        insert into galaxy_settings ( galaxyid,default_qs_data,current_qs_data)
    	values(@galaxy_instance_gid, @quality_status, @quality_status)
    end
    else if @setdefaultonly = 0	
    begin
		update galaxy_settings 
        set current_qs_data = @quality_status          	    	
    end   
	else
	begin
		update galaxy_settings
		set default_qs_data = @quality_status
	end
commit tran

end
go

