create proc dbo.internal_does_object_have_primitive_linked_file
    @gobject_id int, 
    @have_primitive_linked_file int output
as
begin
    if exists (
        select  1
        from    primitive_instance_file_table_link
        where   gobject_id = @gobject_id )
    begin
        set @have_primitive_linked_file = 1
    end
    else
    begin
        set @have_primitive_linked_file = 0
    end
end
go

