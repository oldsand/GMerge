create proc dbo.internal_mark_default_objects_in_galaxy_as_protected
As
begin
set nocount on
begin tran
	declare @DefaultGobjectIds table (gobject_id int)
	
	--add all base templates gojects IDs into table
	insert into @DefaultGobjectIds (gobject_id)
	select base_gobject_id from template_definition
	
	--for $Integer','$Boolean','$Float','$String','$Double'
	insert into @DefaultGobjectIds (gobject_id)
	select g.gobject_id from gobject g 
	inner join template_definition td on 
	g.derived_from_gobject_id = td.base_gobject_id
	and td.original_template_tagname = '$FieldReference'
	and g.tag_name in ('$Integer','$Boolean','$Float','$String','$Double')
	and td.vendor_name = 'ArchestrA'
	
	--check if it is exists or not. if exists then don't insert
	declare @id int
	while exists(select gobject_id from @DefaultGobjectIds)
	begin
		
		select @id = gobject_id from @DefaultGobjectIds
		
		if not exists (select '*' from gobject_protected where gobject_id = @id)
		begin
			insert into gobject_protected (gobject_id) values (@id)
		end
		
		delete from @DefaultGobjectIds
		where gobject_id = @id
		
	end
commit tran

end
go

