-- populates temporary table #gobject_ids
-- from xml document @gObjectIdsAsXml
-- where @gObjectIdsAsXml is created
-- using XmlEncode() from cdi.cpp
/*
Usage:
    create table #gobject_ids( gobject_id int )
    exec internal_get_gobject_ids_from_xml '
    <r>
        <gobject id=''8''/>
        <gobject id=''9''/>
    </r>
    '
    select * from #gobject_ids
    drop table #gobject_ids
*/
create proc dbo.internal_get_gobject_ids_from_xml
    @gObjectIdsAsXml text
as
set nocount on
begin

DECLARE @iDoc int
EXECUTE sp_xml_preparedocument @iDoc OUTPUT, @gObjectIdsAsXml	
insert into #gobject_ids SELECT distinct * FROM OpenXML(@iDoc, '/r/gobject',1) WITH (id int)
EXECUTE sp_xml_removedocument @iDoc

end
go

