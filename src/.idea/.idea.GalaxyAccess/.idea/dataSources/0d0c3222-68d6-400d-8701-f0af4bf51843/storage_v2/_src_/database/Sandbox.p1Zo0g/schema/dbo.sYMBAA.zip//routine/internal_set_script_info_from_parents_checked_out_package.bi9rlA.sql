/*
    Uses the table #results_table as its input.  This table must
    be created and filled prior to the execution of this procedure.
    #results_table contains all the descendents gobject_id
*/
create procedure dbo.internal_set_script_info_from_parents_checked_out_package
as
begin
    begin tran    
        
    -- Update primitive status based on parent primitive status
    update  child_primitive
    set     child_primitive.mx_value_errors = parent_primitive.mx_value_errors,
            child_primitive.mx_value_warnings = parent_primitive.mx_value_warnings,
            child_primitive.mx_value_reference_warnings = parent_primitive.mx_value_reference_warnings,
            child_primitive.primitive_attributes = 
				case when ( 0 = child.is_Template ) then
					convert(binary(1), parent_primitive.mx_primitive_id - parent_primitive.mx_primitive_id/256*256) + convert(binary(1), parent_primitive.mx_primitive_id/256) + 0x00000000
			else	NULL
			end,
            child_primitive.status_id = parent_primitive.status_id,
            child_primitive.ref_status_id =
				case when parent_primitive.ref_status_id <> 0 then 
					parent_primitive.ref_status_id
				else child_primitive.ref_status_id
				end,
            child_primitive.checked_in_primitive_version = child_primitive.checked_in_primitive_version+1,
            child_primitive.checked_out_primitive_version = child_primitive.checked_out_primitive_version+1            
    from    
            gobject child
    inner join
            #results_table r
    on
            child.gobject_id = r.gobject_id
    inner join
            gobject parent
    on
            child.derived_from_gobject_id = parent.gobject_id
    inner join 
            primitive_instance parent_primitive 
    on
            parent_primitive.gobject_id = parent.gobject_id
        and parent_primitive.package_id = parent.checked_out_package_id
        and parent_primitive.extension_type = N'ScriptExtension'
    inner join
            primitive_instance child_primitive
    on
            child_primitive.gobject_id = child.gobject_id
        and child_primitive.package_id = child.checked_out_package_id
        and child_primitive.mx_primitive_id = parent_primitive.mx_primitive_id
	inner join #dirty_primitives_results_table dirtypri
	on		dirtypri.mx_primitive_id = child_primitive.mx_primitive_id
    
    
    -- Reset the package status
    update  pa
    set     pa.status_id = 0
    from    package pa
    inner join 
            gobject g
    on
            g.gobject_id = pa.gobject_id
        and g.checked_out_package_id = pa.package_id
    inner join          
            #results_table r
    on
            g.gobject_id = r.gobject_id


    -- Set package status to warning if necessary
    update  pa
    set     pa.status_id = 2
    from    package pa 
    inner join 
            gobject g
    on
            g.gobject_id = pa.gobject_id
        and g.checked_out_package_id = pa.package_id
    inner join          
            #results_table r
    on
            g.gobject_id = r.gobject_id
    inner join
            primitive_instance pri
    on 
            pri.gobject_id = pa.gobject_id
        and pri.package_id = pa.package_id
        and pri.status_id = 2


    -- Set package status to error if necessary
    update  pa
    set     pa.status_id = 1
    from    package pa 
    inner join 
            gobject g
    on
            g.gobject_id = pa.gobject_id
        and g.checked_out_package_id = pa.package_id
    inner join          
            #results_table r
    on
            g.gobject_id = r.gobject_id
    inner join
            primitive_instance pri
    on 
            pri.gobject_id = pa.gobject_id
        and pri.package_id = pa.package_id
        and pri.status_id = 1


    -- Set lock type of child attributes
    update  child_attribute
    set     child_attribute.mx_value = parent_attribute.mx_value,
            child_attribute.lock_type = 2
    from    
            gobject child
    inner join
            #results_table r
    on
            child.gobject_id = r.gobject_id
    inner join
            gobject parent
    on
            child.derived_from_gobject_id = parent.gobject_id
    inner join 
            primitive_instance parent_primitive 
    on
            parent_primitive.gobject_id = parent.gobject_id
        and parent_primitive.package_id = parent.checked_out_package_id
        and parent_primitive.extension_type = N'ScriptExtension'
    inner join
            template_attribute parent_attribute
    on
            parent_attribute.gobject_id = parent.gobject_id
        and parent_attribute.package_id = parent.checked_out_package_id
        and parent_attribute.mx_primitive_id = parent_primitive.mx_primitive_id
    inner join
            template_attribute child_attribute
    on
            child_attribute.gobject_id = child.gobject_id
        and child_attribute.package_id = child.checked_out_package_id
        and child_attribute.mx_primitive_id = parent_attribute.mx_primitive_id
        and child_attribute.mx_attribute_id = parent_attribute.mx_attribute_id
    where 
            parent_attribute.lock_type = 1
        or  parent_attribute.lock_type = 2

    commit
    
end



go

