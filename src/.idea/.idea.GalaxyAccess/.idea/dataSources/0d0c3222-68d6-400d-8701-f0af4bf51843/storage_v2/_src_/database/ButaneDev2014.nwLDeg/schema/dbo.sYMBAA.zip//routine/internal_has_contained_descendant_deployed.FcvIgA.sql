/*
  This stored procedure takes object id and will return whether the object
  has any contained children which is deployed
*/

create proc dbo.internal_has_contained_descendant_deployed 
@gobject_id int, 
@bHasDeployChild int OUTPUT
AS 
begin

set nocount on
declare @level int
set @level = 0

create table #descendant( objectId int, depth int )
insert into #descendant values(@gobject_id, @level)

while (select COUNT(*) from  #descendant) > 0 
begin
	-- increment the depth for each level
	set @level = @level + 1

	-- get the children of the next level
	INSERT INTO #descendant  (objectId, depth)	
   	SELECT gobject_id, @level
   	FROM gobject where contained_by_gobject_id in (select objectId from #descendant)
	
	-- Remove any object of previous level		
	delete from #descendant where depth < @level

	-- If we found any descendant is deployed then stop
	SELECT @bHasDeployChild = COUNT(*) FROM gobject, #descendant
	where gobject_id = #descendant.objectId AND deployed_package_id <> 0

	if @bHasDeployChild > 0
		truncate table #descendant	
end

drop table #descendant


end
go

