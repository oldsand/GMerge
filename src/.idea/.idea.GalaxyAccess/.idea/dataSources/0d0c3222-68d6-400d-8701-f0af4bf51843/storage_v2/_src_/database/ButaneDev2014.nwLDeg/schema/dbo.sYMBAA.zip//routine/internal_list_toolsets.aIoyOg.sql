/*Object Name :  internal_list_toolsets     */
/*Object Type :  Stored Proc.								   */
/*Purpose :    to get toolset data for all the toolsets */
/*Used By :    CDI									*/
/**************************************************/
CREATE  PROCEDURE dbo.internal_list_toolsets

 AS
begin
set nocount on

select
    'id' = folder.folder_id, 
    'toolsetname' =  folder.folder_name,     
    'bhasTemplates'  =   case when exists(select gobject_id from folder_gobject_link f where f.folder_id =  folder.folder_id)
	                         then 1
						 else 0
						 end
from  folder 
order by  folder.folder_id


end

go

