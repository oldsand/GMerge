create procedure dbo.internal_update_gobject_filter_infos_timestamp
@FileNameOfIds nvarchar (265)
as
begin tran

    set quoted_identifier off
    
    create table  #gobject_ids ( gobject_id int	primary key)	
    
    declare @sql nvarchar(2000)
    
    set @sql = 'bulk insert #gobject_ids  from ''' + @FileNameOfIds+ ''' with(tablock,datafiletype  = ''widechar'')'
    
    exec (@sql)

    update pt
    set pt.gobject_id = pt.gobject_id
    from gobject_filter_info_timestamp pt
    inner join #gobject_ids gi on
        pt.gobject_id = gi.gobject_id 


    declare @max_proxy_timestamp bigint
    select @max_proxy_timestamp = CAST ( @@dbts  AS timestamp ) 

    update galaxy
    set max_proxy_timestamp = @max_proxy_timestamp
    

commit

go

