/**************************************************/
/*Object Name :  internal_get_tag_name								*/
/*Object Type :  Stored Proc.										*/
/*Purpose :    Procedure to get the tagname for a given gobject_id  */
/*Used By :    CDI													*/
/**************************************************/
create proc dbo.internal_get_tag_name
@gobjectid int,
@tagname nvarchar(329) out
as
begin
 set @tagname = ''
 set @tagname = (select tag_name from gobject where gobject_id = @gobjectid)
end
go

