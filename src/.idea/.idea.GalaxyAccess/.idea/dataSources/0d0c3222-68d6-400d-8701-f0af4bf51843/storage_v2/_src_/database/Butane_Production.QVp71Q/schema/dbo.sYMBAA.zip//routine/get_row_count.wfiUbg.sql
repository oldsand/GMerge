-- returns the number of rows in the table given by @table_name
-- returns -1 if @table_name does not exist
--
-- this is much faster than using select count(*) from gobject
--
-- usage: dbo.get_row_count( 'gobject' )
create function dbo.get_row_count( @table_name sysname )
returns int
as
begin
    declare @row_count int
    select @row_count = -1
    SELECT @row_count = rows FROM sysindexes WHERE id = OBJECT_ID(@table_name) AND indid < 2
    return @row_count
end
go

