create proc dbo.internal_get_all_galaxy_visual_elements
( @intouch_viewapp_name nvarchar(329) = '',
    @return_only_delta bit = 0
    )
as
begin
    set quoted_identifier off
	
	if(@return_only_delta = 1)
	begin

        --Here @intouch_viewapp_gobject_id is NO where used we can remove this.. in future.. confirm
		declare @intouch_viewapp_gobject_id int
		declare @timestamp_of_deploy bigint
		set @timestamp_of_deploy = 0
		
		select @intouch_viewapp_gobject_id = gobject.gobject_id,
		@timestamp_of_deploy = timestamp_of_deploy
		from deployed_intouch_viewapp
		inner join gobject
		on gobject.gobject_id = deployed_intouch_viewapp.gobject_id
		and tag_name = @intouch_viewapp_name
			
		
		if(@timestamp_of_deploy <> 0)-- if deployed instance is found than return changed symbols only
		begin
			-- visual_element_ids into table
			create  table #visual_element_ids_for_referenced_elements(visual_element_id int)
    
			--find changed VE
			 insert #visual_element_ids_for_referenced_elements(visual_element_id)
				select 
				vedv.visual_element_id
			from internal_visual_element_description_view vedv
			inner join primitive_instance pinst on 
			vedv.gobject_id = pinst.gobject_id and 
			vedv.package_id = pinst.package_id and
			vedv.mx_primitive_id = pinst.mx_primitive_id
			where vedv.checked_in_package_id = vedv.package_id
			and pinst.timestamp_of_last_change > @timestamp_of_deploy
			and vedv.visual_element_type <> 'ClientControl'
			   order by vedv.visual_element_id asc
			
			--Find direct embedded CC on changed VE
			insert #visual_element_ids_for_referenced_elements(visual_element_id)
			select 
                bound_vev.visual_element_id               
            from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on 
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id
                and bver.package_id = vev.package_id
                and bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id                
            inner join internal_visual_element_description_view vedv on
              bver.checked_in_bound_visual_element_gobject_id = vedv.gobject_id and
                bver.checked_in_bound_visual_element_package_id = vedv.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = vedv.mx_primitive_id 
             where vedv.visual_element_type = 'ClientControl'   
            
            
            --Get all Client Controls which are atelast once embedded in any symbol and higher timestamp --L00116072
			insert #visual_element_ids_for_referenced_elements(visual_element_id)
			select distinct
			vedv.visual_element_id
			from internal_visual_element_description_view vedv 
			inner join visual_element_reference veref
			on veref.checked_in_bound_visual_element_gobject_id = vedv.gobject_id
			and veref.checked_in_bound_visual_element_package_id = vedv.checked_in_package_id
			and veref.checked_in_bound_visual_element_mx_primitive_id = vedv.mx_primitive_id     
			inner join primitive_instance pinst 
			on pinst.gobject_id = vedv.gobject_id
			and pinst.package_id = vedv.checked_in_package_id
			and pinst.mx_primitive_id = vedv.mx_primitive_id 
			where vedv.checked_in_package_id = vedv.package_id
			and vedv.visual_element_type = 'ClientControl' 
			and pinst.timestamp_of_last_change > @timestamp_of_deploy   
			
		
            --Now return            
            select distinct 
				vedv.visual_element_id,vedv.visual_element_type,isnull(vedv.visual_element_name, '') as visual_element_name
			from internal_visual_element_description_view vedv
			inner join #visual_element_ids_for_referenced_elements vei on 
			vei.visual_element_id = vedv.visual_element_id
			where vedv.checked_in_package_id = vedv.package_id			
			   order by vedv.visual_element_id asc
			
            
			return	
		end
		
    end
    
	(
		--Get all symbols
		select 
		visual_element_id,visual_element_type,isnull(visual_element_name, '') as visual_element_name
		from internal_visual_element_description_view where checked_in_package_id = package_id
		and visual_element_type = 'Symbol' 
		
		union 
		--Get all Client Controls which are atelast once embedded in any symbol.
		select distinct
		vedv.visual_element_id,vedv.visual_element_type,isnull(vedv.visual_element_name, '') as visual_element_name
		from internal_visual_element_description_view vedv 
		inner join visual_element_reference veref
		on veref.checked_in_bound_visual_element_gobject_id = vedv.gobject_id
		and veref.checked_in_bound_visual_element_package_id = vedv.checked_in_package_id
		and veref.checked_in_bound_visual_element_mx_primitive_id = vedv.mx_primitive_id     
		where vedv.checked_in_package_id = vedv.package_id
		and vedv.visual_element_type = 'ClientControl'     
	)
	order by visual_element_id asc
 
	        
   
end
go

