create proc dbo.internal_save_gobject_bulk
    @gobjectfile nvarchar(255),
    @gobjectfilehascontent int,
    @primitiveinstancefile nvarchar(255),
    @priminstancefilehascontent int,
    @templateattrfile nvarchar(255),
    @templateattrhascontent int,
    @attrreffile nvarchar(255),
    @attrrefhascontent int,
    @priminstafeature nvarchar(255),
    @primfeaturehascontent int,
    @dynamicattributefile nvarchar(255),
    @dynamicattributefileishascontent int,
    @userID uniqueidentifier,
    @automation_object_change_has_occured bit,
    @graphic_change_has_occured bit,
    @record_change bit,
    @primitivedependencyfile nvarchar(255),
    @primitivedependencyfileishascontent int,
    -- @ObjectHasGraphicRelatedPrimitive is input parameter calculated from C++
    -- It is set to 1 if this object has visualization related stuff 
    @ObjectHasGraphicRelatedPrimitive int, 
    -- @NeedToExecuteVisualizationRelatedSP is the Output parameter to inform 
    -- C++ code whether it needs to call visualization related code after object is saved.
    @NeedToExecuteVisualizationRelatedSP int out 
as 
begin tran
    set nocount on
    
    set @NeedToExecuteVisualizationRelatedSP = @ObjectHasGraphicRelatedPrimitive
    
    create table  #gobject_T (gobjectid int,
                              status_id int,
                              ref_status_id int,
                              is_template int,
                              package_id int,
                              check_in_package_id int,
                              depl_package_id int,
                              last_depl_package_id int,
                              deployed_version int,
                              config_version int,
							  security_group nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS  not null default N'',
                              derived_fp_id int,
                              namespace_id int
                               )
   
    if (@gobjectfilehascontent = 1 )
    begin
        DECLARE @gSQL nvarchar(2000)
        SET @gSQL = 'BULK INSERT #gobject_T  FROM ''' + @gobjectfile+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@gSQL)
        
    end

	
--UPDATE PACKAGE TABLE
    update package 
    set 
        status_id = gt.status_id, 
        reference_status_id = gt.ref_status_id,
        security_group = gt.security_group,
        package_version = package_version + 1,
        deployable_configuration_version = deployable_configuration_version + @automation_object_change_has_occured
    from package , 
         #gobject_T gt
    where package.gobject_id = gt.gobjectid 
    and package.package_id = gt.package_id


	declare @is_checkin_package_save smallint --used by upload operation
	set @is_checkin_package_save = 0
	if(exists(select t.* from #gobject_T t
			  inner join gobject g
			  on g.gobject_id = t.gobjectid	
			  where t.package_id = check_in_package_id
			  and g.deployed_package_id <> 0))
	begin
		set @is_checkin_package_save = 1
	end
	
    update  gobject 
    set     gobject.configuration_guid = NewId(),
            gobject.namespace_id = gt.namespace_id            
    from    gobject,#gobject_T gt
    where   gobject.gobject_id = gt.gobjectid 

    declare @deploy_pkg_id int
    declare @last_deploy_pkg_id int
    declare @deployversion int
    declare @configversion  int
    declare @gobjectid  int
    declare @isTemplate int
    declare @package_id int
    declare @checked_in_package_id int
    declare @is_checked_in_package  bit
	declare @namespace_id int


    select  @deploy_pkg_id = gt.depl_package_id,
            @last_deploy_pkg_id = gt.last_depl_package_id,
            @deployversion = gt.deployed_version, 
            @configversion = gt.config_version,
            @gobjectid = gt.gobjectid,
            @isTemplate = gt.is_template,
            @package_id = gt.package_id,
            @checked_in_package_id = gt.check_in_package_id,
			@namespace_id = gt.namespace_id
    from    #gobject_T gt


	-->>-- Auto-binding
    -- Preserve manual overrides for objects that are linked to devices
    CREATE TABLE #autobound_attribute_transient (
                       gobject_id      int
                     , mx_primitive_id smallint
                     , mx_attribute_id smallint
                     , element_index   smallint
                 , linked_device   nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS 
                 , default_ref     nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                     , xlate_rule_id   int
                 , attr_alias      nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
                     , match_by_id      bit
                     , PRIMARY KEY (gobject_id, mx_primitive_id, mx_attribute_id, element_index))

    -- The autobound_attribute_transient table holds overrides across the save operation: These overrides need to be reinstated now.
    INSERT INTO #autobound_attribute_transient
    SELECT itvf.lo_id, itvf.lo_prim_id, itvf.lo_attr_id, itvf.lo_element_index
         , itvf.dio_tag_name + '.' + itvf.dio_scan_group_name
         , itvf.app_object_attr_name + '.' + itvf.app_object_io_attr
         , itvf.xlate_rule_id, itvf.overridden_attr_reference
         , 1
      FROM object_device_linkage odl
    CROSS APPLY itvfGetAutobindInfoForDIO (odl.dio_id, odl.sg_mx_primitive_id, odl.gobject_id, DEFAULT, DEFAULT) itvf
     WHERE odl.gobject_id = @gobjectid
    OPTION (FORCE ORDER)     --L00136670
	--<<-- Auto-binding



    set @is_checked_in_package = 0
    if (@package_id = @checked_in_package_id)
    begin
        set @is_checked_in_package = 1
    end
    
    if( @deploy_pkg_id > 0 )
        update gobject set gobject.deployed_package_id = @deploy_pkg_id from gobject where gobject.gobject_id = @gobjectid

    if( @last_deploy_pkg_id > 0 )
        update gobject set gobject.last_deployed_package_id = @last_deploy_pkg_id from gobject where gobject.gobject_id = @gobjectid

    if( @deployversion <> 0 )
        update gobject set gobject.deployed_version = @deployversion from gobject where gobject.gobject_id = @gobjectid

    if( @configversion <> 0 )
        update gobject set gobject.configuration_version = @configversion from gobject where gobject.gobject_id = @gobjectid

    create table #primitive_instance_T( primitive_definition_id int,
					primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                    mx_primitive_id smallint,
                    parent_mx_primitive_id  smallint,
                    execution_group int,
                    execution_order int,
                    owned_by_gobject_id int,
					extension_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                    is_object_extension bit,
                    checked_in_primitive_version int,
                    checked_out_primitive_version int,
                    entity_change_type int,
                    operation_on_primitive_mask int,
					created_by_parent smallint,
					status_id smallint,
					ref_status_id smallint,    			                       
					primitive_attributes image,
                    mx_value_errors text not null,    
                    mx_value_warnings text not null,    
                    mx_value_reference_warnings text not null)
    
    -- before we delete the rows, we need to copy the timestamp information to 
    -- a temp table.  We will use this info in an update after the insert....
    declare @primitive_instance_archive table
            (gobject_id int,
             package_id int,
             mx_primitive_id smallint,
             timestamp_of_last_change bigint,
             max_child_timestamp bigint,
             entity_change_type int,
             operation_on_primitive_mask int)


    insert into  @primitive_instance_archive 
             (gobject_id ,
             package_id ,
             mx_primitive_id ,
             timestamp_of_last_change ,
             max_child_timestamp,
             entity_change_type,
             operation_on_primitive_mask)
    select   
             @gobjectid ,
             @package_id ,
             mx_primitive_id ,
             timestamp_of_last_change ,
             max_child_timestamp,
             entity_change_type,
             operation_on_primitive_mask
    from  primitive_instance 
    where gobject_id = @gobjectid and
          package_id = @package_id


    -- create a copy of the current visual elements
    -- so we can see if any have been deleted in the proc : TBD
    
    -- Re-Calculate the bit '@ObjectHasGraphicRelatedPrimitive' 
    -- as we will not have the correct data from the C++ code 
    -- where in if the Graphic Primitive is deleted then we will 
    -- not have the correct data for this bit.
/*
    insert change_log(gobject_id, package_id, need_to_call_ve, comment, spid, happened_at)
    values(@gobjectid,@package_id,@ObjectHasGraphicRelatedPrimitive,N'save-before recalculate', @@spid, GETDATE())
*/    
    
    if (@ObjectHasGraphicRelatedPrimitive = 0)
    begin
        if exists
        (
		    select '*' from primitive_instance 
		    where   gobject_id = @gobjectid
			    and package_id = @package_id
		        and extension_type = N'SymbolExtension'
        )
        begin
		    set @ObjectHasGraphicRelatedPrimitive = 1
		    set @NeedToExecuteVisualizationRelatedSP = 1
        end
    end
/*            
    insert change_log(gobject_id, package_id, need_to_call_ve, comment, spid, happened_at)
    values(@gobjectid,@package_id,@ObjectHasGraphicRelatedPrimitive,N'save-after recalculate', @@spid, GETDATE())
*/    
            
    if (@ObjectHasGraphicRelatedPrimitive = 1)
    begin
		delete 
		from visual_element_archive
		where persisted_for_gobject_id = @gobjectid


		insert into visual_element_archive
		(
			gobject_id,
			package_id,
			mx_primitive_id,
			visual_element_name,
			visual_element_type,
			visual_element_id,
			persisted_for_gobject_id
		)
		select
			gobject_id,
			package_id,
			mx_primitive_id,
			visual_element_name,
			visual_element_type,
			visual_element_id,
			@gobjectid
		from internal_visual_element_description_per_user_view
		where gobject_id = @gobjectid and
			package_id = @package_id and
			user_guid = @userID
	    
		-- handle object's inherited elements..
		if exists(
			select '*'
			from gobject
			where 
				gobject_id = @gobjectid and
				is_template = 1)
		begin
			insert into visual_element_archive
			(
				gobject_id,
				package_id,
				mx_primitive_id,
				visual_element_name,
				visual_element_type,
				visual_element_id,
				persisted_for_gobject_id
			)
			select
				v.gobject_id,
				v.package_id,
				v.mx_primitive_id,
				v.visual_element_name,
				v.visual_element_type,
				v.visual_element_id,
				v.gobject_id
			from visual_element_archive vea
			inner join internal_visual_element_description_view v (noexpand)on
				v.inherited_from_visual_element_id = vea.visual_element_id and
				vea.gobject_id = @gobjectid and
				vea.package_id = @package_id 
		end
	end	 -- if(@ObjectHasGraphicRelatedPrimitive = 1)
    
    if (@is_checkin_package_save = 1)
    begin
		delete from primitive_instance  
		where	gobject_id = @gobjectid 
		and		package_id = @package_id
		and     extension_type <> N'SymbolExtension' 
    end
    else
    begin
		delete from primitive_instance  
		where	gobject_id = @gobjectid 
		and		package_id = @package_id
    end
    

    if (@priminstancefilehascontent = 1 )
    begin
        DECLARE @pSQL nvarchar(2000)
        SET @pSQL = 'BULK INSERT #primitive_instance_T  FROM ''' + @primitiveinstancefile+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@pSQL)
        
        if (@is_checkin_package_save = 1)
        begin
			-- Insert Into Primitive Instance Table
			insert into primitive_instance (
							gobject_id,
							package_id,
							mx_primitive_id,
							primitive_definition_id,
							primitive_name,
							parent_mx_primitive_id,
							execution_group,
							execution_order,
							owned_by_gobject_id,
							extension_type,
							is_object_extension,
							checked_in_primitive_version,
							checked_out_primitive_version,
							entity_change_type,
							operation_on_primitive_mask,
							created_by_parent,
							status_id,
							ref_status_id,    			
							primitive_attributes,
							mx_value_errors,    
							mx_value_warnings,    
							mx_value_reference_warnings)
													
			select  @gobjectid,
					@package_id,
					o.mx_primitive_id,
					o.primitive_definition_id,
					o.primitive_name,
					o.parent_mx_primitive_id,
					o.execution_group,
					o.execution_order, 
					o.owned_by_gobject_id,
					o.extension_type,
					o.is_object_extension,
					o.checked_in_primitive_version,
					o.checked_out_primitive_version,
					o.entity_change_type,
					o.operation_on_primitive_mask,
					o.created_by_parent,
					o.status_id,
					o.ref_status_id,    			
					o.primitive_attributes,
					o.mx_value_errors,    
					o.mx_value_warnings,    
					--o.mx_value_reference_warnings
					'0x00'
	                
			from    #primitive_instance_T o
			where    o.extension_type <> N'SymbolExtension'  
        
        end
        else
        begin
        
			-- Insert Into Primitive Instance Table
			insert into primitive_instance (
							gobject_id,
							package_id,
							mx_primitive_id,
							primitive_definition_id,
							primitive_name,
							parent_mx_primitive_id,
							execution_group,
							execution_order,
							owned_by_gobject_id,
							extension_type,
							is_object_extension,
							checked_in_primitive_version,
							checked_out_primitive_version,
							entity_change_type,
							operation_on_primitive_mask,
							created_by_parent,
							status_id,
							ref_status_id,    			
							primitive_attributes,
							mx_value_errors,    
							mx_value_warnings,    
							mx_value_reference_warnings)
													
			select  @gobjectid,
					@package_id,
					o.mx_primitive_id,
					o.primitive_definition_id,
					o.primitive_name,
					o.parent_mx_primitive_id,
					o.execution_group,
					o.execution_order, 
					o.owned_by_gobject_id,
					o.extension_type,
					o.is_object_extension,
					o.checked_in_primitive_version,
					o.checked_out_primitive_version,
					o.entity_change_type,
					o.operation_on_primitive_mask,
					o.created_by_parent,
					o.status_id,
					o.ref_status_id,    			
					o.primitive_attributes,
					o.mx_value_errors,    
					o.mx_value_warnings,    
					--o.mx_value_reference_warnings
					'0x00'
	                
			from    #primitive_instance_T o
        
        end
        
        update	pri
        set		pri.timestamp_of_last_change = ts.timestamp_of_last_change,
				pri.max_child_timestamp = ts.max_child_timestamp,
				pri.operation_on_primitive_mask = ts.operation_on_primitive_mask | pri.operation_on_primitive_mask
        from	primitive_instance pri
        inner join @primitive_instance_archive ts on
              pri.gobject_id = ts.gobject_id and
              pri.package_id = ts.package_id and
              pri.mx_primitive_id = ts.mx_primitive_id                     




        update	pri
        set		pri.entity_change_type = ts.entity_change_type
        from	primitive_instance pri
        inner join @primitive_instance_archive ts on
              pri.gobject_id = ts.gobject_id and
              pri.package_id = ts.package_id and
              pri.mx_primitive_id = ts.mx_primitive_id                     
        where ts.entity_change_type > pri.entity_change_type

        if (@is_checked_in_package = 1)
        begin
            update	pri
            set		pri.entity_change_type = 1,
                    pri.operation_on_primitive_mask = 0
            from	primitive_instance pri
            where	gobject_id = @gobjectid 
            and		package_id = @package_id 
        end
    end

    -- Attribute Template Table
    if ( @isTemplate = 1 )
    begin
        delete from template_attribute  where gobject_id = @gobjectid and package_id =  @package_id 
           
        if (@templateattrhascontent = 1 )
        begin
            create table #template_attr_T
            (
                mx_primitive_id         smallint,
                mx_attribute_id         smallint,
                mx_data_type                int,
                security_classification int,
                mx_value                    text,
                lock_type                   int,
                original_lock_type          int
            )
            
            DECLARE @taSQL nvarchar(2000)
            SET @taSQL = 'BULK INSERT #template_attr_T  FROM ''' + @templateattrfile+ ''' 
                        WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
            EXEC (@taSQL)
            
            insert into template_attribute ( 
                            gobject_id,
                            package_id,
                            mx_primitive_id,
                            mx_attribute_id,
                            mx_data_type,
                            security_classification,
                     mx_value,
                            lock_type,
                            original_lock_type)
                select  @gobjectid,
                        @package_id,
                        aTemp.mx_primitive_id,
                        aTemp.mx_attribute_id,
                        aTemp.mx_data_type,
                        aTemp.security_classification,
                        aTemp.mx_value,
                        aTemp.lock_type,
                        aTemp.original_lock_type
                from    #template_attr_T aTemp

            drop table #template_attr_T
        end

    end
    else if  ( @isTemplate = 0 )
    begin
       
        delete  attribute_reference 
        where   gobject_id = @gobjectid and package_id = @package_id
     
        -- bulk insert into this table
        if (@attrrefhascontent = 1 )
        begin      
	      create table #attr_reference_inst_T
             (
                referring_mx_primitive_id smallint,
                referring_mx_attribute_id smallint,
                element_index             smallint,
				dest_object_name          nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                resolved_gobject_id       int ,
				reference_string          nvarchar(700) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
				context_string            nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                object_signature          int,
                resolved_mx_primitive_id  smallint,
                resolved_mx_attribute_id  smallint,
                resolved_mx_property_id   smallint,
                attribute_signature       int,
                lock_type                 int,
                attr_res_status           int,
                attribute_index           smallint,
                is_valid                  bit            
             )

            DECLARE @arSQL nvarchar(2000)
            SET @arSQL = 'BULK INSERT #attr_reference_inst_T  FROM ''' + @attrreffile+ ''' 
                        WITH (FIELDTERMINATOR = ''\t'', TABLOCK, DATAFILETYPE  = ''widechar'') '
            EXEC (@arSQL)
            
            update  attr_ref
            set     resolved_gobject_id = ( select isnull(gobj.gobject_id,0) 
                                from gobject gobj where gobj.tag_name = attr_ref.dest_object_name and gobj.namespace_id = 1)
            from    #attr_reference_inst_T attr_ref
    
            insert into attribute_reference(gobject_id,
                                               package_id,
                                               referring_mx_primitive_id,
                                               referring_mx_attribute_id,
                                               element_index,
                                               resolved_gobject_id,
                                               reference_string,
                                               context_string,
                                               object_signature,
                                               resolved_mx_primitive_id,
                                               resolved_mx_attribute_id,
                                               resolved_mx_property_id,

                                               attribute_signature,
                                               lock_type,
                                               is_valid,
                                               attr_res_status,
                                               attribute_index )
                       select @gobjectid,@package_id,
                              attr_ref.referring_mx_primitive_id,
                              attr_ref.referring_mx_attribute_id,
                              attr_ref.element_index,
                              isnull(attr_ref.resolved_gobject_id,0),
                              attr_ref.reference_string,
                              attr_ref.context_string,
                              attr_ref.object_signature,
                              attr_ref.resolved_mx_primitive_id,
                              attr_ref.resolved_mx_attribute_id,
                              attr_ref.resolved_mx_property_id,
                              attr_ref.attribute_signature,
                              attr_ref.lock_type,
                              attr_ref.is_valid,
                              attr_ref.attr_res_status,
                              attr_ref.attribute_index
                       from   #attr_reference_inst_T attr_ref       
       
       
        end
    end

    SET QUOTED_IDENTIFIER OFF


    --Delete all the dynamic attributes associated with this packge
    delete from dynamic_attribute where gobject_id = @gobjectid and package_id = @package_id

    if (@dynamicattributefileishascontent = 1)
    begin
        CREATE TABLE  #dynamic_attributes_table ( 
             mx_attribute_id            smallint,
                mx_primitive_id         smallint,
			 attribute_name				nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS not null default '',
             mx_data_type               smallint,
             is_array                   bit,
             security_classification    smallint,
             mx_attribute_category      int,
             lock_type                  int,
             mx_value                   text,
             owned_by_gobject_id        int,
             original_lock_type         int,
             dynamic_attribute_type     smallint,
             bitvalues					smallint
        )
    
        if (@dynamicattributefileishascontent = 1)
        begin
            DECLARE @dSQL nvarchar(2000)
            SET @dSQL = 'BULK INSERT #dynamic_attributes_table  FROM ''' + @dynamicattributefile+ ''' 
                        WITH (FIELDTERMINATOR = '',\t'', TABLOCK, DATAFILETYPE  = ''widechar'') '
            EXEC (@dSQL)
        end
    
    
        --insert the dynamic attributes
        if (exists(select * from #dynamic_attributes_table))
        begin
            insert into dynamic_attribute (
                        gobject_id,
                        package_id,
                        mx_primitive_id,
                        mx_attribute_id,
                        attribute_name, 
                        mx_data_type, 
                        is_array, 
                        security_classification, 
                        mx_attribute_category, 
                        lock_type, 
                        mx_value, 
                        owned_by_gobject_id,
                        original_lock_type,
                        dynamic_attribute_type,
                        bitvalues)
            select  @gobjectid,@package_id,
                    dInst.mx_primitive_id,
                    dInst.mx_attribute_id, 
                    dInst.attribute_name, 
                    dInst.mx_data_type, 
                    dInst.is_array, 
                    dInst.security_classification, 
                    dInst.mx_attribute_category, 
                    dInst.lock_type, 
                    dInst.mx_value, 
                    dInst.owned_by_gobject_id,
                    dInst.original_lock_type,
                    dInst.dynamic_attribute_type,
                    dInst.bitvalues
            from    #dynamic_attributes_table dInst
        end
        drop table #dynamic_attributes_table
    end

-- END : Update dynamic attributes associated with this package

-- BEGIN : Update features assocaited with this gObject


    ----Delete the previous feature associations for this packge
    delete from primitive_instance_feature_link  where gobject_id = @gobjectid and package_id = @package_id

    if (@primfeaturehascontent = 1 )
    begin
        create table #primitive_instance_feature_T
        (
             mx_primitive_id int,
             feature_id int,
			 feature_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS ,
			 feature_type nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  
        )
        DECLARE @fSQL nvarchar(2000)
        SET @fSQL = 'BULK INSERT #primitive_instance_feature_T  FROM ''' + @priminstafeature+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@fSQL)
        
    
        --Insert the new feature associations 
        insert into primitive_instance_feature_link(gobject_id,package_id,mx_primitive_id,feature_id,feature_name,feature_type)
        select distinct @gobjectid,
               @package_id,
               pif.mx_primitive_id, 

               isnull(f.feature_id,0), 
               isnull(pif.feature_name,''),


               isnull(pif.feature_type,'') 
        from #primitive_instance_feature_T pif
        left outer join feature f --Find the feature_id
            on  pif.feature_name = f.feature_name 
            and pif.feature_type = f.feature_type

        drop table #primitive_instance_feature_T
    end
-- END : Update features assocaited with this gObject



-- BEGIN : Update primitive file dependency assocaited with this gObject

    delete  primitive_instance_file_table_link  
    where   gobject_id = @gobjectid 
            and package_id = @package_id

    if (@primitivedependencyfileishascontent = 1 )
    begin
        create table #primitive_instance_file_table_link_T
        (
             mx_primitive_id int,
             file_id  int,
             is_needed_for_package bit,
             is_needed_for_runtime bit,
             is_needed_for_editor bit
        )
        DECLARE @fSQL2 nvarchar(2000)
        SET @fSQL2 = 'BULK INSERT #primitive_instance_file_table_link_T  FROM ''' + @primitivedependencyfile+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@fSQL2)
            
        insert into primitive_instance_file_table_link(
                    gobject_id,
                    package_id,
                    mx_primitive_id,
                    file_id,
                    is_needed_for_package,
                    is_needed_for_runtime,
                    is_needed_for_editor)
        (
            select distinct @gobjectid,
                   @package_id,
                   pift.mx_primitive_id, 
                   pift.file_id,
                   pift.is_needed_for_package,
                   pift.is_needed_for_runtime,
                   pift.is_needed_for_editor
            from   #primitive_instance_file_table_link_T pift
        )
        drop table #primitive_instance_file_table_link_T
    end
-- END : Update features assocaited with this gObject


    drop table #primitive_instance_T
    drop table #gobject_T
    
	if(@ObjectHasGraphicRelatedPrimitive = 1)
	begin
		if (@is_checkin_package_save <> 1)
		begin
		    if(@namespace_id <>2)
			    exec internal_add_visual_elements_from_parent @gobjectid, @package_id 
		    exec internal_bind_relative_visual_elements_for_gobject @gobjectid, @package_id
		end
	        

		-- add visual_element references from parent if this is a derived template
		-- that is being created for the first time...
		if (
				(@checked_in_package_id = @package_id) and 
				(@configversion = 1) and 
				(@namespace_id <>2) 
			)
		begin
			exec internal_add_visual_element_references_from_parent @gobjectid, @package_id , N'I'
			exec internal_bind_visual_element_references -- CR 117307
		end
	end		-- if(@ObjectHasGraphicRelatedPrimitive = 1)

	-- >> Auto Binding/Device Linkage
	declare @dio_id int
	declare @dio_sg smallint
	select @dio_id = dio_id, @dio_sg = sg_mx_primitive_id
	  from object_device_linkage
	 where gobject_id = @gobjectid

	if @@ROWCOUNT = 1
		exec internal_ab_refresh_autobound_attrs @gobjectid, @dio_id, @dio_sg
		
	-- << Auto Binding/Device Linkage


    if (@record_change = 1) -- log event if flag was passed...
    begin
        -- Validate the user guid that has been passed in....
        if exists(select '*' from user_profile where user_guid = @userID)
        begin
            declare @operationId int
            declare @comment nvarchar(256)
            if (@automation_object_change_has_occured = 1 and @graphic_change_has_occured = 0)                
            begin
                set @operationId = 37
                set @comment = 'Updated configuration.'
            end
            else if (@automation_object_change_has_occured = 1 and @graphic_change_has_occured = 1)
            begin
                set @operationId = 39
                set @comment = 'Updated configuration and graphics.'
            end
            else if (@automation_object_change_has_occured = 0 and @graphic_change_has_occured = 1)
            begin
                set @operationId = 38
                set @comment = 'Updated graphics.'
            end

            exec internal_log_changes @gobjectid, @userID, @operationId, @comment
        end
        else
        begin    
            rollback tran
            return
            /*     this block should be modified to return an error code
                   to indicate that the userId was invalid. -- Anand                 
            */

        end
    end

commit


go

