/**************************************************/
/*Object Name :  internal_list_object_change_log                       */
/*Object Type :  Stored Proc.								 */
/*Purpose :    to retrieve list of objects being referenced*/
/*Used By :    CDI									*/
/**************************************************/
create PROCEDURE dbo.internal_list_object_change_log
@gobjectId int
 AS
begin
    select gobject.tag_name, 
	gobject_change_log.user_profile_name, 
	gobject_change_log.change_date, 
	'operationtext' = lookup_operation.operation_name,  
	gobject_change_log.user_comment, 
	gobject_change_log.configuration_version 
    from gobject_change_log gobject_change_log
	inner join gobject gobject
		on gobject.gobject_id = gobject_change_log.gobject_id
	inner join lookup_operation
		on gobject_change_log.operation_id = lookup_operation.operation_id
	where gobject_change_log.gobject_id = @gobjectId
	order by change_date
end
go

