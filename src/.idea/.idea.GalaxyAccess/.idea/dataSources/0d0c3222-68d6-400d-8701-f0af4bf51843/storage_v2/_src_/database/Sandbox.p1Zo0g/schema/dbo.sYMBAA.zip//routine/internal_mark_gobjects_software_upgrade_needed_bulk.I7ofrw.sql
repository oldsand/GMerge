--	This stored procedure will update the gobject table for all the 
--	the gobjects which are deployed and are using the input runtime file_id
--  and return the table of affected gobject_ids 

create procedure dbo.internal_mark_gobjects_software_upgrade_needed_bulk
@FileNameOfIds nvarchar (265),
@FileNameofInstanceGids nvarchar (265)
AS
SET NOCOUNT ON
begin
   
	create table #affected_gobjects(gobject_id int)

	CREATE TABLE  #results_table ( file_id int)
    DECLARE @SQL nvarchar(2000)
    SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
    EXEC (@SQL)

	declare @bHasFileUpdated bit
	if exists(select * from #results_table)
		set @bHasFileUpdated = 1
	else
		set @bHasFileUpdated = 0
	
	CREATE TABLE  #instancegids_table ( gobject_id int)
    DECLARE @SQL1 nvarchar(2000)
    SET @SQL1 = 'BULK INSERT #instancegids_table  FROM ''' + @FileNameofInstanceGids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
    EXEC (@SQL1)


	--// select gobject
    insert into #affected_gobjects(gobject_id)
	    select distinct  gobject.gobject_id
	    from primitive_definition INNER JOIN 
	    file_primitive_definition_link ON 
	    primitive_definition.primitive_definition_id = file_primitive_definition_link.primitive_definition_id 
	    INNER JOIN 
	    gobject	 ON 
	    primitive_definition.template_definition_id = gobject.template_definition_id 
    	WHERE ---(primitive_definition.runtime_handler_clsid <> '{00000000-0000-0000-0000-000000000000}') AND 
	    file_primitive_definition_link.file_id in (select file_id from #results_table)
-- Not needed for Aquarius
    --//1. Get all the visual elements using these files
--     declare visual_element_cursor cursor for
--         select distinct vev.visual_element_id from
--         visual_element_version vev INNER JOIN
--         primitive_instance pi ON
-- 	vev.mx_primitive_id = pi.mx_primitive_id AND
-- 	vev.gobject_id = pi.gobject_id AND
-- 	vev.package_id = pi.package_id INNER JOIN
-- 	primitive_instance_file_table_link pif ON
--         pif.mx_primitive_id = pi.parent_mx_primitive_id AND
-- 	pif.gobject_id = pi.gobject_id AND
--         pif.package_id = pi.package_id 
--    WHERE
--         pif.file_id = @file_id
--     
--     open visual_element_cursor
--     
--     declare @visual_element_id int
-- 
--     fetch next from visual_element_cursor into @visual_element_id
--     while @@fetch_status = 0
--     begin
--         --//2. Get all view apps using this visual element
--         insert #affected_gobjects(gobject_id)
--             execute internal_getReferringVisualElements @visual_element_id,0,1
--         fetch next from visual_element_cursor into @visual_element_id
--     end
--     
--     close visual_element_cursor
--     
--     deallocate visual_element_cursor
    --remove undeployed objects from the table
    delete #affected_gobjects FROM 
    #affected_gobjects a INNER JOIN gobject g ON  g.gobject_id = a.gobject_id 
                                              AND g.deployed_package_id = 0
        
    --If updated file are not found than atleast include deployed instances
    if @bHasFileUpdated = 0
    begin
		--insert the only gobject_ids from #instancegids_table which are not exit in #affected_gobjects
		insert #affected_gobjects(gobject_id)
		select igt.gobject_id from #instancegids_table igt
		where igt.gobject_id not in (select gobject_id from #affected_gobjects)
	end
	
    --1)	If the files are getting updated then only mark Appengine and platform as SUR
    if @bHasFileUpdated = 1 
    begin
		--Mark software upgrade required for hosted engines and platforms if object is running on fail-over enabled engine
		create table #affected_redundants(gobject_id int)
	    
		--insert Appengines
		insert into #affected_redundants(gobject_id)   
		select distinct imyengine.gobject_id 
		from #affected_gobjects rt
		inner join instance i
		on rt.gobject_id = i.gobject_id 
		inner join instance imyengine
		on imyengine.mx_engine_id = i.mx_engine_id 
			and imyengine.mx_platform_id = i.mx_platform_id
			and imyengine.mx_object_id = 1
		inner join redundancy r 
		on imyengine.gobject_id = r.primary_gobject_id
		
		
		--insert backup Partners which are deployed
		insert into #affected_redundants(gobject_id)   
		select distinct r.backup_gobject_id
		from #affected_gobjects rt
		inner join instance i
		on rt.gobject_id = i.gobject_id 
		inner join instance imyengine
		on imyengine.mx_engine_id = i.mx_engine_id 
			and imyengine.mx_platform_id = i.mx_platform_id
			and imyengine.mx_object_id = 1
		inner join redundancy r 
		on imyengine.gobject_id = r.primary_gobject_id
		inner join gobject g
		on r.backup_gobject_id = g.gobject_id and g.deployed_package_id > 0
		
		--insert platforms from appengines
		create table #affected_platforms(gobject_id int)
		insert into #affected_platforms(gobject_id) 
		select distinct imyplatform.gobject_id
		from #affected_redundants ar
		inner join instance i
		on ar.gobject_id = i.gobject_id 
		inner join instance imyplatform
		on i.mx_platform_id = imyplatform.mx_platform_id
			and imyplatform.mx_engine_id = 1 
			and imyplatform.mx_object_id = 1
			
		insert #affected_gobjects(gobject_id)
		select gobject_id from #affected_redundants
		
		insert #affected_gobjects(gobject_id)
		select gobject_id from #affected_platforms
        
        drop table #affected_redundants
        drop table #affected_platforms
    end
    
    --Mark these objects as SUR
    update gobject 
        set software_upgrade_needed = 1 
        FROM #affected_gobjects a where a.gobject_id = gobject.gobject_id
    
    --Don't return #instancegids_table, because these ids are going to be delete objects
    delete #affected_gobjects  from
    #affected_gobjects ag inner join #instancegids_table ig on ag.gobject_id = ig.gobject_id
    
    --Return these object ids
    select distinct gobject_id from #affected_gobjects
	
    drop table #affected_gobjects

	-- clean the deployed file table for runtime files
	update deployed_file set is_runtime_deployed = 0 where file_id in ( select file_id from file_pending_update )


end


go

