/************************************************************************************/
/*Object Name :  internal_can_assign_host												*/
/*Object Type :  Stored Proc.														*/
/*Purpose	  :  Proc. to verify that whether Assign will cause object's count		*/
/*               exceed limit														*/
/*Used By	  :  PackageServer														*/
/************************************************************************************/

create proc dbo.internal_can_assign_host
	@parent_gobject_id int,
	@child_gobject_id int,
	@bExceedLimit int output
AS

begin
	set nocount on

	declare @child_category int
	declare @object_count int
	declare @total_object_count int

	-- Init the output for default case ( IODevices, etc )
	set @bExceedLimit = 0

	if ( @parent_gobject_id = 0 ) -- UnAssign, always OK
		return

	-- get child category
	select @child_category = category_id 
	from gobject G inner join template_definition TD on G.template_definition_id = TD.template_definition_id
	where gobject_id = @child_gobject_id

	if ( @child_category = 17 or @child_category = 26)	 -- then parent has to be ViewEngine
	begin

		declare @parent_category int
		select @parent_category = category_id
		from gobject G inner join template_definition TD on G.template_definition_id = TD.template_definition_id
		where gobject_id = @parent_gobject_id

		if ( @parent_category = 4 ) 
			return
	end

	if ( @child_category < 10 )	
		-- Child is a kind of engine, then parent has to be Platform
		begin
			select @object_count = count(*) from 
			instance I1 inner join instance I2 
			on I1.mx_platform_id = I2.mx_platform_id
			where I1.gobject_id = @parent_gobject_id and I1.mx_platform_id <> 0 and I2.mx_object_id = 1	

			-- the @object_count here including the Platform engine ( which is itself an engine )
			-- but not including the engine being assign ( then the number cancel out )
			set @total_object_count = @object_count
			if ( @total_object_count > 1000 ) set @bExceedLimit = 1			
		end
	else 
		begin
			-- If we are moving objects within the same engine, then it's always OK
			declare @child_mx_platform_id  int
			declare @child_mx_engine_id    int
			select @child_mx_platform_id = mx_platform_id, @child_mx_engine_id = mx_engine_id
			from instance where gobject_id = @child_gobject_id
			
			if ( @child_mx_platform_id <> 0 )
			begin
				declare @parent_mx_platform_id int
				declare @parent_mx_engine_id   int

				select @parent_mx_platform_id = mx_platform_id, @parent_mx_engine_id = mx_engine_id
				from instance where gobject_id = @parent_gobject_id

				if ( @parent_mx_platform_id = @child_mx_platform_id and @parent_mx_engine_id = @child_mx_engine_id )
					return	-- the @bExceedLimit is already set to 0
			end

			-- count all objects in the same engine with the parent
			select @object_count = count(*) from 
			instance I1 inner join instance I2 
			on I1.mx_platform_id = I2.mx_platform_id and I1.mx_engine_id = I2.mx_engine_id
			where I1.gobject_id = @parent_gobject_id and I1.mx_platform_id <> 0
	
			set @total_object_count = @object_count
			declare @host_table table(gobject_id int, hosted_by_gobject_id int, nLevel int)
	
			-- Add the child object to this table to find all of its children ( by host or contain )
			insert into @host_table
			select gobject_id, hosted_by_gobject_id, 0
			from gobject where gobject_id = @child_gobject_id
	
			declare @nLevel int
			set @nLevel = 0

			if ( @child_category = 13 ) 
				-- Child is an Area, so look for all objects where this Area is their host 
				begin				
					while 1 > 0
					begin
						insert into @host_table
						select G1.gobject_id, G1.hosted_by_gobject_id,  @nLevel + 1
						from @host_table H1 inner join gobject G1 on G1.hosted_by_gobject_id = H1.gobject_id
						where H1.nLevel = @nLevel
					
						if ( @@rowcount = 0 ) break;
						set @nLevel = @nLevel + 1
					end
				end
			else if ( @child_category = 10 )
				-- Child is an Application Object, then look for all objects where this child is their container
				begin
					while 1 > 0
					begin
						insert into @host_table
						select G1.gobject_id, G1.hosted_by_gobject_id,  @nLevel + 1
						from @host_table H1 inner join gobject G1 on G1.contained_by_gobject_id = H1.gobject_id
						where H1.nLevel = @nLevel
					
						if ( @@rowcount = 0 ) break;
						set @nLevel = @nLevel + 1
					end
				end

			select @object_count = count(*) from @host_table 
			set @total_object_count = @total_object_count + @object_count

			-- this total count is including the child objects
			if ( @total_object_count > 30000 ) set @bExceedLimit = 1	
		end
end
go

