create proc dbo.internal_get_galaxy_gobject_id  
    @galaxy_gobject_id int  OUTPUT
as

set nocount on

begin

	select @galaxy_gobject_id = gobject.gobject_id 
	from gobject 
	inner join template_definition
	on gobject.derived_from_gobject_id = template_definition.base_gobject_id
	where template_definition.original_template_tagname = '$Galaxy'

end
go

