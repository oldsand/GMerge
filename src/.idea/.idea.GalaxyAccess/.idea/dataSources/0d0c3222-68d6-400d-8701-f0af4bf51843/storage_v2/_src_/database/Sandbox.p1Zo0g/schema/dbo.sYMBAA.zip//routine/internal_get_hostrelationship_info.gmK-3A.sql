create proc [dbo].[internal_get_hostrelationship_info]
	@tagname nvarchar(329),
	@containedbygobject_id int out,
	@containedbytagname    nvarchar(329) out
as
begin
	set @containedbytagname = ''
	set @containedbygobject_id = (select contained_by_gobject_id from gobject where tag_name = @tagname and namespace_id = 1)
	if ( @containedbygobject_id > 0 )
	begin
	  exec internal_get_tag_name @containedbygobject_id,@containedbytagname out
	end
	else
		begin
			set @containedbygobject_id = (select hosted_by_gobject_id from gobject where tag_name = @tagname and namespace_id = 1)	
				if ( @containedbygobject_id > 0 )
				begin
					exec internal_get_tag_name @containedbygobject_id,@containedbytagname out
				end
		end

	end
go

