create function dbo.get_last_dot (@s nvarchar(max))
returns int
as
begin
  declare @i int
  set @i = len(@s)
  while @i > 0 and substring(@s, @i, 1) <> '.'  set @i = @i - 1
  return @i
end
go

