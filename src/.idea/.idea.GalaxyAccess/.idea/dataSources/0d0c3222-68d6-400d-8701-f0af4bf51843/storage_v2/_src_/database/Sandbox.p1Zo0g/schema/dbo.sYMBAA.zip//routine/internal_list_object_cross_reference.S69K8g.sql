/**********************************************************************/
/*Object Name :  internal_CrossReference						      */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To provide cross reference information for a given   */
/*               gobject                                              */
/*Used By	  :  CDI												  */
/**********************************************************************/
CREATE PROCEDURE dbo.internal_list_object_cross_reference
@gobjectId int
 AS
begin
select 
 referringGobjectID,
  referringAttribute_full_name,
  reference_string,
  context_string,
  referredToGobjectID,
  referredToAttributeName
 from 
    internal_reference_primitive_attribute 
 where 
    referredToGobjectID = @gobjectId
end
go

