/*
return count of deployed gobjects hosted by given gobject_id.
*/
Create FUNCTION dbo.is_gobject_has_deployed_hosted_objects( 	@gobject_id int	)
returns int
as
begin

declare @mx_platform_id as int
declare @mx_engine_id as int
declare @mx_object_id as int
declare @gobjectcount as int
set @gobjectcount = 0

select @mx_platform_id = mx_platform_id,@mx_engine_id  = mx_engine_id, @mx_object_id = mx_object_id from instance where gobject_id = @gobject_id

if(@mx_engine_id = 1 ) -- this is a platform \
	begin
			select @gobjectcount = count(gdeployed.gobject_id)
		        	from gobject gdeployed inner join instance inst on
			inst.mx_platform_id = @mx_platform_id
			and inst.gobject_id = gdeployed.gobject_id 
			and gdeployed.deployed_package_id <> 0
	end
else if(@mx_engine_id <> 1 and @mx_object_id = 1) ------this is a engine
	begin
			select @gobjectcount = gdeployed.gobject_id
		        	from gobject gdeployed inner join instance inst on
			inst.mx_platform_id = @mx_platform_id and
			inst.mx_engine_id = @mx_engine_id
			and inst.gobject_id = gdeployed.gobject_id 
			and gdeployed.deployed_package_id <> 0
	end
else
begin
	

	-------------------------------------------------------
	-- calculate deployed objects hosted by @gobject_id
	------------------------------------------------------
	
	-- table for return value
	declare @ResultSet table( gobject_id int)
	
	-- table for gobjects in a particular iteration in the while loop
	declare @WorkingSet table( gobject_id int)
	
	insert into @WorkingSet values( @gobject_id )
	
	while (
		select count(*) 
	    from  gobject 
	    where hosted_by_gobject_id in ( select * from @WorkingSet ) 
	            and hosted_by_gobject_id <> 0 
	            and deployed_package_id <> 0
	     ) > 0
	begin
		-- table for all the descendants of the @WorkingSet gobjects
		declare @TemporaryCache table( gobject_id int )
	
		delete from @TemporaryCache
	
		insert into @TemporaryCache( gobject_id )
		( 
			select gobject_id from gobject 
	        where hosted_by_gobject_id in ( select * from @WorkingSet ) 
	                and hosted_by_gobject_id <> 0
	                and deployed_package_id <> 0
		)
	
		delete from @WorkingSet
	
		insert into @WorkingSet select gobject_id from @TemporaryCache	

		insert into @ResultSet select * from @TemporaryCache		
	end

	select @gobjectcount = count(*) from @ResultSet
end

return @gobjectcount

end


go

