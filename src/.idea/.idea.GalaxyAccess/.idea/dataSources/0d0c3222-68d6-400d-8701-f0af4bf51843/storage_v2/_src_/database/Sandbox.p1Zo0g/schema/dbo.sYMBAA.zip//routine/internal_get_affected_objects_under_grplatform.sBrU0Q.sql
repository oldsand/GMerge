--1.	Input files are going to update while import with migrate option
--2.	Find Number of deployed instances running on GRPlatform which are sharing the runtime files with files found in step 1
--3.    It need to check objects which are running under backup engine also, which is assigned to GRPlatform
--4.	return base template name of objects which are deployed under GRPlatform(directly or indirectly)

create  procedure dbo.internal_get_affected_objects_under_grplatform
@FileNameOfIds nvarchar (265)
AS
SET NOCOUNT ON
begin
   
	create table #affected_gobjects(gobject_id int)

	CREATE TABLE  #results_table ( file_id int)
    DECLARE @SQL nvarchar(2000)
    SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
    EXEC sp_executesql @SQL

	--// select gobject
    insert into #affected_gobjects(gobject_id)
	    select distinct  gobject.gobject_id
	    from primitive_definition INNER JOIN 
	    file_primitive_definition_link ON 
	    primitive_definition.primitive_definition_id = file_primitive_definition_link.primitive_definition_id 
	    INNER JOIN 
	    gobject	 ON 
	    primitive_definition.template_definition_id = gobject.template_definition_id 
    	WHERE ---(primitive_definition.runtime_handler_clsid <> '{00000000-0000-0000-0000-000000000000}') AND 
	    file_primitive_definition_link.file_id in (select file_id from #results_table)
-- Not needed for Aquarius
    --//1. Get all the visual elements using these files
--     declare visual_element_cursor cursor for
--         select distinct vev.visual_element_id from
--         visual_element_version vev INNER JOIN
--         primitive_instance pi ON
-- 	vev.mx_primitive_id = pi.mx_primitive_id AND
-- 	vev.gobject_id = pi.gobject_id AND
-- 	vev.package_id = pi.package_id INNER JOIN
-- 	primitive_instance_file_table_link pif ON
--         pif.mx_primitive_id = pi.parent_mx_primitive_id AND
-- 	pif.gobject_id = pi.gobject_id AND
--         pif.package_id = pi.package_id 
--    WHERE
--         pif.file_id = @file_id
--     
--     open visual_element_cursor
--     
--     declare @visual_element_id int
-- 
--     fetch next from visual_element_cursor into @visual_element_id
--     while @@fetch_status = 0
--     begin
--         --//2. Get all view apps using this visual element
--         insert #affected_gobjects(gobject_id)
--             execute internal_getReferringVisualElements @visual_element_id,0,1
--         fetch next from visual_element_cursor into @visual_element_id
--     end
--     
--     close visual_element_cursor
--     
--     deallocate visual_element_cursor
    --remove undeployed objects from the table
    delete #affected_gobjects FROM 
    #affected_gobjects a INNER JOIN gobject g ON  g.gobject_id = a.gobject_id 
                                              AND g.deployed_package_id = 0
    
    create table #affected_gobjects_withgr(gobject_id int)
    --Get All objects from #affected_gobjects, which are directly under GRPlatform
    insert into #affected_gobjects_withgr(gobject_id)
    select distinct a.gobject_id from #affected_gobjects a
    INNER JOIN instance i
    on (a.gobject_id = i.gobject_id and i.mx_platform_id = 1)
    
    --Get all objects from #affected_gobjects, which are indirectly under GRPlatform
    --means objects are assigned to primary engine whose backup engine is assigned to GRPlatform
    insert into #affected_gobjects_withgr(gobject_id)   
    select distinct rt.gobject_id from #affected_gobjects rt
	inner join instance i
	on rt.gobject_id = i.gobject_id 
	inner join instance imyengine
	on imyengine.mx_engine_id = i.mx_engine_id
	inner join redundancy r 
	on imyengine.gobject_id = r.primary_gobject_id
	inner join gobject g
	on r.backup_gobject_id = g.gobject_id
	inner join instance imybackupengine
	on imybackupengine.gobject_id = r.backup_gobject_id and
	imybackupengine.mx_platform_id = 1
	where (imyengine.mx_engine_id > 1 and imyengine.mx_object_id = 1) and	--AppEngine	
		g.deployed_package_id <> 0	
    
    
    select distinct td.original_template_tagname    
    from #affected_gobjects_withgr agr
    inner join gobject g
    on agr.gobject_id = g.gobject_id
    inner join template_definition td
    on td.template_definition_id = g.template_definition_id
    
end


go

