create view dbo.internal_visual_element_description_view
with schemabinding 
as
select 
    vev.gobject_id,
    vev.visual_element_id, 
    ve.visual_element_type,
    ve.visual_element_category,                   
    case when pri.primitive_name <> '' then g.tag_name + '.' + left(pri.primitive_name,32) else g.tag_name end as visual_element_name, 
    p.package_id, 
    vev.mx_primitive_id,
    ve.inheritance_status, 
    ove.description,
    pri.primitive_name, 
    g.tag_name tag_name,
    p.package_type,
    case when pri.primitive_name <> '' then g.hierarchical_name + '.' + left(pri.primitive_name,32) else g.hierarchical_name end as hierarchical_visual_element_name, 
    g.hierarchical_name gobject_hierarchical_name,
    case when pri.primitive_name = '' then 1 else 0 end is_library_visual_element,
    vev.inherited_from_visual_element_id,
    g.checked_in_package_id,
    g.checked_out_package_id,
    g.checked_out_by_user_guid,
    vev.inherited_from_gobject_id,
    ove.is_thumbnail_dirty
from dbo.visual_element_version vev
inner join dbo.gobject g on
     vev.gobject_id = g.gobject_id
inner join dbo.primitive_instance pri on           
     vev.gobject_id = vev.gobject_id and
    vev.package_id = pri.package_id and 
    vev.mx_primitive_id = pri.mx_primitive_id
inner join dbo.owned_visual_element ove on
    vev.inherited_from_visual_element_id = ove.visual_element_id and
    vev.inherited_from_gobject_id = ove.gobject_id and
    vev.inherited_from_package_id = ove.package_id and 
    vev.inherited_from_mx_primitive_id = ove.mx_primitive_id
inner join dbo.visual_element ve on 
    vev.visual_element_id = ve.visual_element_id
inner join dbo.package p on  vev.gobject_id = p.gobject_id and
	vev.package_id = p.package_id


go

create unique clustered index idx_internal_visual_element_description_view_on_visual_element_id_and_package_id
    on internal_visual_element_description_view (visual_element_id, package_id)
go

create unique index idx_internal_visual_element_description_view_multi
    on internal_visual_element_description_view (visual_element_name, visual_element_category,
                                                 is_library_visual_element, visual_element_id, package_id)
go

create index idx_visual_element_description_view_on_gobject_id_package_id_and_mx_primitve_id
    on internal_visual_element_description_view (gobject_id, package_id, mx_primitive_id)
go

create index idx_internal_visual_element_description_view_on_hierarchical_visual_element_name
    on internal_visual_element_description_view (hierarchical_visual_element_name)
go

create index idx_visual_element_description_view_on_gobject_id_and_visual_element_id_and_visual_element_name
    on internal_visual_element_description_view (gobject_id, visual_element_id, visual_element_name)
go

create index idx_internal_visual_element_description_view_visual_element_id_package_id
    on internal_visual_element_description_view (visual_element_id, package_id)
go

