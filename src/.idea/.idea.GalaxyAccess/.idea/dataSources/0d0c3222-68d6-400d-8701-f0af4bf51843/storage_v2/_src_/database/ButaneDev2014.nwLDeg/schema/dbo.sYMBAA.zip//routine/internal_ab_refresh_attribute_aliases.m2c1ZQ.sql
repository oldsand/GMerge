/*
** DROP Procedure [internal_ab_refresh_attribute_aliases]
** This procedure matches application object attributes assigned to a scan-group to entries in the scan-group's alias table
** (autobound_attribute_alias): The attribute's alias_id is updated to refer to the corresponding entry in the 
** autobound_attribute_alias table for each match discovered.
**  
** This is either called by internal_ab_assign_app_object_to_device or internal_ab_create_scangroup_alias. Or when the naming rule is changed in the IDE.
*/
CREATE PROCEDURE dbo.internal_ab_refresh_attribute_aliases
      @gobject_id             int = 0         -- [Optional] specific application target
    , @dio_id                 int = 0         -- [Optional] specific target DIO
    , @sg_mx_primitive_id     smallint = 0    -- [Optional] specific target scan-group wwithin a DIO (@dio cannot be non-zero if this parameter is non-zero)
    , @template_definition_id int = 0         -- [Optional] specifiic type of [DIO] template to extend this logic to
    , @category_id            int = 0         -- [Optional] category of objects to which to extend this functionality.
    , @rule_id                int = 0         -- [Optional] ID of a rule that was altered
as
begin
    set nocount on

    if @dio_id = 0
      set @sg_mx_primitive_id = 0

    UPDATE ab_attr
       SET ab_attr.alias_id = ab_aalias.alias_id
      FROM autobound_attribute ab_attr
    -- First, the linked [app] object
    INNER JOIN gobject lo
        ON lo.gobject_id = ab_attr.gobject_id
    INNER JOIN attribute_reference lo_attr_ref
        ON lo_attr_ref.gobject_id = ab_attr.gobject_id
       AND lo_attr_ref.package_id = lo.checked_in_package_id
       AND lo_attr_ref.referring_mx_primitive_id = ab_attr.mx_primitive_id
       AND lo_attr_ref.referring_mx_attribute_id = ab_attr.mx_attribute_id
    INNER JOIN primitive_instance lo_pi
        ON lo_pi.package_id = lo_attr_ref.package_id
       AND lo_pi.gobject_id = lo_attr_ref.gobject_id
       AND lo_pi.mx_primitive_id = lo_attr_ref.referring_mx_primitive_id
    INNER JOIN attribute_definition lo_attr_def
        ON lo_attr_def.primitive_definition_id = lo_pi.primitive_definition_id
       AND lo_attr_def.mx_attribute_id = lo_attr_ref.referring_mx_attribute_id
    INNER JOIN primitive_definition lo_pd
        ON lo_pd.primitive_definition_id = lo_pi.primitive_definition_id
    -- Now the DIO
    INNER JOIN gobject dio
        ON dio.gobject_id = ab_attr.dio_id
    INNER JOIN template_definition td 
        ON td.template_definition_id = dio.template_definition_id
    INNER JOIN lookup_category lcat 
        ON lcat.category_id = td.category_id
  	INNER JOIN primitive_instance sg_pi             -- Pending: Need to fix this to account for <default> scan-groups.
  	    ON sg_pi.gobject_id = dio.gobject_id
  	   AND sg_pi.package_id = dio.checked_in_package_id
  	   AND sg_pi.mx_primitive_id = ab_attr.sg_mx_primitive_id
    INNER JOIN autobind_device_topic ab_topic               -- Note: This is an inner join because <default> topics may not describe aliases. 
        ON ab_topic.dio_id = ab_attr.dio_id
       AND ab_topic.sg_mx_primitive_id = ab_attr.sg_mx_primitive_id
	  CROSS APPLY (SELECT * from AutobindNamingRule (ab_topic.dio_id, ab_topic.sg_mx_primitive_id) r where r.io_type = SUBSTRING (lo_attr_def.attribute_name, 1, 1)) ab_nr
    LEFT OUTER JOIN autobound_attribute_alias ab_aalias     -- Note: This is an outer join because we want NULL to be returned for unmatched aliases.
        ON ab_aalias.dio_id = ab_attr.dio_id
       AND ab_aalias.sg_mx_primitive_id = ab_attr.sg_mx_primitive_id
       AND ab_aalias.attr_name
           = dbo.evaluate_autobind_naming_rule (ab_nr.naming_rule, 
                                                lo.tag_name, lo.hierarchical_name, lo.contained_name, lo_pi.primitive_name, dio.tag_name, sg_pi.primitive_name,
                                                lo_pd.primitive_name, lo_attr_def.attribute_name)
    WHERE ab_attr.dio_id = CASE WHEN @dio_id <> 0 THEN @dio_id ELSE ab_attr.dio_id END
      AND ab_attr.sg_mx_primitive_id = CASE WHEN @sg_mx_primitive_id <> 0 THEN @sg_mx_primitive_id ELSE ab_attr.sg_mx_primitive_id END
      AND ab_attr.gobject_id = CASE WHEN @gobject_id <> 0 THEN @gobject_id ELSE ab_attr.gobject_id END
      AND td.template_definition_id = CASE WHEN @template_definition_id <> 0 THEN @template_definition_id ELSE td.template_definition_id END
      AND lcat.category_id = CASE WHEN @category_id <> 0 THEN @category_id ELSE lcat.category_id END
      AND ab_nr.rule_id = CASE WHEN @rule_id <> 0 THEN @rule_id ELSE ab_nr.rule_id END

    RETURN 0
end
go

