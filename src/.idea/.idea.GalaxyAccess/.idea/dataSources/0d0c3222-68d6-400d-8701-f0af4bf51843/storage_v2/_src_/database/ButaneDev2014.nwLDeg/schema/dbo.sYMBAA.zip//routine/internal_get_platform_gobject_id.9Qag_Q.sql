/**************************************************/
/*Object Name :  internal_get_platform_gobject_id                       */
/*Object Type :  Stored Proc.								 */
/*Purpose :    to retrieve gobject id of platform - used for deploy purpose*/
/*Used By :    CDI									*/
/**************************************************/
CREATE PROCEDURE dbo.internal_get_platform_gobject_id
@gobjectId int
 AS
begin

select isnull(platform.gobject_id, 0)
from gobject obj
inner join instance inst on obj.gobject_id =inst.gobject_id
left join instance platform on inst.mx_platform_id = platform.mx_platform_id and platform.mx_engine_id = 1

where obj.gobject_id = @gobjectId

end
go

