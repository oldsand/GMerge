-- This stored procedure is to list the descendents information of an object
-- 1. If @gobject_id is valid, the returned value would be rows of
--    gobject_id, derived_from_gobject_id, tag_name(of this object)
-- 2. If @gobject_id is the gobject_id of a base template, one row 
--    will be returned and the ancestor is 0.
-- 3. If @gobject_id is invalid, this SP return 0 row
-- 
create proc dbo.internal_list_descendents_for_object
    @gobject_id int,
    @bIsTemplates_only bit = 0 --This is default parameter is added to include templates only or instance as well
as
begin
    set nocount on
	
	--Start
	declare @all_objects int
        
    if @bIsTemplates_only = 1
		set @all_objects = 0
    else
		set @all_objects = 1
	--End
    
    ;with CTE(
        gobject_id,
        derived_from_gobject_id
    )
    as
    (
        select  gobject_id, 
                derived_from_gobject_id
        from    gobject
        where   gobject_id = @gobject_id
				and (is_template + @all_objects) > 0
    
        union all

        select  g.gobject_id,
                g.derived_from_gobject_id
        from    CTE
        inner join
                gobject g
        on
                CTE.gobject_id = g.derived_from_gobject_id
                and (g.is_template + @all_objects) > 0
    )

    select  CTE.gobject_id,
            CTE.derived_from_gobject_id,
            g.tag_name
    from    CTE
    inner join
            gobject g
    on
            g.gobject_id = CTE.gobject_id
    where
            g.gobject_id <> @gobject_id

    
end

go

