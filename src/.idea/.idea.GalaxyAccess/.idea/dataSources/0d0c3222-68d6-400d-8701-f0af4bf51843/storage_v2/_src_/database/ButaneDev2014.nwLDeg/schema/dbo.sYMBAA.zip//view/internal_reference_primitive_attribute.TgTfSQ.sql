/**********************************************************************/
/*Object Name :  internal_reference_primitive_attribute			      */
/*Object Type :  View.												  */
/*Purpose	  :  To provide reference and cross reference information */
/*Used By	  :  CDI												  */
/**********************************************************************/
create view 
   dbo.internal_reference_primitive_attribute 
as
select ar.gobject_id as referringGobjectID,  -- referring gobject id
       greferring.tag_name as referring_TagName, -- referring gobject's tag name
       pinst.primitive_name as referringPrimitiveName, -- referring object's primitive name
       ad.attribute_name as referringAttributeName,    -- referring object's attribute name
       case when pinst.primitive_name  = '' then      
         greferring.tag_name + '.' + ad.attribute_name
       else greferring.tag_name + '.' + pinst.primitive_name + '.' + ad.attribute_name
       end as referringAttribute_full_name,            -- referring attribute's full name tag_name + primitive_name + attribute_name
       ar.reference_string,                  -- Reference String     
       ar.context_string,                    -- Context String ( should be the referring object name )
       inst.gobject_id as referredToGobjectID,    -- referred to object's gobject_id 
       gobj.tag_name as Referred_TagName,         -- referred to object's tag_name 
       referredToPINST.primitive_name as referredToPrimitiveName,  -- referred to object's primitive name if bound
       referredToAD.attribute_name as referredToAttributeName,     -- referred to object's attribute name if bound
       case when referredToPINST.primitive_name = '' then          
         gobj.tag_name + '.' + referredToAD.attribute_name
       else 
	 gobj.tag_name + '.' + referredToPINST.primitive_name + '.' + referredToAD.attribute_name
       end as referredAttribute_full_name  -- referred to object's fully qualified attribute_name if bound
from 
	   attribute_reference ar    -- attribute reference source object
inner join gobject greferring 
	on ar.package_id = greferring.checked_in_package_id
inner join instance inst 
	on ar.resolved_gobject_id = inst.gobject_id
inner join primitive_instance pinst -- get the referring primitive name
	on ar.package_id = pinst.package_id 
	   and pinst.mx_primitive_id = ar.referring_mx_primitive_id
inner join attribute_definition ad -- get the referring attribute name
	on pinst.primitive_definition_id = ad.primitive_definition_id 
	   and ad.mx_attribute_id = ar.referring_mx_attribute_id
inner join gobject gobj 
        on gobj.gobject_id = inst.gobject_id
inner join primitive_instance referredToPINST   -- get the referred primitive_name
        on gobj.checked_in_package_id = referredToPINST.package_id 
       and ar.resolved_mx_primitive_id = referredToPINST.mx_primitive_id
inner join attribute_definition referredToAD    -- get the referred attribute_name
        on referredToPINST.primitive_definition_id = referredToAD.primitive_definition_id
       and ar.resolved_mx_attribute_id = referredToAD.mx_attribute_id
where  ar.is_valid = 0
union

select ar.gobject_id as referringGobjectID,  -- referring gobject id
       greferring.tag_name as referring_TagName, -- referring gobject's tag name
       pinst.primitive_name as referringPrimitiveName, -- referring object's primitive name
       ad.attribute_name as referringAttributeName,    -- referring object's attribute name
       case when pinst.primitive_name  = '' then      
         greferring.tag_name + '.' + ad.attribute_name
       else greferring.tag_name + '.' + pinst.primitive_name + '.' + ad.attribute_name
       end as referringAttribute_full_name,            -- referring attribute's full name tag_name + primitive_name + attribute_name
       ar.reference_string,                  -- Reference String     
       ar.context_string,                    -- Context String ( should be the referring object name )
       inst.gobject_id as referredToGobjectID,    -- referred to object's gobject_id 
       gobj.tag_name as Referred_TagName,         -- referred to object's tag_name 
       referredToPINST.primitive_name as referredToPrimitiveName,  -- referred to object's primitive name if bound
       referredToAD.attribute_name as referredToAttributeName,     -- referred to object's attribute name if bound
       case when referredToPINST.primitive_name = '' then          
         gobj.tag_name + '.' + referredToAD.attribute_name
       else 
	      gobj.tag_name + '.' + referredToPINST.primitive_name + '.' + referredToAD.attribute_name
       end as referredAttribute_full_name  -- referred to object's fully qualified attribute_name if bound
from 
	   attribute_reference ar    -- attribute reference source object
inner join gobject greferring 
	on ar.package_id = greferring.checked_in_package_id
inner join instance inst 
	on ar.resolved_gobject_id = inst.gobject_id
inner join primitive_instance pinst -- get the referring primitive name
	on ar.package_id = pinst.package_id 
	   and pinst.mx_primitive_id = ar.referring_mx_primitive_id
inner join attribute_definition ad -- get the referring attribute name
	on pinst.primitive_definition_id = ad.primitive_definition_id 
	   and ad.mx_attribute_id = ar.referring_mx_attribute_id
inner join gobject gobj 
        on gobj.gobject_id = inst.gobject_id
inner join primitive_instance referredToPINST   -- get the referred primitive_name
        on gobj.checked_in_package_id = referredToPINST.package_id 
       and ar.resolved_mx_primitive_id = referredToPINST.mx_primitive_id
inner join dynamic_attribute referredToAD    -- get the referred attribute_name
        on referredToPINST.package_id = referredToAD.package_id
	   and referredToPINST.mx_primitive_id = referredToAD.mx_primitive_id
       and ar.resolved_mx_attribute_id = referredToAD.mx_attribute_id

union

select ar.gobject_id as referringGobjectID,  -- referring gobject id
       greferring.tag_name as referring_TagName, -- referring gobject's tag name
       pinst.primitive_name as referringPrimitiveName, -- referring object's primitive name
       ad.attribute_name as referringAttributeName,    -- referring object's attribute name
       case when pinst.primitive_name  = '' then      
         greferring.tag_name + '.' + ad.attribute_name
       else greferring.tag_name + '.' + pinst.primitive_name + '.' + ad.attribute_name
       end as referringAttribute_full_name,            -- referring attribute's full name tag_name + primitive_name + attribute_name
       ar.reference_string,                  -- Reference String     
       ar.context_string,                    -- Context String ( should be the referring object name )
       case when ar.resolved_gobject_id = 0 then
	               0
                when ar.resolved_gobject_id > 0 and ar.is_valid = 1 then
                       0
                when ar.resolved_gobject_id > 0 and ar.is_valid = 0 then
					ar.resolved_gobject_id  
       end as referredToGobjectID,    -- referred to object's gobject_id 
       case when ar.resolved_gobject_id = 0 then 
                  '' 
            when ar.resolved_gobject_id > 0 and ar.is_valid = 1 then
                  ''
            when ar.resolved_gobject_id > 0 and ar.is_valid = 0 then
 				(select tag_name from gobject g where ar.resolved_gobject_id = g.gobject_id)
       end as Referred_TagName,         -- referred to object's tag_name 
       '' as referredToPrimitiveName,  -- referred to object's primitive name if bound
       '' as referredToAttributeName,     -- referred to object's attribute name if bound
       case when ar.resolved_gobject_id > 0 and ar.is_valid = 0 then 
                 (select tag_name from gobject g where ar.resolved_gobject_id = g.gobject_id)
            else
               ''
            end 
	as referredAttribute_full_name  -- referred to object's fully qualified attribute_name if bound
from 
	   attribute_reference ar    -- attribute reference source object
inner join gobject greferring 
	on ar.package_id = greferring.checked_in_package_id
inner join primitive_instance pinst -- get the referring primitive name
	on ar.package_id = pinst.package_id 
	   and pinst.mx_primitive_id = ar.referring_mx_primitive_id
inner join attribute_definition ad -- get the referring attribute name
	on pinst.primitive_definition_id = ad.primitive_definition_id 
	   and ad.mx_attribute_id = ar.referring_mx_attribute_id
where   ar.resolved_mx_primitive_id = 0 or is_valid = 1
go

