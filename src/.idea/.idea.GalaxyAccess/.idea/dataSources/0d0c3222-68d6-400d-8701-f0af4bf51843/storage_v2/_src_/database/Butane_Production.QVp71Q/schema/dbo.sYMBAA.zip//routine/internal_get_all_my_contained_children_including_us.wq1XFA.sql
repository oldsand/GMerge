--Returns All Contained Childreens for given GobjectIds

CREATE PROC dbo.internal_get_all_my_contained_children_including_us
	@ParentGobjectIdsFileName nvarchar(256)
AS
BEGIN

	set nocount on
	CREATE TABLE  #results_table ( gobject_id int)
	
	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @ParentGobjectIdsFileName+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'',ROWTERMINATOR = '','')'

	EXEC sp_executesql @SQL

	declare @objCount integer
	declare @nLevel integer
	declare @effectedObjects table(obj_id int,mycontainer int,nLevel smallint)

	insert into @effectedObjects  ( obj_id,mycontainer,nLevel)
		(select gobject_id,0,1 from #results_table )
	

	select @objCount = count(*) from @effectedObjects	
	IF @objCount > 0
	BEGIN
		set @nLevel = 1
		while 1 > 0
		BEGIN
	
			insert into @effectedObjects
			select gobject_id, CI.obj_id, @nLevel + 1
			from gobject G inner join @effectedObjects CI on G.contained_by_gobject_id = CI.obj_id
			where nLevel = @nLevel
	
			if @@rowcount = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END

	declare @final_selection table(
		original_order int identity(1,1),
		gobject_id int)

	insert into @final_selection (gobject_id)
	select obj_id 
	from @effectedObjects

	select 
		distinct gobject_id, 
		original_order
	from @final_selection
	order by original_order
	

	drop table #results_table 
	
END
go

