/**************************************************
Object Name :  internal_get_gobject_immediate_descendants
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves all immediate derived objects for a specific gobject
Used By	    :  CDI uses it in GetDescendants call.
Variables Used -
@WorkingSet - holds gobjects for a particular iteration in the while loop. 
@TemporaryCache - temporarily holds all the descendants of the @WorkingSet gobjects.
@ResultSet - holds all the descendant gobjects
**************************************************/

CREATE PROCEDURE dbo.internal_get_gobject_immediate_descendants
	@gObjectId int
AS
begin
	set nocount on

	select	gobject_id, 
			is_template,
			'isImmediateChild' = 
				case when  derived_from_gobject_id = @gObjectId then
					1
				else
					0
				end
	from	gobject 
	where	derived_from_gobject_id = @gObjectId /*and
			namespace_id = 1*/
	
end

go

