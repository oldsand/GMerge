create  procedure dbo.internal_update_browser_primary_assembly_info
    @file_id int,
    @assembly_name nvarchar(256),
    @assembly_type nvarchar(256)
AS
begin
    set nocount on

    update  file_browserinfo_link
    set     assembly_strong_name = @assembly_name,
            assembly_type_name = @assembly_type
    where   file_id = @file_id 
    set nocount off
end

go

