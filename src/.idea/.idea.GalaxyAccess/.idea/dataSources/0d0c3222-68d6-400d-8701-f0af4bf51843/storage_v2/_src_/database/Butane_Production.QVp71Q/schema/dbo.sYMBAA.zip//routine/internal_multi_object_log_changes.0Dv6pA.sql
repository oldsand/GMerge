/**************************************************/
/*Object Name :  internal_multi_object_log_changes                       */
/*Object Type :  Stored Proc.								 */
/*Purpose :    Procedure to insert data into ChangeLog table.*/
/*Used By :    CDI									*/
/**************************************************/
create procedure dbo.internal_multi_object_log_changes
@FileNameOfids nvarchar (265),
@userid nvarchar(64),
@varOpid   int,
@varUserComment nvarchar(1024)
-- with ENCRYPTION
AS
SET NOCOUNT ON
begin
	
	declare @working_table table
	( 
		id int, 
		configversion int default 1, 
		tag_name nvarchar (329) COLLATE SQL_Latin1_General_CP1_CI_AS
	)
	begin tran


	SET QUOTED_idENTIFIER OFF

	CREATE TABLE  #results_table ( gobject_id int)

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT #results_table  FROM ''' + @FileNameOfids+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'

	EXEC (@SQL)

	insert into @working_table( id )
		( select gobject_id from #results_table )
	
	drop table #results_table


	update @working_table set configversion = gobject.configuration_version, tag_name = gobject.tag_name
	from gobject gobject
	inner join @working_table working_table
		on working_table.id = gobject.gobject_id
    
    declare @user_profile_name nvarchar(256)
    select @user_profile_name  = user_profile_name from user_profile where user_guid = @userid
	if @user_profile_name is NULL
		set @user_profile_name = N'DefaultUser'

	insert into gobject_change_log
	( gobject_id, change_date, operation_id, user_comment, configuration_version,user_profile_name )
	select
	id,
	GetDATE(),
	@varOpid,
	@varUserComment,
	configversion,
    @user_profile_name
	from @working_table

	commit tran


end

go

