create trigger trigger_update_gobject
on gobject
for update
as
begin tran

    -- obain a new timestamp for marking prmitives who have been affected
    -- by this operation

    declare @new_timestamp bigint
	set @new_timestamp = 0


    if update(contained_by_gobject_id)
    begin
        exec internal_get_next_timestamp @new_timestamp out 
        
    
        declare @input table
        ( 
            gobject_id int primary key
        )
        insert into @input 
        select 
            gobject_id
        from deleted 
            
        declare @all table( gobject_id int primary key) -- @all if pk is one column
         
        insert @all 
        select distinct gobject_id 
        from @input
         
        declare @next table ( gobject_id int primary key) 
        declare @prev table ( gobject_id int primary key) 
         
        -- seed 
        insert @prev 
        select gobject_id 
        from @input 
         
        while @@rowcount > 0 -- note, rowcount initially from insert @prev, then from delete @next
        begin

            insert into @next
            select distinct g.gobject_id
            from @prev  p 
            inner join gobject g with(nolock)on
                g.contained_by_gobject_id = p.gobject_id
            where 
                g.gobject_id not in(select gobject_id from  @all )

            insert @all 
            select * from @next

            delete from @prev

            insert @prev 
            select * from @next

            delete from @next
        end

        declare @affected_checked_in_bound_elements table
        (
            gobject_id int not null,
            package_id int not null,
            mx_primitive_id smallint not null,    
            visual_element_reference_index int not null,
            --visual_element_bind_status char (1) not null,-- now a calculated column..
            is_relative_reference bit not null,
            checked_in_unbound_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
            checked_in_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS,
            checked_in_unbound_tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS ,
            checked_in_unbound_primitive_name nvarchar(329)  COLLATE SQL_Latin1_General_CP1_CI_AS null,
            checked_in_unbound_relative_object_name nvarchar (329) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
            checked_in_unbound_visual_element_id int null
         )

        declare @affected_checked_out_bound_elements table
        (
            gobject_id int not null,
            package_id int not null,
            mx_primitive_id smallint not null,    
            visual_element_reference_index int not null,
            is_relative_reference bit not null,
            checked_out_unbound_visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS ,
            checked_out_unbound_visual_element_type nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS ,
            checked_out_unbound_tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS  ,
            checked_out_unbound_primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS  null,
            checked_out_unbound_relative_object_name nvarchar (329)  COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
            checked_out_unbound_visual_element_id int null
        )

        -- break any relative visual element references that refer to checked_in VEs...
        insert into @affected_checked_in_bound_elements
            (gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index,
            --visual_element_bind_status, -- now a calculated column..
            is_relative_reference,
            checked_in_unbound_visual_element_name ,
            checked_in_unbound_visual_element_type ,
            checked_in_unbound_tag_name  ,
            checked_in_unbound_primitive_name ,
            checked_in_unbound_relative_object_name,
            checked_in_unbound_visual_element_id)
            select 
            distinct
            b.gobject_id,
            b.package_id,
            b.mx_primitive_id,
            b.visual_element_reference_index,
            1,
            case when(len(d.hierarchical_name) > len(gme.hierarchical_name)) then
                    'me'+ right(d.hierarchical_name,(len(d.hierarchical_name)- len(gme.hierarchical_name)) )  +   '.' + pri.primitive_name
            else
               null
            end,
            v.visual_element_type,
            '',
            pri.primitive_name,
             case when(len(d.hierarchical_name) > len(gme.hierarchical_name)) then
                 right(d.hierarchical_name,(len(d.hierarchical_name)- len(gme.hierarchical_name) -1))
             else
                 null
             end,
            v.visual_element_id
            from @all a
            inner join gobject d on
                a.gobject_id = d.gobject_id
            inner join visual_element_version vev on
                d.gobject_id = vev.gobject_id and
                d.checked_in_package_id = vev.package_id
            inner join package p on 
                vev.gobject_id = p.gobject_id and
                vev.package_id = p.package_id 
            inner join visual_element_reference b on     
                b.checked_in_bound_visual_element_gobject_id = vev.gobject_id and
                b.checked_in_bound_visual_element_package_id = vev.package_id and
                b.checked_in_bound_visual_element_mx_primitive_id = vev.mx_primitive_id and
                vev.package_id = d.checked_in_package_id and
                b.is_relative_reference = 1
            inner join visual_element v on 
                vev.visual_element_id = v.visual_element_id
            inner join primitive_instance pri on pri.gobject_id = d.gobject_id and
                   pri.package_id = vev.package_id and 
                   pri.mx_primitive_id = vev.mx_primitive_id 
            inner join gobject gme on b.gobject_id = gme.gobject_id 
            where b.gobject_id not in (select gobject_id from @all)
     
            --update the checked_in_unbound ver columns....
            if exists(select 1 from @affected_checked_in_bound_elements)
            begin
                update  ver
                set -- unbound columns...
                    ver.checked_in_unbound_visual_element_name = wt.checked_in_unbound_visual_element_name,
                    ver.checked_in_unbound_visual_element_type = wt.checked_in_unbound_visual_element_type,
                    ver.checked_in_unbound_tag_name = wt.checked_in_unbound_tag_name,
                    ver.checked_in_unbound_primitive_name = wt.checked_in_unbound_primitive_name,
                    ver.checked_in_unbound_relative_object_name = wt.checked_in_unbound_relative_object_name,
                    ver.checked_in_unbound_visual_element_id = null, 
                    -- bound columns....
                    ver.checked_in_bound_visual_element_gobject_id = null,
                    ver.checked_in_bound_visual_element_package_id = null,
                    ver.checked_in_bound_visual_element_mx_primitive_id = null
                from visual_element_reference ver 
                inner join @affected_checked_in_bound_elements wt on
                    wt.gobject_id = ver.gobject_id and
                    wt.package_id = ver.package_id and
                    wt.mx_primitive_id = ver.mx_primitive_id and
                    wt.visual_element_reference_index = ver.visual_element_reference_index
        
                update pri
                set max_child_timestamp = @new_timestamp
                from primitive_instance pri
                inner join @affected_checked_in_bound_elements wt on
                    wt.gobject_id = pri.gobject_id and
                    wt.package_id = pri.package_id and
                    wt.mx_primitive_id = pri.mx_primitive_id
            end
    
       
        -- break any relative visual element references that refer to checked_out VEs...
        insert into @affected_checked_out_bound_elements
            (gobject_id,
            package_id,
            mx_primitive_id,
            visual_element_reference_index,
            --visual_element_bind_status,-- now a calculated column..
            is_relative_reference,
            checked_out_unbound_visual_element_name ,
            checked_out_unbound_visual_element_type ,
            checked_out_unbound_tag_name  ,
            checked_out_unbound_primitive_name ,
            checked_out_unbound_relative_object_name,
            checked_out_unbound_visual_element_id)
            select 
            distinct
            b.gobject_id,
            b.package_id,
            b.mx_primitive_id,
            b.visual_element_reference_index,
            1,
            case when(len(d.hierarchical_name) > len(gme.hierarchical_name)) then
                    'me'+ right(d.hierarchical_name,(len(d.hierarchical_name)- len(gme.hierarchical_name)) )  +   '.' + pri.primitive_name
            else
               null
            end,
            v.visual_element_type,
            '',
            pri.primitive_name,
             case when(len(d.hierarchical_name) > len(gme.hierarchical_name)) then
                 right(d.hierarchical_name,(len(d.hierarchical_name)- len(gme.hierarchical_name) -1))
             else
                 null
             end,
            v.visual_element_id
            from @all a 
            inner join gobject d on
                a.gobject_id = d.gobject_id
            inner join visual_element_version vev on
                d.gobject_id = vev.gobject_id and
                d.checked_out_package_id = vev.package_id
            inner join package p on 
                vev.gobject_id = p.gobject_id and
                vev.package_id = p.package_id 
            inner join visual_element_reference b on     
                b.checked_out_bound_visual_element_gobject_id = vev.gobject_id and
                b.checked_out_bound_visual_element_package_id = vev.package_id and
                b.checked_out_bound_visual_element_mx_primitive_id = vev.mx_primitive_id and
                vev.package_id = d.checked_out_package_id and
                b.is_relative_reference = 1
            inner join visual_element v on 
                vev.visual_element_id = v.visual_element_id
            inner join primitive_instance pri on pri.gobject_id = d.gobject_id and
                   pri.package_id = vev.package_id and 
                   pri.mx_primitive_id = vev.mx_primitive_id 
            inner join gobject gme on b.gobject_id = gme.gobject_id 
            where b.gobject_id not in (select gobject_id from @all)
     
            --update the timestamp of any primitive
            --that referred to an element affected by this operation......
            if exists(select 1 from @affected_checked_out_bound_elements)
            begin
                update  ver
                set -- unbound columns...
                    ver.checked_out_unbound_visual_element_name = wt.checked_out_unbound_visual_element_name,
                    ver.checked_out_unbound_visual_element_type = wt.checked_out_unbound_visual_element_type,
                    ver.checked_out_unbound_tag_name = wt.checked_out_unbound_tag_name,
                    ver.checked_out_unbound_primitive_name = wt.checked_out_unbound_primitive_name,
                    ver.checked_out_unbound_relative_object_name = wt.checked_out_unbound_relative_object_name,
                    --ver.visual_element_bind_status = 0,-- now a calculated column..
                    ver.checked_out_unbound_visual_element_id = null,
                    -- bound columns....
                    ver.checked_out_bound_visual_element_gobject_id = null,
                    ver.checked_out_bound_visual_element_package_id = null,
                    ver.checked_out_bound_visual_element_mx_primitive_id = null
                from visual_element_reference ver 
                inner join @affected_checked_out_bound_elements wt on
                    wt.gobject_id = ver.gobject_id and
                    wt.package_id = ver.package_id and
                    wt.mx_primitive_id = ver.mx_primitive_id and
                    wt.visual_element_reference_index = ver.visual_element_reference_index
            
                -- update the parents of the deleted primitives..
                update pri
                set max_child_timestamp = @new_timestamp
                from primitive_instance pri
                inner join @affected_checked_out_bound_elements wt on
                    wt.gobject_id = pri.gobject_id and
                    wt.package_id = pri.package_id and
                    wt.mx_primitive_id = pri.mx_primitive_id
            end                 


    end



    if update(hierarchical_name) or update(contained_name) or update(tag_name)
    begin

		if(@new_timestamp = 0)
		begin
			exec internal_get_next_timestamp @new_timestamp out
		end
 
        declare @modified_visual_element table
            (visual_element_id int,
            max_child_timestamp bigint)    
    
        -- update all of the object's primitive timestamps...
        
	if exists(
		select '1'
		from 
		primitive_instance pri
		inner join visual_element_version vev on
			pri.gobject_id = vev.gobject_id and
			pri.package_id = vev.package_id and
			pri.mx_primitive_id = vev.mx_primitive_id	
	        inner join inserted i on
	            i.gobject_id = pri.gobject_id 
		)
	begin
		update pri
	        set timestamp_of_last_change = @new_timestamp
	        from primitive_instance pri
		inner join visual_element_version vev on
			pri.gobject_id = vev.gobject_id and
			pri.package_id = vev.package_id and
			pri.mx_primitive_id = vev.mx_primitive_id	
	        inner join inserted i on
	            i.gobject_id = pri.gobject_id 
	end       
        -- get a list of visual elements that were affected by this change
	
	        insert into @modified_visual_element
	             (visual_element_id ,
	             max_child_timestamp)
	        select 
	            vev.visual_element_id,
	            @new_timestamp    
	        from inserted i
	        inner join visual_element_version vev on
	            i.gobject_id = vev.gobject_id
		
		if(@@rowcount > 0)
		begin
		   -- update the parents of the deleted primitives..
			update pri
			set max_child_timestamp = mve.max_child_timestamp
			from visual_element_reference b
			inner join visual_element_version bound_vev on
			 b.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
			 b.checked_in_bound_visual_element_package_id = bound_vev.package_id and
			 b.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
			inner join primitive_instance pri on 
				bound_vev.gobject_id = pri.gobject_id and 
				bound_vev.package_id = pri.package_id and
				bound_vev.mx_primitive_id = pri.mx_primitive_id
			inner join @modified_visual_element mve on 
				mve.visual_element_id = bound_vev.visual_element_id
		end 
    end 


commit
go

