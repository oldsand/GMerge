create procedure dbo.internal_split_objects_for_deploy
	@FileNameOfIds		NVARCHAR( 400 ),
	@operation_type smallint
AS
begin tran
	set nocount on
	
	create table #gobject_ids
	(
		gobject_id	int primary key
	)

	exec internal_construct_table_from_file @FileNameOfIds, '#gobject_ids'

	CREATE TABLE #engines( tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, counter int)

	INSERT INTO #engines( tag_name , counter)
	SELECT MIN(tag_name), COUNT(tag_name) FROM gobject g INNER JOIN
	#gobject_ids gt ON g.gobject_id = gt.gobject_id 
	INNER JOIN redundancy r
	ON ( (g.gobject_id = r.primary_gobject_id) OR (g.gobject_id = r.backup_gobject_id) )
	INNER JOIN instance i
	ON ( (g.gobject_id = i.gobject_id) and (i.mx_platform_id > 0))
	GROUP BY tag_name
	
	CREATE TABLE #redudantObjects(obj_id int primary key)

	if exists (select tag_name from #engines where counter = 2)
	begin
	
		CREATE TABLE #enginesInfo(gobject_id int,
			tag_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
			mx_platform_id int,
			mx_engine_id int,
			mx_object_id int)

		insert into #enginesInfo
		select	i.gobject_id,
				g.tag_name,			
				i.mx_platform_id,
				i.mx_engine_id,
				i.mx_object_id
		from  gobject g  inner join instance i
		on i.gobject_id = g.gobject_id		
		inner join  #engines en 
		ON
		g.tag_name = en.tag_name and 
		en.counter = 2	
		

		
		insert into #redudantObjects
		select i.gobject_id from instance i
		inner join #enginesInfo enf
		on i.mx_platform_id = enf.mx_platform_id	
		and i.mx_engine_id = enf.mx_engine_id
		inner join #gobject_ids gi on 
		i.gobject_id = 	gi.gobject_id
		--inner join gobject g on
		--i.gobject_id = 	g.gobject_id
		--where g.deployed_package_id > 0

		if(@operation_type = 1)
		begin
			select 	obj_id from #redudantObjects			
			select gi.gobject_id from #gobject_ids gi
			--inner join gobject g on
			--gi.gobject_id = 	g.gobject_id
			--where g.deployed_package_id > 0
			where gi.gobject_id 
			not in (select obj_id from #redudantObjects)			
			
		end
		else
		begin
			select 	obj_id from #redudantObjects ro			
			inner join gobject  gi
			on ro.obj_id = gi.gobject_id 
			and gi.deployed_package_id > 0

			select gi.gobject_id from #gobject_ids gi
			inner join gobject g on
			gi.gobject_id =	g.gobject_id
			where g.deployed_package_id > 0
			and gi.gobject_id 
			not in (select obj_id from #redudantObjects)
		end


		
--FOR DEBUG
--	select i.gobject_id,g.tag_name 
--	 from instance i
--	inner join #enginesInfo enf
--	on i.mx_platform_id = enf.mx_platform_id	
--	and i.mx_engine_id = enf.mx_engine_id
--	inner join #gobject_ids gi on 
--	i.gobject_id = 	gi.gobject_id
--	inner join gobject g on g.gobject_id = gi.gobject_id
		DROP TABLE #enginesInfo
	end
	else
	begin
		select 	obj_id from #redudantObjects

		if(@operation_type = 1)
			select gi.gobject_id from #gobject_ids gi 
			inner join instance i on gi.gobject_id = i.gobject_id									
			and i.mx_platform_id > 0			
			union 
			select gi.gobject_id from #gobject_ids gi 
			inner join gobject g on gi.gobject_id = g.gobject_id									
			inner join template_definition td on td.template_definition_id = g.template_definition_id 
			where td.category_id = 25			
			
			
		else
			select gi.gobject_id from #gobject_ids gi 
			inner join instance i on gi.gobject_id = i.gobject_id
			and i.mx_platform_id > 0
			inner join gobject g on gi.gobject_id = g.gobject_id
			and g.deployed_package_id > 0
			union 
			select gi.gobject_id from #gobject_ids gi 
			inner join gobject g on gi.gobject_id = g.gobject_id									
			inner join template_definition td on td.template_definition_id = g.template_definition_id 
			where td.category_id = 25				
			and g.deployed_package_id > 0	 
	end

	DROP TABLE	#redudantObjects
	DROP TABLE #engines	
	DROP TABLE #gobject_ids
	

commit tran



go

