-- This will add an unchecked foreign key constraint to a table
--
-- This is useful in that it adds to the documentation of the schema, 
-- without incurring a performance hit.
--
-- usage: exec add_unchecked_foreign_key "fkTable", "fkColumn", "pkTable"
--
-- example: exec add_unchecked_foreign_key "template_definition", "category_id", "lookup_category", "category_id"
--

create proc dbo.add_unchecked_foreign_key
    @fkTable nvarchar(100),  -- table with foreign key
    @fkColumn nvarchar(100), -- column of foreign key
    @pkTable nvarchar(100),  -- table with foreign key
    @pkColumn nvarchar(100)  -- column of primary key
as
begin
    -- add the foreign key
    declare @execString nvarchar(2000)
    declare @constraintName nvarchar(2000)
    set @constraintName = 'fk_' + @fkTable + '_' + @fkColumn + '_to_' + @pkTable
    set @execString = 'alter table  ' + @fkTable + '  with nocheck  add constraint  ' + @constraintName + ' foreign key (' + @fkColumn + ') references ' +@pkTable + '(' + @pkColumn + ' )'
    
	exec sp_executesql @execString

    -- disable it
    declare @execString2 nvarchar(2000)
    set @execString2 = 'alter table '+@fkTable +' nocheck constraint '+ @constraintName
    exec sp_executesql @execString2
end
go

