/*********************************************************/
/*Object Name :  internal_getIOPointCount                */
/*Object Type :  Stored Proc.                            */
/*Purpose	  :  Procedure to Get the count of IO points */
/*Used By	  :  CDI()                                   */
/*********************************************************/
create procedure dbo.internal_get_io_point_count
@nIOPoints int out 
AS
begin

set @nIOPoints = 
(select count (*) from  
 (select distinct reference_string, 
				  resolved_mx_primitive_id, 
				  resolved_mx_attribute_id, 
 		          resolved_mx_property_id 
  from attribute_reference where resolved_gobject_id in 
   (select gobject_id from gobject where template_definition_id in 
    (select template_definition_id from template_definition where category_id = 12 or category_id = 11 or category_id = 24)
   ) AND package_id NOT IN (SELECT checked_out_package_id FROM gobject WHERE checked_out_package_id <> 0)
 AND resolved_mx_primitive_id=0 AND resolved_mx_attribute_id =0) as q		/*CR L00108911*/
)


end
go

