create proc dbo.internal_set_device_linkage_association(
    @childIdList nvarchar(255),
    @parentId int,
    @sg_mx_primitive_id smallint,
    @assocType smallint,
    @force_area_device_linkage bit, -- Applicable if area objects are selected
    @ignore_area_device_linkage bit, -- Applicable if objects are selected without the areas that host them.
    @operationStatus int out)
As 
begin
  -- TO DO: Account for redundant objects (they need to point to the same DIO as their primary counterparts)
  -- Arguments that require some explanation:
  -- @force_area_device_linkage: If true, all objects hosted by an area are forced to be linked to the 
  --    same device to which the area is being [re]assigned, regardless of whether or not such congruence exists
  --    in the first place.
  -- @ignore_area_device_linkage: If true, individual objects (whose hosting areas haven't been selected for device assignment)
  --    may be assigned to devices other than those to which their hosting areas are assigned.
  set @operationStatus = 1 -- FAILED
	if @parentId = 0 return	-- UNASSIGNMENT, should call internal_unset_association

	if @assocType <> 4 return --This only applicable for the IO assignement

  begin tran
  set nocount on

  declare @BIG_MULT bigint = 1000000

  declare @to_device bigint = @parentId * @BIG_MULT + @sg_mx_primitive_id

  -- ASSIGNMENT
      
  declare @retAffectedObjects table(gobject_id int, is_toolset bit)
  declare @parentCategory nvarchar(329), @childCategory int, @my_container int 
  declare @objCount int, @nLevel smallint
  declare @is_template bit    

  select @parentCategory = category_name, @is_template = is_template
  from gobject inner join template_definition
  on gobject.template_definition_id = template_definition.template_definition_id
  inner join lookup_category lc on lc.category_id = template_definition.category_id
  where gobject_id = @parentId

  if(@parentCategory NOT IN (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO') OR @is_template = 1) -- if host is not a valid DIO then return
  begin
      rollback tran
      return  
  end

  create table  #childList (gid int primary key)
  DECLARE @gSQL nvarchar(2000)
  SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
              WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
  EXEC sp_executesql @gSQL

  -- Remove all deployed objects from the input list.
  exec internal_filter_deployed_objects_from_input_list
  -- Filter out objects that are ineligible for assignment:
  -- DIO objects
  delete #childList
    from #childList cl
  inner join gobject g
      on cl.gid = g.gobject_id
  inner join template_definition
      on template_definition.template_definition_id = g.template_definition_id
  inner join lookup_category lc
      on lc.category_id = template_definition.category_id
     and lc.category_name IN (N'idxCategoryIONetwork', N'idxCategoryIODevice', N'idxCategoryPostIO')
  --truncate table CurrentSessionContainedName 

  declare @Stage table (
      obj_id  int primary key
    , area_id int
    , cat_id  int
    , device  bigint
    , cscdchg bit
  )

  -- Stage all objects: Determine their current device linkages.
  insert into @Stage
  select c.gid, g.area_gobject_id, t.category_id, ISNULL (d.dio_id, 0) * @BIG_MULT + ISNULL (d.sg_mx_primitive_id, 0)
       , CASE WHEN t.category_id = 13 THEN 1 ELSE 0 END
    from #childList c
  inner join gobject g
      on g.gobject_id = c.gid
   and g.is_template = 0
  inner join template_definition t 
      on t.template_definition_id = g.template_definition_id
  left outer join object_device_linkage d
      on d.gobject_id = g.gobject_id

  -- Delete objects in #childList that are hosted by areas that are also included in #childList:
  -- They will be processed with the parent area anyway.
  --delete ds
  --  from @Stage ds
  --inner join @Stage ia 
  --    on ia.obj_id = ds.area_id
  update stage
     set cscdchg = 0
    from @Stage stage
  inner join @Stage ia  -- inclusive app object
      on ia.area_id = stage.obj_id
      and ia.cat_id <> 13
    where stage.cscdchg = 1 


  -- Now determine which objects to process
  declare @ObjInfo table (
      obj_id  int primary key
    , area_id int
    , cat_id  smallint
    , my_dev  bigint
    , cscdchg bit
    , process bit)

  -- Insert areas in @ObjInfo for singles (objects that are selected without their hosting area):
  -- These entries will merely be used to enforce rules regarding assigning objects to devices other than
  -- those to which their parents are linked. Mark them as 'not for processing'. [13 == Area category]
  -- Account for areas (i.e., ignore) areas that were selected by the user, and which were updated not to
  -- cascade change.
  insert into @ObjInfo
  select distinct g.area_gobject_id, 0, 13, ISNULL (d.dio_id, 0) * @BIG_MULT + ISNULL (d.sg_mx_primitive_id, 0), singles.cscdchg, 0
    from gobject g
  inner join @Stage singles
      on singles.obj_id = g.gobject_id
     and singles.cat_id <> 13
  left outer join @Stage area
      on area.obj_id = g.area_gobject_id
  left outer join object_device_linkage d
      on d.gobject_id = g.area_gobject_id
   where area.obj_id IS NULL


  -- Identify objects that may be assigned to the new device/scan-group (1st pass)
  -- This will include for device linkage:
  --    All singles (objects that are selected without their hosting area); and,
  --    All areas included in the original #childList
  insert into @ObjInfo
  select st.obj_id, (CASE WHEN st.cat_id = 13 THEN 0 ELSE st.area_id END), st.cat_id, st.device, st.cscdchg
        , CASE 
            WHEN st.device <> @to_device                          -- Object already assigned to the target device: Don't process.
             AND (st.cat_id = 13                                  -- Area objects included in #childList
                  OR st.area_id = 0                               -- Objects that aren't assigned to an area that are in #childList
                  OR area_id.my_dev = @to_device                  -- Object is being assigned (returned) to its area's device
                  OR @ignore_area_device_linkage = 1              -- Advisory setting makes object eligible for processing
                  OR st.device <> area_id.my_dev)                 -- Object already assigned to a device that's different from its area's
              THEN 1
            ELSE 0 
          END
    from @Stage st
  left outer join @ObjInfo area_id                                -- Outer join because @ObjInfo currently only contains areas that are not to be processed
      on area_id.obj_id = st.area_id


  -- Now, for objects hosted by the areas included in the assignment operation
  insert into @ObjInfo
  select g.gobject_id, g.area_gobject_id, t.category_id, ISNULL (d.dio_id, 0) * @BIG_MULT + ISNULL (d.sg_mx_primitive_id, 0), 0
       , CASE 
            WHEN ISNULL (d.dio_id, 0) * @BIG_MULT 
                 + ISNULL (d.sg_mx_primitive_id, 0) <> @to_device -- Object already assigned to device: Don't process
             AND (@force_area_device_linkage = 1                  -- Advisory setting makes object eligible for processing
                  OR ISNULL (d.dio_id, 0) * @BIG_MULT 
                     + ISNULL (d.sg_mx_primitive_id, 0) 
                     = area_id.my_dev                             -- Object being linked to a device to which its area is being assigned
                  OR area_id.my_dev = @to_device)                 -- Object being assigned (returned) to its area's device
              THEN 1
            ELSE 0 
          END
    from gobject g
  inner join template_definition t
     on t.template_definition_id = g.template_definition_id
  inner join lookup_category lc                                   -- To exclude DIO or sub-areas that are hosted by areas being reassigned
      on lc.category_id = t.category_id
     and lc.category_name NOT IN (N'idxCategoryIONetwork'
                                , N'idxCategoryIODevice'
                                , N'idxCategoryPostIO'
                                , N'idxCategoryArea')
  inner join @ObjInfo area_id
      on area_id.obj_id = g.area_gobject_id
     and area_id.process = 1
     and area_id.cat_id = 13 
     and area_id.cscdchg = 1
  left outer join object_device_linkage d
      on d.gobject_id = g.gobject_id
  where g.deployed_package_id = 0

  -- @ObjInfo now has all objects to be assigned to @parent.@sg_mx_primitive_id
  -- Insert all new associations
  -- Use the MERGE operator to do this in one shot.(TBD)
  insert into object_device_linkage
  select obj_id, @parentId, @sg_mx_primitive_id
    from @ObjInfo
   where my_dev  = 0
     and process = 1 


  -- Update existing associations
  update object_device_linkage
  set dio_id = @parentId, sg_mx_primitive_id = @sg_mx_primitive_id
  from  object_device_linkage ODL 
  inner join @ObjInfo o
     on o.obj_id = ODL.gobject_id
    and o.my_dev <> 0 
    and process = 1 

   -- Finally, the attribute reference table
  update attribute_reference
     set is_valid = 1
    from  attribute_reference AR 
  inner join @ObjInfo o
      on AR.gobject_id = o.obj_id
     and o.process = 1
   where reference_string = N'---Auto---' OR reference_string like 'myDIO.%'

    --START
    --set the package status after assignment of IO
    update package set reference_status_id = 2
    from @ObjInfo o
    inner join gobject g on
    o.obj_id = g.gobject_id and o.process = 1
    inner join package PK on
    g.gobject_id = PK.gobject_id and
    g.checked_in_package_id = PK.package_id
    inner join attribute_reference AR on
    PK.gobject_id = AR.gobject_id and
    PK.package_id = AR.package_id and
    AR.is_valid = 1 
    where  reference_string = N'---Auto---' OR reference_string like 'myDIO.%'
    --END

  select obj_id, 0 from @ObjInfo where process = 1

  set @operationStatus = 0 -- S_OK
	Commit tran
end



go

