CREATE PROCEDURE dbo.internal_delete_unused_alarm_messages
AS
BEGIN
	-- Garbage collector for unused alarm_message_default, and alarm_message_translation 
	-- rows.  Called at the end of export operation once all rows in the cache for the operation 
	-- have been updated
	--
	-- Remove alarm_messages which have no corresponding primitive_instance record (e.g.  
	-- package id changed due to check-out/in for the input objects).

	delete from alarm_messages
	from alarm_messages ams
	left join primitive_instance pi on 
		pi.gobject_id = ams.gobject_id and
		pi.package_id = ams.package_id and
		pi.mx_primitive_id = ams.mx_primitive_id
	where pi.gobject_id is null
	
	--
	-- Next remove alarm_message_defaults which have no corresponding records in alarm_messages.
	delete from alarm_message_defaults
	from alarm_message_defaults amds
	left join alarm_messages ams on ams.phrase_id = amds.phrase_id
	where ams.phrase_id is null

	--
	--	Also delete alarm_message_timestamps for objects that no longer exist
	delete from alarm_message_timestamps
	from alarm_message_timestamps amts
	left join gobject g on g.gobject_id = amts.gobject_id
	where g.gobject_id is null

END

go

