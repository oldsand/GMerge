/************************************************************/
/*Object Name	:	internal_mark_deployed_pending_status   */
/*Object Type	:	Stored Proc.                            */
/*Purpose		:	to set the pending deployment status    */
/*Used By		:	CDI                                     */
/***********************************************************/

create proc [dbo].[internal_mark_deployed_pending_status]

    @GobjectIdsFileName nvarchar(2000)

as

begin
set nocount on
begin tran
      CREATE TABLE  #gobjectids_table ( gobject_id int)
      
      CREATE TABLE  #failed_gobjectids_table ( gobject_id int, failed_reason int)
      
      DECLARE @SQL nvarchar(2000)
      SET @SQL = 'BULK INSERT #gobjectids_table FROM ''' + @GobjectIdsFileName+ ''' WITH(TABLOCK, DATAFILETYPE  = ''widechar'')' 
      EXEC (@SQL)
      
            insert into #failed_gobjectids_table(gobject_id, failed_reason) 
            select gt.gobject_id, 0 from #gobjectids_table gt -- initialize failed_reason to 0 i.e no error                 

            update fgt1 set fgt1.failed_reason = 5 from #failed_gobjectids_table fgt1 where -- 5 is for not existing objects
            fgt1.gobject_id in
            (select fgt.gobject_id from #failed_gobjectids_table fgt except select g.gobject_id from gobject g)

            update fgt1 set fgt1.failed_reason = 20 from #failed_gobjectids_table fgt1 --20 is for not deployed objects
                  inner join gobject g on fgt1.gobject_id = g.gobject_id
                  where g.deployed_package_id = 0 and fgt1.failed_reason = 0
                  
            update gobject set deployment_pending_status =1 where 
            deployed_package_id <> 0 and gobject_id in (select gobject_id from #failed_gobjectids_table where failed_reason = 0)
	    
            declare succeededgobjectid_cursor cursor

	    for select gobject_id from #failed_gobjectids_table where failed_reason = 0
	    open succeededgobjectid_cursor

            declare @succeededgobject_id int

            fetch next from succeededgobjectid_cursor into @succeededgobject_id

	    while (@@fetch_status <> -1 )
            begin
    
		   exec internal_update_gobject_timestamp @succeededgobject_id
		   fetch next from succeededgobjectid_cursor into @succeededgobject_id
	    end
	    
            close succeededgobjectid_cursor
	    deallocate succeededgobjectid_cursor

            select gobject_id, failed_reason from #failed_gobjectids_table-- returns all objects status

            drop table #gobjectids_table
            drop table #failed_gobjectids_table

commit tran

end
go

