/*
This procedure calculates which files are needed on a Platform
for given set of package. It does NOT calculate if files already
exists on Platform or not (via deployed_file table).

This procedure writes to the temporary table 
#deploy_file_ids. This tables must be created by the 
caller.

usage:
exec internal_get_runtime_files_for_packages_needed_on_platform.sql  1
*/

create proc dbo.internal_get_runtime_files_for_packages_needed_on_platform
    @mx_platform_id int,	
	@node_name nvarchar(256) --node_name to which these objects are getting deployed
as
set nocount on
begin



	create table #file_ids( file_id int )


	---------------------------------------
	-- calculate files need by objects
	---------------------------------------

	-- get files for the packages which are getting deployed/undeployed
	-- in: #package_ids out: #file_ids
	exec internal_get_runtime_files_for_packages
	delete from #package_ids

	-- save results to @gobject_file_ids
	declare @gobject_file_ids table ( file_id int )
	insert into @gobject_file_ids
		select * from #file_ids
	delete from #file_ids

	---------------------------------------
	-- calculate files needed by platform it means calculate all the files
	-- which are deployed by the deployed_package_ids
	---------------------------------------

	insert into #package_ids    
		select package.package_id from instance 
			inner join gobject on 
				gobject.gobject_id = instance.gobject_id
			inner join package on
				package.package_id = gobject.deployed_package_id
			where
				instance.mx_platform_id = @mx_platform_id

	-- get files for those packages
	-- in: #package_ids out: #file_ids
	exec internal_get_runtime_files_for_packages
	delete from #package_ids

	-- save results to @on_node_file_ids
	declare @on_node_file_ids table ( file_id int )
	insert into @on_node_file_ids
		select * from #file_ids

	delete from #file_ids

	---------------------------------------
	-- #deploy_file_ids = gobject_file_ids - (on_node_file_ids - deployed_file)
	---------------------------------------

	insert into #deploy_file_ids
		select file_id from @gobject_file_ids gobject_file_ids where not exists (
			select * from @on_node_file_ids on_node_file_ids inner join deployed_file df 
			on on_node_file_ids.file_id = df.file_id and df.node_name = @node_name and df.is_runtime_deployed = 1
    		where on_node_file_ids.file_id = gobject_file_ids.file_id )



end
go

