create proc dbo.internal_set_toolset_imported_object
@gobjectId int,
@folder_type int,
@path nvarchar(650)
as
begin

	--create folder path and then set the folder_gobject_link
    declare @folder_id int
    if(len(@path) > 0)
    begin
        exec internal_add_path  @path,@folder_type 
        exec internal_get_folder_id  @folder_type, @path , @folder_id out 
    end
    else
    begin
       set @folder_id = 0 
    end
    update folder_gobject_link set folder_id = @folder_id 
    where gobject_id = @gobjectId and folder_type = @folder_type

    -- if the gobject does not exists in the database then insert a new row for it
if ( @@ROWCOUNT = 0 )
      insert into folder_gobject_link(folder_id,folder_type,gobject_id) 
        select @folder_id,@folder_type,@gobjectId


end
go

