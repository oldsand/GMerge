/**************************************************
Object Name :  internal_insert_attribute_info_for_migrated_objects
Object Type :  Stored Proc. 
Purpose     :  This procedure inserts attribute info from old objects
               to new objects and remove oldobjects.
Example     :  exec internal_insert_attribute_info_for_migrated_objects 'c:\temp\3.txt'
***************************************************/

create PROCEDURE dbo.internal_insert_attribute_info_for_migrated_objects
    @FileNameOfIds nvarchar (400)
as
begin
begin tran
    set nocount on

  
    DECLARE @SQL nvarchar(2000) 
    SET @SQL = 'BULK INSERT attributes_translation_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE = ''widechar'', FIELDTERMINATOR = '','', ROWTERMINATOR = ''\n'')'
    EXEC (@SQL)   

    
commit tran

end
go

