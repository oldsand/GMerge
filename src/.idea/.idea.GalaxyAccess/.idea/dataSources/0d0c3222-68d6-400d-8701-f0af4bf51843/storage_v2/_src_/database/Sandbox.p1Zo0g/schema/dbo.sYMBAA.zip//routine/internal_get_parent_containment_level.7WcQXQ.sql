/*
  This stored procedure takes object's Id as the input parameters and will return
  how many level the object is under from the top parent. If the object has no parent
  then the level is 1 
*/

create proc dbo.internal_get_parent_containment_level
@gobject_id int, 
@level int OUTPUT

AS 
begin

set nocount on
set @level = 0

while @gobject_id <> 0
begin
	set @level = @level + 1
	select @gobject_id = contained_by_gobject_id 
	from gobject where gobject_id = @gobject_id
end


end
go

