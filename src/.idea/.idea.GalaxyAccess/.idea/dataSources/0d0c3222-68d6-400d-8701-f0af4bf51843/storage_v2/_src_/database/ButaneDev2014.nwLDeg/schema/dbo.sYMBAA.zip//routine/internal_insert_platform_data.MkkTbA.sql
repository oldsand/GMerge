-- insert  data for Platform 
create   procedure dbo.internal_insert_platform_data
	@platform_gobject_id int, -- platform_gobject_id
	@node_name nvarchar(256), -- node_name
	@rmcNode_name nvarchar(256), -- node_name
	@portNMX	integer,
	@portRMC	integer,
	@portRPC	integer
AS
begin
	set nocount on
	IF (SELECT COUNT(platform_gobject_id)
	   FROM platform 
	   WHERE platform_gobject_id = @platform_gobject_id ) > 0   

	 BEGIN
	 SET NOCOUNT ON
		UPDATE platform SET node_name = @node_name,
		rmcNode_name = @rmcNode_name,
		portNMX = @portNMX,
		portRMC = @portRMC,
		portRPC = @portRPC
		WHERE platform_gobject_id = @platform_gobject_id
	   END
	ELSE
	 BEGIN
	     SET NOCOUNT ON
		INSERT INTO platform (platform_gobject_id,node_name,rmcNode_name,portNMX,portRMC,portRPC) values 
		(@platform_gobject_id,@node_name,@rmcNode_name,@portNMX,@portRMC,@portRPC)
   
    END
	
end
go

