/* @assocType should be eMyContainer when this method is called
*/
CREATE proc dbo.internal_are_object_names_valid_if_assigned(
    @childIdList nvarchar(255),
    @parentId int,
    @assocType smallint)    
As
BEGIN
    set nocount on
    
    declare @gobject_id int
    declare @parentHeight int   

    create table  #childList (gobject_id int)
    DECLARE @gSQL nvarchar(2000)
    SET @gSQL = 'BULK INSERT #childList  FROM ''' + @childIdList + ''' 
                WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
    EXEC (@gSQL)
    
    declare @InvalidObjects table(
        gobject_id int, 
        tag_name nvarchar (329) not null,
        error_code smallint)

    insert  @InvalidObjects(gobject_id, tag_name, error_code)
    (
        select  distinct 
                g.gobject_id,
                substring(upper(g.tag_name), 2, len(tag_name)-1),
                1   -- hardcode it at this moment
        from    gobject g
        inner join #childList c
        on      g.gobject_id = c.gobject_id
        where   g.is_template = 1
    )

    select  gobject_id,
            error_code
    from    @InvalidObjects
    where   tag_name in (N'ME', N'MYCONTAINER', N'MYAREA', N'MYHOST', N'MYPLATFORM', N'MYENGINE', N'SYSTEM')

    set nocount off
END
go

