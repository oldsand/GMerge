/**************************************************/
/*Object Name :  internal_get_unnamed_prim_attribute_id*/
/*Object Type :  Stored Proc.					  */
/*Purpose	  :  Proc. to get Attribute ID of an un-namaed primitive for a given*/
/*               attribute name and primitive id*/
/*Used By	  :  CDI(Reference String Resolution) */
/**************************************************/
create procedure dbo.internal_get_unnamed_prim_attribute_id
@varpkgID    int,
@vargobjectId int,
@varAttrname nvarchar(700),
@varPrimID smallint ,
@varAttrID smallint out
AS
SET NOCOUNT ON
begin
    set	@varAttrID = 0

    select 
		@varAttrID = attr_def.mx_attribute_id 
    from 
		primitive_instance prim_inst 
    inner join attribute_definition attr_def on 
         prim_inst.primitive_definition_id = attr_def.primitive_definition_id
    where 
		 prim_inst.gobject_id = @vargobjectId
    and  prim_inst.package_id = @varpkgID 
    and  prim_inst.primitive_name = ''
    and  prim_inst.mx_primitive_id = @varPrimID
	and  attr_def.attribute_name = @varAttrname

	--If Not found, look in the dynamic_attribute table
	if (@varAttrID = 0)
	begin
		    select 
			@varAttrID = dyna_attr.mx_attribute_id 
			from 
			primitive_instance prim_inst 
			inner join dynamic_attribute dyna_attr on 
				prim_inst.gobject_id = dyna_attr.gobject_id
			and prim_inst.gobject_id = @vargobjectId
			and dyna_attr.gobject_id = @vargobjectId
			and prim_inst.package_id = @varpkgID
			and dyna_attr.package_id = @varpkgID
			and prim_inst.primitive_name = ''
			and prim_inst.mx_primitive_id = @varPrimID 
			and dyna_attr.attribute_name = @varAttrname
			and dyna_attr.mx_attribute_category <> 16  -- MxCategory_SystemInternal_Browsable
			and dyna_attr.mx_attribute_category <> 17  -- MxCategory_PackageOnly_Calculated
			and	prim_inst.mx_primitive_id = dyna_attr.mx_primitive_id

	end
end
SET NOCOUNT OFF

go

