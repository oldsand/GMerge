create proc dbo.internal_send_operation_message
@operation_id int,
@message_text nvarchar(300)
as

insert into operation_message
(
    operation_id,
    message_text
)
select 
    @operation_id, 
    @message_text
go

