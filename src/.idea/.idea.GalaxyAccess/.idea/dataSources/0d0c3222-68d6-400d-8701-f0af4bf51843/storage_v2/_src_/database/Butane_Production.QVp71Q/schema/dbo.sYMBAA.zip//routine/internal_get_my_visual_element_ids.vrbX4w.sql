create procedure dbo.internal_get_my_visual_element_ids 
@gobject_id int,
@package_id int
as
set nocount on
begin
	
    select 
        vev.mx_primitive_id,
        vev.visual_element_id 
    from
        visual_element_version vev    
    where 
        vev.gobject_id = @gobject_id and
        vev.package_id = @package_id     
end
go

