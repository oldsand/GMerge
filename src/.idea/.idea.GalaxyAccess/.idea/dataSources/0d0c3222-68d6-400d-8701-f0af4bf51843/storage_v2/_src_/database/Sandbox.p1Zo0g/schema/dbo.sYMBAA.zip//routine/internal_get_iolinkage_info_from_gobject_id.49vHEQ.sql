create proc dbo.internal_get_iolinkage_info_from_gobject_id
@gobject_id int, 
@linkedIODeviceGobjectId int OUTPUT,
@linkedSG_primitive_id int OUTPUT
AS 
begin

set nocount on

	declare @linkedSG smallint
	set @linkedSG = 0
	set @linkedIODeviceGobjectId = 0
	set @linkedSG_primitive_id   = 0

	select @linkedIODeviceGobjectId = dio_id,
	@linkedSG = sg_mx_primitive_id
	from object_device_linkage 
	where  gobject_id = @gobject_id

	set @linkedSG_primitive_id = @linkedSG

end
go

