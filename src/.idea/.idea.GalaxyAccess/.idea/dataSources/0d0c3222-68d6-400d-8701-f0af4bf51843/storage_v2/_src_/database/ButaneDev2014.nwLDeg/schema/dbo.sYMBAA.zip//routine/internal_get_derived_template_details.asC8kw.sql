/*
This procedure will get called when ExportAll function is called.
This procedure returns all derived template details.

usage:
declare @gobject_id int
set @gobject_id = 1
exec internal_get_derived_template_details @gobject_id

*/

create  procedure dbo.internal_get_derived_template_details
@gobject_id int
 AS
begin
	SET NOCOUNT ON

	select g.tag_name, 
	       g.gobject_id,
	       td.codebase, 
	       g.configuration_version, 
	       p.security_group as sec_group,
	       ghost.tag_name as host_name,
	       garea.tag_name as area_name,
	       gcontain.tag_name  as contain_name,
           toolset_name = dbo.get_folder_path(g.gobject_id,1),
           g.checked_out_by_user_guid    
	from gobject g 
	left join template_definition td on td.template_definition_id = g.template_definition_id 
	left join package p 
	    on p.package_id = g.checked_in_package_id and p.gobject_id = g.gobject_id 
	left join gobject ghost 
	    on ghost.gobject_id = g.hosted_by_gobject_id 
	left join gobject garea 
	    on garea.gobject_id = g.area_gobject_id
	left join gobject gcontain 
	    on gcontain.gobject_id = g.contained_by_gobject_id 
	where 
        g.derived_from_gobject_id = @gobject_id 
    and 
        g.is_template = 1 
    order by g.gobject_id


	
end
go

