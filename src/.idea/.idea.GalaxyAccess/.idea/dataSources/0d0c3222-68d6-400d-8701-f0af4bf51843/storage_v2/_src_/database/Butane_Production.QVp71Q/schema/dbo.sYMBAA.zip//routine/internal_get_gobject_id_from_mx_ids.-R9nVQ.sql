/*
returns the gobject_id for a fully bound instance
based on its mx_ids
*/
create procedure dbo.internal_get_gobject_id_from_mx_ids
    @mx_platform_id int,
    @mx_engine_id int,
    @mx_object_id int,
    @gobject_id int out
as

select 
	@gobject_id = gobject_id 
from 
	instance 
where
	mx_platform_id = @mx_platform_id
	and mx_engine_id = @mx_engine_id
	and mx_object_id = @mx_object_id
go

