create procedure dbo.internal_get_visual_element_names_from_reference_index
@gobject_id int,
@visual_element_name nvarchar(395), -- this param must be empty for InTouchViewApp
@file_of_index_ids nvarchar(255), -- if this is empty, we will return all references
@use_checked_out_package bit
as
begin tran
      declare @index_ids_were_passed_id bit
      set @index_ids_were_passed_id = 0
      create table #visual_element_reference_indexes
            (
                  visual_element_reference_index int
            )
 
 
      declare @visual_element_reference_indexes_with_original_order_number table 
            (
                  original_order int identity(1,1),
                  visual_element_reference_index int
            )
      
      DECLARE @gSQL nvarchar(2000)
      SET @gSQL = 'BULK INSERT #visual_element_reference_indexes  FROM ''' + @file_of_index_ids + ''' 
                        WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
      EXEC (@gSQL)
 
      insert into @visual_element_reference_indexes_with_original_order_number (visual_element_reference_index)
      select visual_element_reference_index
      from #visual_element_reference_indexes
 
      if(@@rowcount > 0)
      begin
            set @index_ids_were_passed_id = 1
      end
 
      declare @package_id int
      if(@use_checked_out_package = 1)
      begin
            select @package_id = checked_out_package_id
            from gobject
            where gobject_id = @gobject_id
      end
      else
      begin
            select @package_id = checked_in_package_id
            from gobject
            where gobject_id = @gobject_id
      end
 
      if(@visual_element_name = '') -- The object is an InTouchViewApp
      begin
            if(@index_ids_were_passed_id = 1)
            begin
                  select isnull(v.calculated_visual_element_name,'') visual_element_name
                  from @visual_element_reference_indexes_with_original_order_number requested_indexes
                  left outer join internal_visual_element_reference_view v on
                        v.gobject_id = @gobject_id and
                        v.package_id = @package_id and
                        v.visual_element_reference_index = requested_indexes.visual_element_reference_index
                  order by requested_indexes.original_order asc
            end
            else
            begin
 
                  select isnull(v.reference_string,'') visual_element_name
                  from internal_visual_element_reference_view v
                  where
                        v.gobject_id = @gobject_id and
                        v.package_id = @package_id 
                  order by visual_element_reference_index asc


            end
      end
      else -- The object is an Automation object
      begin
            declare @mx_primitive_id int
            select @mx_primitive_id = mx_primitive_id
            from internal_visual_element_description_view (noexpand)
            where gobject_id = @gobject_id and 
                  primitive_name = @visual_element_name -- Example: if full visual element name is UD.S1, then this 
                                                                       -- should be 'S1'
 
            select isnull(v.calculated_visual_element_name,'') visual_element_name
            from @visual_element_reference_indexes_with_original_order_number requested_indexes
            left outer join internal_visual_element_reference_view v on
                  v.gobject_id = @gobject_id and
                  v.package_id = @package_id and
                  v.mx_primitive_id = @mx_primitive_id and
                  v.visual_element_reference_index = requested_indexes.visual_element_reference_index
            order by requested_indexes.original_order asc
            
      end
      
      drop table #visual_element_reference_indexes
 
commit



go

