--
-- Returns the files necessary for visual elements referenced
--
create proc dbo.internal_get_clientcontrol_and_feature_files
    -- comma separated list of visual element ids or file of ids
    @ids_or_file_of_ids nvarchar(4000)
as begin
    -- put visual_element_ids into table
    create  table #visual_element_ids_for_referenced_elements(visual_element_id int)

    insert #visual_element_ids_for_referenced_elements(visual_element_id)
        exec internal_select_ids @ids_or_file_of_ids

    create table  #final_selection 
    (
        visual_element_id int,
        gobject_id int,
        package_id int,
        visual_element_reference_index int
    )
    create index final_selection_index on #final_selection (visual_element_id, gobject_id, package_id)

    create table #next_selection 
    (
        visual_element_id int,
        gobject_id int,
        package_id int,
        visual_element_reference_index int
    )

    create index next_selection_index on #next_selection (visual_element_id, gobject_id, package_id)

	insert into #final_selection
	(
		visual_element_id,
		gobject_id,
		package_id,
		visual_element_reference_index
	)
	select
		vev.visual_element_id,
		vev.gobject_id,
		vev.package_id,
		1
	from visual_element_version vev
	inner join #visual_element_ids_for_referenced_elements t on
		vev.visual_element_id = t.visual_element_id


    while( 1 = 1 )
    begin
        insert into #next_selection    
            select 
               bound_vev.visual_element_id, 
               vev.gobject_id, 
               vev.package_id, 
               bver.visual_element_reference_index
	        from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on 
                vev.visual_element_id = ids.visual_element_id 
			inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id
                and bver.package_id = vev.package_id
                and bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
               bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
          where not exists( select 1 from #final_selection fs
							 where fs.visual_element_id = bound_vev.visual_element_id
						   )
        union
            select 
                bound_vev.visual_element_id, 
                vev.gobject_id, 
                vev.package_id, 
                bver.visual_element_reference_index
            from  visual_element_version vev
            inner join #visual_element_ids_for_referenced_elements ids on 
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id
                and bver.package_id = vev.package_id
                and bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_out_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_out_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_out_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
          where not exists( select 1 from #final_selection fs
							 where fs.visual_element_id = bound_vev.visual_element_id
						   )

		if (@@ROWCOUNT = 0)
		begin
	        drop table #visual_element_ids_for_referenced_elements
	        drop table #next_selection
			break;
		end
	
        truncate table #visual_element_ids_for_referenced_elements

        insert into #visual_element_ids_for_referenced_elements
              select visual_element_id from #next_selection 
        insert into #final_selection
              select * from #next_selection 

        truncate table #next_selection;
        
	end

    create table  #referenced_visual_elements 
    (
		gobject_id int,
		package_id int,
		mx_primitive_id smallint
	)

	insert into #referenced_visual_elements 
	(
		gobject_id,
		package_id,
		mx_primitive_id
	)

    select 
		v.gobject_id,
		v.package_id,
		v.mx_primitive_id
	from #final_selection fs
    inner join internal_visual_element_description_view v (noexpand)on
			fs.visual_element_id = v.visual_element_id 

    select
	      f.file_name,
		  f.vendor_name,
		  f.subfolder
    from #referenced_visual_elements rve
	inner join primitive_instance pri on
		rve.gobject_id = pri.gobject_id and
        rve.package_id = pri.package_id and
        rve.mx_primitive_id = pri.mx_primitive_id
	inner join primitive_instance_file_table_link pifl on
		pri.gobject_id = pifl.gobject_id and
        pri.package_id = pifl.package_id and
        pri.parent_mx_primitive_id = pifl.mx_primitive_id
    inner join file_table f on 
			pifl.file_id = f.file_id

		 select  distinct
        	            f.file_name,
        	            f.vendor_name        	            
                from    file_table f
				inner join feature_file_link flink on
					flink.file_id = f.file_id
                inner join primitive_instance_feature_link primfeaturelink on
                        flink.feature_id = primfeaturelink.feature_id
                inner join primitive_instance pri on
                        primfeaturelink.gobject_id = pri.gobject_id and
                        primfeaturelink.package_id = pri.package_id and
                        primfeaturelink.mx_primitive_id = pri.parent_mx_primitive_id 
                inner join #referenced_visual_elements vev on
                        pri.gobject_id = vev.gobject_id and
                        pri.package_id = vev.package_id and
                        pri.mx_primitive_id = vev.mx_primitive_id                 

    drop table #final_selection
end

go

