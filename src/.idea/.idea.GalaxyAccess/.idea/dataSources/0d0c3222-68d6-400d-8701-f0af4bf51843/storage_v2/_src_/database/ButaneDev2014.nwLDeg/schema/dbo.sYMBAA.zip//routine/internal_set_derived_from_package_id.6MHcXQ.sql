/*
This procedure will set the derived_from_package_id of a 
checked_in package of an object

usage:
declare @objectid int
declare @packageid int
declare @status nvarchar(80)
exec internal_set_derived_from_package_id @objectid, @packageid, @@status
		
*/
CREATE  PROCEDURE dbo.internal_set_derived_from_package_id
	@gobject_id  int,
	@derived_from_package_id int, 
	@statusmsg nvarchar(80) output
AS
begin
	SET NOCOUNT ON

	update	pa
	set		pa.derived_from_package_id = @derived_from_package_id
	from	package pa 
	inner	join gobject g on pa.package_id = g.checked_in_package_id
	where	g.gobject_id = @gobject_id

	if @@rowcount <> 1
		set @statusmsg = N'Can not find the checked in package for the object.'
	else
		set @statusmsg = N'Derived_from_package_id has been set.'

	
end
go

