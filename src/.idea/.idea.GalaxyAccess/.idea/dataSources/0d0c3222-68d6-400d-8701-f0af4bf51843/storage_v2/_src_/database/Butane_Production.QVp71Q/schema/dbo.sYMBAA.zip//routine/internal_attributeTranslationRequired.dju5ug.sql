create proc dbo.internal_attributeTranslationRequired
@attribute_translation_required int output     
AS
begin
---find attribute_translation_table
---if it exisit check for the records
set @attribute_translation_required = 0

if exists(select id from sysobjects where name = 'attributes_translation_table')
begin
	if exists(select '*' from attributes_translation_table)
		begin
			set @attribute_translation_required = 1			
		end
end

end
go

