/**************************************************
Object Name :  internal_get_gobject_descendants
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves all derived objects for a specific gobject
Used By	    :  CDI uses it in GetDescendants call.
Variables Used -
@WorkingSet - holds gobjects for a particular iteration in the while loop. 
@TemporaryCache - temporarily holds all the descendants of the @WorkingSet gobjects.
@ResultSet - holds all the descendant gobjects
**************************************************/

CREATE PROCEDURE dbo.internal_get_gobject_descendants
	@gObjectId int
AS
begin
	set nocount on

;With CTE
	(
		gId, 
		istemplate, 
		isImmediateChild
	)as
	(	
		select
			gobject_id,
			is_template,
			1
		from gobject
		where derived_from_gobject_id = @gObjectId
		union all	
		select
			gobject_id,
			is_template,
			0
		from CTE inner join gobject g on
			g.derived_from_gobject_id = CTE.gId
	)
	select *
	from CTE
	
	
end

go

