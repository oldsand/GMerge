
-- calculates files required for a given set of 
-- packages at runtime.  This is called by (todo)
--
-- this procedure reads from the temporary table
-- #package_ids and writes to the temporary table 
-- #file_ids.  Both tables must be created by the 
-- caller.
create procedure dbo.internal_get_runtime_files_for_packages
as 
set nocount on
begin

-- get all of the primitive definitions (later we join this with passed in gobject ids)
declare @primitive_definition_ids table ( primitive_definition_id int )
create table #temp_primitive_definition_id  ( primitive_definition_id int )

insert into #temp_primitive_definition_id 
    select primitive_definition.primitive_definition_id 
    from #package_ids package_ids
    inner join primitive_instance on
        primitive_instance.package_id = package_ids.package_id
    inner join primitive_definition on 
        primitive_definition.primitive_definition_id = primitive_instance.primitive_definition_id

insert into @primitive_definition_ids
select distinct primitive_definition_id
from #temp_primitive_definition_id


drop table #temp_primitive_definition_id

-- get all of the files needed by the runtime
declare @primitive_runtime_file_ids table ( file_id int )

insert into @primitive_runtime_file_ids
    select distinct file_id from @primitive_definition_ids primitive_definition_ids
    inner join primitive_definition on 
        primitive_definition.primitive_definition_id = primitive_definition_ids.primitive_definition_id
    inner join file_primitive_definition_link on 
        file_primitive_definition_link.primitive_definition_id = primitive_definition_ids.primitive_definition_id
    where file_primitive_definition_link.is_needed_for_runtime = 1

---------------------------------------
-- get files required for features
---------------------------------------
declare @feature_file_ids table( file_id int )

insert into @feature_file_ids
    select distinct file_id 
    from #package_ids package_ids
    inner join primitive_instance_feature_link
        on primitive_instance_feature_link.package_id = package_ids.package_id
    inner join feature_file_link 
        on feature_file_link.feature_id = primitive_instance_feature_link.feature_id


-------------------------------------
-- For all ViewApp packages,get files required for referred visual elements also
-------------------------------------
create table #visual_element_ids_for_required_file_temp(
                visual_element_id int)

create table #visual_element_ids_for_required_file(
                visual_element_id int)

create table #visual_element_required_file(
                group_id  nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS,
                file_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS,
                vendor_name nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS,
                registration_type int,
                software_upgrade_needed int,
                file_id int,
                is_needed_for_package bit,
                is_needed_for_editor bit,
                is_needed_for_runtime bit)

declare @viewapps table(gobject_id int,package_id int)

insert into @viewapps(gobject_id,package_id)
    ( select g.gobject_id,tp.package_id from #package_ids tp inner join package p on
	  p.package_id = tp.package_id inner join gobject g on
	  g.gobject_id = p.gobject_id inner join template_definition td on
	  g.template_definition_id = td.template_definition_id
 	 where td.category_id = 17 or -- ViewApp
        td.category_id = 26)  -- InTouchViewApp

if @@ROWCOUNT <> 0

begin

declare @user_guid as uniqueidentifier
declare @recursive as bit
set @recursive = 1 
select @user_guid = user_guid from user_profile where user_profile_name = 'SystemEngineer'

create table #visual_element_ids_for_referenced_elements(visual_element_id int)

insert into #visual_element_ids_for_referenced_elements(visual_element_id)
	( select distinct bound_vev.visual_element_id 
      from visual_element_reference bver
      inner join visual_element_version bound_vev on
         bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
          bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
          bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
      inner join @viewapps vapps 
      on  bver.gobject_id = vapps.gobject_id 
      and bver.package_id = vapps.package_id)

exec internal_get_referenced_visual_elements2 @recursive,@user_guid

drop table #visual_element_ids_for_referenced_elements

declare @node_name nvarchar(258)
set @node_name = NULL

BEGIN 

    begin transaction
    truncate table #visual_element_required_file
    
    begin
        insert into #visual_element_required_file
                (group_id,
        	    file_name,
        	    vendor_name,
        	    registration_type,
                software_upgrade_needed,
                file_id,
                is_needed_for_package,
                is_needed_for_editor,
                is_needed_for_runtime)
        (
            select  distinct
                    N'',
        	        f.file_name,
        	        f.vendor_name,
        	        f.registration_type,
                    0,
                    f.file_id,
                    0,
                    0,
                    piftl.is_needed_for_runtime
            from    file_table f
            inner join primitive_instance_file_table_link piftl on
                    piftl.file_id = f.file_id
            inner join primitive_instance pri on
                    piftl.gobject_id = pri.gobject_id and
                    piftl.package_id = pri.package_id and
                    piftl.mx_primitive_id = pri.parent_mx_primitive_id 
            inner join visual_element_version vev on
                    pri.gobject_id = vev.gobject_id and
                    pri.package_id = vev.package_id and
                    pri.mx_primitive_id = vev.mx_primitive_id 
            inner join #visual_element_ids_for_required_file vei on    
                    vei.visual_element_id = vev.visual_element_id
            where   (piftl.is_needed_for_runtime = 1) 
        )
    end

    /*****************************************
    *  set the software_upgrade_needed bit..
    ******************************************/
    if (@node_name is not null)
    begin
        update  #visual_element_required_file
        set     software_upgrade_needed = 1
        where   file_id in 
            (
                select  file_id 
                from    deployed_file d
	            where   d.node_name =UPPER(@node_name)
            )
    end

    commit transaction
END

end
 --return combined file_ids with #file_ids

insert into #file_ids
    select file_id from @feature_file_ids
    union 
    select file_id from @primitive_runtime_file_ids
    union 
    select file_id from #visual_element_required_file

drop table #visual_element_required_file

drop table #visual_element_ids_for_required_file

end
set nocount off

go

