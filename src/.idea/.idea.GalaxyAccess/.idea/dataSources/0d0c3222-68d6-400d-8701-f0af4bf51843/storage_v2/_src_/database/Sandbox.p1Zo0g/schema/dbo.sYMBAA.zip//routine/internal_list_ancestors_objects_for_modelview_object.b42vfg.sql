create proc dbo.internal_list_ancestors_objects_for_modelview_object
    @gobject_id int,
    @bIsExcludeSelf bit = 0
as
begin
    set nocount on

      declare @exclude_gobject int
      declare @nesting_layer int
      
      set @nesting_layer = 0
      
      if @bIsExcludeSelf = 0
            set @exclude_gobject = 0
    else
            set @exclude_gobject = @gobject_id

      
    ;with CTE(
        gobject_id,
        Host_gobject_id,
        nesting_layer
    )
    as
    (
        select  gobject_id, 
        CASE WHEN contained_by_gobject_id = 0 THEN
                  area_gobject_id
            ELSE
                  contained_by_gobject_id
            END as Host_gobject_id,
            @nesting_layer  as nesting_layer
        from    gobject
        where   gobject_id = @gobject_id
    
        union all

        select  g.gobject_id,
        CASE WHEN g.contained_by_gobject_id = 0 THEN
                  g.area_gobject_id
            ELSE
                  g.contained_by_gobject_id
            END as Host_gobject_id,
            CTE.nesting_layer + 1 as nesting_layer
        from    CTE
        inner join
                gobject g
        on
                CTE.Host_gobject_id = g.gobject_id
        where     g.is_template = 0
    )

    select  CTE.gobject_id,
            Host_gobject_id,
            g.tag_name
            --, CTE.nesting_layer
    from    CTE
    inner join
            gobject g
    on
            g.gobject_id = CTE.gobject_id
                  and g.gobject_id <> @exclude_gobject
      order by CTE.nesting_layer asc
    
end
go

