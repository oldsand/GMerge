create view dbo.internal_common_obj as
SELECT     
	gobj.gobject_id AS gobject_id, 
	gobj.tag_name AS tag_name, 
	td.category_id AS category_id, 
	tset.toolset_name AS toolset_name, 
	gobj.is_template AS is_template, 
	pg.status_id AS status, 
	gobj.derived_from_gobject_id AS derived_from, 
	gobj.checked_out_by_user_guid AS checkedout_by, 
	td.base_gobject_id AS base_type, 
	gobj.hosted_by_gobject_id AS myhost, 
	td.required_features AS required_feature_guid, 
	td.supported_features AS supported_feature_guid, 
	case when gobj.checked_out_by_user_guid != '{00000000-0000-0000-0000-000000000000}' then
		1
 	else 
		0 
	end 
	AS is_checkout, 
	case when gobj.deployed_package_id <> 0 then 
             1
        else
             0
        end AS is_deployed, 
	gobj.deployed_package_id AS haspendingupdate, 
	gobj.checked_in_package_id AS checkedinpg, 
	gobj.checked_out_package_id AS checkedoutpg, 
	case when gobj.checked_out_by_user_guid != '{00000000-0000-0000-0000-000000000000}' then 
		gobj.checked_out_package_id 
	else 
		gobj.checked_in_package_id 
	end as readpgid, 
	case when gobj.checked_out_package_id = pg.package_id then
		1 
	else
		0 
	end as packagestate, 
	'objectid' = 0, 
	gobj.contained_by_gobject_id AS mycontainer, 
	gobj.area_gobject_id AS myarea, 
	gobj.hierarchical_name AS hierarchical_name, 
	gobj.is_hidden AS is_hidden,
	isnull( engine_instance.gobject_id, 0 ) as myengine,
	isnull( platform_instance.gobject_id, 0 ) as myplatform
FROM
	gobject gobj
	inner join package pg on
		gobj.gobject_id = pg.gobject_id 
		and gobj.checked_in_package_id = pg.package_id
	inner join template_definition td on
		td.template_definition_id = gobj.template_definition_id 
	inner join template tt on
	 	tt.gobject_id = td.base_gobject_id 
        inner join toolset tset on
                tset.toolset_id = tt.toolset_id
	left join instance inst on
		gobj.gobject_id = inst.gobject_id 
	-- engine instance
	left join instance engine_instance on 
		engine_instance.mx_platform_id = inst.mx_platform_id
		and engine_instance.mx_engine_id = inst.mx_engine_id 
		and engine_instance.mx_object_id = 1 
	-- platform instance
	left join instance platform_instance on
		platform_instance.mx_platform_id = inst.mx_platform_id
		and platform_instance.mx_engine_id = 1
		and platform_instance.mx_object_id = 1

go

