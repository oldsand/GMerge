--Update tagname for galaxy instance
CREATE    proc dbo.internal_rename_galaxy_instance
	@newName nvarchar(329)
as
set nocount on
begin
begin tran
   update gobject set tag_name = @newName 
	where is_template = 0 and 
		template_definition_id = (select
	template_definition_id from template_definition where 
	original_template_tagname = '$Galaxy'	)
commit tran
set nocount off
end
go

