/*
  This stored procedure is used to find a hole in the mx_engine_ids for a given mx_platform_id.
  It does a left join with itself and finds out where the nulls are.
  Called by internal_set_host_and_mx_ids
*/

create proc dbo.internal_get_next_mx_engine_id
  @my_platform_id smallint,
  @my_engine_id smallint out
as
begin
	declare @mytable table( mx_engine_id smallint )
	insert into @mytable(mx_engine_id) (select distinct mx_engine_id from instance i where mx_platform_id = @my_platform_id)
	
	select @my_engine_id = min(i.mx_engine_id) from @mytable i
	left join (select mx_engine_id from @mytable )
	  r on i.mx_engine_id + 1 = r.mx_engine_id
	where r.mx_engine_id is null 
	
	set @my_engine_id = @my_engine_id + 1

end
go

