create proc dbo.internal_list_gobject_eventmask
    as
begin
    select	g.gobject_id, t.event_mask
    from	gobject g inner join template_definition t 
    on g.template_definition_id = t.template_definition_id
end

go

