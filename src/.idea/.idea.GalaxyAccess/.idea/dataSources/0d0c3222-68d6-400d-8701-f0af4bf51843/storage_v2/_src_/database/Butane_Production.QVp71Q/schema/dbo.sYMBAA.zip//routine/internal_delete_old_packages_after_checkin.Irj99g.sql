create procedure dbo.internal_delete_old_packages_after_checkin
as
begin
set nocount on

    declare @allfinished int 
    declare @totalprocessedpackages int
	
	 
    set rowcount 1
    /* CR L00115843: Use table variables instead of temp tables */
    declare @return_deleted_packages table (
        package_id int,
        gobject_id int)

    declare @checked_in_packages table (
        gobject_id int,
        package_id int,
        is_template bit,
        is_being_referenced bit default 0,
		primary key(gobject_id, package_id)
    )
	
	begin tran
		insert  @checked_in_packages(package_id, gobject_id, is_template)
			select  distinct package_id,
					gobject_id,
					is_template
			from    old_checked_in_packages with(nolock)
		select  @totalprocessedpackages = @@rowcount
	commit
    set rowcount 0

	begin tran
		insert @return_deleted_packages(package_id, gobject_id)
		select 	distinct old.package_id,
				old.gobject_id
		from old_checked_in_packages old with(nolock)
		inner join @checked_in_packages c
		on  c.package_id = old.package_id
	 
		delete  old
		from    old_checked_in_packages old with(nolock)
		inner join @checked_in_packages c
		on  c.package_id = old.package_id
	 
	commit

	begin tran    
		update  c
		set     is_being_referenced = 1
		from    @checked_in_packages c
		inner join gobject g with(nolock) 
			on  c.package_id = g.deployed_package_id
		where   c.is_template = 0
    commit

	begin tran
		insert @return_deleted_packages(package_id, gobject_id)
		select 	pa.package_id,
				pa.gobject_id
		from    package pa with(nolock)
		inner join @checked_in_packages c
			on pa.package_id = c.package_id
		where   c.is_template = 0
		and     c.is_being_referenced = 0
	commit

	begin tran
		delete  pa
		from    package pa
		inner join @checked_in_packages c on
			pa.gobject_id = c.gobject_id and
			pa.package_id = c.package_id
		where   c.is_template = 0
		and     c.is_being_referenced = 0	
	commit
    
	delete  @checked_in_packages
    where   is_template = 0


    -- Delete templates in a loop
    declare @loops int
    set @loops = 0
    while (@loops < 10)
    begin
        update  @checked_in_packages
        set is_being_referenced = 0
        
        if (@@rowcount = 0)
            break
        begin tran 
			update  c
			set     is_being_referenced = 1
			from    @checked_in_packages c
			inner join package pa with(nolock)
				on c.package_id = pa.derived_from_package_id
		commit
        if not exists (
            select  1
            from    @checked_in_packages
            where   is_being_referenced = 0)
            break

		begin tran
			insert @return_deleted_packages(package_id, gobject_id)
			select 	pa.package_id,
					pa.gobject_id
			from    package pa with(nolock)
			inner join @checked_in_packages c
				on pa.package_id = c.package_id
			where   c.is_being_referenced = 0
		commit
		
		begin tran    
        delete  pa 
			from    package pa
			inner join @checked_in_packages c on
				pa.gobject_id = c.gobject_id and
				pa.package_id = c.package_id
			where   c.is_being_referenced = 0
		commit

        delete  @checked_in_packages
        where   is_being_referenced = 0

        set @loops = @loops + 1 
    end

    if (exists (select 1 from old_checked_in_packages with(nolock)))  
    begin
        set @allfinished = 0
    end
    else
    begin
        set @allfinished = 1
    end

	select	distinct 
		gobject_id,
		package_id 
	from @return_deleted_packages

	declare @unused_packages_all_finished int
	exec internal_delete_unused_packages @unused_packages_all_finished out
	
	if(@allfinished = 1)
		set @allfinished = @allfinished - @unused_packages_all_finished

    select @allfinished as allfinished,@totalprocessedpackages as totalprocessedpackages

    --CR L00127165
	--Calling the method MarkViewAppForRedeploy() method from Cdi.cpp and Migration.cpp at the end of loop.
    --exec internal_mark_view_app_for_redeploy
	

end
go

