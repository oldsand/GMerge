create proc dbo.internal_check_grnodehavedeployedobjects
	@deployedobjects int out
as
begin
select @deployedobjects = count('*') from gobject where deployed_package_id <> 0
end
go

