/**************************************************/
/*Object Name :  internal_list_objects_in_folder                            */
/*Object Type :  Stored Proc.								*/
/*Purpose :    to provide proxy data for a all the objects inside the folder*/
/*Used By :    CDI									*/
/**************************************************/
create proc dbo.internal_list_objects_in_folder
@folder_id int,
@depth int -- 0 then return : -1 then return all : otherwise return till the depth.. 
AS
begin
set nocount on

SET QUOTED_IDENTIFIER OFF

    if(@depth = 0) return 
	
	declare @objCount integer
	declare @nLevel integer
	declare @effectedObjects table(obj_id int,mycontainer int,nLevel smallint)

	insert into @effectedObjects  ( obj_id,mycontainer,nLevel)
     (  select g.gobject_id,0,1 from folder_gobject_link fg inner join gobject g
        on fg.gobject_id = g.gobject_id
        and g.contained_by_gobject_id = 0
        where 
        fg.folder_id = @folder_id )

	

	select @objCount = count(*) from @effectedObjects	
	IF @objCount > 0
	BEGIN
		set @nLevel = 1        
		while 1 > 0
		BEGIN
	        if(@nLevel = @depth) break
			insert into @effectedObjects
			select gobject_id, CI.obj_id, @nLevel + 1
			from gobject G inner join @effectedObjects CI on G.contained_by_gobject_id = CI.obj_id
			where nLevel = @nLevel
	
			if @@rowcount = 0 break
			set @nLevel = @nLevel + 1
		END	-- while
	END    

	--get proxies for all the selected folder
	declare  @worktable table ( 
	gobject_id int  NOT NULL ,
	is_failover_enabled int )

	insert @worktable
	SELECT 
	gobject.gobject_id, 
	isnull((select distinct 1 from redundancy r where r.primary_gobject_id = gobject.gobject_id or r.backup_gobject_id = gobject.gobject_id),0)is_failover_enabled
	from gobject join @effectedObjects e
	on gobject.gobject_id = e.obj_id

	---Add All Partner IDS also to broadcast proxy
	declare @PartnerGIds table( gobject_id int NOT NULL)
	insert @PartnerGIds 
	select dbo.get_failover_partner_id(w.gobject_id) from @worktable w where is_failover_enabled = 1

	insert @worktable
	select p.gobject_id , 1 from @PartnerGIds p
	---Add All Partner IDS also to broadcast proxy


	select distinct  worktable.gobject_id, 
			gobject.tag_name, 
			gobject.contained_name,
			gobject.hierarchical_name, 
			CASE WHEN (package.status_id = 0 and gobject.is_template = 1) THEN
				CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0)--ver_warning_view.has_warning = 1 
					THEN 2 
				ELSE 0 
				END
			WHEN (package.status_id = 0 and gobject.is_template = 0 and template_definition.category_id = 26) THEN
				CASE WHEN exists(select 1 from gobject itvappgObject
						inner join visual_element_reference myver on
						itvappgObject.gobject_id = myver.gobject_id and
						myver.visual_element_bind_status = 0 and
						myver.checked_in_unbound_visual_element_name <> '---'
						where 
						itvappgObject.gobject_id = gobject.derived_from_gobject_id
						and itvappgObject.checked_in_package_id = myver.package_id
						)
					THEN 2 
					ELSE 0 
				END
			WHEN (package.status_id = 0 and gobject.is_template = 0 and template_definition.category_id <> 26)THEN
				CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0) 
					THEN 2 
				ELSE 0 
				END
			ELSE package.status_id
			END as status,
			package.reference_status_id as refStatus,
			gobject.hosted_by_gobject_id,
			gobject.derived_from_gobject_id as derived_from_id,
			template_definition.base_gobject_id as base_type,  
			isnull((select user_profile_name from user_profile where user_guid = gobject.checked_out_by_user_guid),'') as checkoutbyname, 
			gobject.checked_out_by_user_guid as checkedout_by,
			folder_gobject_link.folder_id AS toolset_id, 
			gobject.checked_in_package_id,
			gobject.template_definition_id,		
			gobject.contained_by_gobject_id as container_id,	
			gobject.area_gobject_id as area_id, 
			CASE WHEN package_checked_out.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
					THEN 2 
					ELSE 0 
				END
				ELSE package_checked_out.status_id 
			END as checked_out_package_status,
			(gobject.is_template * 1) +
		  		(gobject.is_hidden * 2 ) +
		 		((CASE WHEN gobject.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
		  		((CASE WHEN gobject.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +
		 		((CASE WHEN (gobject.deployed_package_id <> 0) and ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
				THEN 1	ELSE 0 	END) * 16 ) +
		  		((CASE WHEN (gobject.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
		  		((CASE WHEN (gobject.namespace_id = 1 and template_definition.category_id = 3 and gobject.is_template = 0 and worktable.is_failover_enabled >0 ) THEN 1 ELSE 0 END) * 64) +
		 		((CASE WHEN (gobject.namespace_id = 2 and template_definition.category_id = 3 and gobject.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
		 		((CASE WHEN (worktable.is_failover_enabled >0) THEN 1 ELSE 0 END) * 256) + 
		 		((CASE WHEN ((worktable.is_failover_enabled >0) and 
		((gobject.deployed_package_id <> 0) and (dbo.is_partner_deployed(gobject.gobject_id) =  0))) then 1 else 0 end) * 512) +
		 		((CASE WHEN ((worktable.is_failover_enabled >0) and 
		((gobject.deployed_package_id = 0) and (dbo.is_partner_deployed(worktable.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
				case when exists(select gobject_id from gobject where derived_from_gobject_id = worktable.gobject_id) --Hasderived_obj
					 then 2048	 else 0	 end +
				case when exists(select gobject_id from gobject where hosted_by_gobject_id = worktable.gobject_id) --Hasassigned_obj
					 then 4096   else 0  end + 
				case when exists(select gobject_id from gobject where contained_by_gobject_id =worktable.gobject_id) --HasContained_obj
					 then 8192	 else 0	 end +
				case when exists(select gobject_id from gobject where area_gobject_id = worktable.gobject_id) --HasBelongTo_obj
					 then 16384  else 0  end +
					( (CASE WHEN (gobject.is_template = 0 and template_definition.category_id = 1) then
 							dbo.is_gr_platform_id(gobject.gobject_id)	
 						else 
 							cast(0 as bit) end) * 32768) +
					CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = worktable.gobject_id )
					then  131072 else 0 end                       				
			 as 'gObjectStatus',
		 CAST ( pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
		 gobject.namespace_id,
		 folder_gobject_link.folder_id,
		  --IO Binding changes
			odl.dio_id,
			odl.sg_mx_primitive_id,
			(case when dio.tag_name is not null and sg_pi.primitive_name is not null
			then
				dio.tag_name + '.' + sg_pi.primitive_name 
			else
				null
			end) as 'MyDiName'
			--IO Binding changes end

	from @worktable worktable 
	inner join gobject 
		on worktable.gobject_id = gobject.gobject_id
	inner join package 
		on gobject.gobject_id = package.gobject_id 
		and gobject.checked_in_package_id = package.package_id
	inner join template_definition on
		gobject.template_definition_id = template_definition.template_definition_id 
    inner join proxy_timestamp pt on
        worktable.gobject_id = pt.gobject_id
	left join package package_checked_out on
		gobject.gobject_id = package_checked_out.gobject_id 
		and gobject.checked_out_package_id = package_checked_out.package_id

	left outer join visual_element_reference ver_warning_view on
		gobject.gobject_id = ver_warning_view.gobject_id and
		package.package_id = ver_warning_view.package_id and
		ver_warning_view.visual_element_bind_status = 0 and
		ver_warning_view.checked_in_unbound_visual_element_name <> '---'

	left outer join visual_element_reference ver_warning_view_checked_out on
		package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
		package_checked_out.package_id = ver_warning_view_checked_out.package_id and
		ver_warning_view_checked_out.visual_element_bind_status = 0 and
		ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
			
--	inner join internal_visual_element_reference_warning_status_view ver_warning_view on
--		gobject.gobject_id = ver_warning_view.gobject_id and
--		package.package_id = ver_warning_view.package_id
--	left outer join internal_visual_element_reference_warning_status_view ver_warning_view_checked_out on
--		package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
--		package_checked_out.package_id = ver_warning_view_checked_out.package_id	
		
	left join folder_gobject_link on
		folder_gobject_link.gobject_id = gobject.gobject_id 
	left outer join package checked_in_package on 
		gobject.gobject_id = checked_in_package.gobject_id and
		gobject.checked_in_package_id = checked_in_package.package_id
	left outer join package deployed_package on 
		gobject.gobject_id = deployed_package.gobject_id and 
		gobject.deployed_package_id = deployed_package.package_id
	--IO Binding changes
		left outer join object_device_linkage odl on
			gobject.gobject_id = odl.gobject_id
		left outer JOIN gobject dio
			ON dio.gobject_id = odl.dio_id
		left outer JOIN primitive_instance sg_pi
			ON sg_pi.gobject_id = dio.gobject_id
			AND sg_pi.mx_primitive_id = odl.sg_mx_primitive_id
			AND sg_pi.package_id = dio.checked_in_package_id
	--IO Binding changes End
		where template_definition.category_id not in (11, 12, 24)
	 --for device
		union
		select distinct  worktable.gobject_id, 
			gobject.tag_name, 
			gobject.contained_name,
			gobject.hierarchical_name, 
			CASE WHEN package.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view.gobject_id,0)> 0) -- ver_warning_view.has_warning = 1 
					THEN 2 
				ELSE 0 
				END
			ELSE package.status_id
			END as status,
			package.reference_status_id as refStatus,
			gobject.hosted_by_gobject_id,
			gobject.derived_from_gobject_id as derived_from_id,
			template_definition.base_gobject_id as base_type,  
			isnull((select user_profile_name from user_profile where user_guid = gobject.checked_out_by_user_guid),'') as checkoutbyname, 
			gobject.checked_out_by_user_guid as checkedout_by,
			folder_gobject_link.folder_id AS toolset_id, 
			gobject.checked_in_package_id,
			gobject.template_definition_id,		
			gobject.contained_by_gobject_id as container_id,	
			gobject.area_gobject_id as area_id, 
			CASE WHEN package_checked_out.status_id = 0 THEN
				CASE WHEN (isnull(ver_warning_view_checked_out.gobject_id,0)> 0) --ver_warning_view_checked_out.has_warning = 1 
					THEN 2 
					ELSE 0 
				END
				ELSE package_checked_out.status_id 
			END as checked_out_package_status,
			(gobject.is_template * 1) +
		  		(gobject.is_hidden * 2 ) +
		 		((CASE WHEN gobject.checked_out_by_user_guid is null THEN 0 ELSE 1 END) * 4 ) +
		  		((CASE WHEN gobject.software_upgrade_needed = 1 THEN 1 ELSE 0 END) * 8 ) +
		 		((CASE WHEN (gobject.deployed_package_id <> 0) and ((gobject.deployment_pending_status <> 0) or checked_in_package.deployable_configuration_version <> deployed_package.deployable_configuration_version)
				THEN 1	ELSE 0 	END) * 16 ) +
		  		((CASE WHEN (gobject.deployed_package_id <> 0) THEN 1 ELSE 0 END) * 32 ) +
		  		((CASE WHEN (gobject.namespace_id = 1 and template_definition.category_id = 3 and gobject.is_template = 0 and worktable.is_failover_enabled >0 ) THEN 1 ELSE 0 END) * 64) +
		 		((CASE WHEN (gobject.namespace_id = 2 and template_definition.category_id = 3 and gobject.is_template = 0)  THEN 1 ELSE 0 END) * 128)  +
		 		((CASE WHEN (worktable.is_failover_enabled >0) THEN 1 ELSE 0 END) * 256) + 
		 		((CASE WHEN ((worktable.is_failover_enabled >0) and 
		((gobject.deployed_package_id <> 0) and (dbo.is_partner_deployed(gobject.gobject_id) =  0))) then 1 else 0 end) * 512) +
		 		((CASE WHEN ((worktable.is_failover_enabled >0) and 
		((gobject.deployed_package_id = 0) and (dbo.is_partner_deployed(worktable.gobject_id) >  0))) then 1 else 0 end) * 1024) + 
				case when exists(select gobject_id from gobject where derived_from_gobject_id = worktable.gobject_id) --Hasderived_obj
					 then 2048	 else 0	 end +
				case when exists(select odl.gobject_id from object_device_linkage odl where odl.dio_id = worktable.gobject_id) --Hasassigned_obj --for IO device only
					 then 4096   else 0  end + 
				case when exists(select gobject_id from gobject where contained_by_gobject_id =worktable.gobject_id) --HasContained_obj
					 then 8192	 else 0	 end +
				case when exists(select gobject_id from gobject where area_gobject_id = worktable.gobject_id) --HasBelongTo_obj
					 then 16384  else 0  end +
					( (CASE WHEN (gobject.is_template = 0 and template_definition.category_id = 1) then
 							dbo.is_gr_platform_id(gobject.gobject_id)	
 						else 
 							cast(0 as bit) end) * 32768) +
					CASE WHEN exists(select gobject_id from gobject_protected where gobject_id = worktable.gobject_id )
					then  131072 else 0 end                       				
			 as 'gObjectStatus',
		 CAST ( pt.timestamp_of_last_change as bigint ) timestamp_of_last_change,
		 gobject.namespace_id,
		 folder_gobject_link.folder_id,
		-- >> IO Binding changes
				0 as dio_id,
				scan_group.cnt as sg_mx_primitive_id, -- Return the number of scan-groups created for the object as the sg_mx_primitive_id (something of a necessary hack)
				null as 'MyDiName'
		-- << IO Binding changes end

	from @worktable worktable 
	inner join gobject 
		on worktable.gobject_id = gobject.gobject_id
	inner join package 
		on gobject.gobject_id = package.gobject_id 
		and gobject.checked_in_package_id = package.package_id
	inner join template_definition on
		gobject.template_definition_id = template_definition.template_definition_id 
    inner join proxy_timestamp pt on
        worktable.gobject_id = pt.gobject_id
	left join package package_checked_out on
		gobject.gobject_id = package_checked_out.gobject_id 
		and gobject.checked_out_package_id = package_checked_out.package_id

	left outer join visual_element_reference ver_warning_view on
		gobject.gobject_id = ver_warning_view.gobject_id and
		package.package_id = ver_warning_view.package_id and
		ver_warning_view.visual_element_bind_status = 0 and
		ver_warning_view.checked_in_unbound_visual_element_name <> '---'

	left outer join visual_element_reference ver_warning_view_checked_out on
		package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
		package_checked_out.package_id = ver_warning_view_checked_out.package_id and
		ver_warning_view_checked_out.visual_element_bind_status = 0 and
		ver_warning_view_checked_out.checked_in_unbound_visual_element_name <> '---'
			
--	inner join internal_visual_element_reference_warning_status_view ver_warning_view on
--		gobject.gobject_id = ver_warning_view.gobject_id and
--		package.package_id = ver_warning_view.package_id
--	left outer join internal_visual_element_reference_warning_status_view ver_warning_view_checked_out on
--		package_checked_out.gobject_id = ver_warning_view_checked_out.gobject_id and
--		package_checked_out.package_id = ver_warning_view_checked_out.package_id	
		
	left join folder_gobject_link on
		folder_gobject_link.gobject_id = gobject.gobject_id 
	left outer join package checked_in_package on 
		gobject.gobject_id = checked_in_package.gobject_id and
		gobject.checked_in_package_id = checked_in_package.package_id
	left outer join package deployed_package on 
		gobject.gobject_id = deployed_package.gobject_id and 
		gobject.deployed_package_id = deployed_package.package_id
	-- >> I/O Binding
		CROSS APPLY (select      cast(COUNT(*) as smallint) as CNT from primitive_instance sg_pi
					 inner join primitive_definition pd
							 on pd.primitive_definition_id = sg_pi.primitive_definition_id
							and pd.primitive_name in (N'S', N'SG', N'ScanGroup1')
						  where sg_pi.gobject_id = gobject.gobject_id
							and sg_pi.package_id = gobject.checked_in_package_id
			) scan_group
	-- << I/O Binding
		where template_definition.category_id in (11, 12, 24)

end

go

