CREATE PROCEDURE dbo.internal_export_alarm_messages
(
	@locale_id smallint,

	@filepath_of_gobject_ids nvarchar(265),

	@exportOnlyIfUntranslated smallint, -- 0 = false  1 = true 

	@error_code int out 
	
	--returns the following two tables in a dataset
	--	full_alarm_name	and phrase_id
	--	phrase_id, default_message, and translated_message 
)
AS
BEGIN
	set nocount on

	if not exists (select 1 from supported_locales sls where sls.locale_id = @locale_id)
	begin
		set @error_code = 1000
		return
	end

	UPDATE STATISTICS alarm_message_timestamps
	UPDATE STATISTICS alarm_messages
	UPDATE STATISTICS alarm_message_defaults
	UPDATE STATISTICS alarm_message_translations

	create table #gobjectIds 
	(
		gobject_id int primary key
	)

	declare @SQL nvarchar(2000)
	SET @SQL = 'BULK INSERT #gobjectIds  FROM ''' + @filepath_of_gobject_ids + ''' WITH(FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' )'
	EXEC sp_executesql @SQL


	create table #new_alarm_messages
	(	
		full_alarm_name nvarchar(362) COLLATE SQL_Latin1_General_CP1_CI_AS primary key, 
		phrase_id int
	)
	
	create table #new_alarm_message_translations
	(
		phrase_id int PRIMARY KEY,
		default_message nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS,
		translated_message nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS
	)

	if (@exportOnlyIfUntranslated = 0) 
		begin
			select Name, phrase_id from internal_localized_alarm_messages lams 
			inner join #gobjectIds gids on gids.gobject_id = lams.gobject_id
			where lams.locale_id = @locale_id 
			union select Name, phrase_id from unlocalized_alarm_messages(@locale_id) uams
			inner join #gobjectIds gids on gids.gobject_id = uams.gobject_id
			order by name

			select distinct phrase_id, default_message, translated_message from internal_localized_alarm_messages lams
			inner join #gobjectIds gids on gids.gobject_id = lams.gobject_id
			where lams.locale_id = @locale_id
			union select distinct phrase_id, default_message, '' as translated_message from unlocalized_alarm_messages(@locale_id) uams
			inner join #gobjectIds gids on gids.gobject_id = uams.gobject_id
			order by phrase_id
		end
	else
		begin
			select Name, phrase_id from unlocalized_alarm_messages(@locale_id) uams
			inner join #gobjectIds gids on gids.gobject_id = uams.gobject_id
			order by name

			select distinct phrase_id, default_message, '' as translated_message from unlocalized_alarm_messages(@locale_id) uams
			inner join #gobjectIds gids on gids.gobject_id = uams.gobject_id
			order by phrase_id
		end
	
	drop table #gobjectIds 
	drop table #new_alarm_messages
	drop table #new_alarm_message_translations
	
	set @error_code = 0		
	
END
go

