/**************************************************
Object Name :  internal_get_clientcontrol_gids_associatedwith
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves all client control gobject ids which are created from
			   given PrimaryFile and VendorName
Used By	    :  CDI uses it in GetClientControlGIdsAssociatedWith.
Variables Used -
@filename - Primary File Name
@vendor_name - vendor name
**************************************************/

create proc dbo.internal_get_clientcontrol_gids_associatedwith(
	@filename nvarchar(256),
	@vendor_name nvarchar(256)	)
as
begin
set nocount on

-- Get inputs from file
declare @file_id int
set @file_id = 0

select  @file_id = file_id
from file_table 
where file_name = @filename and
vendor_name = @vendor_name

select distinct gobject_id
from primitive_instance_file_table_link
where file_id = @file_id



end
go

