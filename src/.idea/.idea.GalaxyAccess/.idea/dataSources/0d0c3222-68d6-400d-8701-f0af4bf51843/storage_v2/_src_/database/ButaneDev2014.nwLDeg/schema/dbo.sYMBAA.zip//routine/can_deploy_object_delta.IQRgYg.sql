-- Returns true if a gObject is eligible for deploying updates
--
-- This means that the object is deployed and pending updates
-- and there have been no shape changes 
create function dbo.can_deploy_object_delta(@gobject_id as int) 
	returns bit as
begin
	declare @deployed_package_id int
	declare @checked_in_package_id int
    declare @deployment_pending_status bit -- CR134612
 
	select	@deployed_package_id = deployed_package_id,
			@checked_in_package_id = checked_in_package_id,
            @deployment_pending_status = deployment_pending_status -- CR134612
	from	gobject 
	where	gobject_id = @gobject_id

	-- must fully deploy
    -- CR134612: The assertion of auto-bound attribute overrides sets the deployment_pending_status bit to true,
    --           and does not precipitate changes to the object's shape, which entails checking out the object. 
    --           So we forcibly disallow delta-deployment as an option for objects whose auto-bound references are overridden.
	if  @deployed_package_id = 0 
	 or @deployed_package_id = @checked_in_package_id
     or @deployment_pending_status = 1
	begin
		return 0
	end

	-- can not host any object
	if exists (
	select	gobject_id
	from	gobject 
	where	hosted_by_gobject_id = @gobject_id)
	begin
		return 0
	end


	-- no primitives can be different
	if exists ( 
	select p1.mx_primitive_id,p2.mx_primitive_id 
	from ( 
	  select *
	  from primitive_instance 
	  where gobject_id = @gobject_id and package_id = @checked_in_package_id ) 
	  p1
	full join (
	  select * 
	  from primitive_instance 
	  where gobject_id = @gobject_id and package_id = @deployed_package_id ) 
	  p2 
	on 
	  -- all these must be identical, or primitives or different
	   p1.mx_primitive_id = p2.mx_primitive_id 
	   and p1.primitive_definition_id = p2.primitive_definition_id
	   and p1.primitive_name = p2.primitive_name
	   and p1.parent_mx_primitive_id = p2.parent_mx_primitive_id
	   and p1.execution_group = p2.execution_group
	   and p1.execution_order = p2.execution_order
	   and p1.is_object_extension = p2.is_object_extension
	where 
	  -- null means no match found
	  p1.mx_primitive_id is null 
	  or p2.mx_primitive_id is null 
	)
	begin
		return 0
	end

	-- handle feature changes
	if exists ( 
	select p1.mx_primitive_id,p2.mx_primitive_id 
	from ( 
	  select *
	  from primitive_instance_feature_link 
	  where gobject_id = @gobject_id and package_id = @checked_in_package_id ) 
	  p1
	full join (
	  select * 
	  from primitive_instance_feature_link 
	  where gobject_id = @gobject_id and package_id = @deployed_package_id ) 
	  p2 
	on 
	  -- all these must be identical, or primitives are different
	   p1.mx_primitive_id = p2.mx_primitive_id 
	   and p1.feature_id = p2.feature_id
	where 
	  -- null means no match found
	  p1.mx_primitive_id is null 
	  or p2.mx_primitive_id is null 
	)
	begin
		return 0
	end

	-- Handle added/deleted/renamed dynamic attributes
	if exists (
	select 	checked_in_dynamic.mx_attribute_id, 
		deployed_dynamic.mx_attribute_id
	from	(select 	* 
		from	dynamic_attribute
		where	gobject_id = @gobject_id and package_id = @checked_in_package_id)
		checked_in_dynamic
	full join 
		(select 	* 
		from	dynamic_attribute
		where	gobject_id = @gobject_id and package_id = @deployed_package_id)
		deployed_dynamic
	on	checked_in_dynamic.mx_primitive_id = deployed_dynamic.mx_primitive_id
	    and checked_in_dynamic.mx_attribute_id = deployed_dynamic.mx_attribute_id
	    and checked_in_dynamic.attribute_name = deployed_dynamic.attribute_name
	    and checked_in_dynamic.mx_data_type = deployed_dynamic.mx_data_type
	    and checked_in_dynamic.mx_attribute_category = deployed_dynamic.mx_attribute_category
	    and checked_in_dynamic.lock_type = deployed_dynamic.lock_type
	    and checked_in_dynamic.is_array = deployed_dynamic.is_array

	where	checked_in_dynamic.mx_attribute_id is null
	    or	deployed_dynamic.mx_attribute_id is null
	)
	begin	
		return 0
	end

	-- Check the lock type on the package id for the templates it is derived from
	declare @derived_from_deployed_pkg int
	set @derived_from_deployed_pkg = (select derived_from_package_id from 
												 package where 
												 gobject_id = @gobject_id 
											 and package_id = @deployed_package_id)

	declare @derived_from_checked_in_pkg int
	set @derived_from_checked_in_pkg = (select derived_from_package_id from 
												 package where 
												 gobject_id = @gobject_id 
											 and package_id = @checked_in_package_id)
	if ( @derived_from_deployed_pkg <> @derived_from_checked_in_pkg)
	begin
		declare @derived_from_gobject_id int
		set @derived_from_gobject_id = (select derived_from_gobject_id from gobject where gobject_id = @gobject_id)
		if exists(
 				select 	checked_in_temp_attr.mx_attribute_id, 
					deployed_temp_attr.mx_attribute_id
				from	(select 	* 
					from	template_attribute
					where	gobject_id = @derived_from_gobject_id and package_id = @derived_from_checked_in_pkg)
					checked_in_temp_attr
				full join 
					(select 	* 
					from	template_attribute
					where	gobject_id = @derived_from_gobject_id and package_id = @derived_from_deployed_pkg)
					deployed_temp_attr
				on	checked_in_temp_attr.mx_primitive_id = deployed_temp_attr.mx_primitive_id
					and checked_in_temp_attr.mx_attribute_id = deployed_temp_attr.mx_attribute_id
					and checked_in_temp_attr.lock_type = deployed_temp_attr.lock_type
					and checked_in_temp_attr.mx_data_type = deployed_temp_attr.mx_data_type
				where	checked_in_temp_attr.mx_attribute_id is null
					or	deployed_temp_attr.mx_attribute_id is null

			)
			begin
				return 0
			end
		end

	return 1
end



go

