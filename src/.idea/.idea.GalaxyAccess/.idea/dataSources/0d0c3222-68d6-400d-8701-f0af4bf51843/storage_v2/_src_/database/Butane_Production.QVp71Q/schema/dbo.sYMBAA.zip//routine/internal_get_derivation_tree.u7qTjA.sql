/**************************************************
Object Name :  internal_get_derivation_tree
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves all derived objects for a specific gobject

Variables Used -
@WorkingSet - holds gobjects for a particular iteration in the while loop. 
@TemporaryCache - temporarily holds all the descendants of the @WorkingSet gobjects.
@ResultSet - holds all the descendant gobjects

Example		:	exec internal_get_derivation_tree 7
**************************************************/

CREATE PROCEDURE dbo.internal_get_derivation_tree
	@gObjectId int
AS
begin
	set nocount on

	declare @ResultSet table( 
				gobject_id int, 
				gobject_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
				derived_from_gobject_id int, 
				derived_from_gobject_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS, 
				istemplate bit, 
				nLevel int)
	declare @WorkingSet table( gobject_id int)
	declare @TempWorkingSet table( gobject_id int)
	declare @nLevel int

	set @nLevel = 0

	insert	@ResultSet 
		select	go.gobject_id, 
				go.tag_name, 
				go.derived_from_gobject_id, 
				case go.derived_from_gobject_id when 0 then '' else parent.tag_name end,
				go.is_template,
				@nLevel
		from	gobject go
        left outer join gobject parent on
            go.derived_from_gobject_id = parent.gobject_id
		where	go.gobject_id = @gObjectId

	insert into @WorkingSet values( @gObjectId )

	while (1=1)
	begin
		set @nLevel = @nLevel + 1

		insert @ResultSet
			select	go.gobject_id, 
					go.tag_name, 
					go.derived_from_gobject_id, 
					case go.derived_from_gobject_id when 0 then '' else parent.tag_name end,
					go.is_template,
					@nLevel
			from	gobject go, @WorkingSet ws, gobject parent
			where	go.derived_from_gobject_id = ws.gobject_id
				and	go.derived_from_gobject_id = parent.gobject_id

		insert @TempWorkingSet
			select	go.gobject_id 
			from	gobject go, @WorkingSet ws
			where	go.derived_from_gobject_id = ws.gobject_id
				and	go.is_template = 1

		delete	@WorkingSet

		insert 	@WorkingSet
			select	gobject_id 
			from	@TempWorkingSet
		
		delete @TempWorkingSet

		if (not exists (select * from @WorkingSet))
			break
	end

	select * from @ResultSet order by gobject_id

	
end

go

