CREATE FUNCTION dbo.itvfGetAutobindInfoForDIO (@dio_id int, @sg_mx_primitive_id smallint = 0, @gobject_id int = 0, @attr_name nvarchar(329) = NULL, @io_attr_name nvarchar(329) = NULL)
RETURNS TABLE 
AS 
  /*
    Implemented as an inlined TVF, returns @AutoBoundInfo
      dio_id                      int
    , sg_mx_primitive_id          smallint
    , lo_id                       int
    , lo_package_id               int
    , lo_prim_id                  smallint
    , lo_attr_id                  smallint
    , lo_element_index            smallint
    , dio_tag_name                nvarchar (329)
    , dio_scan_group_name         nvarchar (329)
    , app_object_tag_name         nvarchar (329)
    , app_object_attr_name        nvarchar (329)
    , app_object_attr_type        smallint
    , app_object_io_attr          nvarchar (329)
    , binding_rule_id             int
    , binding_rule                nvarchar (500)
    , default_attr_reference      nvarchar (500)
    , xlate_rule_id               int
    , xlate_rule_name             nvarchar (329)
    , overridden_attr_reference   nvarchar (500)
  */

  RETURN (
    SELECT ab_device.dio_id             AS dio_id
         , ab_topic.sg_mx_primitive_id  AS sg_mx_primitive_id
         , lo.gobject_id                AS lo_id
         , lo_pi.package_id             AS lo_package_id
         , ab_attr.mx_primitive_id      AS lo_prim_id
         , ab_attr.mx_attribute_id      AS lo_attr_id
         , ab_attr.element_index        AS lo_element_index
         , dio.tag_name                 AS dio_tag_name
         , sg_pi.primitive_name         AS dio_scan_group_name
         , lo.tag_name                  AS app_object_tag_name
         , lo_pi.primitive_name         AS app_object_attr_name
         , dynattr.mx_data_type	        AS app_object_attr_type
         , lo_attr_def.attribute_name   AS app_object_io_attr
         , ab_nr.rule_id                AS binding_rule_id
         , ab_nr.naming_rule            AS binding_rule
         , dbo.evaluate_autobind_naming_rule (
                        ab_nr.naming_rule
                      , lo.tag_name
                      , lo.hierarchical_name
                      , lo.contained_name
                      , lo_pi.primitive_name
                      , dio.tag_name
                      , sg_pi.primitive_name
                      , lo_pd.primitive_name
                      , lo_attr_def.attribute_name
                    )                   AS default_attr_reference
         , ab_xlate.xlate_rule_id       AS xlate_rule_id
         , ab_xlate.xlate_rule_name     AS xlate_rule_name
         , ab_attr.attr_alias           AS overridden_attr_reference
      FROM autobind_device ab_device
    -- Device information
    INNER JOIN gobject dio
        ON dio.gobject_id = ab_device.dio_id
    INNER JOIN primitive_instance sg_pi
        ON sg_pi.gobject_id = dio.gobject_id
       AND sg_pi.package_id = dio.checked_in_package_id
    INNER JOIN autobind_device_topic ab_topic
        ON ab_topic.dio_id = ab_device.dio_id
       AND ab_topic.sg_mx_primitive_id = sg_pi.mx_primitive_id
    -- Linked object information:
    INNER JOIN autobound_attribute ab_attr
        ON ab_attr.dio_id = ab_device.dio_id
       AND ab_attr.sg_mx_primitive_id = ISNULL (ab_topic.sg_mx_primitive_id, 0)
    INNER JOIN gobject lo
        ON lo.gobject_id = ab_attr.gobject_id
    INNER JOIN attribute_reference lo_attr_ref
        ON lo_attr_ref.gobject_id = ab_attr.gobject_id
       AND lo_attr_ref.package_id = lo.checked_in_package_id
       AND lo_attr_ref.referring_mx_primitive_id = ab_attr.mx_primitive_id
       AND lo_attr_ref.referring_mx_attribute_id = ab_attr.mx_attribute_id
       AND lo_attr_ref.element_index = 0                                      -- No arrays for now.
       AND lo_attr_ref.reference_string = N'---Auto---'
    INNER JOIN primitive_instance lo_pi
        ON lo_pi.package_id = lo_attr_ref.package_id
       AND lo_pi.gobject_id = lo_attr_ref.gobject_id
       AND lo_pi.mx_primitive_id = lo_attr_ref.referring_mx_primitive_id
    INNER JOIN attribute_definition lo_attr_def
        ON lo_attr_def.primitive_definition_id = lo_pi.primitive_definition_id
       AND lo_attr_def.mx_attribute_id = lo_attr_ref.referring_mx_attribute_id
    INNER JOIN primitive_definition lo_pd
        ON lo_pd.primitive_definition_id = lo_pi.primitive_definition_id
    INNER JOIN autobind_translation_rule ab_xlate
        ON ab_xlate.xlate_rule_id = ab_attr.xlate_rule_id
    -- For Attr Type
    INNER JOIN dynamic_attribute dynattr
        ON dynattr.gobject_id = lo_pi.gobject_id
       AND dynattr.package_id = lo_pi.package_id
    -- AND dynattr.mx_primitive_id = lo_pi.parent_mx_primitive_id
       AND dynattr.attribute_name = lo_pi.primitive_name
    -- Naming rules
    CROSS APPLY (SELECT * from AutobindNamingRule (ab_topic.dio_id, ab_topic.sg_mx_primitive_id) r where r.io_type = SUBSTRING (lo_attr_def.attribute_name, 1, 1)) ab_nr
    -- Where clause
     WHERE ab_device.dio_id           = @dio_id
       AND sg_pi.mx_primitive_id      = (CASE WHEN @sg_mx_primitive_id <> 0 THEN @sg_mx_primitive_id ELSE sg_pi.mx_primitive_id END)
       AND lo.gobject_id              = (CASE WHEN @gobject_id <> 0 THEN @gobject_id ELSE lo.gobject_id END)
       AND lo_pi.primitive_name       = ISNULL (@attr_name, lo_pi.primitive_name) 
       AND lo_attr_def.attribute_name = ISNULL (@io_attr_name, lo_attr_def.attribute_name)
  )
go

