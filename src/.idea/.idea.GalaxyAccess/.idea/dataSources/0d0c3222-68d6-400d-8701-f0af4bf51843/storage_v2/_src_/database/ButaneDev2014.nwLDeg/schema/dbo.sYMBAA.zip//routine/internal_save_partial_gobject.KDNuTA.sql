create proc dbo.internal_save_partial_gobject
    @gobjectid int,
    @package_id int,    
    @primitiveinstancefile nvarchar(255),
    @priminstancefilehascontent int,
    @templateattrfile nvarchar(255),
    @templateattrhascontent int,
    @attrreffile nvarchar(255),
    @attrrefhascontent int,
    @userID uniqueidentifier,
    @automation_object_change_has_occured bit,
    @graphic_change_has_occured bit,
    @record_change bit
as 
begin tran
    set nocount on

	-- before we delete the rows, we need to copy the timestamp information to 
	-- a temp table.  We will use this info in an update after the insert....
	declare @primitive_instance_archive table
				(gobject_id int,
				package_id int,
				mx_primitive_id smallint,
				timestamp_of_last_change bigint,
				max_child_timestamp bigint,
				entity_change_type int,
				operation_on_primitive_mask int)
	    
	    
    if (@priminstancefilehascontent = 1 )
    begin
    
        create table #primitive_instance_T( primitive_definition_id int,
                        primitive_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                        mx_primitive_id smallint,
                        parent_mx_primitive_id  smallint,
                        execution_group int,
                        execution_order int,
                        owned_by_gobject_id int,
                        extension_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
                        is_object_extension bit,
                        checked_in_primitive_version int,
                        checked_out_primitive_version int,
                        entity_change_type int,
                        operation_on_primitive_mask int,
                        created_by_parent smallint,
                        status_id smallint,
                        ref_status_id smallint,                                    
                        primitive_attributes image,
                        mx_value_errors text not null,    
                        mx_value_warnings text not null,    
                        mx_value_reference_warnings text not null)
                            

        DECLARE @pSQL nvarchar(2000)
        SET @pSQL = 'BULK INSERT #primitive_instance_T  FROM ''' + @primitiveinstancefile+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@pSQL)
        
        
		insert into  @primitive_instance_archive 
				(gobject_id ,
				package_id ,
				mx_primitive_id ,
				timestamp_of_last_change ,
				max_child_timestamp,
				entity_change_type,
				operation_on_primitive_mask)
		select   
				@gobjectid ,
				@package_id ,
				mx_primitive_id ,
				timestamp_of_last_change ,
				max_child_timestamp,
				entity_change_type,
				operation_on_primitive_mask
		from  primitive_instance 
		where gobject_id = @gobjectid and
			package_id = @package_id
          
          
          
        -- obtain a new timestamp to insert into primitive_instance..
        declare @new_timestamp bigint    
        exec internal_get_next_timestamp @new_timestamp out

        -- Update Primitive Instance Table        
        update  pri 
        set     gobject_id = @gobjectid,
                package_id = @package_id,
                mx_primitive_id = i.mx_primitive_id,
                primitive_definition_id = i.primitive_definition_id,
                primitive_name = i.primitive_name,
                parent_mx_primitive_id = i.parent_mx_primitive_id,
                execution_group = i.execution_group,
                execution_order = i.execution_order,
                owned_by_gobject_id = i.owned_by_gobject_id,
                extension_type = i.extension_type,
                is_object_extension = i.is_object_extension,
                checked_in_primitive_version = i.checked_in_primitive_version,
                checked_out_primitive_version = i.checked_out_primitive_version,
                entity_change_type = i.entity_change_type,
                operation_on_primitive_mask = pri.operation_on_primitive_mask | i.operation_on_primitive_mask,
                created_by_parent = i.created_by_parent,
                status_id = i.status_id,
                ref_status_id = i.ref_status_id,
                primitive_attributes = i.primitive_attributes,
                mx_value_errors = i.mx_value_errors,
                mx_value_warnings = i.mx_value_warnings,
                mx_value_reference_warnings = '0x00',
                timestamp_of_last_change = @new_timestamp
                
        from    primitive_instance pri
        inner   join #primitive_instance_T i on 
            @gobjectid = pri.gobject_id and 
            @package_id = pri.package_id and
            i.mx_primitive_id = pri.mx_primitive_id 
            
            
        
        update	pri
        set		pri.timestamp_of_last_change = ts.timestamp_of_last_change,
				pri.max_child_timestamp = ts.max_child_timestamp,
				pri.operation_on_primitive_mask = ts.operation_on_primitive_mask | pri.operation_on_primitive_mask
        from	primitive_instance pri
        inner join @primitive_instance_archive ts on
              pri.gobject_id = ts.gobject_id and
              pri.package_id = ts.package_id and
              pri.mx_primitive_id = ts.mx_primitive_id                     

        update	pri
        set		pri.entity_change_type = ts.entity_change_type
        from	primitive_instance pri
        inner join @primitive_instance_archive ts on
              pri.gobject_id = ts.gobject_id and
              pri.package_id = ts.package_id and
              pri.mx_primitive_id = ts.mx_primitive_id                     
        where ts.entity_change_type > pri.entity_change_type
        
    end

    -- Attribute Template Table
           
    if (@templateattrhascontent = 1 )
    begin
        create table #template_attr_T
        (
            mx_primitive_id         smallint,
            mx_attribute_id         smallint,
            mx_data_type                int,
            security_classification int,
            mx_value                    text,
            lock_type                   int,
            original_lock_type          int
        )
        
        DECLARE @taSQL nvarchar(2000)
        SET @taSQL = 'BULK INSERT #template_attr_T  FROM ''' + @templateattrfile+ ''' 
                    WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@taSQL)
        
        update tempattr
        set     gobject_id = @gobjectid,
                package_id = @package_id,
                mx_primitive_id = atemp.mx_primitive_id,
                mx_attribute_id = atemp.mx_attribute_id,
                mx_data_type = atemp.mx_data_type ,
                security_classification = atemp.security_classification ,
                mx_value = atemp.mx_value ,
                lock_type = atemp.lock_type ,
                original_lock_type = atemp.original_lock_type 
        from template_attribute tempattr
        inner join #template_attr_T atemp
        on   tempattr.gobject_id = @gobjectid and
             tempattr.package_id = @package_id and
             tempattr.mx_primitive_id = atemp.mx_primitive_id and
             tempattr.mx_attribute_id = atemp.mx_attribute_id

        drop table #template_attr_T
    end  
    
    delete  ar 
	from attribute_reference ar
	inner join #primitive_instance_T t on
		ar.gobject_id = @gobjectid and 
		ar.package_id = @package_id and
		ar.referring_mx_primitive_id = t.mx_primitive_id 

    
    -- bulk insert into this table
    if (@attrrefhascontent = 1 )
    begin      
      create table #attr_reference_inst_T
         (
            referring_mx_primitive_id smallint,
            referring_mx_attribute_id smallint,
            element_index             smallint,
            dest_object_name          nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
            resolved_gobject_id       int ,
            reference_string          nvarchar(700) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
            context_string            nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS not null,
            object_signature          int,
            resolved_mx_primitive_id  smallint,
            resolved_mx_attribute_id  smallint,
            resolved_mx_property_id   smallint,
            attribute_signature       int,
            lock_type                 int,
            attr_res_status           int,
            attribute_index           smallint,
            is_valid                  bit            
         )

        DECLARE @arSQL nvarchar(2000)
        SET @arSQL = 'BULK INSERT #attr_reference_inst_T  FROM ''' + @attrreffile+ ''' 
                    WITH (FIELDTERMINATOR = ''\t'', TABLOCK, DATAFILETYPE  = ''widechar'') '
        EXEC (@arSQL)
        
        update  attr_ref
        set     resolved_gobject_id = ( select isnull(gobj.gobject_id,0) 
                            from gobject gobj where gobj.tag_name = attr_ref.dest_object_name and gobj.namespace_id = 1)
        from    #attr_reference_inst_T attr_ref
        
        
        insert into attribute_reference(gobject_id,
                                           package_id,
                                           referring_mx_primitive_id,
                                           referring_mx_attribute_id,
                                           element_index,
                                           resolved_gobject_id,
                                           reference_string,
                                           context_string,
                                           object_signature,
                                           resolved_mx_primitive_id,
                                           resolved_mx_attribute_id,
                                           resolved_mx_property_id,
                                           attribute_signature,
                                           lock_type,
                                           is_valid,
                                           attr_res_status,
                                           attribute_index )
                   select @gobjectid,@package_id,
                          attr_ref.referring_mx_primitive_id,
                          attr_ref.referring_mx_attribute_id,
                          attr_ref.element_index,
                          isnull(attr_ref.resolved_gobject_id,0),
                          attr_ref.reference_string,
                          attr_ref.context_string,
                          attr_ref.object_signature,
                          attr_ref.resolved_mx_primitive_id,
                          attr_ref.resolved_mx_attribute_id,
                          attr_ref.resolved_mx_property_id,
                          attr_ref.attribute_signature,
                          attr_ref.lock_type,
                          attr_ref.is_valid,
                          attr_ref.attr_res_status,
                          attr_ref.attribute_index
                   from   #attr_reference_inst_T attr_ref  
    end


    -- Reset the package status
    update  package
    set     status_id = 0,
            reference_status_id = 0
    where   gobject_id = @gobjectid
    and     package_id = @package_id

    -- Set package status to warning or error if necessary
    update  pa
    set     pa.status_id = pri.status_id
    from    package pa 
    inner join primitive_instance pri
    on      pa.gobject_id = pri.gobject_id
    and     pa.package_id = pri.package_id 
    and     (
				(pri.status_id = 2 ) or
				(pri.status_id = 1 ) 
			)
    where   pa.gobject_id = @gobjectid
    and     pa.package_id = @package_id

    
    --Invalidate the attribute_reference rows
	--This will enable reference binding to retrieve and try to bind these references... 
    update  ar
    set     ar.is_valid = 1
    from    attribute_reference ar
    inner join primitive_instance pri
    on      ar.gobject_id = pri.gobject_id and
			ar.package_id = pri.package_id and
			ar.referring_mx_primitive_id = pri.mx_primitive_id
    where   pri.gobject_id = @gobjectid and
			pri.package_id = @package_id and
			pri.ref_status_id = 2
	
	-- Primitive instance's ref_status_id column is NOT VALID ANY MORE.
	-- So we need to set the Package Reference from Attribute_Reference table
	

    
    update  pa
    set     pa.reference_status_id = 2
    from    package pa 
    inner join attribute_reference attr
    on      pa.gobject_id = attr.gobject_id
    and     pa.package_id = attr.package_id 
    and     attr.is_valid = 1
    where   pa.gobject_id = @gobjectid
    and     pa.package_id = @package_id

	

    if (@record_change = 1) -- log event if flag was passed...
    begin
        -- Validate the user guid that has been passed in....
        if exists(select '*' from user_profile where user_guid = @userID)
        begin
            declare @operationId int
            set @operationId = 0
            declare @comment nvarchar(256)
            if (@automation_object_change_has_occured = 1 and @graphic_change_has_occured = 0)
            begin
                set @operationId = 37
                set @comment = 'Updated configuration.'
            end
            else if (@automation_object_change_has_occured = 1 and @graphic_change_has_occured = 1)
            begin
                set @operationId = 39
                set @comment = 'Updated configuration and graphics.'
            end
            else if (@automation_object_change_has_occured = 0 and @graphic_change_has_occured = 1)
            begin
                set @operationId = 38
                set @comment = 'Updated graphics.'
            end

            if(@operationId > 0)
            begin 
                exec internal_log_changes @gobjectid, @userID, @operationId, @comment
            end

        end
        else
        begin    
            rollback tran
            return
            /*     this block should be modified to return an error code
                   to indicate that the userId was invalid. -- Anand                 
            */

        end
    end

commit



go

