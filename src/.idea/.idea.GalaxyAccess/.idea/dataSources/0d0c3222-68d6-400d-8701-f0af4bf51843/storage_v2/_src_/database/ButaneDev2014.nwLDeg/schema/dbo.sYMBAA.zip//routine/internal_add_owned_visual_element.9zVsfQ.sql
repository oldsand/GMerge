create proc dbo.internal_add_owned_visual_element
@visual_element_id int,
@change_type int,
@visual_element_type nvarchar(32), 
@gobject_id int,
@package_id int,
@mx_primitive_id smallint,
@description nvarchar(1024)


as

begin tran
    declare @ErrorCode int
    declare @visual_element_category nchar(1)
    declare @isNewVisualElement bit
    
    
   
    -- get the visual_element_name....
    declare @visual_element_name nvarchar(329)
    SELECT  @visual_element_name = 
     CASE WHEN pri.primitive_name <> '' THEN g.tag_name + '.' + pri.primitive_name ELSE g.tag_name END 
    FROM gobject g 
    INNER JOIN 
     package p ON g.gobject_id = p.gobject_id and g.checked_in_package_id = p.package_id
    INNER JOIN            
     primitive_instance pri ON p.gobject_id = pri.gobject_id 
     and pri.gobject_id = @gobject_id and pri.mx_primitive_id = @mx_primitive_id
     and pri.package_id = @package_id
    
    
    if (@visual_element_type = N'Display' )
    begin
        set @visual_element_category = N'S'
    end
    else
    begin
       set @visual_element_category = N'E' 
    end

    if (@visual_element_id = 0)
    begin-- this visual element has not been created in the db yet..
        set @isNewVisualElement = 1        
        -- get new visual_element_id
        exec internal_get_new_visual_element_id @visual_element_id out
        
        insert into visual_element 
            (visual_element_id,
             visual_element_type,
             visual_element_category,
             inheritance_status)
        values
            (@visual_element_id,
             @visual_element_type,
             @visual_element_category,
             N'O')
            
        set @ErrorCode = @@error
        if @ErrorCode <> 0 begin
            rollback
            return @ErrorCode
        end
        --set @visual_element_id = @@identity
    end
    else
    begin
        set @isNewVisualElement = 0
    end
    if (@isNewVisualElement = 1) or not exists   
                  ( select 
                        '*' 
                    from 
                        visual_element_version
                    where
                        visual_element_id = @visual_element_id and
                        gobject_id = @gobject_id and
                        package_id = @package_id and
                        mx_primitive_id = @mx_primitive_id
                    )
    begin -- this is the first time we are 
          -- saving this visual element 
          -- in this package.
        if not exists(
                        select 
                                1 
                        from 
                                visual_element 
                        where     
                                visual_element_id = @visual_element_id
                        )
        begin
            insert into visual_element 
                (visual_element_id,
                 visual_element_type,
                 visual_element_category,
                 inheritance_status)
            values
                (@visual_element_id,
                 @visual_element_type,
                 @visual_element_category,
                 N'O')
        end
        else
        begin
             update visual_element 
             set visual_element_type = @visual_element_type,
                 visual_element_category = @visual_element_category
             where visual_element_id = @visual_element_id            
        end

        insert into visual_element_version
            (gobject_id,
        	package_id,
        	mx_primitive_id,
            visual_element_id,
            inherited_from_gobject_id ,
       	    inherited_from_package_id ,
            inherited_from_mx_primitive_id ,
            inherited_from_visual_element_id )
        values
            (@gobject_id,
           	 @package_id,
        	 @mx_primitive_id,
             @visual_element_id,
             @gobject_id,
             @package_id,
        	 @mx_primitive_id,
             @visual_element_id)
		

    
        set @ErrorCode = @@error
        if @ErrorCode <> 0 begin
            rollback
            return @ErrorCode
        end
        
        insert into owned_visual_element
            (gobject_id,
        	package_id,
        	mx_primitive_id,
            visual_element_id,
            description,
            thumbnail,
			visual_element_definition,
			is_thumbnail_dirty)
        select
            @gobject_id,
        	@package_id,
        	@mx_primitive_id,
            @visual_element_id,
            @description,
            thumbnail,
	visual_element_definition,
	1
       from #owned_visual_element
      where mx_primitive_id = @mx_primitive_id
            
        set @ErrorCode = @@error
        if @ErrorCode <> 0 begin
            rollback
            return @ErrorCode
        end
    end
    else -- this package already contains this visual element
         -- so we should just update the information...
    begin
        update 
            ove
        set 
            ove.thumbnail = t.thumbnail,
            ove.description = @description,
			ove.visual_element_definition = t.visual_element_definition
		from owned_visual_element ove
		inner join #owned_visual_element t on    
        ove.visual_element_id = @visual_element_id and
        ove.gobject_id = @gobject_id and
        ove.package_id = @package_id and
        ove.mx_primitive_id = t.mx_primitive_id
    end        


-- -- bind the visual_element if necessary...
/*
    exec internal_bind_visual_element
    @visual_element_id,
    @visual_element_type,
    @visual_element_name,
    null
    
insert into visual_elements_to_bind
select 
	@visual_element_id,
    @visual_element_type,
    @visual_element_name
*/  
--    exec internal_bind_relative_visual_elements_for_gobject 
--        @gobject_id, @package_id
    
    exec internal_update_visual_element_timestamp 
        @gobject_id,
        @package_id,
        @mx_primitive_id,
        @visual_element_id,
		@change_type
   
commit

return @ErrorCode



go

