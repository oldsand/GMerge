create procedure dbo.internal_purge_visual_element_change_logs
as
begin tran
	truncate table visual_element_timestamp
	truncate table renamed_visual_element
    truncate table deleted_visual_element_version
commit
go

