create proc dbo.internal_get_file_dependencies_for_gobjects    
    -- comma separated list of visual element ids or file of ids
    @file_of_gobject_ids nvarchar(4000)

as
begin
    -- read file_of_gobject_ids
    create table  #gobject_ids ( gobject_id int)

	insert #gobject_ids(gobject_id)
    	exec internal_select_ids @file_of_gobject_ids

select distinct
    f.file_name,
    f.subfolder,  
    f.vendor_name, 
    f.registration_type, 
    piftl.is_needed_for_editor, 
    piftl.is_needed_for_package,  
    piftl.is_needed_for_runtime,
    piftl.mx_primitive_id,
    piftl.gobject_id
from
    file_table f inner join
    primitive_instance_file_table_link piftl on
    piftl.file_id = f.file_id
where 
    piftl.gobject_id in (select gobject_id from #gobject_ids)   
end
go

