/**************************************************
Object Name :  internal_get_gobjects_all_descendants_info
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves all derived objects for a specific gobject
Used By	    :  CDI uses it in GetDescendants call.
Variables Used -
@WorkingSet - holds gobjects for a particular iteration in the while loop. 
@TemporaryCache - temporarily holds all the descendants of the @WorkingSet gobjects.
@ResultSet - holds all the descendant gobjects
**************************************************/

CREATE PROCEDURE dbo.internal_get_gobjects_all_descendants_info
	@FileNameOfIds nvarchar (256)
AS
begin
set nocount on

SET QUOTED_IDENTIFIER OFF

-- Get inputs from file
CREATE TABLE  #input_table ( gobject_id int)
DECLARE @SQL nvarchar(2000)

SET @SQL = 'BULK INSERT #input_table  FROM ''' + @FileNameOfIds+ ''' WITH(TABLOCK,DATAFILETYPE  = ''widechar'')'
EXEC (@SQL)

-- Move the input to working set
declare @WorkingSet table( gobject_id int, ancestor int, nLevel int, done int)

insert into @WorkingSet
select I.gobject_id, G.derived_from_gobject_id, 0, 0
from gobject G inner join #input_table I on I.gobject_id = G.gobject_id

drop table #input_table

-- Get ancestor of all objects
update W1 set done = 1
from @WorkingSet W1 inner join @WorkingSet W2 on W1.ancestor = W2.gobject_id

while (select count(*) from @WorkingSet where done = 0) > 0
begin

	update @WorkingSet set ancestor = G.derived_from_gobject_id
	from @WorkingSet inner join gobject G on ancestor = G.gobject_id
	where done = 0

	update W1 set done = 1
	from @WorkingSet W1 inner join @WorkingSet W2 on W1.ancestor = W2.gobject_id 

	update @WorkingSet set done = 1 where ancestor = 0 and done = 0
end

-- set the object point to itself if it is not derived from any within the list
update @WorkingSet set ancestor = gobject_id where ancestor = 0

-- remove any object which is a child of another object in this list
delete from @WorkingSet where gobject_id <> ancestor

-- Add all descendants of all objects to this list
declare @nLevel int
set @nLevel = 0

while 1 > 0
begin
	insert into @WorkingSet
	select G.gobject_id, W.ancestor,  @nLevel + 1, 0
	from gobject G inner join @WorkingSet W on G.derived_from_gobject_id = W.gobject_id
	where W.nLevel = @nLevel

	if @@rowcount = 0 break
	set @nLevel = @nLevel + 1
end

-- return the result set ( note that some of the info here is not used )
select W.gobject_id, istemplate = G.is_template, isImmediateChild = 0, 
	   isCheckOut = case when G.checked_out_package_id <> 0 then 1 else 0 end,
	   Checked_Out_By = G.checked_out_by_user_guid, W.nLevel, W.ancestor
from @WorkingSet W inner join gobject G on W.gobject_id = G.gobject_id



END
go

