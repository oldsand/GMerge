-- Insert record in file_pending_update for all the nodes where input file_id has to be updated...
CREATE procedure dbo.internal_update_file_pending_update
	@file_id int --file_id which has been updated
AS
begin
	set nocount on
	-- get list of all the nodes where this file has 
	-- been send for runtime, editor, & package deployment

	delete from file_pending_update where file_id = @file_id

	insert into file_pending_update 	
		SELECT DISTINCT file_id, node_name from deployed_file
			where deployed_file.file_id = @file_id
			and (
				(is_package_deployed = 1) or
				(is_editor_deployed = 1) or
				(is_runtime_deployed = 1) or
				(is_browser_deployed = 1) 
			     )
		-- CR8219

	 -- Any visual element which depends on this file will need to have
	 -- it's timestamp updated to notify polling monitors.
	exec internal_update_file_dependent_visual_element_timestamps @file_id
	
end

go

