CREATE function dbo.get_next_mx_engine_id( 
	@my_platform_id smallint
	)
returns smallint

as
begin

	declare @next_engine_id smallint
	declare @mytable table( mx_engine_id smallint )

	insert into @mytable(mx_engine_id) (select distinct mx_engine_id from instance i where mx_platform_id = @my_platform_id)
	
	if ( @my_platform_id = 0 )
		insert into @mytable values( 1 )
	
	select @next_engine_id = min(i.mx_engine_id) + 1 
	from @mytable i
	left join  @mytable r on i.mx_engine_id + 1 = r.mx_engine_id
	where r.mx_engine_id is null 

	return @next_engine_id
		
end


go

