

create proc dbo.internal_get_visual_element_data
(
    -- comma separated list of visual element ids or file of ids
    @ids_or_file_of_ids nvarchar(4000),
 
    -- user making request, will affect results returned
    @user_guid uniqueidentifier
)
as 
begin
    if @user_guid is null or @user_guid = '00000000-0000-0000-0000-000000000000'
    begin
        select  @user_guid = user_guid 
        from    user_profile with(nolock)
        where   user_profile_name= 'SystemEngineer'
    end
 
    -- put visual_element_ids into table
    create  table #visual_element_ids_for_visual_element_data(
            idx int identity(0,1), 
            visual_element_id int)
 
    create index idx_vd on #visual_element_ids_for_visual_element_data(visual_element_id)
 
    -- put inherited_from_visual_element_ids into another table
    create  table #owned_visual_element_ids(
            visual_element_id int)
 
    create index idx_ovd on #owned_visual_element_ids(visual_element_id)
 
    -- take input visual element ids. (they are unique)
    insert #visual_element_ids_for_visual_element_data(visual_element_id)
        exec internal_select_ids @ids_or_file_of_ids
    
    -- inherited visual_element_ids  
    insert #owned_visual_element_ids(visual_element_id)
        select  distinct 
                vev.inherited_from_visual_element_id
        from    visual_element_version vev with(nolock)
        inner join #visual_element_ids_for_visual_element_data vid on
                vev.visual_element_id = vid.visual_element_id   
 
    -- retrieve the common portion: visual_element_definition
 
    -- Visual Element Definition
            select   ovid.visual_element_id visual_element_id,
            vpv.visual_element_definition visual_element_definition
    from    #owned_visual_element_ids ovid
    inner join internal_visual_element_description_per_user_view vpv with(nolock) on
            ovid.visual_element_id = vpv.visual_element_id
    where   vpv.user_guid = @user_guid
 
    -- retrieve the visual_element and owned_visual_element mapping
    select  distinct
            vid.idx,
            vid.visual_element_id,
            vev.inherited_from_visual_element_id
    from    #visual_element_ids_for_visual_element_data vid
    inner join visual_element_version vev with(nolock) on
    vid.visual_element_id = vev.visual_element_id
    order by vid.idx
         
    -- Visual Element Description 
    select  vid.idx,
            vpv.gobject_id,
            vpv.tag_name,
            vpv.description,
            vpv.primitive_name,
            vpv.visual_element_type,
            vpv.visual_element_id,            
            vpv.visual_element_category,
            vpv.inherited_from_visual_element_id,
            vpv.is_thumbnail_dirty
    from    #visual_element_ids_for_visual_element_data vid
    inner join internal_visual_element_description_per_user_view vpv with(nolock) on
            vid.visual_element_id = vpv.visual_element_id
    where   vpv.user_guid = @user_guid and (vpv.folder_id <> -1 OR vpv.folder_id is NULL)
    order by vid.idx
 
 
    -- Thumbnail
            select   vid.idx,
            vid.visual_element_id visual_element_id,
            vpv.visual_element_name visual_element_name,
            vpv.thumbnail thumbnail
    from    #visual_element_ids_for_visual_element_data vid
    inner join internal_visual_element_description_per_user_view vpv  with(nolock) on
            vid.visual_element_id = vpv.visual_element_id
    where   vpv.user_guid = @user_guid and (vpv.folder_id <> -1 OR vpv.folder_id is NULL)
    order by vid.idx
  
  
create table #references
(
    vid int,
    from_visual_element_id int,
    visual_element_id int,
    visual_element_source_handle int,
    visual_element_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    visual_element_type nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS,
    visual_element_reference_index int,          
    context_object_name nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS
)    

create index idx_veid on #references(visual_element_id)
create index idx_vref on #references(visual_element_reference_index)
 
-- create table to hold the full keys of the visual_elements....
 create table #visual_element_ids_for_visual_element_data2
    (
        idx int, 
        gobject_id int,
        package_id int,
        mx_primitive_id smallint, 
        visual_element_id int
    )

create index idx_veid on #visual_element_ids_for_visual_element_data2(visual_element_id)

insert into 
#visual_element_ids_for_visual_element_data2
    (
        idx,
        gobject_id ,
        package_id ,
        mx_primitive_id , 
        visual_element_id 
    )
select  tempv.idx,
        v.gobject_id ,
        v.package_id ,
        v.mx_primitive_id , 
        v.visual_element_id
from #visual_element_ids_for_visual_element_data tempv
inner join internal_visual_element_description_per_user_view v with(nolock) on
    tempv.visual_element_id = v.visual_element_id and
    v.user_guid = @user_guid
    

insert into #references
(
    vid , 
    from_visual_element_id ,
    visual_element_id ,
    visual_element_source_handle ,
    visual_element_name ,
    visual_element_type ,
    visual_element_reference_index ,          
    context_object_name 
)    
 -- get the visual_element's bound references.....
 select  distinct
            vid.idx vid,
            vid.visual_element_id from_visual_element_id,
            vedpuv.visual_element_id,
            gobject_referee.gobject_id,
            case when bver.is_relative_reference = 0 then                        
                case when referee_pri.primitive_name <> '' then 
                    gobject_referee.tag_name + '.' + left(referee_pri.primitive_name,32) 
                else gobject_referee.tag_name 
                end
             else
     		     case when(len(gobject_referee.hierarchical_name) >= len(referer_gobject.hierarchical_name)) then
			        'me'+ right(gobject_referee.hierarchical_name,
                        (len(gobject_referee.hierarchical_name)- len(referer_gobject.hierarchical_name)) )  
                        +   '.' + referee_pri.primitive_name
    		     else
	    	        ''
		         end
             end as visual_element_name,
            ve.visual_element_type,
            bver.visual_element_reference_index visual_element_reference_index,          
            g.tag_name context_object_name
    from    #visual_element_ids_for_visual_element_data2 vid 
    inner join visual_element_reference bver with(nolock) on
            vid.gobject_id = bver.gobject_id
        and vid.package_id = bver.package_id
        and vid.mx_primitive_id = bver.mx_primitive_id
    inner join visual_element_version vedpuv  with(nolock) on -- the target element....
            (bver.checked_in_bound_visual_element_gobject_id = vedpuv.gobject_id and
             bver.checked_in_bound_visual_element_package_id = vedpuv.package_id and
             bver.checked_in_bound_visual_element_mx_primitive_id = vedpuv.mx_primitive_id) 
    inner join primitive_instance referee_pri  with(nolock) on
            referee_pri.gobject_id = vedpuv.gobject_id and
            referee_pri.package_id = vedpuv.package_id and
            referee_pri.mx_primitive_id = vedpuv.mx_primitive_id
    inner join gobject g  with(nolock) on 
            g.gobject_id = vid.gobject_id
    inner join gobject referer_gobject  with(nolock) on
        bver.gobject_id = referer_gobject.gobject_id
    inner join gobject gobject_referee  with(nolock) on 
          gobject_referee.gobject_id = referee_pri.gobject_id
    inner join visual_element ve  with(nolock) on
          vedpuv.visual_element_id = ve.visual_element_id
    where bver.visual_element_bind_status = 1 and
          (
            (bver.checked_out_visual_element_package_id is null)
            or  (bver.checked_out_visual_element_package_id is not null and bver.checked_out_to_user_guid <> @user_guid )
           )

 union
 select  distinct
            vid.idx vid,
            vid.visual_element_id from_visual_element_id,
            vedpuv.visual_element_id,
            gobject_referee.gobject_id,
            case when bver.is_relative_reference = 0 then                        
                case when referee_pri.primitive_name <> '' then 
                    gobject_referee.tag_name + '.' + left(referee_pri.primitive_name,32) 
                else gobject_referee.tag_name 
                end
             else
                case when(len(g.hierarchical_name) >= len(referer_gobject.hierarchical_name)) then
                         'me' + right(gobject_referee.hierarchical_name,
                         (len(gobject_referee.hierarchical_name) - len(referer_gobject.hierarchical_name)) )  
                         + '.' + referee_pri.primitive_name
                     else
                         ''
                     end
            end as visual_element_name,
            ve.visual_element_type,
            bver.visual_element_reference_index visual_element_reference_index,          
            g.tag_name context_object_name
    from    #visual_element_ids_for_visual_element_data2 vid 
    inner join visual_element_reference bver  with(nolock) on
            vid.gobject_id = bver.gobject_id
        and vid.package_id = bver.package_id
        and vid.mx_primitive_id = bver.mx_primitive_id
    inner join visual_element_version vedpuv  with(nolock) on -- the target element....
            (bver.checked_out_bound_visual_element_gobject_id = vedpuv.gobject_id and
             bver.checked_out_bound_visual_element_package_id = vedpuv.package_id and
             bver.checked_out_bound_visual_element_mx_primitive_id = vedpuv.mx_primitive_id) 
    inner join primitive_instance referee_pri  with(nolock) on
            referee_pri.gobject_id = vedpuv.gobject_id and
            referee_pri.package_id = vedpuv.package_id and
            referee_pri.mx_primitive_id = vedpuv.mx_primitive_id
    inner join gobject g  with(nolock) on 
            g.gobject_id = vid.gobject_id
    inner join gobject referer_gobject  with(nolock) on
        bver.gobject_id = referer_gobject.gobject_id
    inner join gobject gobject_referee  with(nolock) on 
          gobject_referee.gobject_id = referee_pri.gobject_id
    inner join visual_element ve  with(nolock) on
          vedpuv.visual_element_id = ve.visual_element_id
    where bver.visual_element_bind_status = 1 and
          bver.checked_out_visual_element_package_id is not null and bver.checked_out_to_user_guid = @user_guid
    order by vid, visual_element_reference_index
      
insert into #references
(
    vid ,
    from_visual_element_id ,
    visual_element_id ,
    visual_element_source_handle ,
    visual_element_name ,
    visual_element_type ,
    visual_element_reference_index ,          
    context_object_name 
)    
        -- unbound, not checked out, (data will come from unbound,checked-in columns...)
    select   distinct
        vid.idx vid,
        vid.visual_element_id from_visual_element_id,
        0 visual_element_id,
        0 visual_element_source_handle,
        ubver.checked_in_unbound_visual_element_name,
        ubver.checked_in_unbound_visual_element_type,
        ubver.visual_element_reference_index visual_element_reference_index,          
        g.tag_name context_object_name
    from    #visual_element_ids_for_visual_element_data2 vid 
    inner join visual_element_reference ubver  with(nolock) on
            vid.gobject_id = ubver.gobject_id
        and vid.package_id = ubver.package_id
        and vid.mx_primitive_id = ubver.mx_primitive_id
        and ubver.visual_element_bind_status = 0 
         and ubver.checked_out_visual_element_package_id is null -- target is not checked out....        
    inner join gobject g  with(nolock) on
            vid.gobject_id = g.gobject_id 


   -- unbound visual element references 
    insert into #references
    (
        vid ,
        from_visual_element_id ,
        visual_element_id ,
        visual_element_source_handle ,
        visual_element_name ,
        visual_element_type ,
        visual_element_reference_index ,          
        context_object_name 
    )    
            select   distinct
            vid.idx vid,
            vid.visual_element_id from_visual_element_id,
            0 visual_element_id,
            0 visual_element_source_handle ,
            ubver.checked_out_unbound_visual_element_name,
            ubver.checked_out_unbound_visual_element_type,
            ubver.visual_element_reference_index visual_element_reference_index,          
            g.tag_name context_object_name
    from    #visual_element_ids_for_visual_element_data vid 
    inner join visual_element_version vev  with(nolock) on
            vid.visual_element_id = vev.visual_element_id
    inner join visual_element_reference ubver  with(nolock) on
            vev.gobject_id = ubver.gobject_id
        and vev.package_id = ubver.package_id
        and vev.mx_primitive_id = ubver.mx_primitive_id
        and ubver.visual_element_bind_status = 0
    inner join gobject g  with(nolock) on
            vev.gobject_id = g.gobject_id 
    where ubver.checked_out_to_user_guid = @user_guid 
    order by vid, visual_element_reference_index
                                        

   -- unbound visual element references
    insert into #references
    (
        vid ,
        from_visual_element_id ,
        visual_element_id ,
        visual_element_source_handle ,
        visual_element_name ,
        visual_element_type ,
        visual_element_reference_index ,          
        context_object_name 
    )    
            select   distinct
            vid.idx vid,
            vid.visual_element_id from_visual_element_id,
            0 visual_element_id,
            0 visual_element_source_handle ,
            ubver.checked_in_unbound_visual_element_name,
            ubver.checked_in_unbound_visual_element_type,
            ubver.visual_element_reference_index visual_element_reference_index,          
            g.tag_name context_object_name
    from    #visual_element_ids_for_visual_element_data vid 
    inner join visual_element_version vev  with(nolock) on
            vid.visual_element_id = vev.visual_element_id
    inner join visual_element_reference ubver  with(nolock) on
            vev.gobject_id = ubver.gobject_id
        and vev.package_id = ubver.package_id
        and vev.mx_primitive_id = ubver.mx_primitive_id
        and ubver.visual_element_bind_status = 0 
         and (
                 ubver.checked_out_visual_element_package_id > 0 
                 and ubver.checked_out_to_user_guid <> @user_guid )        
    inner join gobject g  with(nolock) on
            vev.gobject_id = g.gobject_id 
    

   
select 
    vid idx,
    from_visual_element_id ,
    visual_element_id ,
    visual_element_source_handle,
    visual_element_name ,
    visual_element_type ,
    visual_element_reference_index ,          
    context_object_name 
from 
#references
order by idx, visual_element_reference_index
     
    -- retrieve attribute_reference
    create table #primitive_to_retrieve (
            idx int,
            referring_object_tagname nvarchar(329) COLLATE SQL_Latin1_General_CP1_CI_AS ,
            gobject_id int,
            package_id int,
            mx_primitive_id int
    )
 
    insert #primitive_to_retrieve(
            idx,
            referring_object_tagname,
            gobject_id,
            package_id,
            mx_primitive_id)
    (
        select  distinct
                vid.idx,
                g.tag_name,
                ver.gobject_id,
                ver.package_id,
                ver.mx_primitive_id
        from    visual_element_version ver with(nolock) 
        inner join #visual_element_ids_for_visual_element_data vid on 
                vid.visual_element_id = ver.visual_element_id
        inner join gobject g  with(nolock) on
                g.gobject_id = ver.gobject_id
    )
 
 
    select  distinct 
            p.idx,
            p.mx_primitive_id,
            p.referring_object_tagname,
            a.referring_mx_primitive_id,
            a.referring_mx_attribute_id,
                a.element_index,
                isnull(inst.mx_platform_id,0) as platform_id,
            isnull(inst.mx_engine_id,0) as engine_id,
            isnull(inst.mx_object_id,0) as object_id,
            isnull(backup_engine.mx_platform_id,0) as redundant_engine_platform_id,
            isnull(backup_engine.mx_engine_id,0) as redundant_engine_engine_id,                  
                object_signature,
            reference_string,
                context_string,
                resolved_mx_primitive_id,
                resolved_mx_attribute_id,
                resolved_mx_property_id,
                attribute_signature, 
                lock_type,
                attr_res_status,
                is_valid,
                isnull(g.tag_name,'') as tag_name,
                a.attribute_index
    from    #primitive_to_retrieve p
    inner join attribute_reference a  with(nolock) on
            p.gobject_id = a.gobject_id
        and p.package_id = a.package_id 
        and p.mx_primitive_id = a.referring_mx_primitive_id
    left join instance inst  with(nolock) on   
            a.resolved_gobject_id = inst.gobject_id
    left join gobject g  with(nolock) on   
            g.gobject_id = inst.gobject_id
    left join instance engine  with(nolock) on                  
            inst.mx_platform_id = engine.mx_platform_id 
            and inst.mx_engine_id = engine.mx_engine_id
            and engine.mx_object_id = 1
    left join redundancy redun  with(nolock) on               
            redun.primary_gobject_id = engine.gobject_id
    left join instance backup_engine  with(nolock) on                 
            backup_engine.gobject_id = redun.backup_gobject_id
    order by p.idx, 
            p.mx_primitive_id, 
            a.referring_mx_primitive_id,
            a.referring_mx_attribute_id,
            a.element_index  
 
end
go

