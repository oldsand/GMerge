/********************************************************************/
/*Object Name	:  internal_construct_table_from_file				    */
/*Object Type	:  Stored Proc.										*/
/*Purpose		:  to construct table from file						*/
/*Used By		:  CDI												*/
/********************************************************************/
CREATE   PROCEDURE dbo.internal_construct_table_from_file

@FileNameOfIds nvarchar (400),
@TableName nvarchar(100)
 AS
begin
	set nocount on


	SET QUOTED_IDENTIFIER OFF

	DECLARE @SQL nvarchar(2000)

	SET @SQL = 'BULK INSERT ' + @TableName + ' FROM ''' + @FileNameOfIds+ ''' WITH (FIELDTERMINATOR = '','', TABLOCK, DATAFILETYPE  = ''widechar'' ) '

	EXEC sp_executesql @SQL

	
end
go

