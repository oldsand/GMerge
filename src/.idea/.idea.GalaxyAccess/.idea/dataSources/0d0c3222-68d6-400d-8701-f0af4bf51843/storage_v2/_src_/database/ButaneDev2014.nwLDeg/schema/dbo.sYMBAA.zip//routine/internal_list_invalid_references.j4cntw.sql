/************************************************************************/
/*Object Name :  internal_list_invalid_references							*/
/*Object Type :  Stored Proc.											*/
/*Purpose	  :  Proc. to Provide the invalid attribute references list.*/
/*Used By	  :  CDI													*/
/************************************************************************/
CREATE PROCEDURE dbo.internal_list_invalid_references
@processedGObjectID int OUTPUT
 AS
BEGIN
SET NOCOUNT ON

DECLARE @upperGObjectID INT
DECLARE @lowerGObjectID INT
DECLARE @References TABLE(gobject_id int)
DECLARE @noOfReferencesToBind INT

SET @lowerGObjectID = 0
SET @upperGObjectID = 0
SET @noOfReferencesToBind = 0



-- Find the reference needs to bind
INSERT INTO @References
 SELECT distinct top 10 ar.gobject_id
 FROM  attribute_reference ar inner join gobject gobj 
	on ar.gobject_id = gobj.gobject_id 
   and gobj.checked_out_package_id = 0
 WHERE ar.gobject_id > @processedGObjectID
 AND ar.is_valid = 1

SELECT @noOfReferencesToBind = ISNULL(COUNT(*), 0)
FROM @References

-- If all references are binded, 
-- then set the proceesedGObjectID to max(gobject) + 1
IF @noOfReferencesToBind <= 0
BEGIN
	SELECT @processedGObjectID = ISNULL(MAX(gobject_id), 0) + 1
	FROM attribute_reference
END 

-- Get the lower gobject id whose references needs to bind.
-- Get the upper gobject id whose references needs to bind.
SELECT @lowerGObjectID = ISNULL(MIN(gobject_id), 0),
       @upperGObjectID = ISNULL(MAX(gobject_id), 0)
FROM @References ar

SELECT 
	ar.gobject_id,
	ar.package_id,
	ar.referring_mx_primitive_id,
	ar.referring_mx_attribute_id,
	ar.element_index,
	ar.reference_string,
	ar.context_string,
	ar.attribute_index, 
	ar.attr_res_status 
FROM attribute_reference ar,gobject gobj
WHERE ar.is_valid = 1 and ar.gobject_id = gobj.gobject_id 
and gobj.checked_out_package_id = 0
and ar.gobject_id >= (@lowerGObjectID) and 
ar.gobject_id <= (@upperGObjectID)
ORDER BY ar.gobject_id ASC


end
go

