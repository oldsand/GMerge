create proc dbo.internal_add_path
    @path nvarchar(1000),
    @folder_Type smallint 
As

    declare @folder_name_split table(folder_name int )
	declare @folder_name nvarchar(64), @pos int, @start int

	set @path = @path + '$'
    set @start = 0
	set @pos = charindex('$',@path)
    declare @parent_folder_id int
    declare @folder_id int
    set @parent_folder_id = 0     
    set @folder_id = 0     
	while @pos > 0
	begin
		set @folder_name = substring(@path, @start, @pos - @start)
		if @folder_name <> ''
		begin
            set @folder_id = 0
            select	@folder_id = folder_id from folder 
                        where folder_name = @folder_name
                        and parent_folder_id = @parent_folder_id
			and folder_type = @folder_Type 

            if(@folder_id <> 0)
            begin
                set @parent_folder_id = @folder_id
            end
            else                
            begin
                
                declare @errCode int
                set @errCode = 0

                exec @errCode = dbo.internal_add_folder 
                        @folder_Type,
                        @folder_name,
						'',	
                	    @parent_folder_id,
                    	@folder_id out

                if(@errCode <> 0)
                    return

                set @parent_folder_id = @folder_id 
            end
		end
        set @start = @pos+1
		set @pos = charindex('$', @path, @start)
	end
go

