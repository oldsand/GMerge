create procedure dbo.internal_update_visual_element_timestamp
@gobject_id int ,
@package_id int ,
@mx_primitive_id smallint ,
@visual_element_id int,
@change_type int
as
-- do not record "no change"
if @change_type = 0
		return
begin tran
	insert into visual_element_timestamp
	( 
		gobject_id,
		package_id,
		mx_primitive_id,
		visual_element_id,
		change_type
	)
	select 			
		@gobject_id,
		@package_id ,
		@mx_primitive_id,
		@visual_element_id,
		@change_type

	
	update galaxy 
	set max_visual_element_timestamp = cast(@@dbts as bigint)


commit

go

