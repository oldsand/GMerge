/*
This procedure verifies whether the host, area, container, security group associated with
the template / instance to be imported exist in the current database.
*/

create proc dbo.internal_check_objects_validity_for_import
@hostname nvarchar(32),
@areaname nvarchar(32),
@containername nvarchar(32)

as
begin
set nocount on
declare @temptable table
( 
	object_name nvarchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS, 
	object_type smallint, 
	bValid bit
)

insert into @temptable values( @hostname, 1, 0 )
insert into @temptable values( @areaname, 2, 0 )
insert into @temptable values( @containername, 3, 0 )

select template_definition.category_id, temp.object_type
from gobject gobject
right join @temptable temp
	on gobject.tag_name = temp.object_name
inner join template_definition template_definition
	on gobject.template_definition_id = template_definition.template_definition_id
where gobject.tag_name in ( @hostname, @areaname, @containername ) and gobject.namespace_id = 1 -- Automation Object

end
go

