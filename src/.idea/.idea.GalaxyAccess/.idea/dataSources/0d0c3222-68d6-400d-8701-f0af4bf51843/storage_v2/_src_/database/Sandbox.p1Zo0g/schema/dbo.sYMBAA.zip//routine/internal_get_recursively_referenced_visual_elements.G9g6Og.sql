/*

Returns a list of recursive visual elments referenced.

   Assumes that the following input and output tables are created prior to execution.
   The input table should contain the 'seed' references...
	create  table #input_table
   (
 	 visual_element_id int,
	 gobject_id int,
	 package_id int,
	 mx_primitive_id smallint,
	 visual_element_reference_index int	
	)

    create table  #output_table 
    (
        visual_element_id int,
        gobject_id int,
	    package_id int,
	    mx_primitive_id smallint,
		visual_element_reference_index int
    )


*/

create procedure dbo.internal_get_recursively_referenced_visual_elements
as    
begin tran

    
    declare @next_selection  table
    (
        visual_element_id int,
        gobject_id int,
	    package_id int,
	    mx_primitive_id smallint,
	    visual_element_reference_index int
    )



insert into @next_selection
select 
        visual_element_id,
        gobject_id,
        package_id,
		mx_primitive_id,
	    visual_element_reference_index
from
	#input_table
 
    while( 1 = 1 )
    begin   

        insert into @next_selection    

            select 
                bound_vev.visual_element_id, 
                vev.gobject_id, 
                vev.package_id,
				vev.mx_primitive_id,
                bver.visual_element_reference_index
            from  visual_element_version vev
            inner join #input_table ids on 
                vev.visual_element_id = ids.visual_element_id 
            inner join visual_element_reference bver  on 
                bver.gobject_id = vev.gobject_id
                and bver.package_id = vev.package_id
                and bver.mx_primitive_id = vev.mx_primitive_id
            inner join visual_element_version bound_vev on
                bver.checked_in_bound_visual_element_gobject_id = bound_vev.gobject_id and
                bver.checked_in_bound_visual_element_package_id = bound_vev.package_id and
                bver.checked_in_bound_visual_element_mx_primitive_id = bound_vev.mx_primitive_id
            where bound_vev.visual_element_id not in 
            (select visual_element_id from #output_table)

        --delete from @next_selection where dbo.IsPackageVisibleToUser( gobject_id, package_id, @user_guid ) = 0		
	    truncate table #input_table 		

        insert into #input_table(visual_element_id)
	        select visual_element_id from @next_selection 

	    insert into #output_table
	         select * from @next_selection 

         delete from @next_selection
 
        
    if(@@ROWCOUNT = 0)
      break
    end
	
	
commit

go

