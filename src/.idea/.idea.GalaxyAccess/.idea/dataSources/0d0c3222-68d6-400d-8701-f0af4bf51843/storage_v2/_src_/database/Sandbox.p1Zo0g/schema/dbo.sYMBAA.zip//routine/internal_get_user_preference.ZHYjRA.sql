
/**************************************************/
/*Object Name :  internal_getuserpreference									*/
/*Object Type :  Stored Proc.												*/
/*Purpose :    Procedure to get preference for given preference type & user	*/
/*Used By :    PackageServerNet												*/
/**************************************************/
create  proc dbo.internal_get_user_preference
@user_guid nvarchar(64),
@preference_type nvarchar(256)
as
begin

declare @user_profile_id int
set @user_profile_id = 0

select @user_profile_id = user_profile_id from
user_profile where user_guid = @user_guid

select preferences from user_preferences  
where user_profile_id = @user_profile_id
		and preference_type = @preference_type

end


go

