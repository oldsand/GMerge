
/***********************************************************************************************************************************
If you change this you need to check w/ Foxboro. This is used by Foxboro objects in their MigratePrimitive methods -- HF1467 CR93406
************************************************************************************************************************************/

/**************************************************
Object Name :  internal_get_gobject_id_from_tag_name2
Object Type :  Stored Proc. 
Purpose	    :  This procedure retrieves a gobject_id 
			   for a given namespace and tag_name.
**************************************************/

CREATE PROCEDURE dbo.internal_get_gobject_id_from_tag_name2
	@namespace_id smallint,
	@tag_name nvarchar(329),
	@gobject_d int  OUTPUT
AS
begin
SET NOCOUNT ON

select	@gobject_d = gobject_id 
from	gobject 
where	namespace_id = @namespace_id 
	and	tag_name = @tag_name 


end

go

