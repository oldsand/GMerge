---This stored procedure will return all the runtime files 
--required by the input packages
CREATE   PROC dbo.internal_get_runtime_files
    @FileNameOfIds nvarchar(400),
    @Location nvarchar(256),
    @RequireFileType int -- 1 All 0 -- Only Delta
as
set nocount on
begin
begin tran
	create table #file_ids( file_id int )
	create table #package_ids( package_id int )
	-- populate #package_ids	
	exec internal_get_package_ids_from_xml @FileNameOfIds
	exec internal_get_runtime_files_for_packages 
	insert into deployed_file
	(
		file_id,
		node_name,
		need_to_delete,
		is_package_deployed,
		is_editor_deployed,
		is_runtime_deployed,
        is_browser_deployed
	)
	select
		fi.file_id,
		UPPER(@Location),
		0,
		0,
		0,
		0,
        0
	from #file_ids fi
	where fi.file_id 
	not in 
	(select file_id from deployed_file where node_name = @Location)

	
	if( @RequireFileType = 1)
	begin
		select file_name, vendor_name, registration_type from file_table ft
		inner join #file_ids dfi
		on ft.file_id = dfi.file_id
	end
	else
	begin
		select file_name, vendor_name, registration_type 
		from file_table ft
		inner join #file_ids dfi
		on ft.file_id = dfi.file_id
		where dfi.file_id not in 
		(
			select file_id from deployed_file d where d.node_name = @Location
			and 	(d.is_editor_deployed = 1 
				or 
				d.is_package_deployed = 1 
				or
				d.is_runtime_deployed = 1)
		)		
	end	

	drop table #package_ids
	drop table #file_ids

commit tran
set nocount off
end
go

