create proc dbo.internal_update_ref_status
      @targetgobjectid  int,
      @packagestatus int,
      @srcgobjectid  int
as
begin tran
	
	declare @objectid table ( gobject_id int)
	
	insert into @objectid 
	select 
		distinct g.gobject_id 
	from 
	gobject g inner join attribute_reference ar 
	    on ar.gobject_id = g.gobject_id
	where ar.gobject_id <> @srcgobjectid and 
        ar.resolved_gobject_id = @srcgobjectid
	
	--select * from @objectid
	update package 
        set reference_status_id  = @packagestatus 
    from package 
	inner join gobject on package_id = gobject.checked_in_package_id
	inner join @objectid obj on obj.gobject_id = gobject.gobject_id
	
	update attribute_reference set is_valid = 1,resolved_mx_primitive_id=0 from attribute_reference ar
	where ar.resolved_gobject_id = @srcgobjectid and ar.gobject_id <> @srcgobjectid

	

commit

go

