-- Returns the required feature string form requiredFeatureobjID 
-- and the supported feature string for supportedFeatureObjID

CREATE    procedure dbo.internal_get_required_supported_feature_strings
    @requiredFeatureobjID  int,
    @supportedFeatureobjID  int,
    @requiredFeature  nvarchar(256)  OUTPUT,
    @supportedFeature nvarchar(256)  OUTPUT
as 
begin
	set @requiredFeature = (select required_features from internal_required_support_features  where gobject_id = @requiredFeatureobjID )
	set @supportedFeature = (select supported_features from internal_required_support_features  where gobject_id = @supportedFeatureobjID )
end
go

