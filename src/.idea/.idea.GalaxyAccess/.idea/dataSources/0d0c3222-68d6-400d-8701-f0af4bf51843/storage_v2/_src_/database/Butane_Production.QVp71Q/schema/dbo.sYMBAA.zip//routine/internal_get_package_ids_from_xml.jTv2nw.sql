-- populates temporary table #package_ids
-- from xml document @PackageIdsAsXml
-- where @PackageIdsAsXml is created
-- using XmlEncode() from cdi.cpp
/*
Usage:
    create table #package_ids( package_id int )
    exec internal_get_package_ids_from_xml.sql '
    <r>
        <package id=''8''/>
        <package id=''9''/>
    </r>
    '
    select * from #package_ids
    drop table #package_ids
*/
CREATE proc dbo.internal_get_package_ids_from_xml
    @FileNameOfIds nvarchar(400)
as
set nocount on
begin

create table #Temp_ids( package_id int )
-- call the stored procedure 'internal_construct_table_from_file'
EXEC internal_construct_table_from_file @FileNameOfIds, '#Temp_ids'

insert into #package_ids SELECT distinct * FROM #Temp_ids

DROP TABLE #Temp_ids

end

go

