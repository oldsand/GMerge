-- creates a new operation.
-- Returns operation_id which will be used to refer to 
-- newly created operation.
create procedure dbo.internal_create_new_operation
@operation_name nvarchar(300),
@user_profile_id int,
@operation_id int out
as

declare @new_operation_id int

insert into operation(
    operation_name,
    user_profile_id)
select  
    @operation_name,
    @user_profile_id

select @new_operation_id = @@identity

/*
Use this code when operation serialization is implemented.- Anand
insert into async_operation_data(
    operation_id,
    input_data
    )
select 
    @new_operation_id,
    @input_data
*/
-- add a row in the status table to indicate that
-- this operation is queued...
insert into operation_status
select @new_operation_id, 1

set @operation_id = @new_operation_id

go

