/**********************************************************************/
/*Object Name :  internal_Reference									  */
/*Object Type :  Stored Procedure.									  */
/*Purpose	  :  To provide reference information for a given		  */
/*               gobject                                              */
/*Used By	  :  CDI												  */
/**********************************************************************/
CREATE PROCEDURE dbo.internal_list_object_reference
    @gobjectId int,
    @user_guid uniqueidentifier
 AS
begin

select distinct
  referringGobjectID,
  case when referringPrimitiveName <> '' then
     referringPrimitiveName + '.' + referringAttributeName
  else
     referringAttributeName
  end
  as referringAttributeName,
-- fix for CR L00087087
  IRPA.reference_string,  
  IRPA.context_string,  
  referredToGobjectID,  
  referredAttribute_full_name  

-- from   
--     internal_reference_primitive_attribute   
-- where   
--    referringGobjectID = @gobjectId 

	from   
		internal_reference_primitive_attribute IRPA  join 
		attribute_reference AR  on IRPA.referringGobjectID = AR.gobject_id
		and AR.reference_string = IRPA.reference_string
	where 
		IRPA.referringGobjectID = @gobjectId
		and (AR.is_valid = 0 or referredToGobjectID = 0)

end
go

